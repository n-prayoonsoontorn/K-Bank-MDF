-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_hris_staff_accnt_vw.sql
# Area: hris
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-19    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_HRIS.HRIS_STAFF_ACCNT_VW
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_hris.hris_staff_accnt_vw (
	pos_dt      	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	rectype     	smallint      comment "Type of record, this will be detail",
	compcode    	string        comment "Def(En): Company Code",
	accountno   	string        comment "Def(En): K-Companies staff payroll account",
	accnt_status	string        comment "Def(En):Employee status code (HR Status)",
	stampdt     	date          comment "Def(En): Last update date",
	officer_cd  	string        comment "Def(En): Officer CD",
	load_tms    	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id  	string        comment "Source system ID",
	ptn_yyyy    	string        comment "Partition field - year",
	ptn_mm      	string        comment "Partition field - month",
	ptn_dd      	string        comment "Partition field - day",
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_hris/hris_staff_accnt_vw' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);