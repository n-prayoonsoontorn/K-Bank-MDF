-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_lpm_as400_lmt_ar_inf_bfr_wrtof.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-19    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_LMT_AR_INF_BFR_WRTOF
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_lmt_ar_inf_bfr_wrtof (
	pos_dt                  	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	lmd23400_cust_no        	bigint        comment "เลขที่ลูกหนี้ LPM",
	lmd23400_acct_type      	smallint      comment "ประเภทเครดิต",
	lmd23400_acct_no        	string        comment "หมายเลขบัญชี",
	lmd23400_acct_type_sub  	string        comment "ประเภท Product ระดับ SUB หรือ เลขที่บัญชีระดับ SUB",
	lmd23400_cust_no_tr     	string        comment "เลขที่ลูกค้า Trade",
	lmd23400_sub_tr         	string        comment "ลำดับวงเงินของ Trade",
	lmd23400_fics_acct_no   	string        comment "ประเภทหัวบัญชี",
	lmd23400_br_no          	smallint      comment "สาขา",
	lmd23400_acct_flag      	string        comment "0 = บัญชีปิดแล้ว
1 = บัญชียังไม่ปิด",
	lmd23400_fg_pod         	string        comment "Flag POD เพื่อใช้แยกกรณีมี Acct-type = 2
0 = ไม่เป็น POD
1 = เป็น POD",
	lmd23400_limit_sub      	decimal       comment "วงเงินอนุมัติ (ระดับ ACCT-TYPE-SUB)",
	lmd23400_limit_port     	decimal       comment "วงเงินอนุมัติ (ระดับ ACCT-TYPE-SUB)
ที่หักยอดที่ซ้ำออกแล้ว
สามารถนำมารวมได้เป็นวงเงินภาระผูกพันทั้ง Port ของธนาคาร",
	lmd23400_used_limit     	decimal       comment "วงเงินที่ใช้ไปแล้ว",
	lmd23400_principle      	decimal       comment "เงินต้น",
	lmd23400_accru          	decimal       comment "ดอกเบี้ย",
	lmd23400_memo           	decimal       comment "ดอกเบี้ยนอกการ์ด",
	lmd23400_due_date1      	integer       comment "วันที่เริ่มสัญญา  1",
	lmd23400_cont_date1     	integer       comment "วันที่ครบกำหนดสัญญา  1",
	lmd23400_due_date2      	integer       comment "วันที่เริ่มสัญญา  2",
	lmd23400_cont_date2     	integer       comment "วันที่ครบกำหนดสัญญา  2",
	lmd23400_due_date3      	integer       comment "วันที่เริ่มสัญญา  3",
	lmd23400_cont_date3     	integer       comment "วันที่ครบกำหนดสัญญา  3",
	lmd23400_due_date4      	integer       comment "วันที่เริ่มสัญญา  4",
	lmd23400_cont_date4     	integer       comment "วันที่ครบกำหนดสัญญา  4",
	lmd23400_due_date5      	integer       comment "วันที่เริ่มสัญญา  5",
	lmd23400_cont_date5     	integer       comment "วันที่ครบกำหนดสัญญา  5",
	lmd23400_due_date6      	integer       comment "วันที่เริ่มสัญญา  6",
	lmd23400_cont_date6     	integer       comment "วันที่ครบกำหนดสัญญา  6",
	lmd23400_due_date7      	integer       comment "วันที่เริ่มสัญญา  7",
	lmd23400_cont_date7     	integer       comment "วันที่ครบกำหนดสัญญา  7",
	lmd23400_block_code     	string        comment "รหัสการติด Code",
	lmd23400_cancel_flag    	string        comment "รหัสการ Cancel",
	lmd23400_fg_limit_used3 	smallint      comment "Flag ของ Aval/Acceptance",
	lmd23400_limit_no       	integer       comment "ลำดับที่ของวงเงิน",
	lmd23400_jl_id          	bigint        comment "เลขที่ของ Joint limit",
	lmd23400_dummy_acct_fg  	string        comment "Flag ว่าเป็น Dummy",
	lmd23400_debit_amt      	decimal       comment "ยอดที่เบิกใช้ เฉพาะ Loan",
	lmd23400_product_type   	string        comment "ประเภท Product ของวงเงิน",
	lmd23400_product_limit  	decimal       comment "วงเงินระดับ Product
วงเงินระดับ Product ที่ระบบ Trade ใช้ควบคุมการใช้ (ซึ่งรวมกันหลาย Product อาจจะเกินวงเงินระดับลูกค้า)",
	lmd23400_unuse_limit    	decimal       comment "วงเงินที่ใช้คำนวณวงเงินคงเหลือ Unuse Limit (ระดับ ACCT-TYPE-SUB)",
	lmd23400_group_id       	string        comment "เลขที่กลุ่มลูกค้า Trade",
	lmd23400_group_cust-no  	bigint        comment "เลขที่กลุ่มลูกค้า LPM",
	lmd23400_group_limit    	decimal       comment "วงเงินระดับกลุ่มลูกค้า ที่ได้รับอนุมัติ",
	lmd23400_limit_flag     	smallint      comment "การนับวงเงินว่าอนุญาตให้ใช้หรือไม่ให้ใช้วงเงิน
0 = NAL (Disabled)
1 = Normal customer (Enabled)
(เพราะมีบางกรณี หยุดคิดดอกเบี้ย แต่ยังอนุญาตให้ใช้วงเงินเป็นกรณีพิเศษ)",
	lmd23400_legal_entity   	smallint      comment "รหัสบริษัท",
	lmd23400_resp_center    	smallint      comment "รหัสสังกัด",
	lmd23400_gl_account     	integer       comment "รหัสบัญชีประเภทเครดิต",
	lmd23400_function       	smallint      comment "รหัสฟังก์ชันงาน",
	lmd23400_line_business  	smallint      comment "รหัสประเภทธุรกิจ",
	lmd23400_gl_product_code	integer       comment "รหัสผลิตภัณฑ์สำหรับการบันทึกบัญชี",
	lmd23400_inter_company  	smallint      comment "รหัสบริษัทในการหักค่าใช้จ่ายระหว่างบริษัทในเครือ",
	lmd23400_intra_company  	smallint      comment "รหัสบริษัทในการหักค่าใช้จ่ายระหว่างฝ่ายงาน",
	lmd23400_project        	smallint      comment "รหัสโครงการ",
	lmd23400_gl_filler1     	integer       comment "สำหรับใช้ในอนาคต",
	lmd23400_gl_filler2     	smallint      comment "สำหรับใช้ในอนาคต",
	lmd23400_product_code   	integer       comment "รหัสผลิตภัณฑ์",
	load_tms                	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id              	string        comment "Source system ID",
	ptn_yyyy                	string        comment "Partition field - year",
	ptn_mm                  	string        comment "Partition field - month",
	ptn_dd                  	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_lmt_ar_inf_bfr_wrtof' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);