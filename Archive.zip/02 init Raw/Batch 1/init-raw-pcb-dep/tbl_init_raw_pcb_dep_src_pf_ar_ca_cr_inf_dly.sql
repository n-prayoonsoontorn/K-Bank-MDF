-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_pcb_dep_src_pf_ar_ca_cr_inf_dly.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-19    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_PCB_DEP.PCB_DEP_SRC_PF_AR_CA_CR_INF_DLY
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_pcb_dep.pcb_dep_src_pf_ar_ca_cr_inf_dly (
	pos_dt             	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	rec_type           	string        comment "Record Type - This is to indicate the body record type (Detail record)",
	header3            	string        ,
	accountnumber      	string        ,
	reverseflag        	string        ,
	reversedate        	timestamp     ,
	delinquencyday     	string        ,
	delinquencydate    	timestamp     ,
	penaltyrttype      	string        ,
	penaltyrtsign      	string        ,
	penaltyrtspread    	string        ,
	maxrttype          	string        ,
	maxrtsign          	string        ,
	maxrtspread        	string        ,
	actualintamtinmonth	string        ,
	clearingamt        	string        ,
	legalentity        	string        ,
	responsibilitycode 	string        ,
	function           	string        ,
	linebusiness       	string        ,
	intercompany       	string        ,
	intracompany       	string        ,
	project            	string        ,
	load_tms           	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id         	string        comment "Source system ID",
	ptn_yyyy           	string        comment "Partition field - year",
	ptn_mm             	string        comment "Partition field - month",
	ptn_dd             	string        comment "Partition field - day",
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_pcb_dep/pcb_dep_src_pf_ar_ca_cr_inf_dly' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);