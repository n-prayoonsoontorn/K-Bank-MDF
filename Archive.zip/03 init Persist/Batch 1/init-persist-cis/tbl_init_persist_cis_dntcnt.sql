-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_cis_dntcnt.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-19    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CIS.CIS_DNTCNT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cis.cis_dntcnt (
	pos_dt           	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	method           	string        comment "Description (Eng): Ingestion Method
Description (Thai): วิธีการนำเข้า",
	dntcnt_ip_id     	integer       comment "Description (Eng): Customer id
Description (Thai): เลขที่ลูกค้า",
	dntcnt_cnt_chnnl 	string        comment "Description (Eng): Contact Channel
Description (Thai): ช่องทางสำหรับติดต่อลูกค้า",
	dntcnt_prd_domain	string        comment "Description (Eng): Product Domain
Description (Thai): Domain ของผลิตภัณฑ์",
	dntcnt_purpose   	string        comment "Description (Eng): Contact Purpose
Description (Thai): วัตถุประสงค์ในการติดต่อ",
	dntcnt_mark_user 	string        comment "Description (Eng): User id
Description (Thai): รหัสผู้ทำรายการ do not contact",
	dntcnt_mark_dt   	timestamp     comment "Description (Eng): Update date time
Description (Thai): วันและเวลาที่ทำรายการ do not contact",
	dntcnt_user_id   	string        comment "Description (Eng): User id
Description (Thai): รหัสผู้ทำรายการ",
	dntcnt_upd_dt    	timestamp     comment "Description (Eng): Update date time
Description (Thai): วันและเวลาที่ทำรายการ",
	load_tms         	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id       	string        comment "Source system ID",
	ptn_yyyy         	string        comment "Partition field - year",
	ptn_mm           	string        comment "Partition field - month",
	ptn_dd           	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cis/cis_dntcnt' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);