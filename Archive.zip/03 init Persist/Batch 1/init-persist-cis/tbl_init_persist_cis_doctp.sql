-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_cis_doctp.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-19    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CIS.CIS_DOCTP
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cis.cis_doctp (
	pos_dt          	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	doctp_cd        	string        comment "Description (Eng): Document Type code
Description (Thai): รหัสประเภทเอกสาร",
	doctp_local_desc	string        comment "Description (Eng): Document Type description in Local language
Description (Thai): คำอธิบายประเภทเอกสาร ภาษาท้องถิ่น",
	doctp_en_desc   	string        comment "Description (Eng): Document Type description in English
Description (Thai): คำอธิบายประเภทเอกสาร ภาษาอังกฤษ",
	doctp_user_id   	string        comment "Description (Eng): User id
Description (Thai): รหัสผู้ทำรายการ",
	doctp_upd_dt    	timestamp     comment "Description (Eng): Update date time
Description (Thai): วันและเวลาที่ทำรายการ",
	load_tms        	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id      	string        comment "Source system ID",
	ptn_yyyy        	string        comment "Partition field - year",
	ptn_mm          	string        comment "Partition field - month",
	ptn_dd          	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cis/cis_doctp' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);