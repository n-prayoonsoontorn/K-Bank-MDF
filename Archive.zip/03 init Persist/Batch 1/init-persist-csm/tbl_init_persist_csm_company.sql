-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_csm_company.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CSM.CSM_COMPANY
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_csm.csm_company (
	pos_dt                  	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	company_cd              	smallint     comment "Description (Eng): Company Code
Description (Thai): รหัสของ Company",
	company_th_full_name    	string       comment "Description (Eng):Company Thai fullname
Description (Thai):ชื่อบริษัทภาษาไทยแบบเต็ม",
	company_th_abbr_name    	string       comment "Description (Eng):Company Thai abreviate
Description (Thai):ชื่อบริษัทภาษาไทยแบบย่อ",
	company_en_full_name    	string       comment "Description (Eng):Company English fullname
Description (Thai):ชื่อบริษัทภาษาอังกฤษแบบเต็ม",
	company_en_abbr_name    	string       comment "Description (Eng):Company English abreviate
Description (Thai):ชื่อบริษัทภาษาอังกฤษแบบย่อ",
	company_display_priority	smallint     comment "Description (Eng):Company display prioryty
Description (Thai):ลำดับการแสดงผลเพื่อขอ consent",
	company_controller_flag 	string       comment "Description (Eng):Controller flag
Description (Thai):สถานะของของบริษัทว่าสามารถเก็บค่า consent ของลูกค้าได้หรือไม่",
	company_status          	string       comment "Description (Eng):Company status
Description (Thai):สถานะของ company",
	company_upd_user        	string       comment "Description (Eng):Update by UserID
Description (Thai):user ที่แก้ไขข้อมูล",
	company_upd_dt          	timestamp    comment "Description (Eng):Update date
Description (Thai):วันที่อัพเดทข้อมูล",
	load_tms                	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id              	string       comment "Source system ID",
	ptn_yyyy                	string       comment "Partition field - year",
	ptn_mm                  	string       comment "Partition field - month",
	ptn_dd                  	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_csm/csm_company' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);