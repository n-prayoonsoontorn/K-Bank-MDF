-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_are_share_bdw2p_arexp_edw_ar4d0001.sql
# Area: are
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-22         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_are.are_share_bdw2p_arexp_edw_ar4d0001
#--------------------------------------------------------------------------------------------------*/



-- COMMAND ----------
    
alter table ${catalog}.persist_are.are_share_bdw2p_arexp_edw_ar4d0001 set tags ('rbac_table_are');


-- COMMAND ----------
            
alter table ${catalog}.persist_are.are_share_bdw2p_arexp_edw_ar4d0001 alter column arrangementid set tags ('rbac_rde_account_number');

