-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_v_are_coa_acct_ca_prfl.sql
# Area: are
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-22         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_are_view.v_are_coa_acct_ca_prfl
#--------------------------------------------------------------------------------------------------*/



-- COMMAND ----------

alter table ${catalog}.persist_are_view.v_are_coa_acct_ca_prfl set tags ('rbac_table_are');


-- COMMAND ----------

alter table ${catalog}.persist_are_view.v_are_coa_acct_ca_prfl alter column acct_num set tags ('rbac_rde_account_number');

