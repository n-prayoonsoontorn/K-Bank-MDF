-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_lpm_as400_ln_cntg_clss_prvn_bfr_wrtof.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-04    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_LN_CNTG_CLSS_PRVN_BFR_WRTOF
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_ln_cntg_clss_prvn_bfr_wrtof (
	pos_dt                    	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	l01w910_cust_no           	string       comment "Def(En):
Def(Th):",
	l01w910_acct_type         	string       comment "Def(En):
Def(Th):",
	l01w910_acct_no           	string       comment "Def(En):
Def(Th):",
	l01w910_cr_type           	string       comment "Def(En):
Def(Th):",
	l01w910_fics_type         	string       comment "Def(En):
Def(Th):",
	l01w910_acct_cust_type    	string       comment "Def(En):
Def(Th):",
	l01w910_staff_flag        	string       comment "Def(En):
Def(Th):",
	l01w910_close_date        	string       comment "Def(En):
Def(Th):",
	l01w910_npl_date          	string       comment "Def(En):
Def(Th):",
	l01w910_bus_code          	string       comment "Def(En):
Def(Th):",
	l01w910_bus_bot           	string       comment "Def(En):
Def(Th):",
	l01w910_bus_group         	string       comment "Def(En):
Def(Th):",
	l01w910_bus_grp_seq       	string       comment "Def(En):
Def(Th):",
	l01w910_branch_no         	string       comment "Def(En):
Def(Th):",
	l01w910_dept_no           	string       comment "Def(En):
Def(Th):",
	l01w910_prv_int_fg        	string       comment "Def(En):
Def(Th):",
	l01w910_prv_stop_date     	string       comment "Def(En):
Def(Th):",
	l01w910_acct_group        	string       comment "Def(En):
Def(Th):",
	l01w910_prv_day_diff      	string       comment "Def(En):
Def(Th):",
	l01w910_class_level       	string       comment "Def(En):
Def(Th):",
	l01w910_class_from        	string       comment "Def(En):
Def(Th):",
	l01w910_class_reason      	string       comment "Def(En):
Def(Th):",
	l01w910_acct_res_group    	string       comment "Def(En):
Def(Th):",
	l01w910_acct_npl_group    	string       comment "Def(En):
Def(Th):",
	l01w910_r_prv_outs        	string       comment "Def(En):
Def(Th):",
	l01w910_prv_outs          	string       comment "Def(En):
Def(Th):",
	l01w910_prv_accru         	string       comment "Def(En):
Def(Th):",
	l01w910_limit             	string       comment "Def(En):
Def(Th):",
	l01w910_npl_outs          	string       comment "Def(En):
Def(Th):",
	l01w910_npl_accru         	string       comment "Def(En):
Def(Th):",
	l01w910_prv_pay           	string       comment "Def(En):
Def(Th):",
	l01w910_prv_ext_pay       	string       comment "Def(En):
Def(Th):",
	l01w910_enter_date        	string       comment "Def(En):
Def(Th):",
	l01w910_cr_bot            	string       comment "Def(En):
Def(Th):",
	l01w910_src_br            	string       comment "Def(En):
Def(Th):",
	l01w910_src_br_seq        	string       comment "Def(En):
Def(Th):",
	l01w910_area_code         	string       comment "Def(En):
Def(Th):",
	l01w910_reg_code          	string       comment "Def(En):
Def(Th):",
	l01w910_zone_code         	string       comment "Def(En):
Def(Th):",
	l01w910_div_code          	string       comment "Def(En):
Def(Th):",
	l01w910_acct_res_group_old	string       comment "Def(En):
Def(Th):",
	l01w910_center_branch     	string       comment "Def(En):
Def(Th):",
	l01w910_currency          	string       comment "Def(En):
Def(Th):",
	l01w910_bef_outs          	string       comment "Def(En):
Def(Th):",
	l01w910_bef_accru         	string       comment "Def(En):
Def(Th):",
	l01w910_wrt_bot_flag      	string       comment "Def(En):
Def(Th):",
	l01w910_wrt_tfb_flag      	string       comment "Def(En):
Def(Th):",
	l01w910_rec_flag          	string       comment "Def(En):
Def(Th):",
	l01w910_prv_reverse_flag  	string       comment "Def(En):
Def(Th):",
	l01w910_prv_reverse_date  	string       comment "Def(En):
Def(Th):",
	l01w910_prv_reverse_accru 	string       comment "Def(En):
Def(Th):",
	l01w910_prv_memo_accru    	string       comment "Def(En):
Def(Th):",
	l01w910_class_date        	string       comment "Def(En):
Def(Th):",
	l01w910_dr_memo_flag      	string       comment "Def(En):
Def(Th):",
	l01w910_cls_day_diff      	string       comment "Def(En):
Def(Th):",
	l01w910_npl_day_diff      	string       comment "Def(En):
Def(Th):",
	l01w910_bot_acct_group    	string       comment "Def(En):
Def(Th):",
	l01w910_acct_coll_res     	string       comment "Def(En):
Def(Th):",
	l01w910_acct_res_outs     	string       comment "Def(En):
Def(Th):",
	l01w910_acct_b_coll_res   	string       comment "Def(En):
Def(Th):",
	l01w910_acct_b_res_outs   	string       comment "Def(En):
Def(Th):",
	l01w910_rec_type          	string       comment "Def(En):
Def(Th):",
	l01w910_acct_res_outs_5   	string       comment "Def(En):
Def(Th):",
	l01w910_acct_npv_prov     	string       comment "Def(En):
Def(Th):",
	l01w910_acct_cushion      	string       comment "Def(En):
Def(Th):",
	l01w910_bef_reverse_accru 	string       comment "Def(En):
Def(Th):",
	l01w910_bef_memo_accru    	string       comment "Def(En):
Def(Th):",
	l01w910_acct_coll_res_kb  	string       comment "Def(En):
Def(Th):",
	l01w910_acct_res_outs_kb  	string       comment "Def(En):
Def(Th):",
	l01w910_acct_res_outs_5_kb	string       comment "Def(En):
Def(Th):",
	l01w910_acct_npv_prov_kb  	string       comment "Def(En):
Def(Th):",
	l01w910_provision_basel   	string       comment "Def(En):
Def(Th):",
	l01w910_legal_entity      	string       comment "Def(En):
Def(Th):",
	l01w910_resp_center       	string       comment "Def(En):
Def(Th):",
	l01w910_gl_account        	string       comment "Def(En):
Def(Th):",
	l01w910_function          	string       comment "Def(En):
Def(Th):",
	l01w910_line_business     	string       comment "Def(En):
Def(Th):",
	l01w910_gl_product_code   	string       comment "Def(En):
Def(Th):",
	l01w910_inter_company     	string       comment "Def(En):
Def(Th):",
	l01w910_intra_company     	string       comment "Def(En):
Def(Th):",
	l01w910_project           	string       comment "Def(En):
Def(Th):",
	l01w910_gl_filler1        	string       comment "Def(En):
Def(Th):",
	l01w910_gl_filler2        	string       comment "Def(En):
Def(Th):",
	l01w910_product_code      	string       comment "Def(En):
Def(Th):",
	l01w910_filler            	string       comment "Def(En):
Def(Th):",
	load_tms                  	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_ln_cntg_clss_prvn_bfr_wrtof' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);