-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cis_ip.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-04    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CIS.CIS_IP
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cis.cis_ip (
	pos_dt         	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	method         	string       comment "Def(En): Ingestion Method
Def(Th): วิธีการนำเข้า",
	ip_id          	integer      comment "Def(En): Customer id
Def(Th): เลขที่ลูกค้า",
	ip_indx_id     	integer      comment "Def(En): Main Customer id
Def(Th): เลขที่ลูกค้าหลักจากการ Merge",
	ip_doc_tp      	string       comment "Def(En): Document Type code
Def(Th): รหัสประเภทเอกสารสำคัญ",
	ip_doc_id      	string       comment "Def(En): Identification no. or Registration no.
Def(Th): เลขที่เอกสารสำคัญ หรือ เลขที่จดทะเบียน",
	ip_birth_dt    	date         comment "Def(En): Birth date or Registration date
Def(Th): วันเกิด หรือ วันที่จดทะเบียน",
	ip_doc_dept    	string       comment "Def(En): Document issuer department
Def(Th): หน่วยงานที่ออกเอกสารสำคัญ",
	ip_doc_iss_dt  	date         comment "Def(En): Document issue date
Def(Th): วันที่ออกเอกสารสำคัญ",
	ip_doc_exp_dt  	date         comment "Def(En): Document expire date
Def(Th): วันที่เอกสารสำคัญหมดอายุ",
	ip_cust_grp    	string       comment "Def(En): Customer Group code
Def(Th): รหัสกลุ่มลูกค้า",
	ip_cust_val    	string       comment "Def(En): Customer Validation code
Def(Th): รหัสการตรวจสอบข้อมูลลูกค้า",
	ip_cust_prvn   	string       comment "Def(En): Customer Creation code
Def(Th): รหัสการสร้างลูกค้า",
	ip_cust_tp     	string       comment "Def(En): Customer Type code
Def(Th): รหัสประเภทลูกค้า",
	ip_local_title 	string       comment "Def(En): Title in Local language
Def(Th): คำนำหน้าชื่อ ภาษาท้องถิ่น",
	ip_local_nm    	string       comment "Def(En): Name in Local language
Def(Th): ชื่อ ภาษาท้องถิ่น",
	ip_local_surnm 	string       comment "Def(En): Surname in Local language
Def(Th): นามสกุล ภาษาท้องถิ่น",
	ip_local_mid_nm	string       comment "Def(En): Middle Name in Local language
Def(Th): ชื่อกลาง ภาษาท้องถิ่น",
	ip_en_title    	string       comment "Def(En): Title in English
Def(Th): คำนำหน้าชื่อ ภาษาอังกฤษ",
	ip_en_nm       	string       comment "Def(En): Name in English
Def(Th): ชื่อ ภาษาอังกฤษ",
	ip_en_surnm    	string       comment "Def(En): Surname in English
Def(Th): นามสกุล ภาษาอังกฤษ",
	ip_en_mid_nm   	string       comment "Def(En): Middle Name in English
Def(Th): ชื่อกลาง ภาษาอังกฤษ",
	ip_br_no       	string       comment "Def(En): Customer created Branch no.
Def(Th): รหัสสาขาที่สร้างลูกค้า",
	ip_kyc_br_no   	string       comment "Def(En): KYC Take Care Branch no.
Def(Th): รหัสสาขาที่เปิดบัญชีล่าสุด",
	ip_bus_cd      	string       comment "Def(En): KBank Business Type code
Def(Th): รหัสประเภทธุรกิจหลักกสิกรไทย",
	ip_no_emp      	integer      comment "Def(En): No. of employee
Def(Th): จำนวนลูกจ้างกรณ๊เป็นเจ้าของกิจการ",
	ip_asst_exc_ld 	decimal(17,2) comment "Def(En): Asset exclude land
Def(Th): มูลค่าทรัพย์สินไม่รวมที่ดิน",
	ip_majorsrc_inc	string       comment "Def(En): Major Source of income
Def(Th): รหัสประเทศที่มาของรายได้",
	ip_chg_nm_flg  	string       comment "Def(En): Change Name flag
Def(Th): Flag ของการเปลี่ยนชื่อ-นามสกุล",
	ip_open_dt     	date         comment "Def(En): Customer Create date
Def(Th): วันที่สร้างลูกค้าเข้าระบบ",
	ip_close_dt    	date         comment "Def(En): Customer (logical) Delete date
Def(Th): วันที่ลบลูกค้าออกจากระบบ",
	ip_merge_stat  	string       comment "Def(En): Customer Merge Status
Def(Th): รหัสสถานะการยุบรวมลูกค้า",
	ip_merge_dt    	date         comment "Def(En): Customer Merge date
Def(Th): วันที่ยุบรวมลูกค้า",
	ip_cust_stat   	string       comment "Def(En): Customer status code
Def(Th): รหัสสถานะลูกค้า",
	ip_user_id     	string       comment "Def(En): User id
Def(Th): รหัสผู้ทำรายการ",
	ip_upd_dt      	timestamp    comment "Def(En): Update date time
Def(Th): วันและเวลาที่ทำรายการ",
	load_tms       	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id     	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy       	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm         	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd         	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cis/cis_ip' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);