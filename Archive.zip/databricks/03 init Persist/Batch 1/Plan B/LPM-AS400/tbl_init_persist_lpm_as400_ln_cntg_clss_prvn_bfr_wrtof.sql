-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_lpm_as400_ln_cntg_clss_prvn_bfr_wrtof.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-04    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_LPM_AS400.LPM_AS400_LN_CNTG_CLSS_PRVN_BFR_WRTOF
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_lpm_as400.lpm_as400_ln_cntg_clss_prvn_bfr_wrtof (
	pos_dt                    	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	l01w910_cust_no           	integer      comment "Def(En):
Def(Th):",
	l01w910_acct_type         	integer      comment "Def(En):
Def(Th):",
	l01w910_acct_no           	string       comment "Def(En):
Def(Th):",
	l01w910_cr_type           	integer      comment "Def(En):
Def(Th):",
	l01w910_fics_type         	integer      comment "Def(En):
Def(Th):",
	l01w910_acct_cust_type    	integer      comment "Def(En):
Def(Th):",
	l01w910_staff_flag        	integer      comment "Def(En):
Def(Th):",
	l01w910_close_date        	integer      comment "Def(En):
Def(Th):",
	l01w910_npl_date          	integer      comment "Def(En):
Def(Th):",
	l01w910_bus_code          	integer      comment "Def(En):
Def(Th):",
	l01w910_bus_bot           	integer      comment "Def(En):
Def(Th):",
	l01w910_bus_group         	integer      comment "Def(En):
Def(Th):",
	l01w910_bus_grp_seq       	integer      comment "Def(En):
Def(Th):",
	l01w910_branch_no         	integer      comment "Def(En):
Def(Th):",
	l01w910_dept_no           	integer      comment "Def(En):
Def(Th):",
	l01w910_prv_int_fg        	integer      comment "Def(En):
Def(Th):",
	l01w910_prv_stop_date     	integer      comment "Def(En):
Def(Th):",
	l01w910_acct_group        	integer      comment "Def(En):
Def(Th):",
	l01w910_prv_day_diff      	integer      comment "Def(En):
Def(Th):",
	l01w910_class_level       	integer      comment "Def(En):
Def(Th):",
	l01w910_class_from        	integer      comment "Def(En):
Def(Th):",
	l01w910_class_reason      	integer      comment "Def(En):
Def(Th):",
	l01w910_acct_res_group    	integer      comment "Def(En):
Def(Th):",
	l01w910_acct_npl_group    	integer      comment "Def(En):
Def(Th):",
	l01w910_r_prv_outs        	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_prv_outs          	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_prv_accru         	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_limit             	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_npl_outs          	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_npl_accru         	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_prv_pay           	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_prv_ext_pay       	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_enter_date        	integer      comment "Def(En):
Def(Th):",
	l01w910_cr_bot            	integer      comment "Def(En):
Def(Th):",
	l01w910_src_br            	integer      comment "Def(En):
Def(Th):",
	l01w910_src_br_seq        	integer      comment "Def(En):
Def(Th):",
	l01w910_area_code         	integer      comment "Def(En):
Def(Th):",
	l01w910_reg_code          	integer      comment "Def(En):
Def(Th):",
	l01w910_zone_code         	integer      comment "Def(En):
Def(Th):",
	l01w910_div_code          	integer      comment "Def(En):
Def(Th):",
	l01w910_acct_res_group_old	integer      comment "Def(En):
Def(Th):",
	l01w910_center_branch     	integer      comment "Def(En):
Def(Th):",
	l01w910_currency          	integer      comment "Def(En):
Def(Th):",
	l01w910_bef_outs          	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_bef_accru         	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_wrt_bot_flag      	integer      comment "Def(En):
Def(Th):",
	l01w910_wrt_tfb_flag      	integer      comment "Def(En):
Def(Th):",
	l01w910_rec_flag          	integer      comment "Def(En):
Def(Th):",
	l01w910_prv_reverse_flag  	integer      comment "Def(En):
Def(Th):",
	l01w910_prv_reverse_date  	integer      comment "Def(En):
Def(Th):",
	l01w910_prv_reverse_accru 	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_prv_memo_accru    	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_class_date        	integer      comment "Def(En):
Def(Th):",
	l01w910_dr_memo_flag      	integer      comment "Def(En):
Def(Th):",
	l01w910_cls_day_diff      	integer      comment "Def(En):
Def(Th):",
	l01w910_npl_day_diff      	integer      comment "Def(En):
Def(Th):",
	l01w910_bot_acct_group    	integer      comment "Def(En):
Def(Th):",
	l01w910_acct_coll_res     	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_acct_res_outs     	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_acct_b_coll_res   	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_acct_b_res_outs   	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_rec_type          	integer      comment "Def(En):
Def(Th):",
	l01w910_acct_res_outs_5   	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_acct_npv_prov     	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_acct_cushion      	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_bef_reverse_accru 	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_bef_memo_accru    	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_acct_coll_res_kb  	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_acct_res_outs_kb  	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_acct_res_outs_5_kb	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_acct_npv_prov_kb  	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_provision_basel   	decimal(13,2) comment "Def(En):
Def(Th):",
	l01w910_legal_entity      	integer      comment "Def(En):
Def(Th):",
	l01w910_resp_center       	integer      comment "Def(En):
Def(Th):",
	l01w910_gl_account        	integer      comment "Def(En):
Def(Th):",
	l01w910_function          	integer      comment "Def(En):
Def(Th):",
	l01w910_line_business     	integer      comment "Def(En):
Def(Th):",
	l01w910_gl_product_code   	integer      comment "Def(En):
Def(Th):",
	l01w910_inter_company     	integer      comment "Def(En):
Def(Th):",
	l01w910_intra_company     	integer      comment "Def(En):
Def(Th):",
	l01w910_project           	integer      comment "Def(En):
Def(Th):",
	l01w910_gl_filler1        	integer      comment "Def(En):
Def(Th):",
	l01w910_gl_filler2        	integer      comment "Def(En):
Def(Th):",
	l01w910_product_code      	integer      comment "Def(En):
Def(Th):",
	l01w910_filler            	string       comment "Def(En):
Def(Th):",
	load_tms                  	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_lpm_as400/lpm_as400_ln_cntg_clss_prvn_bfr_wrtof' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);