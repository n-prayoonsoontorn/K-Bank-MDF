-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_fcl_common_account_info.sql
# Area: fcl
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-22         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_fcl.fcl_common_account_info
#--------------------------------------------------------------------------------------------------*/



-- COMMAND ----------
    
alter table ${catalog}.persist_fcl.fcl_common_account_info set tags ('rbac_table_fcl');


-- COMMAND ----------
            
alter table ${catalog}.persist_fcl.fcl_common_account_info alter column ac_ar_id set tags ('rbac_rde_account_number');


-- COMMAND ----------
            
alter table ${catalog}.persist_fcl.fcl_common_account_info alter column prfl_ac_ar_id set tags ('rbac_rde_account_number');


-- COMMAND ----------
            
alter table ${catalog}.persist_fcl.fcl_common_account_info alter column ar_nm_th set tags ('rbac_rde_name');


-- COMMAND ----------
            
alter table ${catalog}.persist_fcl.fcl_common_account_info alter column ar_nm_eng set tags ('rbac_rde_name');


-- COMMAND ----------
            
alter table ${catalog}.persist_fcl.fcl_common_account_info alter column ac_adr1 set tags ('rbac_rde_address');


-- COMMAND ----------
            
alter table ${catalog}.persist_fcl.fcl_common_account_info alter column ac_adr2 set tags ('rbac_rde_address');

