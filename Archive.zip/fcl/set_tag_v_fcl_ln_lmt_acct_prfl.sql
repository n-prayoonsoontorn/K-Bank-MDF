-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_v_fcl_ln_lmt_acct_prfl.sql
# Area: fcl
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-22         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_fcl_view.v_fcl_ln_lmt_acct_prfl
#--------------------------------------------------------------------------------------------------*/



-- COMMAND ----------

alter table ${catalog}.persist_fcl_view.v_fcl_ln_lmt_acct_prfl set tags ('rbac_table_fcl');


-- COMMAND ----------

alter table ${catalog}.persist_fcl_view.v_fcl_ln_lmt_acct_prfl alter column lmt_acct_num set tags ('rbac_rde_account_number');


-- COMMAND ----------

alter table ${catalog}.persist_fcl_view.v_fcl_ln_lmt_acct_prfl alter column fcl_acct_num set tags ('rbac_rde_account_number');


-- COMMAND ----------

alter table ${catalog}.persist_fcl_view.v_fcl_ln_lmt_acct_prfl alter column lmt_acct_th_nm set tags ('rbac_rde_name');


-- COMMAND ----------

alter table ${catalog}.persist_fcl_view.v_fcl_ln_lmt_acct_prfl alter column lmt_acct_eng_nm set tags ('rbac_rde_name');

