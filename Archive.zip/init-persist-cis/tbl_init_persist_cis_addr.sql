-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_cis_addr.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CIS.CIS_ADDR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cis.cis_addr (
	pos_dt           	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	method           	string       comment "Description (Eng): Ingestion Method
Description (Thai): วิธีการนำเข้า",
	addr_id          	bigint       comment "Description (Eng): Address id
Description (Thai): เลขที่ที่อยู่",
	addr_ip_id       	integer      comment "Description (Eng): Customer id
Description (Thai): เลขที่ลูกค้า",
	addr_src_stm     	string       comment "Description (Eng): Address source system
Description (Thai): ระบบที่สร้างที่อยู่",
	addr_wkplc_nm    	string       comment "Description (Eng): Work Place name
Description (Thai): ชื่อสถานที่ทำงาน",
	addr_po          	string       comment "Description (Eng): PO. Box
Description (Thai): ตู้ป.ณ.",
	addr_no          	string       comment "Description (Eng): Address no.
Description (Thai): บ้านเลขที่",
	addr_moo         	string       comment "Description (Eng): Moo
Description (Thai): หมู่ที่",
	addr_mooban      	string       comment "Description (Eng): Village
Description (Thai): หมู่บ้าน",
	addr_bld         	string       comment "Description (Eng): Building
Description (Thai): อาคาร",
	addr_fl          	string       comment "Description (Eng): Floor no.
Description (Thai): ชั้น",
	addr_room        	string       comment "Description (Eng): Room no.
Description (Thai): ห้อง",
	addr_soi         	string       comment "Description (Eng): Soi
Description (Thai): ซอย",
	addr_rd          	string       comment "Description (Eng): Road
Description (Thai): ถนน",
	addr_tumbol      	string       comment "Description (Eng): Tumbol
Description (Thai): ตำบล, แขวง",
	addr_amp         	string       comment "Description (Eng): Amphur
Description (Thai): อำเภอ, เขต",
	addr_prov        	string       comment "Description (Eng): Province
Description (Thai): จังหวัด",
	addr_post_cd     	string       comment "Description (Eng): Post code
Description (Thai): รหัสไปรษณีย์",
	addr_country_cd  	string       comment "Description (Eng): Country code
Description (Thai): รหัสประเทศของที่อยู่",
	addr_1           	string       comment "Description (Eng): Address 2 Line Line#1
Description (Thai): ที่อยู่ 2 บรรทัด บรรทัดที่ 1",
	addr_2           	string       comment "Description (Eng): Address 2 Line Line#2
Description (Thai): ที่อยู่ 2 บรรทัด บรรทัดที่ 2",
	addr_stat        	string       comment "Description (Eng): Address Status code
Description (Thai): รหัสสถานะของที่อยู่",
	addr_eft_dt      	date         comment "Description (Eng): Address Effective date
Description (Thai): วันที่สร้างที่อยู่",
	addr_exp_dt      	date         comment "Description (Eng): Address Expire date
Description (Thai): วันที่ยกเลิกที่อยู่",
	addr_uncnt_flg   	string       comment "Description (Eng): Address Uncontact Mark flag
Description (Thai): ระบุสถานะที่อยู่ที่ไม่สามารถติดต่อได้",
	addr_uncnt_dt    	date         comment "Description (Eng): Address Uncontact Mark date
Description (Thai): วันที่บันทึกที่อยู่ที่ไม่สามารถติดต่อได้",
	addr_uncnt_user  	string       comment "Description (Eng): User id
Description (Thai): รหัสผู้บันทึกที่อยู่ที่ไม่สามารถติดต่อได้",
	addr_uncnt_cen_cd	string       comment "Description (Eng): User Center code
Description (Thai): รหัสสังกัดของผู้บันทึกที่อยู่ที่ไม่สามารถติดต่อได้",
	addr_uncnt_br_no 	string       comment "Description (Eng): User Branch no.
Description (Thai): รหัสสาขาของผู้บันทึกที่อยู่ที่ไม่สามารถติดต่อได้",
	addr_cre_user    	string       comment "Description (Eng): User id
Description (Thai): รหัสผู้สร้างที่อยู่",
	addr_user_id     	string       comment "Description (Eng): User id
Description (Thai): รหัสผู้ทำรายการ",
	addr_upd_dt      	timestamp    comment "Description (Eng): Update date time
Description (Thai): วันและเวลาที่ทำรายการ",
	load_tms         	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id       	string       comment "Source system ID",
	ptn_yyyy         	string       comment "Partition field - year",
	ptn_mm           	string       comment "Partition field - month",
	ptn_dd           	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cis/cis_addr' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);