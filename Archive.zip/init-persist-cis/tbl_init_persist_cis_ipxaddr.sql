-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_cis_ipxaddr.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CIS.CIS_IPXADDR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cis.cis_ipxaddr (
	pos_dt        	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	method        	string       comment "Description (Eng): Ingestion Method
Description (Thai): วิธีการนำเข้า",
	ipaddr_ip_id  	integer      comment "Description (Eng): Customer id
Description (Thai): เลขที่ลูกค้า",
	ipaddr_addr_id	bigint       comment "Description (Eng): Address id
Description (Thai): เลขที่ที่อยู่",
	ipaddr_tp     	string       comment "Description (Eng): Customer and Address Relationship Type
Description (Thai): รหัสประเภทความสัมพันธ์ของลูกค้ากับที่อยู่",
	ipaddr_stat   	string       comment "Description (Eng): Customer and Address Relationship Status code
Description (Thai): รหัสสถานะความสัมพันธ์ของลูกค้ากับที่อยู่",
	ipaddr_eft_dt 	date         comment "Description (Eng): Customer and Address Relationship Effective date
Description (Thai): วันที่ผูกความสัมพันธ์",
	ipaddr_exp_dt 	date         comment "Description (Eng): Customer and Address Relationship Expire date
Description (Thai): วันที่ยกเลิกความสัมพันธ์",
	ipaddr_user_id	string       comment "Description (Eng): User id
Description (Thai): รหัสผู้ทำรายการ",
	ipaddr_upd_dt 	timestamp    comment "Description (Eng): Update date time
Description (Thai): วันและเวลาที่ทำรายการ",
	load_tms      	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id    	string       comment "Source system ID",
	ptn_yyyy      	string       comment "Partition field - year",
	ptn_mm        	string       comment "Partition field - month",
	ptn_dd        	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cis/cis_ipxaddr' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);