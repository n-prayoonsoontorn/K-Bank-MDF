-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_cis_ar.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CIS.CIS_AR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cis.cis_ar (
	pos_dt         	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	method         	string       comment "Description (Eng): Ingestion Method
Description (Thai): วิธีการนำเข้า",
	ar_id          	bigint(15)   comment "Description (Eng): Arrangement id
Description (Thai): เลขที่ arrangement",
	ar_ip_id       	integer(10)  comment "Description (Eng): Customer id
Description (Thai): เลขที่ลูกค้า",
	ar_src_stm_no_1	string       comment "Description (Eng): Arrangement source system no. 1
Description (Thai): รหัสชนิดธุรกรรมจากแต่ละระบบ#1 (cust ref)",
	ar_src_stm_no_2	string       comment "Description (Eng): Arrangement source system no. 2
Description (Thai): รหัสชนิดธุรกรรมจากแต่ละระบบ#2 (product)",
	ar_src_stm_no_3	string       comment "Description (Eng): Arrangement source system no. 3
Description (Thai): รหัสชนิดธุรกรรมจากแต่ละระบบ#3 (sub product)",
	ar_src_stm     	string       comment "Description (Eng): Arrangement Source System
Description (Thai): รหัสของ Product group",
	ar_pd_cd       	string       comment "Description (Eng): Arrangement Product code
Description (Thai): รหัสของ Product sub group",
	ar_pd_cd_9     	string       comment "Description (Eng): Arrangement Product code 9 digits
Description (Thai): รหัสของ Product sub group 9 หลัก",
	ar_br_no       	string       comment "Description (Eng): Arrangement Branch no.
Description (Thai): สาขาที่ทำธุรกรรม",
	ar_term_prd    	string       comment "Description (Eng): Arrangement Term Period
Description (Thai): รหัสความสัมพันธ์ทางบัญชี",
	ar_stat        	string       comment "Description (Eng): Arrangement Status code
Description (Thai): รหัสสถานะของ arrangement",
	ar_begin_dt    	date         comment "Description (Eng): Arrangement Begin date
Description (Thai): วันที่เริ่มผูกหรือเปลี่ยนความสัมพันธ์",
	ar_end_dt      	date         comment "Description (Eng): Arrangement End date
Description (Thai): วันที่ยกเลิกความสัมพันธ์",
	ar_user_id     	string       comment "Description (Eng): User id
Description (Thai): รหัสผู้ทำรายการ",
	ar_upd_dt      	timestamp    comment "Description (Eng): Update date time
Description (Thai): วันและเวลาที่ทำรายการ",
	load_tms       	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id     	string       comment "Source system ID",
	ptn_yyyy       	string       comment "Partition field - year",
	ptn_mm         	string       comment "Partition field - month",
	ptn_dd         	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cis/cis_ar' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);