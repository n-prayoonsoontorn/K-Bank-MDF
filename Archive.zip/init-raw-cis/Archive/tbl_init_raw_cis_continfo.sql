-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_cis_continfo.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CIS.CIS_CONTINFO
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cis.cis_continfo (
	pos_dt           	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	method           	string       comment "Description (Eng): Ingestion Method
Description (Thai): วิธีการนำเข้า",
	cont_id          	bigint(15)   comment "Description (Eng): Contact id
Description (Thai): เลขที่ Contact",
	cont_tp          	string       comment "Description (Eng): Contact Type
Description (Thai): ประเภท Contact",
	cont_ip_id       	integer(10)  comment "Description (Eng): Customer id
Description (Thai): เลขที่ลูกค้า",
	cont_src_stm     	string       comment "Description (Eng): Contact Source system
Description (Thai): ระบบที่สร้าง Contact",
	cont_info        	string       comment "Description (Eng): Contact infomation
Description (Thai): ข้อมูล contact แต่ละประเภท เช่น เบอร์โทรศัพท์, เบอร์มือถือ, email address, URL, FB account",
	cont_phone_ext   	string       comment "Description (Eng): Phone Extension no.
Description (Thai): เบอร์ต่อ",
	cont_phone_cntry 	string       comment "Description (Eng): Phone Country code
Description (Thai): รหัสประเทศของเบอร์โทร",
	cont_phone_area  	string       comment "Description (Eng): Phone Area code
Description (Thai): รหัสพื้นที่ของเบอร์โทรต่างประเทศ",
	cont_stat        	string       comment "Description (Eng): Contact Status code
Description (Thai): รหัสสถานะของ Contact",
	cont_eft_dt      	date         comment "Description (Eng): Contact Effective date
Description (Thai): วันที่สร้าง Contact",
	cont_exp_dt      	date         comment "Description (Eng): Contact Expire date
Description (Thai): วันที่ยกเลิก Contact",
	cont_uncnt_flg   	string       comment "Description (Eng): Contact Uncontact Mark flag
Description (Thai): ระบุสถานะ contact ที่ไม่สามารถติดต่อได้",
	cont_uncnt_dt    	date         comment "Description (Eng): Contact Uncontact Mark date
Description (Thai): วันที่บันทึก Contact ที่ไม่สามารถติดต่อได้",
	cont_uncnt_user  	string       comment "Description (Eng): User id
Description (Thai): รหัสผู้บันทึก Contact ที่ไม่สามารถติดต่อได้",
	cont_uncnt_cen_cd	string       comment "Description (Eng): User Center code
Description (Thai): รหัสสังกัดของผู้บันทึก Contact ที่ไม่สามารถติดต่อได้",
	cont_uncnt_br_no 	string       comment "Description (Eng): User Branch no.
Description (Thai): รหัสสาขาของผู้บันทึก Contact ที่ไม่สามารถติดต่อได้",
	cont_cre_user    	string       comment "Description (Eng): User id
Description (Thai): รหัสผู้สร้าง Contact",
	cont_user_id     	string       comment "Description (Eng): User id
Description (Thai): รหัสผู้ทำรายการ",
	cont_upd_dt      	timestamp    comment "Description (Eng): Update date time
Description (Thai): วันและเวลาที่ทำรายการ",
	load_tms         	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id       	string       comment "Source system ID",
	ptn_yyyy         	string       comment "Partition field - year",
	ptn_mm           	string       comment "Partition field - month",
	ptn_dd           	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cis/cis_continfo' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);