-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_cis_idv.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CIS.CIS_IDV
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cis.cis_idv (
	pos_dt          	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	method          	string       comment "Description (Eng): Ingestion Method
Description (Thai): วิธีการนำเข้า",
	idv_ip_id       	integer(10)  comment "Description (Eng): Customer id
Description (Thai): เลขที่ลูกค้า",
	idv_nation      	string       comment "Description (Eng): Nationality
Description (Thai): รหัสสัญชาติ",
	idv_gender      	string       comment "Description (Eng): Gender code
Description (Thai): รหัสเพศ",
	idv_marital_stat	string       comment "Description (Eng): Marital status code
Description (Thai): รหัสสถานภาพสมรส",
	idv_edu_level   	string       comment "Description (Eng): Education level
Description (Thai): รหัสระดับการศึกษา",
	idv_income      	string       comment "Description (Eng): Income range
Description (Thai): รหัสรายได้ต่อเดือน",
	idv_fmly_inc    	string       comment "Description (Eng): Family income range
Description (Thai): รหัสรายได้ครอบครัวต่อเดือน",
	idv_ocp         	string       comment "Description (Eng): Occupation code
Description (Thai): รหัสอาชีพ",
	idv_position    	string       comment "Description (Eng): Job position code
Description (Thai): รหัสตำแหน่งงาน",
	idv_prof        	string       comment "Description (Eng): Profession code
Description (Thai): รหัสสาขาอาชีพ",
	idv_prof_oth    	string       comment "Description (Eng): Profession (Other)
Description (Thai): สาขาอาชีพอื่น ๆ",
	idv_dth_flg     	string       comment "Description (Eng): Death flag
Description (Thai): Flag การเสียชีวิต",
	idv_dth_dt      	date         comment "Description (Eng): Death date
Description (Thai): วันที่เสียชีวิต",
	idv_no_child    	smallint(2)  comment "Description (Eng): No. of child
Description (Thai): จำนวนบุตร",
	idv_user_id     	string       comment "Description (Eng): User id
Description (Thai): รหัสผู้ทำรายการ",
	idv_upd_dt      	timestamp    comment "Description (Eng): Update date time
Description (Thai): วันและเวลาที่ทำรายการ",
	load_tms        	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id      	string       comment "Source system ID",
	ptn_yyyy        	string       comment "Partition field - year",
	ptn_mm          	string       comment "Partition field - month",
	ptn_dd          	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cis/cis_idv' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);