-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_cis_histsegm.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CIS.CIS_HISTSEGM
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cis.cis_histsegm (
	pos_dt               	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	method               	string       comment "Description (Eng): Ingestion Method
Description (Thai): วิธีการนำเข้า",
	hstsgm_id            	bigint       comment "Description (Eng): Hist Segment running no.
Description (Thai): เลข running สำหรับประวัติ segment",
	hstsgm_ip_id         	integer      comment "Description (Eng): Customer id
Description (Thai): เลขที่ลูกค้า",
	hstsgm_segm_tp       	string       comment "Description (Eng): Segment type
Description (Thai): รหัสประเภท segment",
	hstsgm_segm_cd       	string       comment "Description (Eng): Segment code
Description (Thai): รหัส segment ของลูกค้า",
	hstsgm_segm_dt       	date         comment "Description (Eng): Segment update date
Description (Thai): วันที่เปลี่ยนแปลง segment",
	hstsgm_chg_cd        	string       comment "Description (Eng): Segment changed Reason code
Description (Thai): สาเหตุของการเปลี่ยน Segment",
	hstsgm_ipsegm_act    	string       comment "Description (Eng): Action on IPSEGMENT table
Description (Thai): Action ที่กระทำกับ record ใน table IPSEGMENT",
	hstsgm_ipsegm_dt     	date         comment "Description (Eng): Action date on IPSEGMENT table
Description (Thai): วันที่ที่กระทำกับ record ใน table IPSEGMENT",
	hstsgm_ipsegm_user_id	string       comment "Description (Eng): User id from IPSEGMENT table
Description (Thai): รหัสผู้ทำรายการจาก table IPSEGMENT",
	hstsgm_ipsegm_upd_dt 	timestamp    comment "Description (Eng): Update date time from IPSEGMENT table
Description (Thai): วันและเวลาที่ทำรายการจาก table IPSEGMENT",
	hstsgm_user_id       	string       comment "Description (Eng): User id
Description (Thai): รหัสผู้ทำรายการ",
	hstsgm_upd_dt        	timestamp    comment "Description (Eng): Update date time
Description (Thai): วันและเวลาที่ทำรายการ",
	load_tms             	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id           	string       comment "Source system ID",
	ptn_yyyy             	string       comment "Partition field - year",
	ptn_mm               	string       comment "Partition field - month",
	ptn_dd               	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cis/cis_histsegm' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);