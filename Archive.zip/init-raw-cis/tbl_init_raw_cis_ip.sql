-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_cis_ip.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-15    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CIS.CIS_IP
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cis.cis_ip (
	pos_dt         	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	method         	string        comment "Description (Eng): Ingestion Method
Description (Thai): วิธีการนำเข้า",
	ip_id          	integer       comment "Description (Eng): Customer id
Description (Thai): เลขที่ลูกค้า",
	ip_indx_id     	integer       comment "Description (Eng): Main Customer id
Description (Thai): เลขที่ลูกค้าหลักจากการ Merge",
	ip_doc_tp      	string        comment "Description (Eng): Document Type code
Description (Thai): รหัสประเภทเอกสารสำคัญ",
	ip_doc_id      	string        comment "Description (Eng): Identification no. or Registration no.
Description (Thai): เลขที่เอกสารสำคัญ หรือ เลขที่จดทะเบียน",
	ip_birth_dt    	date          comment "Description (Eng): Birth date or Registration date
Description (Thai): วันเกิด หรือ วันที่จดทะเบียน",
	ip_doc_dept    	string        comment "Description (Eng): Document issuer department
Description (Thai): หน่วยงานที่ออกเอกสารสำคัญ",
	ip_doc_iss_dt  	date          comment "Description (Eng): Document issue date
Description (Thai): วันที่ออกเอกสารสำคัญ",
	ip_doc_exp_dt  	date          comment "Description (Eng): Document expire date
Description (Thai): วันที่เอกสารสำคัญหมดอายุ",
	ip_cust_grp    	string        comment "Description (Eng): Customer Group code
Description (Thai): รหัสกลุ่มลูกค้า",
	ip_cust_val    	string        comment "Description (Eng): Customer Validation code
Description (Thai): รหัสการตรวจสอบข้อมูลลูกค้า",
	ip_cust_prvn   	string        comment "Description (Eng): Customer Creation code
Description (Thai): รหัสการสร้างลูกค้า",
	ip_cust_tp     	string        comment "Description (Eng): Customer Type code
Description (Thai): รหัสประเภทลูกค้า",
	ip_local_title 	string        comment "Description (Eng): Title in Local language
Description (Thai): คำนำหน้าชื่อ ภาษาท้องถิ่น",
	ip_local_nm    	string        comment "Description (Eng): Name in Local language
Description (Thai): ชื่อ ภาษาท้องถิ่น",
	ip_local_surnm 	string        comment "Description (Eng): Surname in Local language
Description (Thai): นามสกุล ภาษาท้องถิ่น",
	ip_local_mid_nm	string        comment "Description (Eng): Middle Name in Local language
Description (Thai): ชื่อกลาง ภาษาท้องถิ่น",
	ip_en_title    	string        comment "Description (Eng): Title in English
Description (Thai): คำนำหน้าชื่อ ภาษาอังกฤษ",
	ip_en_nm       	string        comment "Description (Eng): Name in English
Description (Thai): ชื่อ ภาษาอังกฤษ",
	ip_en_surnm    	string        comment "Description (Eng): Surname in English
Description (Thai): นามสกุล ภาษาอังกฤษ",
	ip_en_mid_nm   	string        comment "Description (Eng): Middle Name in English
Description (Thai): ชื่อกลาง ภาษาอังกฤษ",
	ip_br_no       	string        comment "Description (Eng): Customer created Branch no.
Description (Thai): รหัสสาขาที่สร้างลูกค้า",
	ip_kyc_br_no   	string        comment "Description (Eng): KYC Take Care Branch no.
Description (Thai): รหัสสาขาที่เปิดบัญชีล่าสุด",
	ip_bus_cd      	string        comment "Description (Eng): KBank Business Type code
Description (Thai): รหัสประเภทธุรกิจหลักกสิกรไทย",
	ip_no_emp      	integer       comment "Description (Eng): No. of employee
Description (Thai): จำนวนลูกจ้างกรณ๊เป็นเจ้าของกิจการ",
	ip_asst_exc_ld 	decimal(17,2) comment "Description (Eng): Asset exclude land
Description (Thai): มูลค่าทรัพย์สินไม่รวมที่ดิน",
	ip_majorsrc_inc	string        comment "Description (Eng): Major Source of income
Description (Thai): รหัสประเทศที่มาของรายได้",
	ip_chg_nm_flg  	string        comment "Description (Eng): Change Name flag
Description (Thai): Flag ของการเปลี่ยนชื่อ-นามสกุล",
	ip_open_dt     	date          comment "Description (Eng): Customer Create date
Description (Thai): วันที่สร้างลูกค้าเข้าระบบ",
	ip_close_dt    	date          comment "Description (Eng): Customer (logical) Delete date
Description (Thai): วันที่ลบลูกค้าออกจากระบบ",
	ip_merge_stat  	string        comment "Description (Eng): Customer Merge Status
Description (Thai): รหัสสถานะการยุบรวมลูกค้า",
	ip_merge_dt    	date          comment "Description (Eng): Customer Merge date
Description (Thai): วันที่ยุบรวมลูกค้า",
	ip_cust_stat   	string        comment "Description (Eng): Customer status code
Description (Thai): รหัสสถานะลูกค้า",
	ip_user_id     	string        comment "Description (Eng): User id
Description (Thai): รหัสผู้ทำรายการ",
	ip_upd_dt      	timestamp     comment "Description (Eng): Update date time
Description (Thai): วันและเวลาที่ทำรายการ",
	load_tms       	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id     	string        comment "Source system ID",
	ptn_yyyy       	string        comment "Partition field - year",
	ptn_mm         	string        comment "Partition field - month",
	ptn_dd         	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cis/cis_ip' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);