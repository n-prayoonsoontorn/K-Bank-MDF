-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_cis_ipxar.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CIS.CIS_IPXAR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cis.cis_ipxar (
	pos_dt      	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	method      	string       comment "Description (Eng): Ingestion Method
Description (Thai): วิธีการนำเข้า",
	ipar__ip_id 	integer      comment "Description (Eng): Customer id
Description (Thai): เลขที่ลูกค้า",
	ipar_ar_id  	bigint       comment "Description (Eng): Arrangement id
Description (Thai): เลขที่ arrangement",
	ipar_rel_tp 	string       comment "Description (Eng): Customer and Arrangement Relationship Type
Description (Thai): รหัสประเภทความสัมพันธ์ของลูกค้ากับ arrangement",
	ipar_stat   	string       comment "Description (Eng): Arrangement Status code
Description (Thai): รหัสสถานะของ arrangement",
	ipar_eft_dt 	date         comment "Description (Eng): Arrangement Begin date
Description (Thai): วันที่เริ่มผูกหรือเปลี่ยนความสัมพันธ์",
	ipar_exp_dt 	date         comment "Description (Eng): Arrangement End date
Description (Thai): วันที่ยกเลิกความสัมพันธ์",
	ipar_user_id	string       comment "Description (Eng): User id
Description (Thai): รหัสผู้ทำรายการ",
	ipar_upd_dt 	timestamp    comment "Description (Eng): Update date time
Description (Thai): วันและเวลาที่ทำรายการ",
	load_tms    	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id  	string       comment "Source system ID",
	ptn_yyyy    	string       comment "Partition field - year",
	ptn_mm      	string       comment "Partition field - month",
	ptn_dd      	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cis/cis_ipxar' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);