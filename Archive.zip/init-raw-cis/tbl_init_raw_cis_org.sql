-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_cis_org.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CIS.CIS_ORG
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cis.cis_org (
	pos_dt     	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	method     	string       comment "Description (Eng): Ingestion Method
Description (Thai): วิธีการนำเข้า",
	org_ip_id  	integer      comment "Description (Eng): Customer id
Description (Thai): เลขที่ลูกค้า",
	org_revenue	string       comment "Description (Eng): Revenue code
Description (Thai): รหัสประมาณการรายได้ต่อเดือน",
	org_ds_dt  	date         comment "Description (Eng): Dissolve date
Description (Thai): วันที่เลิกกิจการ",
	org_user_id	string       comment "Description (Eng): User id
Description (Thai): รหัสผู้ทำรายการ",
	org_upd_dt 	timestamp    comment "Description (Eng): Update date time
Description (Thai): วันและเวลาที่ทำรายการ",
	load_tms   	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id 	string       comment "Source system ID",
	ptn_yyyy   	string       comment "Partition field - year",
	ptn_mm     	string       comment "Partition field - month",
	ptn_dd     	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cis/cis_org' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);