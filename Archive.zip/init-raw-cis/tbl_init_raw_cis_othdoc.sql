-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_cis_othdoc.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CIS.CIS_OTHDOC
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cis.cis_othdoc (
	pos_dt           	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	method           	string       comment "Description (Eng): Ingestion Method
Description (Thai): วิธีการนำเข้า",
	othdoc_ip_id     	integer      comment "Description (Eng): Customer id
Description (Thai): เลขที่ลูกค้า",
	othdoc_doc_tp    	string       comment "Description (Eng): Document Type code
Description (Thai): รหัสประเภทเอกสาร",
	othdoc_doc_id    	string       comment "Description (Eng): Other Document Identification no.
Description (Thai): เลขที่เอกสารอื่นๆ",
	othdoc_stat      	string       comment "Description (Eng): Document status code
Description (Thai): รหัสสถานะเอกสาร",
	othdoc_doc_dept  	string       comment "Description (Eng): Document issuer department
Description (Thai): หน่วยงานที่ออกเอกสาร",
	othdoc_doc_iss_dt	date         comment "Description (Eng): Document issue date
Description (Thai): วันที่ออกเอกสาร",
	othdoc_doc_exp_dt	date         comment "Description (Eng): Document expire date
Description (Thai): วันที่เอกสารหมดอายุ",
	othdoc_user_id   	string       comment "Description (Eng): User id
Description (Thai): รหัสผู้ทำรายการ",
	othdoc_upd_dt    	timestamp    comment "Description (Eng): Update date time
Description (Thai): วันและเวลาที่ทำรายการ",
	load_tms         	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id       	string       comment "Source system ID",
	ptn_yyyy         	string       comment "Partition field - year",
	ptn_mm           	string       comment "Partition field - month",
	ptn_dd           	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cis/cis_othdoc' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);