-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_mcl_host_share_mcl1d101_nextday.sql
# Area: mcl_host
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-21   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_MCL_HOST.MCL_HOST_SHARE_MCL1D101_NEXTDAY
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_mcl_host.mcl_host_share_mcl1d101_nextday (
	pos_dt                      	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	mcl1d101_k_eft_date         	date         comment "Def(En): Effective date
Def(Th):",
	mcl1d101_k_rev_acct_no      	bigint       comment "Def(En): Receiving Bank A/C No.
Def(Th):",
	mcl1d101_k_seq_no           	integer      comment "Def(En): Seq.
Def(Th):",
	mcl1d101_d_fl_type          	string       comment "Def(En): File Type
Def(Th): มีค่าเป็น '20' ทั้งหมด",
	mcl1d101_d_batch_no         	integer      comment "Def(En): Batch Number
Def(Th): 1 batch ไม่เกิน 999 รายการ พอครบก็ run เลขใหม่)
 >> referece batch number ที่ ITMX gen มาให้ปกติเป็นการ running มีโอกาสซ้ำ",
	mcl1d101_d_rev_bk_code      	smallint     comment "Def(En): 
Def(Th): Receiving Bank Code ที่เอาเงินเข้า
ขาเอาเงินเข้าเป็น Kbank เสมอ",
	mcl1d101_d_rev_br_code      	smallint     comment "Def(En): Receiving Branch Code
Def(Th):",
	mcl1d101_d_rev_acct_no      	bigint       comment "Def(En): Receiving Bank A/C No.
Def(Th): เป็นมาตรฐานที่ทุกธนาคาร field นี้เป็น 11 หลัก แต่ kbank มี 10หลัก EBAN เลยต้องตัด 0 ข้างหน้าออก)

ถ้าเป็น prompt pay MCL จะเอาค่าใน ANYID ไป look up  หา account จริง",
	mcl1d101_d_send_bk_code     	smallint     comment "Def(En): Sending Bank Code
Def(Th): ขาธนาคารอื่นที่เอาเงินมาเข้า Kbank",
	mcl1d101_d_send_br_code     	smallint     comment "Def(En): Sending Branch Code
Def(Th):",
	mcl1d101_d_send_acct_no     	bigint       comment "Def(En): Sending Bank A/C No.
Def(Th): บางธนาคาร 11 , 10  หรือเอาที่เกินไปไว้ใน branch เช่น ธกสเอา 2 หลักแรกที่เกินไปแปะไว้ที่ branch)",
	mcl1d101_d_eft_date         	date         comment "Def(En): Effective Date of Transfer (DDMMYYYY)
Def(Th): ต่างธนาคารส่งมาเพื่อให้เราเอาเงินเข้าบัญชีวันไหน อาจจะเป็นวันล่วงหน้า (next day)",
	mcl1d101_d_serv_type        	string       comment "Def(En): Service Type Code
Def(Th):",
	mcl1d101_d_cl_house_code    	string       comment "Def(En): Clearing House Code 
Def(Th):",
	mcl1d101_d_tran_amount      	decimal(12,2) comment "Def(En): Transfer amount
Def(Th):",
	mcl1d101_d_rev_info         	string       comment "Def(En): 
Def(Th): ข้อมูลของลูกค้ารายย่อย แล้วแต่ว่าต้นทางใส่มา เป็น information free text อาจมีข้อมูลชื่อลูกค้า",
	mcl1d101_d_send_info        	string       comment "Def(En): 
Def(Th): ข้อมูลของบริษัท",
	mcl1d101_otherinformation   	string       comment "Def(En): 
Def(Th): เลขที่อ้างอิง",
	mcl1d101_anyid              	string       comment "Def(En): ANYID Ref. 
Def(Th): I - identno ,เลขที่นิติบุคคล
M- mobile ตามด้วย proxy value เช่น ident no",
	mcl1d101_d_ref_out_transfer 	integer      comment "Def(En): 
Def(Th): เป็นเลขไว้เช็คกับ  ITMX (system use)",
	mcl1d101_d_ref_no           	integer      comment "Def(En): 
Def(Th):",
	mcl1d101_d_authen_code      	string       comment "Def(En): Authen Code
Def(Th):",
	mcl1d101_d_prod_code        	string       comment "Def(En): Product Code
Def(Th):",
	mcl1d101_d_kind_tran        	string       comment "Def(En): Debit / Credit Code
Def(Th):",
	mcl1d101_d_deposit_prod_code	string       comment "Def(En): Profile product code
Def(Th):",
	mcl1d101_d_tran_status      	string       comment "Def(En): Transaction Status
Def(Th):",
	mcl1d101_d_acct_dt          	date         comment "Def(En): 
Def(Th): วันที่ตัดเงินจริง ถ้าตัดไม่ได้เป็นค่าว่าง
TRAN-STATUS = F
กรณีปกติจะเท่ากับ MCL1D101-D-EFT-DATE",
	mcl1d101_d_terminal_id      	string       comment "Def(En): 
Def(Th): เป็นค่าจาก profile",
	mcl1d101_d_user_id          	string       comment "Def(En): 
Def(Th): เป็น user สำหรับ transaction
(MCL เอา MCL1D101-D-REC-TYPE ไป look up ใน table อื่นเพื่อดึง MCL1D101-D-USER-ID ถ้าไม่มีจะใส่ค่า defualt MCL00045)",
	mcl1d101_d_auth_user_id     	string       comment "Def(En): 
Def(Th):",
	mcl1d101_d_auth_level       	string       comment "Def(En): 
Def(Th):",
	mcl1d101_d_dom_branch_id    	string       comment "Def(En): 
Def(Th):",
	mcl1d101_d_trn_dt           	date         comment "Def(En): system data time
Def(Th): system data time ที่ profile ตัดเงิน ถ้า ไม่สำเร็จก็มีค่า return กลับมา
แต่ไม่มี txn dt ที่ลูกค้าทำรายการเพราะทำจากต่าง ธนาคาร",
	mcl1d101_d_trn_time         	string       comment "Def(En): 
Def(Th): มาจาก profile",
	mcl1d101_d_src_sys_flag     	string       comment "Def(En): 
Def(Th): มาจาก profile",
	mcl1d101_d_return_code      	string       comment "Def(En): Re-turn Code
Def(Th):",
	mcl1d101_d_anyid_result_flag	string       comment "Def(En): 
Def(Th): MCL1D101-D-TRAN-STATUS = 'S'
(ที่ส่งมา MCL1D101-D-REV-ACCT-NO =88888888888 ถ้าไป look up ใน any id เจอจะ update REV-ACCT-NO เป็น account จริง )
ถ้าไม่ any id อาจจะเป็นค่าว่าง",
	mcl1d101_d_fee_amt          	decimal(12,2) comment "Def(En): Fee amoumnt
Def(Th):",
	mcl1d101_d_fee_type         	string       comment "Def(En): Fee Type  :                                                                                       Sameday:                                                                                                 “0”  = NOT  IN CONDITIONS below                                      
1 =   TIER   1  (  AMT <= 100000)
2 =   TIER   2  (  AMT <= 500000)
3 =   TIER   3  (  AMT <= 2000000)
A =   ANY ID                                                                                                Nextday:
“0”  = NOT  IN CONDITIONS below                                                           
5 =   TIER   5  (Not Any ID and
          SERV-TYPE = 09 and 
          SEND-BK-CODE = 001 Move 5                                                        
4 =   TIER   4  (Not Any ID and
          SERV-TYPE = 08 and 
          NOT found in SENIOR-FEE  file (MCL1D88) )                                           1 =   TIER   1  (  AMT <= 100000)
 2 =   TIER   2  (  AMT <= 500000)
 3 =   TIER   3  (  AMT <= 2000000)
 A =   ANY ID
Def(Th):",
	mcl1d101_d_pcb_date         	date         comment "Def(En): PCB date
Def(Th):",
	mcl1d101_d_pcb_time         	string       comment "Def(En): PCB Time
Def(Th):",
	mcl1d101_d_rquid            	string       comment "Def(En): 
Def(Th):",
	load_tms                    	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                  	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                    	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                      	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                      	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_mcl_host/mcl_host_share_mcl1d101_nextday' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);