-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_lpm_tdr_ct1d408a.sql
# Area: lpm_tdr
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-22   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_TDR.LPM_TDR_CT1D408A
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_tdr.lpm_tdr_ct1d408a (
	pos_dt                        	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	g_b                           	string       comment "Def(En): GOOD BAD Code
Def(Th):",
	`ภาค`                         	string       comment "Def(En): Area Code
Def(Th): ภาค",
	`ศูนย์`                       	string       comment "Def(En): Center Code
Def(Th): ศูนย์",
	`หน่วย`                       	string       comment "Def(En): Unit Code
Def(Th):  หน่วย",
	`สาขา`                        	string       comment "Def(En): Branch Number
Def(Th): สาขา",
	`เลขที่ลูกหนี้`               	string       comment "Def(En):  LPM Customer ID
Def(Th): เลขที่ลูกหนี้",
	`ชื่อ-สกุล`                   	string       comment "Def(En):
Def(Th):",
	`วิธีการแก้ไขหนี้`            	string       comment "Def(En): Reschedule Method Indicator
Def(Th): วิธีการแก้ไขหนี้  มี 4 แบบ 
ช่อง1 -  ขยายเวลาการชำระหนี้
ช่อง2 - เปลี่ยนอัตราดอกเบี้ย
ช่อง3 - เปลี่ยนหนี้
ช่อง4 - ปลอดต้นชำระดอกเบี้ย
* FILED นี้จะมีทั้งหมด 4 ช่อง แก้ไขหนี้ด้วยวิธีใด ช่องนั้นจะ 1
  ส่วนช่องอื่นๆจะมีค่าเป็น 0 หมด  เช่น       
  แก้ไขหนี้ด้วยวิธีที่1 -  ขยายเวลาการชำระหนี้ จะมีค่าเท่ากับ 1000                  
  แก้ไขหนี้ด้วยวิธีที่1 - ขยายเวลาการชำระหนี้ และ 3 - เปลี่ยนหนี้  จะมีค่าเท่ากับ 1010",
	`ระยะเวลา เดิม(ปี)`           	string       comment "Def(En): number of year for Original Loan Installment
Def(Th): จำนวนปี ของระยะเวลาการชำระหนี้เดิม",
	`ระยะเวลา เดิม(เดือน)`        	string       comment "Def(En): number of month for Original Loan Installment
Def(Th): จำนวนเดือน ของระยะเวลาการชำระหนี้เดิม",
	`ระยะเวลา ผ่อนมาแล้ว(ปี)`     	string       comment "Def(En): number of year for paid Original Loan Installment
Def(Th): จำนวนปี ของระยะเวลาการชำระหนี้เดิมที่ผ่อนมาแล้ว",
	`ระยะเวลา ผ่อนมาแล้ว(เดือน)`  	string       comment "Def(En): number of month for paid Original Loan Installment
Def(Th): จำนวนเดือน ของระยะเวลาการชำระหนี้เดิมที่ผ่อนมาแล้ว",
	`ระยะเวลา เหลือ(ปี)`          	string       comment "Def(En): number of year for remain Original Loan Installment
Def(Th): จำนวนปี ที่เหลือของระยะเวลาการชำระหนี้เดิม",
	`ระยะเวลา เหลือ(เดือน)`       	string       comment "Def(En): number of month for remain Original Loan Installment
Def(Th): จำนวนเดือน ที่เหลือของระยะเวลาการชำระหนี้เดิม",
	`ระยะเวลาตั๋ว เดิม(วัน)`      	string       comment "Def(En): number of day for group arrangement before reschedule
Def(Th): จำนวนวันของบัญชีตั๋ว ฯ ก่อนแก้ไขหนี้",
	`ระยะเวลาตั๋ว ใหม่(วัน)`      	string       comment "Def(En):  number of day for group arrangement after reschedule
Def(Th): จำนวนวันของบัญชีตั๋ว ฯ หลังแก้ไขหนี้",
	`เลขที่บัญชี(เดิม)`           	string       comment "Def(En): Original Arrangement ID
Def(Th): เลขที่บัญชี [เดิม]
(กรณีเป็นหมายเลขบัตรเครดิตจะเก็บเป็นค่า encrypt)",
	`ประเภทบัญชี(เดิม)`           	string       comment "Def(En): Original Arrangement Type Code
Def(Th): ประเภทบัญชี [เดิม]",
	`รหัสเปลี่ยนเลขที่บัญชี`      	string       comment "Def(En): Changed Arrangement Indicator
Def(Th): รหัสเปลี่ยนเลขที่บัญชี",
	`เปลี่ยนหนี้(บัญชีใหม่)`      	string       comment "Def(En): New Arrangement ID
Def(Th): เลขที่บัญชี [ใหม่]
(กรณีเป็นหมายเลขบัตรเครดิตจะเก็บเป็นค่า encrypt)",
	`ประเภท(บัญชีใหม่)`           	string       comment "Def(En): New Arrangement Type Code
Def(Th): ประเภทบัญชี [ใหม่]",
	`เงินต้นก่อนแก้ไขหนี้`        	string       comment "Def(En): Before Reschedule Before Write off  Principal Amount
Def(Th): เงินต้น ณ. สิ้นเดือนก่อนลงนามแก้ไขหนี้ระดับบัญชี",
	`ดอกเบี้ยก่อนแก้ไขหนี้`       	string       comment "Def(En): Before Reschedule Before Write off  Accru Interest Amount
Def(Th): ดอกเบี้ย ณ. สิ้นเดือนก่อนลงนามแก้ไขหนี้ระดับบัญชี",
	`ยอดหนี้ก่อนแก้ไขหนี้`        	string       comment "Def(En): Before Reschedule Before Write off  Outstanding Balance
Def(Th): ยอดหนี้ทั้งหมด ณ. สิ้นเดือนก่อนลงนามแก้ไขหนี้ระดับบัญชี",
	grace_period                  	string       comment "Def(En): Grace Period Indicator
Def(Th): Indicator ระยะเวลาปลอดหนี้",
	`วันค้างชำระ ก่อนแก้ไขหนี้`   	string       comment "Def(En): Before Reschedule Delinquent days
Def(Th): วันค้างชำระ ก่อนแก้ไขหนี้",
	manual_aging                  	string       comment "Def(En): Manual Aging User ID
Def(Th): User ที่แก้ Aging",
	`หมวดสาเหตุที่ขอแก้ไขหนี้`    	string       comment "Def(En): Main Cause  of Reschedule
Def(Th): สาเหตุใหญ่ในการแก้ไขหนี้",
	`รายละเอียดสาเหตุที่ขอแก้ไขหนี้`	string       comment "Def(En): Detail Cause  of Reschedule
Def(Th): รายละเอียดสาเหตุการแก้ไขหนี้",
	`ครั้งที่แก้ไขหนี้`           	string       comment "Def(En): Reschedule Sequence
Def(Th): ครั้งที่แก้ไขหนี้",
	`เลขที่อนุมัติ`               	string       comment "Def(En): Reschedule Approve ID
Def(Th): เลขที่อนุมัติแก้ไขหนี้",
	`วันที่อนุมัติให้แก้ไขหนี้`   	string       comment "Def(En): Reschedule Approve Date
Def(Th): วันที่อนุมัติแก้ไขหนี้",
	`ผู้มีอำนาจอนุมัติ`           	string       comment "Def(En): Reschedule Approve name
Def(Th): ผู้มีอำนาจอนุมัติแก้ไขหนี้",
	`วันลงนามบันทึกข้อตกลง/สัญญา` 	string       comment "Def(En): Reschedule Date
Def(Th): วันที่ลงนามบันทึกข้อตกลง/สัญญา",
	`วันที่บันทึกในระบบ`          	string       comment "Def(En): Insert Date
Def(Th): วันที่บันทึกในระบบ",
	`วันที่อนุมัติในระบบ`         	string       comment "Def(En): Reschedule System Approve Date
Def(Th): วันที่อนุมัติในระบบ",
	`ผู้อนุมัติในระบบ`            	string       comment "Def(En): Reschedule System Approve user ID
Def(Th): User ที่อนุมัติในระบบ",
	`ผลการปลด`                    	string       comment "Def(En): Reschedule Result Description
Def(Th): ผลการปลด",
	`สาเหตุในการปลด`              	string       comment "Def(En): Exempt Description
Def(Th): สาเหตุในการปลด",
	`ปลดด้วยวิธีการแก้ไขหนี้ที่`  	string       comment "Def(En): Exempt Method Description
Def(Th): ปลดด้วยวิธีการแก้ไขหนี้ที่",
	`ช่วงเวลาที่ใช้ในกการปลด`     	string       comment "Def(En): Exempt Period
Def(Th): ช่วงเวลาที่ใช้ในการปลด",
	`วันที่ปลดสถานะ`              	string       comment "Def(En): Reschedule Result change date
Def(Th): วันที่ปลดสถานะ",
	`ผู้บันทึกปลดสถานะ`           	string       comment "Def(En): Reschedule Result change user ID
Def(Th): ผู้บันทึกปลดสถานะ",
	data_date                     	string       comment "Def(En): Data Month
Def(Th): เดือน/ปี ของข้อมูล",
	load_tms                      	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                    	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                      	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                        	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                        	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_tdr/lpm_tdr_ct1d408a' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);