-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_cis_ip.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_cis.cis_ip
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_cis.cis_ip set tags ('rbac_table_cis');


-- COMMAND ----------

alter table ${catalog}.persist_cis.cis_ip alter column ip_doc_id set tags ('rbac_rde_customer_id');
    

-- COMMAND ----------

alter table ${catalog}.persist_cis.cis_ip alter column ip_birth_dt set tags ('rbac_rde_birth_date');
    

-- COMMAND ----------

alter table ${catalog}.persist_cis.cis_ip alter column ip_local_nm set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_cis.cis_ip alter column ip_local_surnm set tags ('rbac_rde_surname');
    

-- COMMAND ----------

alter table ${catalog}.persist_cis.cis_ip alter column ip_local_mid_nm set tags ('rbac_rde_middle_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_cis.cis_ip alter column ip_en_nm set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_cis.cis_ip alter column ip_en_surnm set tags ('rbac_rde_surname');
    

-- COMMAND ----------

alter table ${catalog}.persist_cis.cis_ip alter column ip_en_mid_nm set tags ('rbac_rde_middle_name');
    