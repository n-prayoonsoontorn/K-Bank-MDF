-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_v_cis_cst_prfl.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_cis_view.v_cis_cst_prfl
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_cis_view.v_cis_cst_prfl set tags ('rbac_table_cis');


-- COMMAND ----------

alter table ${catalog}.persist_cis_view.v_cis_cst_prfl alter column id_doc_num set tags ('rbac_rde_customer_id');
    

-- COMMAND ----------

alter table ${catalog}.persist_cis_view.v_cis_cst_prfl alter column brth_dt set tags ('rbac_rde_birth_date');
    

-- COMMAND ----------

alter table ${catalog}.persist_cis_view.v_cis_cst_prfl alter column local_nm set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_cis_view.v_cis_cst_prfl alter column local_surnm set tags ('rbac_rde_surname');
    

-- COMMAND ----------

alter table ${catalog}.persist_cis_view.v_cis_cst_prfl alter column local_mid_nm set tags ('rbac_rde_middle_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_cis_view.v_cis_cst_prfl alter column eng_nm set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_cis_view.v_cis_cst_prfl alter column eng_surnm set tags ('rbac_rde_surname');
    

-- COMMAND ----------

alter table ${catalog}.persist_cis_view.v_cis_cst_prfl alter column eng_mid_nm set tags ('rbac_rde_middle_name');
    