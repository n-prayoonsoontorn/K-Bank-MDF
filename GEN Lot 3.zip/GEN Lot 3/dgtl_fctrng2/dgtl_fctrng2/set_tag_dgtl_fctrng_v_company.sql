-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_dgtl_fctrng_v_company.sql
# Area: dgtl_fctrng
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_dgtl_fctrng.dgtl_fctrng_v_company
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_dgtl_fctrng.dgtl_fctrng_v_company set tags ('rbac_table_dgtl_fctrng');


-- COMMAND ----------

alter table ${catalog}.persist_dgtl_fctrng.dgtl_fctrng_v_company alter column compnameth set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_dgtl_fctrng.dgtl_fctrng_v_company alter column compnameen set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_dgtl_fctrng.dgtl_fctrng_v_company alter column docno set tags ('rbac_rde_customer_id');
    

-- COMMAND ----------

alter table ${catalog}.persist_dgtl_fctrng.dgtl_fctrng_v_company alter column policyno set tags ('rbac_rde_policy_number');
    