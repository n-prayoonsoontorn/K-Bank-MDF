-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_v_dgtl_fctrng_lmt_sellr_prfl.sql
# Area: dgtl_fctrng
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_dgtl_fctrng_view.v_dgtl_fctrng_lmt_sellr_prfl
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_dgtl_fctrng_view.v_dgtl_fctrng_lmt_sellr_prfl set tags ('rbac_table_dgtl_fctrng');


-- COMMAND ----------

alter table ${catalog}.persist_dgtl_fctrng_view.v_dgtl_fctrng_lmt_sellr_prfl alter column clnt_th_nm set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_dgtl_fctrng_view.v_dgtl_fctrng_lmt_sellr_prfl alter column clnt_eng_nm set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_dgtl_fctrng_view.v_dgtl_fctrng_lmt_sellr_prfl alter column doc_id_num set tags ('rbac_rde_customer_id');
    

-- COMMAND ----------

alter table ${catalog}.persist_dgtl_fctrng_view.v_dgtl_fctrng_lmt_sellr_prfl alter column plcy_num set tags ('rbac_rde_policy_number');
    