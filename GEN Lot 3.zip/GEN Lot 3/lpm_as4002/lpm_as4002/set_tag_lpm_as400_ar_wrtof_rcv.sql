-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_lpm_as400_ar_wrtof_rcv.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_lpm_as400.lpm_as400_ar_wrtof_rcv
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_lpm_as400.lpm_as400_ar_wrtof_rcv set tags ('rbac_table_lpm_as400');


-- COMMAND ----------

alter table ${catalog}.persist_lpm_as400.lpm_as400_ar_wrtof_rcv alter column l01d070_acct_no set tags ('rbac_rde_loan_number');
    