-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_lpm_as400_lmt_ar_inf_bfr_wrtof.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_lpm_as400.lpm_as400_lmt_ar_inf_bfr_wrtof
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_lpm_as400.lpm_as400_lmt_ar_inf_bfr_wrtof set tags ('rbac_table_lpm_as400');


-- COMMAND ----------

alter table ${catalog}.persist_lpm_as400.lpm_as400_lmt_ar_inf_bfr_wrtof alter column lmd23400_acct_no set tags ('rbac_rde_loan_number');
    

-- COMMAND ----------

alter table ${catalog}.persist_lpm_as400.lpm_as400_lmt_ar_inf_bfr_wrtof alter column lmd23400_acct_type_sub set tags ('rbac_rde_loan_number');
    