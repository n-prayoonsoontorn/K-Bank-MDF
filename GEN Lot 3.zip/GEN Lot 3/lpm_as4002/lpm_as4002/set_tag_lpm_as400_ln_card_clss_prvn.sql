-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_lpm_as400_ln_card_clss_prvn.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_lpm_as400.lpm_as400_ln_card_clss_prvn
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_lpm_as400.lpm_as400_ln_card_clss_prvn set tags ('rbac_table_lpm_as400');


-- COMMAND ----------

alter table ${catalog}.persist_lpm_as400.lpm_as400_ln_card_clss_prvn alter column l01w181_cust_name set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_lpm_as400.lpm_as400_ln_card_clss_prvn alter column l01w181_acct_no set tags ('rbac_rde_loan_number');
    

-- COMMAND ----------

alter table ${catalog}.persist_lpm_as400.lpm_as400_ln_card_clss_prvn alter column l01w181_birth_date set tags ('rbac_rde_birth_date');
    

-- COMMAND ----------

alter table ${catalog}.persist_lpm_as400.lpm_as400_ln_card_clss_prvn alter column l01w181_alt_cust_no set tags ('rbac_rde_card_number');
    

-- COMMAND ----------

alter table ${catalog}.persist_lpm_as400.lpm_as400_ln_card_clss_prvn alter column l01w181_id_no set tags ('rbac_rde_customer_id');
    