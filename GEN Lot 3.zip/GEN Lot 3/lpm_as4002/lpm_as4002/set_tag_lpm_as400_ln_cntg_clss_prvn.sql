-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_lpm_as400_ln_cntg_clss_prvn.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_lpm_as400.lpm_as400_ln_cntg_clss_prvn
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_lpm_as400.lpm_as400_ln_cntg_clss_prvn set tags ('rbac_table_lpm_as400');


-- COMMAND ----------

alter table ${catalog}.persist_lpm_as400.lpm_as400_ln_cntg_clss_prvn alter column l01w909_acct_no set tags ('rbac_rde_loan_number');
    