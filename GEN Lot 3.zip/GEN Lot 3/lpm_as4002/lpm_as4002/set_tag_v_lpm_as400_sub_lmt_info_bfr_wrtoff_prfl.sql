-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_v_lpm_as400_sub_lmt_info_bfr_wrtoff_prfl.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_lpm_as400_view.v_lpm_as400_sub_lmt_info_bfr_wrtoff_prfl
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_lpm_as400_view.v_lpm_as400_sub_lmt_info_bfr_wrtoff_prfl set tags ('rbac_table_lpm_as400');
