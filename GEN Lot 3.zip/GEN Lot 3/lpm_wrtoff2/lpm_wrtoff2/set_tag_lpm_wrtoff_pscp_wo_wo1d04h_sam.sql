-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_lpm_wrtoff_pscp_wo_wo1d04h_sam.sql
# Area: lpm_wrtoff
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_lpm_wrtoff.lpm_wrtoff_pscp_wo_wo1d04h_sam
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_lpm_wrtoff.lpm_wrtoff_pscp_wo_wo1d04h_sam set tags ('rbac_table_lpm_wrtoff');


-- COMMAND ----------

alter table ${catalog}.persist_lpm_wrtoff.lpm_wrtoff_pscp_wo_wo1d04h_sam alter column wo04_account_no set tags ('rbac_rde_loan_number');
    