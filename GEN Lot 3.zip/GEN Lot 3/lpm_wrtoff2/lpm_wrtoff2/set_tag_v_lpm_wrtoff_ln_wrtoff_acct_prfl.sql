-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_v_lpm_wrtoff_ln_wrtoff_acct_prfl.sql
# Area: lpm_wrtoff
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_lpm_wrtoff_view.v_lpm_wrtoff_ln_wrtoff_acct_prfl
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_lpm_wrtoff_view.v_lpm_wrtoff_ln_wrtoff_acct_prfl set tags ('rbac_table_lpm_wrtoff');


-- COMMAND ----------

alter table ${catalog}.persist_lpm_wrtoff_view.v_lpm_wrtoff_ln_wrtoff_acct_prfl alter column acct_num set tags ('rbac_rde_loan_number');
    