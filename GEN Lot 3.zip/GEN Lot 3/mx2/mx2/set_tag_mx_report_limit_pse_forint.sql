-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_mx_report_limit_pse_forint.sql
# Area: mx
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_mx.mx_report_limit_pse_forint
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_mx.mx_report_limit_pse_forint set tags ('rbac_table_mx');


-- COMMAND ----------

alter table ${catalog}.persist_mx.mx_report_limit_pse_forint alter column fullname set tags ('rbac_rde_name');
    