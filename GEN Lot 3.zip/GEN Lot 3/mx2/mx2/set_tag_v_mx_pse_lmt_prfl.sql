-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_v_mx_pse_lmt_prfl.sql
# Area: mx
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_mx_view.v_mx_pse_lmt_prfl
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_mx_view.v_mx_pse_lmt_prfl set tags ('rbac_table_mx');


-- COMMAND ----------

alter table ${catalog}.persist_mx_view.v_mx_pse_lmt_prfl alter column orig_cst_nm set tags ('rbac_rde_name');
    