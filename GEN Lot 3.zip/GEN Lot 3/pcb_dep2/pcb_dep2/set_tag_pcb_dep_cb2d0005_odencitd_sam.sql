-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_pcb_dep_cb2d0005_odencitd_sam.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_pcb_dep.pcb_dep_cb2d0005_odencitd_sam
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_cb2d0005_odencitd_sam set tags ('rbac_table_pcb_dep');


-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_cb2d0005_odencitd_sam alter column ar_id set tags ('rbac_rde_account_number');
    