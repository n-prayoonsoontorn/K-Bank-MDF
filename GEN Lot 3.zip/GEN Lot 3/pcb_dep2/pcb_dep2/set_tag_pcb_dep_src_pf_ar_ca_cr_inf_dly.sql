-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_pcb_dep_src_pf_ar_ca_cr_inf_dly.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_pcb_dep.pcb_dep_src_pf_ar_ca_cr_inf_dly
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_ar_ca_cr_inf_dly set tags ('rbac_table_pcb_dep');


-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_ar_ca_cr_inf_dly alter column accountnumber set tags ('rbac_rde_account_number');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_ar_ca_cr_inf_dly alter column accountnameeng set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_ar_ca_cr_inf_dly alter column accountnamethai set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_ar_ca_cr_inf_dly alter column accountarrangementaddress1 set tags ('rbac_rde_address');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_ar_ca_cr_inf_dly alter column accountarrangementaddress2 set tags ('rbac_rde_address');
    