-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_pcb_dep_src_pf_ar_ca_dly.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_pcb_dep.pcb_dep_src_pf_ar_ca_dly
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_ar_ca_dly set tags ('rbac_table_pcb_dep');


-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_ar_ca_dly alter column ar_id set tags ('rbac_rde_account_number');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_ar_ca_dly alter column ar_nm_th set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_ar_ca_dly alter column ar_nm_eng set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_ar_ca_dly alter column tax_id set tags ('rbac_rde_tax_id');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_ar_ca_dly alter column citizen_id set tags ('rbac_rde_national_id_number');
    