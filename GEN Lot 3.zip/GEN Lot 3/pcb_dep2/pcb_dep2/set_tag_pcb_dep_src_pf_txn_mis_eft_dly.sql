-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_pcb_dep_src_pf_txn_mis_eft_dly.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_pcb_dep.pcb_dep_src_pf_txn_mis_eft_dly
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_txn_mis_eft_dly set tags ('rbac_table_pcb_dep');


-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_txn_mis_eft_dly alter column fm_ar_id set tags ('rbac_rde_account_number');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_txn_mis_eft_dly alter column to_ar_id set tags ('rbac_rde_account_number');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_txn_mis_eft_dly alter column eft_co_th_nm set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_txn_mis_eft_dly alter column eft_co_en_nm set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep.pcb_dep_src_pf_txn_mis_eft_dly alter column eft_cst_nm set tags ('rbac_rde_name');
    