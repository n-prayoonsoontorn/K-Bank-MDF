-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_v_pcb_dep_ca_cr_prfl.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_pcb_dep_view.v_pcb_dep_ca_cr_prfl
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_ca_cr_prfl set tags ('rbac_table_pcb_dep');


-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_ca_cr_prfl alter column acct_num set tags ('rbac_rde_account_number');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_ca_cr_prfl alter column acct_eng_nm set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_ca_cr_prfl alter column acct_th_nm set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_ca_cr_prfl alter column acct_ctc_addr_line_1 set tags ('rbac_rde_address');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_ca_cr_prfl alter column acct_ctc_addr_line_2 set tags ('rbac_rde_address');
    