-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_v_pcb_dep_dep_txn.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_pcb_dep_view.v_pcb_dep_dep_txn
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_dep_txn set tags ('rbac_table_pcb_dep');


-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_dep_txn alter column acct_num set tags ('rbac_rde_account_number');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_dep_txn alter column intnl_sub_acct_num set tags ('rbac_rde_account_number');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_dep_txn alter column from_to_acct_num set tags ('rbac_rde_account_number');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_dep_txn alter column from_to_intnl_acct_num set tags ('rbac_rde_account_number');
    