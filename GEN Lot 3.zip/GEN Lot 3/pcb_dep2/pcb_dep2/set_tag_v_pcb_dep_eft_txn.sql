-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_v_pcb_dep_eft_txn.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_pcb_dep_view.v_pcb_dep_eft_txn
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_eft_txn set tags ('rbac_table_pcb_dep');


-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_eft_txn alter column sendr_acct_num set tags ('rbac_rde_account_number');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_eft_txn alter column rcpnt_acct_num set tags ('rbac_rde_account_number');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_eft_txn alter column rcpnt_acct_th_nm set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_eft_txn alter column rcpnt_acct_eng_nm set tags ('rbac_rde_name');
    

-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_eft_txn alter column sendr_cst_nm set tags ('rbac_rde_name');
    