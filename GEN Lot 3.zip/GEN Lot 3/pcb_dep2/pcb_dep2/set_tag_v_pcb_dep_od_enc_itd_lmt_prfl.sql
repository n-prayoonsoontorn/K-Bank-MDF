-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_v_pcb_dep_od_enc_itd_lmt_prfl.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_pcb_dep_view.v_pcb_dep_od_enc_itd_lmt_prfl
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_od_enc_itd_lmt_prfl set tags ('rbac_table_pcb_dep');


-- COMMAND ----------

alter table ${catalog}.persist_pcb_dep_view.v_pcb_dep_od_enc_itd_lmt_prfl alter column acct_num set tags ('rbac_rde_account_number');
    