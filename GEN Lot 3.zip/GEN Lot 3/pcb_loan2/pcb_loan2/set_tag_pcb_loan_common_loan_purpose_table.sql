-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_pcb_loan_common_loan_purpose_table.sql
# Area: pcb_loan
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_pcb_loan.pcb_loan_common_loan_purpose_table
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_pcb_loan.pcb_loan_common_loan_purpose_table set tags ('rbac_table_pcb_loan');
