-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_pcb_loan_common_rate_type.sql
# Area: pcb_loan
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-06-10         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_pcb_loan.pcb_loan_common_rate_type
#--------------------------------------------------------------------------------------------------*/


-- COMMAND ----------

alter table ${catalog}.persist_pcb_loan.pcb_loan_common_rate_type set tags ('rbac_table_pcb_loan');
