# Databricks notebook source
# MAGIC %fs
# MAGIC ls /Volumes/mdpdev/inbound/source_file/mdp/cardlink

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT  COUNT(*) AS record_count
# MAGIC FROM mdpdev.raw_ud.ud_vw_flt_dp_div_cert_inc
# MAGIC Where pos_dt = '2024-04-04'

# COMMAND ----------

# Read the file into a DataFrame
df = spark.read.text("/Volumes/mdpdev/inbound/source_file/mdp/cardlink/CPACP.DIH.KB1DH014.CC1DMPGL.D310324")

# Display the last row
last_row = df.tail(5)[1]
print(last_row)

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /Volumes/mdpdev/inbound/source_file/mdp/gts/

# COMMAND ----------



# COMMAND ----------


import os
directory = '/Volumes/mdpdev/inbound/source_file/mdp/scf'

# List files in the directory
files = os.listdir(directory)

# Filter files with names ending in ".txt" or ".TXT"
txt_files = [file for file in files if file.endswith('.txt') or file.endswith('.TXT')]

# Print the filtered files
for txt_file in txt_files:
    print(txt_file)

# COMMAND ----------

import os

directory = '/Volumes/mdpdev/inbound/source_file/mdp/pcb_dep'

# List files in the directory
files = os.listdir(directory)

# txt_files = [file for file in files if file.endswith('.txt') or file.endswith('.TXT')]


txt_files = [file for file in files if os.path.splitext(file)[1].lower() in ['.txt', '.TXT'] or not any(file.endswith(ext) for ext in ['.txt', '.TXT'])]

# Create a list to store table names and their corresponding latest dates as tuples
table_latest_dates_list = []

# Iterate over each file
for file_name in txt_files:
    # Extract the table name from the file name
    parts = file_name.split('_')

    # Join the first parts excluding the last one
    table_name = '_'.join(parts[:-1])

    # Extract the date from the file name and format it as 'YYYYMMDD'
    date = parts[-1].split('.')[0]

    # Check if the table name already exists in the list
    for i, (name, _) in enumerate(table_latest_dates_list):
        if name == table_name:
            # If the current date is later than the stored date, update it
            if date > table_latest_dates_list[i][1]:
                table_latest_dates_list[i] = (table_name, date)
            break
    else:
        # If the table name is not in the list, add it with the current date
        table_latest_dates_list.append((table_name, date))

# Print the result in the desired format
for table_name, latest_date in table_latest_dates_list:
    print(f"'{table_name}': {latest_date}")


# COMMAND ----------

import os

directory = '/Volumes/mdpdev/inbound/source_file/mdp/dgtl_fctrng'

# List files in the directory
files = os.listdir(directory)

# txt_files = [file for file in files if file.endswith('.txt') or file.endswith('.TXT')]


txt_files = [file for file in files if os.path.splitext(file)[1].lower() in ['.txt', '.TXT'] or not any(file.endswith(ext) for ext in ['.txt', '.TXT'])]

# Create a list to store table names and their corresponding latest dates as tuples
table_latest_dates_list = []

# Iterate over each file
for file_name in txt_files:
    # Extract the table name from the file name
    parts = file_name.split('_')

    # Join the first parts excluding the last one
    table_name = '_'.join(parts[:-1])

    # Extract the date from the file name and format it as 'YYYYMMDD'
    date = parts[-1].split('.')[0]

    # Check if the table name already exists in the list
    for i, (name, _) in enumerate(table_latest_dates_list):
        if name == table_name:
            # If the current date is later than the stored date, update it
            if date > table_latest_dates_list[i][1]:
                table_latest_dates_list[i] = (table_name, date)
            break
    else:
        # If the table name is not in the list, add it with the current date
        table_latest_dates_list.append((table_name, date))

# Print the result in the desired format
for table_name, latest_date in table_latest_dates_list:
    print(f"'{table_name}': {latest_date}")


# COMMAND ----------

# Function to convert date format from 'YYYYMMDD' to 'YYYY-MM-DD'
##--------------------STEP CONVERT TO YYYY-MM-DD FOR DOC

def convert_date_format(date):
    return f"{date[:4]}-{date[4:6]}-{date[6:]}"

# Given table dates
table_dates = {
'FCD_AR': 20240320,
}



# Convert to desired format
for table_name, date in table_dates.items():
    # Convert date format
    formatted_date = convert_date_format(str(date))
    print(f"Table {table_name}: {formatted_date}")

# COMMAND ----------

# Function to convert date format to 'yyyy-mm-dd' wiht replace YYYYMMD
#--------------------------STEP GENERATE EXECUTE FOR JOBRUN 
import os
##RETRIVE NAME FOR CREATE RUN JOB

src_sys = 'mnul'

directory_config = '/Volumes/mdpdev/artifact/config/mdp/ingest/{}/'.format(src_sys)

files_name_job_config_in_directory = [f for f in os.listdir(directory_config) if os.path.isfile(os.path.join(directory_config, f))]



def format_date(date):
    year = date[:4]
    month = date[4:6]
    day = date[6:]
    return f"{year}-{month}-{day}"

# Environment variable
env = '{env}'


for file_name in files_name_job_config_in_directory:
    # Format the date

    date = "20202020"
    formatted_date = format_date(str(date))
    
    # Construct the job config path
    job_config_path = f"/Volumes/mdp{env}/artifact/config/mdp/ingest/{src_sys}/{file_name}"


    # Split the filename by underscores
    filename_parts = file_name.split('.')

    # Take the first part and remove the "job_config_" prefix
    extracted_part = filename_parts[0].replace('job_config_', '')

    
    # Print in the desired format
    print(f"{{'job_name': '{extracted_part}', 'pos_dt': '{formatted_date}', 'job_config': '{job_config_path}'}},")



# COMMAND ----------

# MAGIC %sql
# MAGIC select * from mdpdev.raw_scf.scf_customer
# MAGIC

# COMMAND ----------

import os
from pyspark.sql.window import Window
from pyspark.sql.functions import desc,row_number,col
schema_list = ['persist_cardlink']
fw_log_df = spark.table(f'mdpdev.fw_log.ingestion') \
                .filter(col('persist_database_name').isin(schema_list)) \
                .withColumn('rank', row_number().over(
                        Window.partitionBy("job_name").orderBy(desc("job_start_datetime"))
                ))\
                .filter(col('rank')==1)
 
# fw_log_df.display()
# for select columns
# column_list = ['job_status','job_name','pos_dt','job_message','persist_record_count','job_start_datetime','job_url']
column_list = ['job_status','pos_dt','job_name','persist_table_name','job_end_datetime','job_message','source_record_count','persist_record_count','job_url']
fw_log_df.select(column_list).display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from mdpdev.persist_pcb_dep.pcb_dep_cb2d0005_odencitd_sam 
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC  select * from mdpdev.persist_ks_view.v_ks_ks_fund_info_cl
# MAGIC limit 1;
# MAGIC
# MAGIC

# COMMAND ----------

# Import the necessary libraries
from pyspark.sql import SparkSession

# Create a SparkSession
spark = SparkSession.builder \
    .appName("QueryData") \
    .getOrCreate()

# Define the SQL query to select distinct values across all columns and limit to 4 rows
sql_query = """
SELECT DISTINCT * FROM mdpdev.persist_mx_view.v_mx_pse_lmt_utlz_prfl		
LIMIT 10
"""

# Execute the SQL query
df = spark.sql(sql_query)

# Get the column names
columns = df.columns

# Display column names
print("Column Names:")
for col in columns:
    print(col)

# Display values for each row
print("\nValues:")
for row in df.collect():
    for col, val in zip(columns, row):
        print(f"{col}: {val}")
    print()


# COMMAND ----------

# Import the necessary libraries
from pyspark.sql import SparkSession

# Create a SparkSession
spark = SparkSession.builder \
    .appName("QueryData") \
    .getOrCreate()

# Define the SQL query to select distinct values across all columns and limit to 4 rows
sql_query = """
SELECT DISTINCT bad_bank_cst_f FROM  mdpdev.persist_mx_view.v_mx_pse_lmt_utlz_prfl
"""

# Execute the SQL query
df = spark.sql(sql_query)

# Get the column names
columns = df.columns

# Display column names
print("Column Names:")
for col in columns:
    print(col)

# Display values for each row
print("\nValues:")
for row in df.collect():
    for col, val in zip(columns, row):
        print(f"{col}: {val}")
    print()


# COMMAND ----------

from pyspark.sql import SparkSession
import re
 
# Initialize Spark session
spark = SparkSession.builder.appName("ColumnComparison").getOrCreate()
 
# Define table and view names
table_names = [
    "persist_ud.ud_vw_transactionext"

]
view_names = [
    "persist_ud_view.v_ud_fund_txn"

]
 
# Function to check if a table or view exists
def table_or_view_exists(name):
    try:
        spark.sql(f"DESCRIBE {name}")
        return True
    except:
        return False
 
# Initialize an empty list to store results
results = []
 
# Iterate over each table and view name
# Iterate over each table and view name
for table_name, view_name in zip(table_names, view_names):
    # Check if table and view exist
    if not table_or_view_exists(table_name):
        raise Exception(f"Table {table_name} does not exist.")
    if not table_or_view_exists(view_name):
        raise Exception(f"View {view_name} does not exist.")
 
    # Fetch the table schema
    table_df = spark.table(table_name)
    table_columns = [field.name for field in table_df.schema]
 
    # Fetch the view definition
    view_definition = spark.sql(f"SHOW CREATE TABLE {view_name}").collect()[0][0]
 
    # Extract the SELECT statement from the view definition using regex
    # select_statement_match = re.search(r'SELECT(.*?)FROM', view_definition, re.DOTALL | re.IGNORECASE)
    select_statement_match = re.search(r'\bSELECT\b(.*?)\bFROM\b', view_definition, re.DOTALL | re.IGNORECASE)
    
    if not select_statement_match:
        raise Exception(f"SELECT statement not found in view definition for {view_name}")
 
    # Extract the actual SELECT statement
    select_statement = select_statement_match.group(0)
    
    # Remove newline characters from the SELECT statement
    select_statement = select_statement.replace('\n', ' ')


 
    # Extract columns from the SELECT statement
    view_columns_with_aliases = re.findall(r'\b(\w+)\b\s+AS\s+\b(\w+)\b', select_statement, re.IGNORECASE)
    view_columns_without_aliases = re.findall(r'\b(\w+)\b(?!.*\bAS\b)', select_statement)
 
    # Combine columns with aliases and without aliases
    view_columns = [col[0] for col in view_columns_with_aliases] + view_columns_without_aliases
    view_columns = list(set(view_columns))  # Remove duplicates
 
    # Identify columns present in the table but not in the view
    unused_columns = [col for col in table_columns if col not in view_columns]
 
    # Check if all columns from the table are used in the view
    if not unused_columns:
        unused_columns = ["All columns from the table are used in the view"]
 
    # Append results to the list
    results.extend([(table_name, view_name, col) for col in unused_columns])
    

 
# Create the result DataFrame
result_df = spark.createDataFrame(results, ["table_name", "view_name", "Remark/Persist_column_name"])


 
# Display the result as a table
# display(result_df)
result_df.show(result_df.count(), truncate=False)