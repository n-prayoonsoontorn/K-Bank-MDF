# Databricks notebook source
##REMOVE DATA FROM SOURCE SYSTEM : KPLUS
dbutils.widgets.text("catalog","")

 

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_kplus.kplus_view_jmobile_log
# MAGIC
# MAGIC  

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_kplus.kplus_view_jmobile_log
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-05-29';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Check Data Date: persist_kplus.kplus_view_jmobile_log
# MAGIC  

# COMMAND ----------

# MAGIC  
# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_kplus.kplus_view_jmobile_log
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-05-29';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_kplus.kplus_jmobiletranloghd
# MAGIC
# MAGIC  

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_kplus.kplus_jmobiletranloghd
# MAGIC WHERE pos_dt BETWEEN '2024-05-06' AND '2024-05-29';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Check Data Date: persist_kplus.kplus_jmobiletranloghd
# MAGIC  

# COMMAND ----------

# MAGIC  
# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_kplus.kplus_jmobiletranloghd
# MAGIC WHERE pos_dt BETWEEN '2024-05-06' AND '2024-05-29';