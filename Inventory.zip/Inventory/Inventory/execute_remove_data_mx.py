# Databricks notebook source
##REMOVE DATA FROM SOURCE SYSTEM : MX
dbutils.widgets.text("catalog","")

 

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_mx.mx_report_limit_pse_forint
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_mx.mx_report_limit_pse_forint
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-18';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Check Data Date: persist_mx.mx_report_limit_pse_forint
# MAGIC  

# COMMAND ----------

# MAGIC  
# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_mx.mx_report_limit_pse_forint
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-18';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_mx.mx_report_limit_se_forint
# MAGIC
# MAGIC  

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_mx.mx_report_limit_se_forint
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-18';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Check Data Date: persist_mx.mx_report_limit_se_forint
# MAGIC  

# COMMAND ----------

# MAGIC  
# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_mx.mx_report_limit_se_forint
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-18';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_mx.mx_reset_lp_ctp_funded_forint
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_mx.mx_reset_lp_ctp_funded_forint
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-18';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Check Data Date: persist_mx.mx_reset_lp_ctp_funded_forint
# MAGIC  

# COMMAND ----------

# MAGIC  
# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_mx.mx_reset_lp_ctp_funded_forint
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-18';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_mx.mx_reset_mplcde_forint
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_mx.mx_reset_mplcde_forint
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-18';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Check Data Date: persist_mx.mx_reset_mplcde_forint
# MAGIC  

# COMMAND ----------

# MAGIC  
# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_mx.mx_reset_mplcde_forint
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-18';