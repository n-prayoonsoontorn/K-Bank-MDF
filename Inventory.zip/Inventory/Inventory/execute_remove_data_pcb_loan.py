# Databricks notebook source
##REMOVE DATA FROM SOURCE SYSTEM : PCB_LOAN
dbutils.widgets.text("catalog","")

 

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_pcb_loan.pcb_loan_common_account_info
# MAGIC
# MAGIC  

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_pcb_loan.pcb_loan_common_account_info
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-21';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Check Data Date: persist_pcb_loan.pcb_loan_common_account_info
# MAGIC  

# COMMAND ----------

# MAGIC  
# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_pcb_loan.pcb_loan_common_account_info
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-21';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_pcb_loan.pcb_loan_common_account_tier_by_time
# MAGIC
# MAGIC  

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_pcb_loan.pcb_loan_common_account_tier_by_time
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-05-06';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Check Data Date: persist_pcb_loan.pcb_loan_common_account_tier_by_time
# MAGIC  

# COMMAND ----------

# MAGIC  
# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_pcb_loan.pcb_loan_common_account_tier_by_time
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-05-06';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_pcb_loan.pcb_loan_common_limit_info

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_pcb_loan.pcb_loan_common_limit_info
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-21';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Check Data Date: persist_pcb_loan.pcb_loan_common_limit_info

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_pcb_loan.pcb_loan_common_limit_info
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-21';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_pcb_loan.pcb_loan_common_loan_purpose_table

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_pcb_loan.pcb_loan_common_loan_purpose_table
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-21';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Check Data Date: persist_pcb_loan.pcb_loan_common_loan_purpose_table

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_pcb_loan.pcb_loan_common_loan_purpose_table
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-21';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_pcb_loan.pcb_loan_common_market_code

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_pcb_loan.pcb_loan_common_market_code
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-21';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Check Data Date: persist_pcb_loan.pcb_loan_common_market_code

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_pcb_loan.pcb_loan_common_market_code
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-21';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_pcb_loan.pcb_loan_common_rate_type

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_pcb_loan.pcb_loan_common_rate_type
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-21';

# COMMAND ----------

# MAGIC
# MAGIC %md
# MAGIC # Check Data Date: persist_pcb_loan.pcb_loan_common_rate_type

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_pcb_loan.pcb_loan_common_rate_type
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-21';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_pcb_loan.pcb_loan_common_sub_type

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_pcb_loan.pcb_loan_common_sub_type
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-21';

# COMMAND ----------

# MAGIC
# MAGIC %md
# MAGIC # Check Data Date: persist_pcb_loan.pcb_loan_common_sub_type

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_pcb_loan.pcb_loan_common_sub_type
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-21';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_pcb_loan.pcb_loan_common_transaction_file

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_pcb_loan.pcb_loan_common_transaction_file
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-21';

# COMMAND ----------

# MAGIC
# MAGIC %md
# MAGIC # Check Data Date: persist_pcb_loan.pcb_loan_common_transaction_file

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_pcb_loan.pcb_loan_common_transaction_file
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-21';