# Databricks notebook source
##REMOVE DATA FROM SOURCE SYSTEM : SCF
dbutils.widgets.text("catalog","")

 

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_scf.scf_product_map
# MAGIC
# MAGIC  

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_scf.scf_product_map
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-22';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Check Data Date:  persist_scf.scf_product_map
# MAGIC  

# COMMAND ----------

# MAGIC  
# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_scf.scf_product_map
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-22';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_scf.scf_vw_rdt_scf_cl_acct
# MAGIC
# MAGIC  

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_scf.scf_vw_rdt_scf_cl_acct
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-22';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Check Data Date:  persist_scf.scf_vw_rdt_scf_cl_acct
# MAGIC  

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_scf.scf_vw_rdt_scf_cl_acct
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-22';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_scf.scf_vw_rdt_scf_cl
# MAGIC
# MAGIC  

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_scf.scf_vw_rdt_scf_cl
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-22';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Check Data Date:  persist_scf.scf_vw_rdt_scf_cl

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_scf.scf_vw_rdt_scf_cl
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-22';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_scf.scf_vw_scm_acct
# MAGIC
# MAGIC  

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_scf.scf_vw_scm_acct
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-22';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Check Data Date:  persist_scf.scf_vw_scm_acct

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt 
# MAGIC FROM ${catalog}.persist_scf.scf_vw_scm_acct
# MAGIC WHERE pos_dt BETWEEN '2024-04-16' AND '2024-04-22';