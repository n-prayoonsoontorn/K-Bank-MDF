# Databricks notebook source
##REMOVE DATA FROM SOURCE SYSTEM : UD
dbutils.widgets.text("catalog","")


 

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : persist_ud.ud_vw_t_su_sub_uh_ful
# MAGIC
# MAGIC >  

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_ud.ud_vw_t_su_sub_uh_ful
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Delete Data : raw_ud.ud_vw_t_su_sub_uh_ful
# MAGIC
# MAGIC  

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.raw_ud.ud_vw_t_su_sub_uh_ful
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC  
# MAGIC %md
# MAGIC # Check Data Date: persist_ud.ud_vw_t_su_sub_uh_ful
# MAGIC  

# COMMAND ----------

# MAGIC  
# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.persist_ud.ud_vw_t_su_sub_uh_ful
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: raw_ud.ud_vw_t_su_sub_uh_ful
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.raw_ud.ud_vw_t_su_sub_uh_ful
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Delete Data : persist_ud.ud_vw_t_uh_uh_ful
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_ud.ud_vw_t_uh_uh_ful
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Delete Data : raw_ud.ud_vw_t_uh_uh_ful
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.raw_ud.ud_vw_t_uh_uh_ful
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: persist_ud.ud_vw_t_uh_uh_ful
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.persist_ud.ud_vw_t_uh_uh_ful
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: raw_ud.ud_vw_t_uh_uh_ful
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.raw_ud.ud_vw_t_uh_uh_ful
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Delete Data : persist_ud.ud_vw_transactioneodext
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_ud.ud_vw_transactioneodext
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Delete Data : raw_ud.ud_vw_transactioneodext
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.raw_ud.ud_vw_transactioneodext
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: persist_ud.ud_vw_transactioneodext
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.persist_ud.ud_vw_transactioneodext
# MAGIC WHERE pos_dt <= '2024-05-28';
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: raw_ud.ud_vw_transactioneodext
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.raw_ud.ud_vw_transactioneodext
# MAGIC WHERE pos_dt <= '2024-05-28';
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Delete Data : persist_ud.ud_vw_transactionext
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_ud.ud_vw_transactionext
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Delete Data : raw_ud.ud_vw_transactionext
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.raw_ud.ud_vw_transactionext
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: persist_ud.ud_vw_transactionext
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.persist_ud.ud_vw_transactionext
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: raw_ud.ud_vw_transactionext
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.raw_ud.ud_vw_transactionext
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Delete Data : persist_ud.ud_vw_fi_fnd_inf_ful
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_ud.ud_vw_fi_fnd_inf_ful
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Delete Data : raw_ud.ud_vw_fi_fnd_inf_ful
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.raw_ud.ud_vw_fi_fnd_inf_ful
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: persist_ud.ud_vw_fi_fnd_inf_ful
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.persist_ud.ud_vw_fi_fnd_inf_ful
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: raw_ud.ud_vw_fi_fnd_inf_ful
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.raw_ud.ud_vw_fi_fnd_inf_ful
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Delete Data : persist_ud.ud_vw_flt_div_pmt_inc
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_ud.ud_vw_flt_div_pmt_inc
# MAGIC WHERE pos_dt <= '2024-05-28';
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Delete Data : raw_ud.ud_vw_flt_div_pmt_inc
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.raw_ud.ud_vw_flt_div_pmt_inc
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: persist_ud.ud_vw_flt_div_pmt_inc
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.persist_ud.ud_vw_flt_div_pmt_inc
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: raw_ud.ud_vw_flt_div_pmt_inc
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.raw_ud.ud_vw_flt_div_pmt_inc
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Delete Data : persist_ud.ud_vw_flt_dp_div_cert_inc
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_ud.ud_vw_flt_dp_div_cert_inc
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Delete Data : raw_ud.ud_vw_flt_dp_div_cert_inc
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.raw_ud.ud_vw_flt_dp_div_cert_inc
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: persist_ud.ud_vw_flt_dp_div_cert_inc
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.persist_ud.ud_vw_flt_dp_div_cert_inc
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: raw_ud.ud_vw_flt_dp_div_cert_inc
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.raw_ud.ud_vw_flt_dp_div_cert_inc
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Delete Data : persist_ud.ud_vw_kgroup_sidetexttbl
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_ud.ud_vw_kgroup_sidetexttbl
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Delete Data : raw_ud.ud_vw_kgroup_sidetexttbl
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.raw_ud.ud_vw_kgroup_sidetexttbl
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: persist_ud.ud_vw_kgroup_sidetexttbl
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.persist_ud.ud_vw_kgroup_sidetexttbl
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: raw_ud.ud_vw_kgroup_sidetexttbl
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.raw_ud.ud_vw_kgroup_sidetexttbl
# MAGIC WHERE pos_dt <= '2024-05-28';

# COMMAND ----------

# MAGIC %md
# MAGIC # Delete Data : persist_ud.ud_vw_flt_rl_sub_bal_enq
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.persist_ud.ud_vw_flt_rl_sub_bal_enq
# MAGIC WHERE pos_dt <= '2024-04-22';

# COMMAND ----------

# MAGIC %md
# MAGIC # Delete Data : raw_ud.ud_vw_flt_rl_sub_bal_enq
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM ${catalog}.raw_ud.ud_vw_flt_rl_sub_bal_enq
# MAGIC WHERE pos_dt <= '2024-04-22';

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: persist_ud.ud_vw_flt_rl_sub_bal_enq

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.persist_ud.ud_vw_flt_rl_sub_bal_enq
# MAGIC WHERE pos_dt <= '2024-04-22';

# COMMAND ----------

# MAGIC %md
# MAGIC # Check Data Date: raw_ud.ud_vw_flt_rl_sub_bal_enq

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT pos_dt
# MAGIC FROM ${catalog}.raw_ud.ud_vw_flt_rl_sub_bal_enq
# MAGIC WHERE pos_dt <= '2024-04-22';