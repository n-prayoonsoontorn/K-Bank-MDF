-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: db_init_persist_cardlink.sql
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-07    Pinyarat C.         Initial Version
#
# Database(s): ${catalog}.persist_cardlink
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create database if not exists ${catalog}.persist_cardlink managed location 'abfss://${storage_persist}/${catalog}/persist_cardlink';