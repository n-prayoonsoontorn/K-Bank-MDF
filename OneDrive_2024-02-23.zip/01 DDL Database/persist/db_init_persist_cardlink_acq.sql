-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: db_init_persist_cardlink_acq.sql
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-07    Pinyarat C.         Initial Version
#
# Database(s): ${catalog}.persist_cardlink_acq
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create database if not exists ${catalog}.persist_cardlink_acq managed location 'abfss://${storage_persist}/${catalog}/persist_cardlink_acq';