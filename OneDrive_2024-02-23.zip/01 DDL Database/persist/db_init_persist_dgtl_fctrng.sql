-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: db_init_persist_dgtl_fctrng.sql
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-07    Pinyarat C.         Initial Version
#
# Database(s): ${catalog}.persist_dgtl_fctrng
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create database if not exists ${catalog}.persist_dgtl_fctrng managed location 'abfss://${storage_persist}/${catalog}/persist_dgtl_fctrng';