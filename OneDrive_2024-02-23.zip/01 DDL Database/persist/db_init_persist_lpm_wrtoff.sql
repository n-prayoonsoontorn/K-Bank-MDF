-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: db_init_persist_lpm_wrtoff.sql
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-07    Pinyarat C.         Initial Version
#
# Database(s): ${catalog}.persist_lpm_wrtoff
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create database if not exists ${catalog}.persist_lpm_wrtoff managed location 'abfss://${storage_persist}/${catalog}/persist_lpm_wrtoff';