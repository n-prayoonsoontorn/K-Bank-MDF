-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_fcd_fcdglsc.sql
# Area: fcd
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-06   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_FCD.FCD_FCDGLSC
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_fcd.fcd_fcdglsc (
	pos_dt    	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	glsc      	string       comment "Def(En): G/L Set Code
Def(Th):",
	cls       	string       comment "Def(En): Product Class
Def(Th):",
	grp       	string       comment "Def(En): Product Group
Def(Th):",
	desc      	string       comment "Def(En): Description
Def(Th):",
	dgl1      	bigint       comment "Def(En): Dep G/L # (Principal)
Def(Th):",
	dgl2      	bigint       comment "Def(En): Dep G/L # (Accrued Int)
Def(Th):",
	dgl3      	bigint       comment "Def(En): Dep G/L # (Penalty)
Def(Th):",
	dgl4      	bigint       comment "Def(En): Federal Withholding General Ledger Acc
Def(Th):",
	dgl5      	bigint       comment "Def(En): Dep G/L # (Escrow Suspense)
Def(Th):",
	dglf      	bigint       comment "Def(En): Dep G/L # (Fee Income)
Def(Th):",
	dgli      	bigint       comment "Def(En): Dep G/L # (Interest Expense)
Def(Th):",
	dglnb     	bigint       comment "Def(En): Deposit G/L # (Negative Balance Totals)
Def(Th):",
	load_tms  	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_fcd/fcd_fcdglsc' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);