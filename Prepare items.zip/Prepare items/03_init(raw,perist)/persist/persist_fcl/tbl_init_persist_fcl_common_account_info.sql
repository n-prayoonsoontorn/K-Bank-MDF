-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_fcl_common_account_info.sql
# Area: fcl
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-02   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_FCL.FCL_COMMON_ACCOUNT_INFO
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_fcl.fcl_common_account_info (
	pos_dt                   	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	cst_id                   	string       comment "Def(En): CIS ID
Def(Th):",
	ac_ar_id                 	string       comment "Def(En): Account Number
Def(Th):",
	prfl_ac_ar_id            	string       comment "Def(En): FCL Account Number
Def(Th):",
	lmt_ac_ar_id             	string       comment "Def(En): Limit Account ID
Def(Th):",
	prfl_lmt_ac_ar_id        	string       comment "Def(En): FCL Limit Account ID
Def(Th):",
	opn_dt                   	date         comment "Def(En): Account Opening Date - CC (YYYYMMDD)
Def(Th):",
	eff_dt                   	date         comment "Def(En): Effective Date
Def(Th):",
	ctr_dt                   	date         comment "Def(En): Contract Date
Def(Th):",
	ctr_mat_dt               	date         comment "Def(En): Contract Maturity Date
Def(Th):",
	cls_dt                   	date         comment "Def(En): Close Date
Def(Th):",
	ctr_ar_term_prd          	smallint     comment "Def(En): Contract Account Term Period
Def(Th):",
	ctr_ar_term_unit_id      	string       comment "Def(En): Contract Account Term Period Unit
Def(Th):",
	lmt_amt                  	decimal(17,2) comment "Def(En): Limit Amount (Currency)
Def(Th):",
	ccy_code                 	string       comment "Def(En): Currency 
Def(Th):",
	eff_int_rate             	decimal(8,5) comment "Def(En): Effective interest rate
Def(Th):",
	eff_int_rate_typ_id      	string       comment "Def(En): Effective Interest rate type ID
Def(Th):",
	eff_sprd_int_sign        	string       comment "Def(En): Effective Spread Interest Rate
Def(Th):",
	eff_sprd_int_rate        	decimal(8,5) comment "Def(En): Effective Spread Interest Rate
Def(Th):",
	pnp_amt                  	decimal(17,2) comment "Def(En): Principal Amount(Currency)
Def(Th):",
	acr_int_amt              	decimal(17,2) comment "Def(En): Accrued Interest Amount(Currency)
Def(Th):",
	int_late_chrg_amt        	decimal(17,2) comment "Def(En): Accrued Interest Late Charge (Currency)
Def(Th):",
	late_int_rate_tp_id      	string       comment "Def(En): Late charge index interest
Def(Th): Late charge index interest ที่ถูก default มาจาก MKT Code (ค่าจะเป็นเท่าไหร่ให้ไปดู Interest Index table)",
	otsnd_bal_amt            	decimal(17,2) comment "Def(En): Outstanding Balance Amount (Currency)
Def(Th):",
	tot_dr_txn_amt           	decimal(17,2) comment "Def(En): Total Debit Transaction Amount (Currency)
Def(Th):",
	dsbt_dt                  	date         comment "Def(En): Disbursement Date
Def(Th):",
	refr_ddcn_ac             	string       comment "Def(En): Reference Deduction Account Number
Def(Th):",
	last_pymt_dt             	date         comment "Def(En): Last Payment Date
Def(Th):",
	upd_bill_amt             	decimal(17,2) comment "Def(En): Unpaid Bill Amount (รวม Late Charge ในบิล)
Def(Th):",
	upd_int_bill_amt         	decimal(17,2) comment "Def(En): Unpaid Interest Bill Amount + Unpaid Late Charge Bill Amount
Def(Th):",
	ac_typ_flg               	smallint     comment "Def(En): Account Type Flag
Def(Th):",
	acm_rpymt_amt            	decimal(17,2) comment "Def(En): Accumulate Repayment Amount
Def(Th):",
	ac_sts_id                	string       comment "Def(En): Account status ID
Def(Th):",
	ar_nm_th                 	string       comment "Def(En): Arrangement Thai Name
Def(Th):",
	ar_nm_eng                	string       comment "Def(En): Arrangement English Name
Def(Th):",
	br_nbr                   	string       comment "Def(En): Branch Number of that Account Arrangement (Owner Branch)
Def(Th):",
	pd_grp                   	string       comment "Def(En): FCL Product Group
Def(Th):",
	pd_typ                   	string       comment "Def(En): FCL Product Type
Def(Th):",
	sub_typ                  	string       comment "Def(En): FCL Product Sub Type
Def(Th):",
	mkt_code                 	string       comment "Def(En): FCL Market Code
Def(Th):",
	kbank_pd_code            	string       comment "Def(En): Kbank Product Code
Def(Th):",
	cst_typ_id               	string       comment "Def(En): Customer Type ID
Def(Th):",
	bsn_code_id              	string       comment "Def(En): Kbank Business code
Def(Th):",
	aprv_id                  	string       comment "Def(En): Approver ID
Def(Th):",
	mx_int_rate              	decimal(8,5) comment "Def(En): Maximum Interest Rate
Def(Th):",
	pny_int_rate             	decimal(8,5) comment "Def(En): Penalty Interest Rate
Def(Th):",
	grc_prd                  	smallint     comment "Def(En): Grace Period for Principal or Principal&Interest (unit in month), 
Def(Th):",
	int_chg_flg              	smallint     comment "Def(En): Interest Change Flag
Def(Th):",
	act_int_amt_in_mo        	decimal(15,2) comment "Def(En): The interest which system calculate in this month
Def(Th): เป็นรายได้ดอกเบี้ยรับในเดือน

Data As of วันสิ้นเดือน (Calendar day) - กรณีที่ไม่ใช่สิ้นเดือนจะเป็นค่าของ Last Calendar Day of Previous Month

Remark
กรณีบัญชีปิดระหว่างเดือน จะต้องคำนวณค่า Interest ตั้งแต่วันที่ 1 จนถึงวันปิดบัญชี",
	ddc_int_typ              	smallint     comment "Def(En): Deducted Interest Type
Def(Th):",
	coa_lgl_ent_pnp          	string       comment "Def(En): Chart of Account (Legal Entity): Company Code
Def(Th):",
	coa_rspl_cntr_pnp        	string       comment "Def(En): Chart of Account (Responsibility Centre)
Def(Th):",
	coa_ac_pnp               	string       comment "Def(En): Chart of Account (OGL Account Number)
Def(Th):",
	coa_fnc_pnp              	string       comment "Def(En): Chart of Account (Function)
Def(Th):",
	coa_line_of_bsn_pnp      	string       comment "Def(En): Chart of Account (Line of Business)
Def(Th):",
	coa_pd_pnp               	string       comment "Def(En): Chart of Account (Product)
Def(Th):",
	coa_intco_pnp            	string       comment "Def(En): Chart of Account (Inter Company)
Def(Th):",
	coa_inrco_pnp            	string       comment "Def(En): Chart of Account (Intra Company)
Def(Th):",
	coa_prj_pnp              	string       comment "Def(En): Chart of Account (Project)
Def(Th):",
	coa_futr_used1_pnp       	string       comment "Def(En): Chart of Account (Future Use 1)
Def(Th):",
	coa_futr_used2_pnp       	string       comment "Def(En): Chart of Account (Future Use 2)
Def(Th):",
	coa_pd_ftr_code_pnp      	string       comment "Def(En): Chart of Account (Product Feature Code)
Def(Th):",
	coa_lgl_ent_acr          	string       comment "Def(En): Chart of Account (Legal Entity) 
Def(Th):",
	coa_rspl_cntr_acr        	string       comment "Def(En): Chart of Account (Responsibility Centre)
Def(Th):",
	coa_ac_acr               	string       comment "Def(En): Chart of Account (OGL Account Number)
Def(Th):",
	coa_fnc_acr              	string       comment "Def(En): Chart of Account (Function)
Def(Th):",
	coa_line_of_bsn_acr      	string       comment "Def(En): Chart of Account (Line of Business)
Def(Th):",
	coa_pd_acr               	string       comment "Def(En): Chart of Account (Product)
Def(Th):",
	coa_intco_acr            	string       comment "Def(En): Chart of Account (Inter Company)
Def(Th):",
	coa_inrco_acr            	string       comment "Def(En): Chart of Account (Intra Company)
Def(Th):",
	coa_prj_acr              	string       comment "Def(En): Chart of Account (Project)
Def(Th):",
	coa_futr_used1_acr       	string       comment "Def(En): Chart of Account (Future Use 1)
Def(Th):",
	coa_futr_used2_acr       	string       comment "Def(En): Chart of Account (Future Use 2)
Def(Th):",
	coa_pd_ftr_code_acr      	string       comment "Def(En): Chart of Account (Product Feature Code)
Def(Th):",
	coa_lgl_ent_late_chrg    	string       comment "Def(En): Chart of Account (Legal Entity) 
Def(Th):",
	coa_rspl_cntr_late_chrg  	string       comment "Def(En): Chart of Account (Responsibility Centre)
Def(Th):",
	coa_ac_late_chrg         	string       comment "Def(En): Chart of Account (OGL Account Number)
Def(Th):",
	coa_fnc_late_chrg        	string       comment "Def(En): Chart of Account (Function)
Def(Th):",
	coa_line_of_bsn_late_chrg	string       comment "Def(En): Chart of Account (Line of Business)
Def(Th):",
	coa_pd_late_chrg         	string       comment "Def(En): Chart of Account (Product)
Def(Th):",
	coa_intco_late_chrg      	string       comment "Def(En): Chart of Account (Inter Company)
Def(Th):",
	coa_inrco_late_chrg      	string       comment "Def(En): Chart of Account (Intra Company)
Def(Th):",
	coa_prj_late_chrg        	string       comment "Def(En): Chart of Account (Project)
Def(Th):",
	coa_futr_used1_late_chrg 	string       comment "Def(En): Chart of Account (Future Use 1)
Def(Th):",
	coa_futr_used2_late_chrg 	string       comment "Def(En): Chart of Account (Future Use 2)
Def(Th):",
	coa_pd_ftr_code_late_chrg	string       comment "Def(En): Chart of Account (Product Feature Code)
Def(Th):",
	ac_adr1                  	string       comment "Def(En): 
Def(Th): ที่อยู่ 1 (ระดับบัญชี)",
	ac_adr2                  	string       comment "Def(En): 
Def(Th): ที่อยู่ 2 (ระดับบัญชี)",
	tot_instl                	integer      comment "Def(En):
Def(Th): จำนวนงวดตลอดอายุสัญญา
(รวมงวดผ่อนผันด้วย)
eg. 60 งวด",
	acm_act_pnp              	decimal(17,2) comment "Def(En):
Def(Th): ยอดชำระเงินต้น(Currency)
(สะสมจนถึงปัจจุบัน)",
	acm_act_acr_mem          	decimal(17,2) comment "Def(En): 
Def(Th): ยอดชำระดอกเบี้ยค้างรับทั้งหมด(Currency)
(สะสมจนถึงปัจจุบัน)",
	acm_act_late_chrg        	decimal(17,2) comment "Def(En): 
Def(Th): ยอดชำระดอกเบี้ยผิดนัด(Currency)(สะสมจนถึงปัจจุบัน)",
	due_amt                  	decimal(17,2) comment "Def(En): 
Def(Th): ยอดที่ต้องชำระ / ยอดเรียกเก็บเฉพาะล่าสุด (รวม Late Charge ในบิล)
(Currency)",
	odue_amt                 	decimal(17,2) comment "Def(En): 
Def(Th): ยอดค้างชำระ (รวม Late Charge ในบิล)
(Currency)",
	tot_due_amt              	decimal(17,2) comment "Def(En): 
Def(Th): ยอดที่ต้องชำระทั้งหมด
(ยอดค้างชำระ + ยอดที่ต้องชำระ) (รวม Late Charge ในบิล)
(Currency)",
	dt_pay_due               	date         comment "Def(En): 
Def(Th): วันที่ครบกำหนดชำระล่าสุด
เช่นชำระทุกวันที่ 30 , Current Date 25/7/2016 
DT_PAY_DUE = 30/6/2016",
	del_inq_day              	integer      comment "Def(En): 
Def(Th): จำนวนวันค้างชำระ
จำนวนวันค้างต้นหรือดอก",
	odue_prd                 	integer      comment "Def(En): 
Def(Th): จำนวนงวดที่ค้างชำระ",
	odue_dt                  	date         comment "Def(En): 
Def(Th): วันที่เริ่มค้างชำระ",
	nxt_pymt_dt              	date         comment "Def(En): Next Payment Date
Def(Th):",
	nxt_pymt_amt             	decimal(17,2) comment "Def(En): Next Payment Amount (Currency)
Def(Th):",
	eff_int_rate_typ_prfl    	string       comment "Def(En): Effective Interest rate type ID FCL
Def(Th):",
	rate_flg                 	smallint     comment "Def(En): Rate Flag
Def(Th):",
	bill_seq_no              	smallint     comment "Def(En): Billing sequence number
Def(Th):",
	ren_code                 	string       comment "Def(En): Maturity Renewal Code
Def(Th):",
	pmt_act_grid             	string       comment "Def(En): Payment Due Action Grid
Def(Th):",
	lmt_amt_thb              	decimal(17,2) comment "Def(En): Limit Amount เทียบเท่าบาท
Def(Th):",
	pnp_amt_thb              	decimal(17,2) comment "Def(En): Principal Amount เทียบเท่าบาท
Def(Th):",
	acr_int_amt_thb          	decimal(17,2) comment "Def(En): Accrued Interest Amount เทียบเท่าบาท
Def(Th):",
	int_late_chrg_amt_thb    	decimal(17,2) comment "Def(En): Interest Late Charge เทียบเท่าบาท
Def(Th):",
	otsnd_bal_amt_thb        	decimal(17,2) comment "Def(En): Outstanding Balance Amount เทียบเท่าบาท
Def(Th):",
	tot_dr_txn_amt_thb       	decimal(17,2) comment "Def(En): Total Debit Transaction Amount เทียบเท่าบาท
(กรณี LN, PN : Total Disbursement Amount ตั้งแต่เปิดบัญชีจนถึงวันปัจจุบัน)
Def(Th):",
	upd_bill_amt_thb         	decimal(17,2) comment "Def(En): Unpaid Bill Amount เทียบเท่าบาท (รวม Late Charge ในบิล)
Def(Th):",
	upd_int_bill_amt_thb     	decimal(17,2) comment "Def(En): Unpaid Interest Bill Amount เทียบเท่าบาท (รวม Late Charge ในบิล)
Def(Th):",
	acm_rpymt_amt_thb        	decimal(17,2) comment "Def(En): Accumulate Repayment Amount เทียบเท่าบาท
Def(Th):",
	act_int_amt_in_mo_thb    	decimal(15,2) comment "Def(En): The interest which system calculate in this month
(เป็นรายได้ดอกเบี้ยรับในเดือนเทียบเท่าบาท)
Def(Th):",
	acm_act_pnp_thb          	decimal(17,2) comment "Def(En): 
Def(Th): ยอดชำระเงินต้นเทียบเท่าบาท
(สะสมจนถึงปัจจุบัน)",
	acm_act_acr_mem_thb      	decimal(17,2) comment "Def(En): 
Def(Th): ยอดชำระดอกเบี้ยค้างรับทั้งหมดเทียบเท่าบาท
(สะสมจนถึงปัจจุบัน)",
	acm_act_late_chrg_thb    	decimal(17,2) comment "Def(En): 
Def(Th): ยอดชำระดอกเบี้ยผิดนัดเทียบเท่าบาท
(สะสมจนถึงปัจจุบัน)",
	due_amt_thb              	decimal(17,2) comment "Def(En): 
Def(Th): ยอดที่ต้องชำระ / ยอดเรียกเก็บเฉพาะล่าสุดเทียบเท่าบาท  (รวม Late Charge ในบิล)",
	odue_amt_thb             	decimal(17,2) comment "Def(En): 
Def(Th): ยอดค้างชำระเทียบเท่าบาท (รวม Late Charge ในบิล)",
	tot_due_amt_thb          	decimal(17,2) comment "Def(En): 
Def(Th): ยอดที่ต้องชำระทั้งหมดเทียบเท่าบาท (รวม Late Charge ในบิล)
(ยอดค้างชำระ + ยอดที่ต้องชำระ)",
	nxt_pymt_amt_thb         	decimal(17,2) comment "Def(En): Next Payment Amount เทียบเท่าบาท
Def(Th):",
	kbank_midrate            	decimal(11,8) comment "Def(En): KBank Mid Rate that use to convert TXN_AMT_CCY to TXN_AMT_THB

Maximun number of digits before Dot = 3
Number of digits after Dot = 8
Def(Th):",
	basisday                 	smallint     comment "Def(En): 
Def(Th): จำนวนวันที่ใช้เป็นฐานในการคำนวณดอกเบี้ย ตามแต่ละสกุลเงิน",
	lnd_brw_flg              	string       comment "Def(En): Lending / Borrowing Flag
Def(Th):",
	pd_typ_flg               	string       comment "Def(En): Product Type Flag 
Def(Th):",
	old_ctr_mat_dt           	date         comment "Def(En): Old Contract Maturity Date
Def(Th):",
	upd_ctr_mat_dt           	string       comment "Def(En): Update Contract Maturity Date Flag
Def(Th):",
	cntry_to_invest          	string       comment "Def(En): Country to Invest
Def(Th):",
	load_tms                 	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id               	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                 	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                   	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                   	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_fcl/fcl_common_account_info' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);