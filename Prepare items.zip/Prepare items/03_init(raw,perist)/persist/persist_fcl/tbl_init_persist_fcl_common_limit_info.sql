-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_fcl_common_limit_info.sql
# Area: fcl
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-07   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_FCL.FCL_COMMON_LIMIT_INFO
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_fcl.fcl_common_limit_info (
	pos_dt             	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	lmt_ac_ar_id       	string       comment "Def(En): Limit Account Number (Limit Level)
Def(Th):",
	prfl_ac_ar_id      	string       comment "Def(En): FCL Account Number
Def(Th):",
	ar_nm_th           	string       comment "Def(En): Limit Thai Name
Def(Th):",
	ar_nm_eng          	string       comment "Def(En): Limit Eng Name
Def(Th):",
	cst_typ_id         	string       comment "Def(En): Customer Type ID
Def(Th):",
	bsn_code_id        	string       comment "Def(En): Kbank Business code
Def(Th):",
	ctr_dt             	date         comment "Def(En): Limit Contract date 
Def(Th):",
	eff_dt             	date         comment "Def(En): Effective Date (EffDt**)
Def(Th):",
	lmt_end_dt         	date         comment "Def(En): Limit Maturity Date
Def(Th):",
	ac_sts_id          	string       comment "Def(En): Account status ID
Def(Th):",
	cls_dt             	date         comment "Def(En): Close Date 
Def(Th):",
	lmt_ccy_cde        	string       comment "Def(En): Limit Currency Code
Def(Th):",
	ctr_lmt_amt        	decimal(17,2) comment "Def(En): Contract Limit Amount
Def(Th):",
	setup_lmt_amt      	decimal(17,2) comment "Def(En): Setup Limit Amount
Def(Th):",
	lmt_typ_id         	smallint     comment "Def(En): Finance Service Limit Type Id
Def(Th):",
	lmt_typ            	smallint     comment "Def(En): Limit Type
Def(Th):",
	aprv_id            	string       comment "Def(En): Approver ID
Def(Th):",
	br_nbr             	string       comment "Def(En): Branch Number of Account Arrangement (DomicileBranchId**)
Def(Th):",
	pd_grp             	string       comment "Def(En): Product Group
Def(Th):",
	pd_typ             	string       comment "Def(En): Product Type
Def(Th):",
	sub_typ            	string       comment "Def(En): Sub Type
Def(Th):",
	mkt_code           	string       comment "Def(En): Market Code
Def(Th):",
	kbank_pd_code      	string       comment "Def(En): Kbank Product Code
Def(Th):",
	coa_pd_ftr_code_pnp	string       comment "Def(En): Chart of Account (Product Feature Code)
Def(Th):",
	used_lmt           	decimal(17,2) comment "Def(En):
Def(Th): วงเงินที่ใช้ไป",
	esr                	decimal(17,2) comment "Def(En):
Def(Th): ยอดความเสี่ยงที่ธนาคารต้องแบกรับภาระ   (ยอดวงเงินที่ยังไม่เบิกใช้ +  ยอดเงินต้นคงค้าง)",
	unused_lmt         	decimal(17,2) comment "Def(En):
Def(Th): วงเงินที่ยังไม่ได้ใช้",
	avl_lmt            	decimal(17,2) comment "Def(En):
Def(Th): วงเงินคงเหลือที่สามารถใช้ได้",
	hold_amt           	decimal(17,2) comment "Def(En):
Def(Th): จำนวนเงินที่ถูก Hold",
	cis_id             	integer      comment "Def(En):
Def(Th): เลขที่ลูกค้า",
	eff_int_rate_typ_id	string       comment "Def(En): Effective Interest rate type ID
Def(Th):",
	eff_sprd_int_sign  	string       comment "Def(En): Effective Spread Interest Rate
Def(Th):",
	eff_sprd_int_rate  	decimal(8,5) comment "Def(En): Effective Spread Interest Rate
Def(Th):",
	max_days           	smallint     comment "Def(En): Max Days
Def(Th):",
	refr_ddcn_ac       	string       comment "Def(En): Reference Deduction Account Number
Def(Th):",
	cr_prog            	string       comment "Def(En): Credit Program
Def(Th):",
	kcps_app_id        	string       comment "Def(En): Credit Application ID
Def(Th):",
	ctr_lmt_amt_thb    	decimal(17,2) comment "Def(En): Contract Limit Amount เทียบเท่าบาท 
Def(Th):",
	setup_lmt_amt_thb  	decimal(17,2) comment "Def(En): Setup Limit Amount เทียบเท่าบาท 
Def(Th):",
	used_lmt_thb       	decimal(17,2) comment "Def(En): 
Def(Th): วงเงินที่ใช้ไปเทียบเท่าบาท",
	esr_thb            	decimal(17,2) comment "Def(En): 
Def(Th): ยอดความเสี่ยงที่ธนาคารต้องแบกรับภาระเทียบเท่าบาท   (ยอดวงเงินที่ยังไม่เบิกใช้ +  ยอดเงินต้นคงค้าง)",
	unused_lmt_thb     	decimal(17,2) comment "Def(En): 
Def(Th): วงเงินที่ยังไม่ได้ใช้เทียบเท่าบาท",
	avl_lmt_thb        	decimal(17,2) comment "Def(En):
Def(Th): วงเงินคงเหลือที่สามารถใช้ได้เทียบ",
	hold_amt_thb       	decimal(17,2) comment "Def(En):
Def(Th): จำนวนเงินที่ถูก Hold เทียบเท่าบาท",
	kbank_midrate      	decimal(11,8) comment "Def(En): KBank Mid Rate that use to convert TXN_AMT_CCY to TXN_AMT_THB

Maximun number of digits before Dot = 3
Number of digits after Dot = 8
Def(Th):",
	committed_type     	string       comment "Def(En): COMMITTED_TYPE
Def(Th):",
	revolving_type     	string       comment "Def(En): REVOLVING_TYPE
Def(Th):",
	lnd_brw_flg        	string       comment "Def(En): Lending or Borrowing Flag
L - Lending
B - Borrowing
Def(Th):",
	pd_typ_flg         	string       comment "Def(En): Product Type Flag 
Def(Th):",
	finality_cd        	string       comment "Def(En): Finality Code
Def(Th):",
	load_tms           	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id         	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy           	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm             	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd             	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_fcl/fcl_common_limit_info' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);