-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_ks_acctxcust.sql
# Area: ks
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-20   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_KS.KS_ACCTXCUST
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_ks.ks_acctxcust (
	pos_dt           	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt       	date         comment "Def(En): Date of data generated (Source)
Def(Th): วันที่ข้อมูล",
	card_id          	string       comment "Def(En): Customer identification number
Def(Th): เลขบัตรประชาชน/หนังสือเดินทาง",
	cust_cd          	string       comment "Def(En): Customer reference number
Def(Th): รหัสลูกค้าตามประเภทการเปิดบัญชี",
	acct             	string       comment "Def(En): Customer account number by product
Def(Th): หมายเลขบัญชี",
	acct_type        	string       comment "Def(En): Account type
Def(Th): ประเภทบัญชี",
	acct_approve_date	date         comment "Def(En): Account approve date
Def(Th): วันที่ลูกค้าเปิดบัญชีประเภทต่างๆ",
	load_tms         	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id       	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy         	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm           	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd           	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_ks/ks_acctxcust' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);