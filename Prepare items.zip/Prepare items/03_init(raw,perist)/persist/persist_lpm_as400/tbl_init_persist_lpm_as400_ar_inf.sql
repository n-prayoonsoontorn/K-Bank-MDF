-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_lpm_as400_ar_inf.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-07-26   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_LPM_AS400.LPM_AS400_AR_INF
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_lpm_as400.lpm_as400_ar_inf (
	pos_dt                   	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt               	timestamp    comment "Def(En):Position Date
Def(Th):วันที่ของข้อมูล",
	l01d003_acct_no          	string       comment "Def(En):
Def(Th): เลขที่บัญชี
ในกรณีที่เป็น ACCOUNT DUMMY                                                 
TYPE = 4  ACCTNO  = XXX-X-XXXX-X/XXX/XXX/000                  
TYPE = 5  ACCTNO  = TR+TRADE-CUST-NO(10)                      
TYPE = 14 ACCTNO  = LIMIT-BR(3)+LI-CUST-ID(10)+LIMIT-NO(4)+XX 
                    XX = L1   ลูกค้าเดี่ยว                    
                       = L2   ลูกค้า JOINT ACCOUNT            
                  = LI-CUST-ID(10)+LIMIT-NO(4)+JL-ID(4)+L     
TYPE = 15 ACCTNO  = LIMIT-BR(3)+LI-CUST-ID(10)+LIMIT-NO(4)+XX 
                    XX = V1   ลูกค้าเดี่ยว                    
                       = V2   ลูกค้า JOINT ACCOUNT            
                  = LI-CUST-ID(10)+LIMIT-NO(4)+JL-ID(4)+V     
TYPE = 16 ACCTNO  = LIMIT-BR(3)+LI-CUST-ID(10)+LIMIT-NO(4)+XX 
                    XX = C1   ลูกค้าเดี่ยว                    
                       = C2   ลูกค้า JOINT ACCOUNT            
                  = LI-CUST-ID(10)+LIMIT-NO(4)+JL-ID(4)+C",
	l01d003_cr_type          	smallint     comment "Def(En):
Def(Th): ประเภทเครดิต",
	l01d003_branch_no        	smallint     comment "Def(En):
Def(Th): รหัสสาขา",
	l01d003_dept_no          	smallint     comment "Def(En):
Def(Th): รหัสสังกัด",
	l01d003_bus_code         	integer      comment "Def(En):
Def(Th): ประเภทธุรกิจ",
	l01d003_fics_acct        	integer      comment "Def(En):
Def(Th): ประเภทหัวบัญชี",
	l01d003_acct_cust_type   	smallint     comment "Def(En):
Def(Th): ประเภทลูกค้า ( ระดับบัญชี )",
	l01d003_staff_flag       	smallint     comment "Def(En):
Def(Th): FLAG พนักงาน",
	l01d003_close_date       	date         comment "Def(En):
Def(Th): ปีเดือนวันที่ปิดบัญชี",
	l01d003_npl_date         	date         comment "Def(En):
Def(Th): ปีเดือนวันที่เป็น NPL",
	l01d003_jan_int_fg       	smallint     comment "Def(En):
Def(Th): FLAG การคิดดอกเบี้ยเดือนมกราคม : 0 = คิด , 1 = งดคิด",
	l01d003_jan_stop_date    	date         comment "Def(En):
Def(Th): ปีเดือนวันที่พักดอกเบี้ยเดือนมกราคม",
	l01d003_feb_int_fg       	smallint     comment "Def(En):
Def(Th): FLAG การคิดดอกเบี้ยเดือนกุมภาพันธ์ : 0 = คิด , 1 = งดคิด",
	l01d003_feb_stop_date    	date         comment "Def(En):
Def(Th): ปีเดือนวันที่พักดอกเบี้ยเดือนกุมภาพันธ์",
	l01d003_mar_int_fg       	smallint     comment "Def(En):
Def(Th): FLAG การคิดดอกเบี้ยเดือนมีนาคม : 0 = คิด , 1 = งดคิด",
	l01d003_mar_stop_date    	date         comment "Def(En):
Def(Th): ปีเดือนวันที่พักดอกเบี้ยเดือนมีนาคม",
	l01d003_apr_int_fg       	smallint     comment "Def(En):
Def(Th): FLAG การคิดดอกเบี้ยเดือนเมษายน : 0 = คิด , 1 = งดคิด",
	l01d003_apr_stop_date    	date         comment "Def(En):
Def(Th): ปีเดือนวันที่พักดอกเบี้ยเดือนเมษายน",
	l01d003_may_int_fg       	smallint     comment "Def(En):
Def(Th): FLAG การคิดดอกเบี้ยเดือนพฤษภาคม : 0 = คิด , 1 = งดคิด",
	l01d003_may_stop_date    	date         comment "Def(En):
Def(Th): ปีเดือนวันที่พักดอกเบี้ยเดือนพฤษภาคม",
	l01d003_jun_int_fg       	smallint     comment "Def(En):
Def(Th): FLAG การคิดดอกเบี้ยเดือนมิถุนายน : 0 = คิด , 1 = งดคิด",
	l01d003_jun_stop_date    	date         comment "Def(En):
Def(Th): ปีเดือนวันที่พักดอกเบี้ยเดือนมิถุนายน",
	l01d003_jul_int_fg       	smallint     comment "Def(En):
Def(Th): FLAG การคิดดอกเบี้ยเดือนกรกฎาคม : 0 = คิด , 1 = งดคิด",
	l01d003_jul_stop_date    	date         comment "Def(En):
Def(Th): ปีเดือนวันที่พักดอกเบี้ยเดือนกรกฎาคม",
	l01d003_aug_int_fg       	smallint     comment "Def(En):
Def(Th): FLAG การคิดดอกเบี้ยเดือนสิงหาคม : 0 = คิด , 1 = งดคิด",
	l01d003_aug_stop_date    	date         comment "Def(En):
Def(Th): ปีเดือนวันที่พักดอกเบี้ยเดือนสิงหาคม",
	l01d003_sep_int_fg       	smallint     comment "Def(En):
Def(Th): FLAG การคิดดอกเบี้ยเดือนกันยายน : 0 = คิด , 1 = งดคิด",
	l01d003_sep_stop_date    	date         comment "Def(En):
Def(Th): ปีเดือนวันที่พักดอกเบี้ยเดือนกันยายน",
	l01d003_oct_int_fg       	smallint     comment "Def(En):
Def(Th): FLAG การคิดดอกเบี้ยเดือนตุลาคม : 0 = คิด , 1 = งดคิด",
	l01d003_oct_stop_date    	date         comment "Def(En):
Def(Th): ปีเดือนวันที่พักดอกเบี้ยเดือนตุลาคม",
	l01d003_nov_int_fg       	smallint     comment "Def(En):
Def(Th): FLAG การคิดดอกเบี้ยเดือนพฤศจิกายน : 0 = คิด , 1 = งดคิด",
	l01d003_nov_stop_date    	date         comment "Def(En):
Def(Th): ปีเดือนวันที่พักดอกเบี้ยเดือนพฤศจิกายน",
	l01d003_dec_int_fg       	smallint     comment "Def(En):
Def(Th): FLAG การคิดดอกเบี้ยเดือนธันวาคม : 0 = คิด , 1 = งดคิด",
	l01d003_dec_stop_date    	date         comment "Def(En):
Def(Th): ปีเดือนวันที่พักดอกเบี้ยเดือนธันวาคม",
	l01d003_prv_int_fg       	smallint     comment "Def(En):
Def(Th): FLAG การคิดดอกเบี้ยเดือนที่แล้ว : 0 = คิด , 1 = งดคิด",
	l01d003_prv_stop_date    	date         comment "Def(En):
Def(Th): วันที่พักดอกเบี้ยเดือนที่แล้ว",
	l01d003_int_fg           	smallint     comment "Def(En):
Def(Th): FLAG การคิดดอกเบี้ย  0 = คิดดอกเบี้ย , 1 = งดคิดดอกเบี้ย",
	l01d003_stop_date        	date         comment "Def(En):
Def(Th): ปีเดือนวันที่พักดอกเบี้ย",
	l01d003_jan_day_diff     	integer      comment "Def(En):
Def(Th): จำนวนวันที่ค้างชำระเดือนมกราคม",
	l01d003_feb_day_diff     	integer      comment "Def(En):
Def(Th): จำนวนวันที่ค้างชำระเดือนกุมภาพันธ์",
	l01d003_mar_day_diff     	integer      comment "Def(En):
Def(Th): จำนวนวันที่ค้างชำระเดือนมีนาคม",
	l01d003_apr_day_diff     	integer      comment "Def(En):
Def(Th): จำนวนวันที่ค้างชำระเดือนเมษายน",
	l01d003_may_day_diff     	integer      comment "Def(En):
Def(Th): จำนวนวันที่ค้างชำระเดือนพฤษภาคม",
	l01d003_jun_day_diff     	integer      comment "Def(En):
Def(Th): จำนวนวันที่ค้างชำระเดือนมิถุนายน",
	l01d003_jul_day_diff     	integer      comment "Def(En):
Def(Th): จำนวนวันที่ค้างชำระเดือนกรกฎาคม",
	l01d003_aug_day_diff     	integer      comment "Def(En):
Def(Th): จำนวนวันที่ค้างชำระเดือนสิงหาคม",
	l01d003_sep_day_diff     	integer      comment "Def(En):
Def(Th): จำนวนวันที่ค้างชำระเดือนกันยายน",
	l01d003_oct_day_diff     	integer      comment "Def(En):
Def(Th): จำนวนวันที่ค้างชำระเดือนตุลาคม",
	l01d003_nov_day_diff     	integer      comment "Def(En):
Def(Th): จำนวนวันที่ค้างชำระเดือนพฤศจิกายน",
	l01d003_dec_day_diff     	integer      comment "Def(En):
Def(Th): จำนวนวันที่ค้างชำระเดือนธันวาคม",
	l01d003_prv_day_diff     	integer      comment "Def(En):
Def(Th): จำนวนวันที่ค้างชำระเดือนที่แล้ว",
	l01d003_day_diff         	integer      comment "Def(En):
Def(Th): จำนวนวันที่ค้างชำระ",
	l01d003_jan_accru        	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยค้างรับเดือนมกราคม",
	l01d003_feb_accru        	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยค้างรับเดือนกุมภาพันธ์",
	l01d003_mar_accru        	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยค้างรับเดือนมีนาคม",
	l01d003_apr_accru        	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยค้างรับเดือนเมษายน",
	l01d003_may_accru        	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยค้างรับเดือนพฤษภาคม",
	l01d003_jun_accru        	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยค้างรับเดือนมิถุนายน",
	l01d003_jul_accru        	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยค้างรับเดือนกรกฎาคม",
	l01d003_aug_accru        	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยค้างรับเดือนสิงหาคม",
	l01d003_sep_accru        	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยค้างรับเดือนกันยายน",
	l01d003_oct_accru        	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยค้างรับเดือนตุลาคม",
	l01d003_nov_accru        	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยค้างรับเดือนพฤศจิกายน",
	l01d003_dec_accru        	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยค้างรับเดือนธันวาคม",
	l01d003_prv_accru        	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยค้างรับเดือนที่แล้ว",
	l01d003_accru            	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยค้างรับ",
	l01d003_jan_outs         	decimal(13,2) comment "Def(En):
Def(Th): ยอดคงค้างเดือนมกราคม",
	l01d003_feb_outs         	decimal(13,2) comment "Def(En):
Def(Th): ยอดคงค้างเดือนกุมภาพันธ์",
	l01d003_mar_outs         	decimal(13,2) comment "Def(En):
Def(Th): ยอดคงค้างเดือนมีนาคม",
	l01d003_apr_outs         	decimal(13,2) comment "Def(En):
Def(Th): ยอดคงค้างเดือนเมษายน",
	l01d003_may_outs         	decimal(13,2) comment "Def(En):
Def(Th): ยอดคงค้างเดือนพฤษภาคม",
	l01d003_jun_outs         	decimal(13,2) comment "Def(En):
Def(Th): ยอดคงค้างเดือนมิถุนายน",
	l01d003_jul_outs         	decimal(13,2) comment "Def(En):
Def(Th): ยอดคงค้างเดือนกรกฎาคม",
	l01d003_aug_outs         	decimal(13,2) comment "Def(En):
Def(Th): ยอดคงค้างเดือนสิงหาคม",
	l01d003_sep_outs         	decimal(13,2) comment "Def(En):
Def(Th): ยอดคงค้างเดือนกันยายน",
	l01d003_oct_outs         	decimal(13,2) comment "Def(En):
Def(Th): ยอดคงค้างเดือนตุลาคม",
	l01d003_nov_outs         	decimal(13,2) comment "Def(En):
Def(Th): ยอดคงค้างเดือนพฤศจิกายน",
	l01d003_dec_outs         	decimal(13,2) comment "Def(En):
Def(Th): ยอดคงค้างเดือนธันวาคม",
	l01d003_prv_outs         	decimal(13,2) comment "Def(En):
Def(Th): ยอดคงค้างเดือนที่แล้ว",
	l01d003_outs             	decimal(13,2) comment "Def(En):
Def(Th): ยอดคงค้าง",
	l01d003_jan_pay          	decimal(13,2) comment "Def(En):
Def(Th): ยอดชำระเดือนมกราคม",
	l01d003_feb_pay          	decimal(13,2) comment "Def(En):
Def(Th): ยอดชำระเดือนกุมภาพันธ์",
	l01d003_mar_pay          	decimal(13,2) comment "Def(En):
Def(Th): ยอดชำระเดือนมีนาคม",
	l01d003_apr_pay          	decimal(13,2) comment "Def(En):
Def(Th): ยอดชำระเดือนเมษายน",
	l01d003_may_pay          	decimal(13,2) comment "Def(En):
Def(Th): ยอดชำระเดือนพฤษภาคม",
	l01d003_jun_pay          	decimal(13,2) comment "Def(En):
Def(Th): ยอดชำระเดือนมิถุนายน",
	l01d003_jul_pay          	decimal(13,2) comment "Def(En):
Def(Th): ยอดชำระเดือนกรกฎาคม",
	l01d003_aug_pay          	decimal(13,2) comment "Def(En):
Def(Th): ยอดชำระเดือนสิงหาคม",
	l01d003_sep_pay          	decimal(13,2) comment "Def(En):
Def(Th): ยอดชำระเดือนกันยายน",
	l01d003_oct_pay          	decimal(13,2) comment "Def(En):
Def(Th): ยอดชำระเดือนตุลาคม",
	l01d003_nov_pay          	decimal(13,2) comment "Def(En):
Def(Th): ยอดชำระเดือนพฤศจิกายน",
	l01d003_dec_pay          	decimal(13,2) comment "Def(En):
Def(Th): ยอดชำระเดือนธันวาคม",
	l01d003_prv_pay          	decimal(13,2) comment "Def(En):
Def(Th): ยอดชำระเดือนที่แล้ว",
	l01d003_pay              	decimal(13,2) comment "Def(En):
Def(Th): ยอดชำระ",
	l01d003_jan_ext_pay      	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยที่ยังไม่ถูกกระจายเป็นรายได้(UNAMORTIZE) ณ สิ้นเดือนมกราคม ในกรณีของตั๋ว PN",
	l01d003_feb_ext_pay      	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยที่ยังไม่ถูกกระจายเป็นรายได้(UNAMORTIZE) ณ สิ้นเดือนกุมภาพันธ์ ในกรณีของตั๋ว PN",
	l01d003_mar_ext_pay      	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยที่ยังไม่ถูกกระจายเป็นรายได้(UNAMORTIZE) ณ สิ้นเดือนมีนาคม ในกรณีของตั๋ว PN",
	l01d003_apr_ext_pay      	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยที่ยังไม่ถูกกระจายเป็นรายได้(UNAMORTIZE) ณ สิ้นเดือนเมษายน ในกรณีของตั๋ว PN",
	l01d003_may_ext_pay      	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยที่ยังไม่ถูกกระจายเป็นรายได้(UNAMORTIZE) ณ สิ้นเดือนพฤษภาคม ในกรณีของตั๋ว PN",
	l01d003_jun_ext_pay      	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยที่ยังไม่ถูกกระจายเป็นรายได้(UNAMORTIZE) ณ สิ้นเดือนมิถุนายน ในกรณีของตั๋ว PN",
	l01d003_jul_ext_pay      	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยที่ยังไม่ถูกกระจายเป็นรายได้(UNAMORTIZE) ณ สิ้นเดือนกรกฎาคม ในกรณีของตั๋ว PN",
	l01d003_aug_ext_pay      	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยที่ยังไม่ถูกกระจายเป็นรายได้(UNAMORTIZE) ณ สิ้นเดือนสิงหาคม ในกรณีของตั๋ว PN",
	l01d003_sep_ext_pay      	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยที่ยังไม่ถูกกระจายเป็นรายได้(UNAMORTIZE) ณ สิ้นเดือนกันยายน ในกรณีของตั๋ว PN",
	l01d003_oct_ext_pay      	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยที่ยังไม่ถูกกระจายเป็นรายได้(UNAMORTIZE) ณ สิ้นเดือนตุลาคม ในกรณีของตั๋ว PN",
	l01d003_nov_ext_pay      	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยที่ยังไม่ถูกกระจายเป็นรายได้(UNAMORTIZE) ณ สิ้นเดือนพฤศจิกายน ในกรณีของตั๋ว PN",
	l01d003_dec_ext_pay      	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยที่ยังไม่ถูกกระจายเป็นรายได้(UNAMORTIZE) ณ สิ้นเดือนธันวาคม ในกรณีของตั๋ว PN",
	l01d003_prv_ext_pay      	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยที่ยังไม่ถูกกระจายเป็นรายได้(UNAMORTIZE) ณ สิ้นเดือน ในกรณีของตั๋ว PN",
	l01d003_ext_pay          	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยที่ยังไม่ถูกกระจายเป็นรายได้(UNAMORTIZE) ในกรณีของตั๋ว PN",
	l01d003_last_int_date    	date         comment "Def(En):
Def(Th): วันที่คิดดอกเบี้ยครั้งล่าสุด",
	l01d003_currency         	smallint     comment "Def(En):
Def(Th): สกุลเงิน",
	l01d003_exc_rate         	decimal(10,7) comment "Def(En):
Def(Th): อัตราแลกเปลี่ยน",
	l01d003_fc_amount        	decimal(13,2) comment "Def(En):
Def(Th): จำนวนเงินที่เป็นสกุลเงินต่างประเทศ",
	l01d003_bibf_in_out      	smallint     comment "Def(En):
Def(Th): ประเภทของ BIBF : 1 = OUT - IN  ,  2 = OUT - OUT",
	l01d003_center_branch    	smallint     comment "Def(En):
Def(Th): ศูนย์ธุรกิจต่างประเทศ ( เฉพาะหนี้ตั๋วต่างประเทศ )",
	l01d003_memo_fee         	decimal(13,2) comment "Def(En):
Def(Th): ค่าธรรมเนียม",
	l01d003_jan_reverse_flag 	smallint     comment "Def(En):
Def(Th): Flag การพักดอกเบี้ยเดือนมกราคม",
	l01d003_feb_reverse_flag 	smallint     comment "Def(En):
Def(Th): Flag การพักดอกเบี้ยเดือนกุมภาพันธ์",
	l01d003_mar_reverse_flag 	smallint     comment "Def(En):
Def(Th): Flag การพักดอกเบี้ยเดือนมีนาคม",
	l01d003_apr_reverse_flag 	smallint     comment "Def(En):
Def(Th): Flag การพักดอกเบี้ยเดือนเมษายน",
	l01d003_may_reverse_flag 	smallint     comment "Def(En):
Def(Th): Flag การพักดอกเบี้ยเดือนพฤษภาคม",
	l01d003_jun_reverse_flag 	smallint     comment "Def(En):
Def(Th): Flag การพักดอกเบี้ยเดือนมิถุนายน",
	l01d003_jul_reverse_flag 	smallint     comment "Def(En):
Def(Th): Flag การพักดอกเบี้ยเดือนกรกฎาคม",
	l01d003_aug_reverse_flag 	smallint     comment "Def(En):
Def(Th): Flag การพักดอกเบี้ยเดือนสิงหาคม",
	l01d003_sep_reverse_flag 	smallint     comment "Def(En):
Def(Th): Flag การพักดอกเบี้ยเดือนกันยายน",
	l01d003_oct_reverse_flag 	smallint     comment "Def(En):
Def(Th): Flag การพักดอกเบี้ยเดือนตุลาคม",
	l01d003_nov_reverse_flag 	smallint     comment "Def(En):
Def(Th): Flag การพักดอกเบี้ยเดือนพฤษศจิกายน",
	l01d003_dec_reverse_flag 	smallint     comment "Def(En):
Def(Th): Flag การพักดอกเบี้ยเดือนธันวาคม",
	l01d003_prv_reverse_flag 	smallint     comment "Def(En):
Def(Th): Flag การพักดอกเบี้ยเดือนล่าสุด",
	l01d003_reverse_flag     	smallint     comment "Def(En):
Def(Th): Flag การพักดอกเบี้ย ณ ปัจจุบัน 
เป็น FLAG การพักดบ.หลังปี 43
0 = ไม่พักดบ.
1 = พักดบ.โดย SAFE
2 = พักดบ.โดย LPM
3 = การนำดอกเบี้ยนอกการ์ดที่พักก่อนปี 43 ยกกลับมา คำนวณเป็น memo-accrued ต่อเนื่องโดยระบบ
4 = ทานตะวัน",
	l01d003_jan_reverse_date 	date         comment "Def(En):
Def(Th): วันที่พักดอกเบี้ยเดือนมกราคม",
	l01d003_feb_reverse_date 	date         comment "Def(En):
Def(Th): วันที่พักดอกเบี้ยเดือนกุมภาพันธ์",
	l01d003_mar_reverse_date 	date         comment "Def(En):
Def(Th): วันที่พักดอกเบี้ยเดือนมีนาคม",
	l01d003_apr_reverse_date 	date         comment "Def(En):
Def(Th): วันที่พักดอกเบี้ยเดือนเมษายน",
	l01d003_may_reverse_date 	date         comment "Def(En):
Def(Th): วันที่พักดอกเบี้ยเดือนพฤษภาคม",
	l01d003_jun_reverse_date 	date         comment "Def(En):
Def(Th): วันที่พักดอกเบี้ยเดือนมิถุนายน",
	l01d003_jul_reverse_date 	date         comment "Def(En):
Def(Th): วันที่พักดอกเบี้ยเดือนกรกฎาคม",
	l01d003_aug_reverse_date 	date         comment "Def(En):
Def(Th): วันที่พักดอกเบี้ยเดือนสิงหาคม",
	l01d003_sep_reverse_date 	date         comment "Def(En):
Def(Th): วันที่พักดอกเบี้ยเดือนกันยายน",
	l01d003_oct_reverse_date 	date         comment "Def(En):
Def(Th): วันที่พักดอกเบี้ยเดือนตุลาคม",
	l01d003_nov_reverse_date 	date         comment "Def(En):
Def(Th): วันที่พักดอกเบี้ยเดือนพฤศจิกายน",
	l01d003_dec_reverse_date 	date         comment "Def(En):
Def(Th): วันที่พักดอกเบี้ยเดือนธันวาคม",
	l01d003_prv_reverse_date 	date         comment "Def(En):
Def(Th): วันที่พักดอกเบี้ยเดือนล่าสุด",
	l01d003_reverse_date     	date         comment "Def(En):
Def(Th): วันที่พักดอกเบี้ย ประจำวันนี้",
	l01d003_jan_reverse_accru	decimal(13,2) comment "Def(En):
Def(Th): ยอดที่พักดอกเบี้ยเดือนมกราคม",
	l01d003_feb_reverse_accru	decimal(13,2) comment "Def(En):
Def(Th): ยอดที่พักดอกเบี้ยเดือนกุมภาพันธ์",
	l01d003_mar_reverse_accru	decimal(13,2) comment "Def(En):
Def(Th): ยอดที่พักดอกเบี้ยเดือนมีนาคม",
	l01d003_apr_reverse_accru	decimal(13,2) comment "Def(En):
Def(Th): ยอดที่พักดอกเบี้ยเดือนเมษายน",
	l01d003_may_reverse_accru	decimal(13,2) comment "Def(En):
Def(Th): ยอดที่พักดอกเบี้ยเดือนพฤษภาคม",
	l01d003_jun_reverse_accru	decimal(13,2) comment "Def(En):
Def(Th): ยอดที่พักดอกเบี้ยเดือนมิถุนายน",
	l01d003_jul_reverse_accru	decimal(13,2) comment "Def(En):
Def(Th): ยอดที่พักดอกเบี้ยเดือนกรกฎาคม",
	l01d003_aug_reverse_accru	decimal(13,2) comment "Def(En):
Def(Th): ยอดที่พักดอกเบี้ยเดือนสิงหาคม",
	l01d003_sep_reverse_accru	decimal(13,2) comment "Def(En):
Def(Th): ยอดที่พักดอกเบี้ยเดือนกันยายน",
	l01d003_oct_reverse_accru	decimal(13,2) comment "Def(En):
Def(Th): ยอดที่พักดอกเบี้ยเดือนตุลาคม",
	l01d003_nov_reverse_accru	decimal(13,2) comment "Def(En):
Def(Th): ยอดที่พักดอกเบี้ยเดือนพฤศจิกายน",
	l01d003_dec_reverse_accru	decimal(13,2) comment "Def(En):
Def(Th): ยอดที่พักดอกเบี้ยเดือนธันวาคม",
	l01d003_prv_reverse_accru	decimal(13,2) comment "Def(En):
Def(Th): ยอดที่พักดอกเบี้ยเดือนล่าสุด",
	l01d003_reverse_accru    	decimal(13,2) comment "Def(En):
Def(Th): ยอดที่พักดอกเบี้ย ประจำวันนี้",
	l01d003_jan_memo_accru   	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยสะสมทั้งหมดเดือนมกราคม",
	l01d003_feb_memo_accru   	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยสะสมทั้งหมดเดือนกุมภาพันธ์",
	l01d003_mar_memo_accru   	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยสะสมทั้งหมดเดือนมีนาคม",
	l01d003_apr_memo_accru   	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยสะสมทั้งหมดเดือนเมษายน",
	l01d003_may_memo_accru   	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยสะสมทั้งหมดเดือนพฤษภาคม",
	l01d003_jun_memo_accru   	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยสะสมทั้งหมดเดือนมิถุนายน",
	l01d003_jul_memo_accru   	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยสะสมทั้งหมดเดือนกรกฎาคม",
	l01d003_aug_memo_accru   	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยสะสมทั้งหมดเดือนสิงหาคม",
	l01d003_sep_memo_accru   	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยสะสมทั้งหมดเดือนกันยายน",
	l01d003_oct_memo_accru   	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยสะสมทั้งหมดเดือนตุลาคม",
	l01d003_nov_memo_accru   	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยสะสมทั้งหมดเดือนพฤศจิกายน",
	l01d003_dec_memo_accru   	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยสะสมทั้งหมดเดือนธันวาคม",
	l01d003_prv_memo_accru   	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยสะสมทั้งหมดเดือนล่าสุด",
	l01d003_memo_accru       	decimal(13,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยสะสมทั้งหมด ประจำวันนี้ (กรณีมีการพักดอกเบี้ย)",
	l01d003_int_pay          	decimal(13,2) comment "Def(En):
Def(Th): จำนวนเงินที่เป็นสกุลเงินต่างประเทศ",
	l01d003_enter_date       	date         comment "Def(En):
Def(Th): วันที่เข้าระบบ LPM",
	l01d003_open_date        	date         comment "Def(En):
Def(Th): วันที่เปิดบัญชี",
	l01d003_jan_auto_accru   	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยเดือนมกราคม  (เพื่อใช้คำนวณ interest receive/interest income)",
	l01d003_feb_auto_accru   	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยเดือนกุมภาพันธ์ (เพื่อใช้คำนวณ interest receive/interest income)",
	l01d003_mar_auto_accru   	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยเดือนมีนาคม (เพื่อใช้คำนวณ interest receive/interest income)",
	l01d003_apr_auto_accru   	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยเดือนเมษายน (เพื่อใช้คำนวณ interest receive/interest income)",
	l01d003_may_auto_accru   	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยเดือนพฤษภาคม (เพื่อใช้คำนวณ interest receive/interest income)",
	l01d003_jun_auto_accru   	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยเดือนมิถุนายน (เพื่อใช้คำนวณ interest receive/interest income)",
	l01d003_jul_auto_accru   	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยเดือนกรกฎาคม (เพื่อใช้คำนวณ interest receive/interest income)",
	l01d003_aug_auto_accru   	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยเดือนสิงหาคม (เพื่อใช้คำนวณ interest receive/interest income)",
	l01d003_sep_auto_accru   	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยเดือนกันยายน (เพื่อใช้คำนวณ interest receive/interest income)",
	l01d003_oct_auto_accru   	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยเดือนตุลาคม (เพื่อใช้คำนวณ interest receive/interest income)",
	l01d003_nov_auto_accru   	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยเดือนพฤศจิกายน (เพื่อใช้คำนวณ interest receive/interest income)",
	l01d003_dec_auto_accru   	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยเดือนธันวาคม (เพื่อใช้คำนวณ interest receive/interest income)",
	l01d003_prv_auto_accru   	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยเดือนล่าสุด (เพื่อใช้คำนวณ interest receive/interest income)",
	l01d003_auto_accru       	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยประจำวันนี้ (เพื่อใช้คำนวณ interest receive/interest income)",
	l01d003_jan_manual_accru 	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยแบบ Manualเดือนมกราคม (เพื่อใช้คำนวณ interest receive/interest income) เฉพาะ ACCTTYPE = 1,2,4 ยกเว้น ACCTTYPE = 3 จะเป็นดอกเบี้ยนอกการ์ดนอกระบบ ( เริ่ม 11/2552) และ ACCTTYPE = 13 เริ่ม 09/2553",
	l01d003_feb_manual_accru 	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยแบบ Manualเดือนกุมภาพันธ์ (เพื่อใช้คำนวณ interest receive/interest income)
เฉพาะ ACCTTYPE = 1,2,4 ยกเว้น ACCTTYPE = 3 จะเป็นดอกเบี้ยนอกการ์ดนอกระบบ ( เริ่ม 11/2552 และ ACCTTYPE = 13 เริ่ม 09/2553",
	l01d003_mar_manual_accru 	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยแบบ Manualเดือนมีนาคม  (เพื่อใช้คำนวณ interest receive/interest income)
เฉพาะ ACCTTYPE = 1,2,4 ยกเว้น ACCTTYPE = 3 จะเป็นดอกเบี้ยนอกการ์ดนอกระบบ ( เริ่ม 11/2552) และ ACCTTYPE = 13 เริ่ม 09/2553",
	l01d003_apr_manual_accru 	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยแบบ Manualเดือนเมษายน (เพื่อใช้คำนวณ interest receive/interest income)
เฉพาะ ACCTTYPE = 1,2,4 ยกเว้น ACCTTYPE = 3 จะเป็นดอกเบี้ยนอกการ์ดนอกระบบ ( เริ่ม 11/2552) และ ACCTTYPE = 13 เริ่ม 09/2553",
	l01d003_may_manual_accru 	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยแบบ Manualเดือนพฤษภาคม (เพื่อใช้คำนวณ interest receive/interest income)
เฉพาะ ACCTTYPE = 1,2,4 ยกเว้น ACCTTYPE = 3 จะเป็นดอกเบี้ยนอกการ์ดนอกระบบ ( เริ่ม 11/2552) และ ACCTTYPE = 13 เริ่ม 09/2553",
	l01d003_jun_manual_accru 	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยแบบ Manualเดือนมิถุนายน (เพื่อใช้คำนวณ interest receive/interest income)
เฉพาะ ACCTTYPE = 1,2,4 ยกเว้น ACCTTYPE = 3 จะเป็นดอกเบี้ยนอกการ์ดนอกระบบ ( เริ่ม 11/2552) และ ACCTTYPE = 13 เริ่ม 09/2553",
	l01d003_jul_manual_accru 	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยแบบ Manualเดือนกรกฎาคม (เพื่อใช้คำนวณ interest receive/interest income)
เฉพาะ ACCTTYPE = 1,2,4 ยกเว้น ACCTTYPE = 3 จะเป็นดอกเบี้ยนอกการ์ดนอกระบบ ( เริ่ม 11/2552) และ ACCTTYPE = 13 เริ่ม 09/2553",
	l01d003_aug_manual_accru 	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยแบบ Manualเดือนสิงหาคม (เพื่อใช้คำนวณ interest receive/interest income)
เฉพาะ ACCTTYPE = 1,2,4 ยกเว้น ACCTTYPE = 3 จะเป็นดอกเบี้ยนอกการ์ดนอกระบบ ( เริ่ม 11/2552) และ ACCTTYPE = 13 เริ่ม 09/2553",
	l01d003_sep_manual_accru 	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยแบบ Manualเดือนกันยายน (เพื่อใช้คำนวณ interest receive/interest income)
เฉพาะ ACCTTYPE = 1,2,4 ยกเว้น ACCTTYPE = 3 จะเป็นดอกเบี้ยนอกการ์ดนอกระบบ ( เริ่ม 11/2552) และ ACCTTYPE = 13 เริ่ม 09/2553",
	l01d003_oct_manual_accru 	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยแบบ Manualเดือนตุลาคม (เพื่อใช้คำนวณ interest receive/interest income)
เฉพาะ ACCTTYPE = 1,2,4 ยกเว้น ACCTTYPE = 3 จะเป็นดอกเบี้ยนอกการ์ดนอกระบบ ( เริ่ม 11/2552) และ ACCTTYPE = 13 เริ่ม 09/2553",
	l01d003_nov_manual_accru 	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยแบบ Manualเดือนพฤศจิกายน (เพื่อใช้คำนวณ interest receive/interest income)
เฉพาะ ACCTTYPE = 1,2,4 ยกเว้น ACCTTYPE = 3 จะเป็นดอกเบี้ยนอกการ์ดนอกระบบ ( เริ่ม 11/2552) และ ACCTTYPE = 13 เริ่ม 09/2553",
	l01d003_dec_manual_accru 	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยแบบ Manualเดือนธันวาคม (เพื่อใช้คำนวณ interest receive/interest income)
เฉพาะ ACCTTYPE = 1,2,4 ยกเว้น ACCTTYPE = 3 จะเป็นดอกเบี้ยนอกการ์ดนอกระบบ ( เริ่ม 11/2552) และ ACCTTYPE = 13 เริ่ม 09/2553",
	l01d003_prv_manual_accru 	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยแบบ Manualเดือนล่าสุด (เพื่อใช้คำนวณ interest receive/interest income)
เฉพาะ ACCTTYPE = 1,2,4 ยกเว้น ACCTTYPE = 3 จะเป็นดอกเบี้ยนอกการ์ดนอกระบบ ( เริ่ม 11/2552) และ ACCTTYPE = 13 เริ่ม 09/2553",
	l01d003_manual_accru     	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยแบบ Manualประจำวันนี้ (เพื่อใช้คำนวณ interest receive/interest income)
เฉพาะ ACCTTYPE = 1,2,4 ยกเว้น ACCTTYPE = 3 จะเป็นดอกเบี้ยนอกการ์ดนอกระบบ ( เริ่ม 11/2552) และ ACCTTYPE = 13 เริ่ม 09/2553",
	l01d003_legal_entity     	smallint     comment "Def(En):
Def(Th): รหัสบริษัท",
	l01d003_resp_center      	integer      comment "Def(En):
Def(Th): รหัสสังกัด",
	l01d003_gl_account       	integer      comment "Def(En):
Def(Th): รหัสบัญชีประเภทเครดิต",
	l01d003_function         	smallint     comment "Def(En):
Def(Th): รหัสฟังก์ชันงาน",
	l01d003_line_business    	smallint     comment "Def(En):
Def(Th): รหัสประเภทธุรกิจ",
	l01d003_gl_product_code  	integer      comment "Def(En):
Def(Th): รหัสผลิตภัณฑ์สำหรับการบันทึกบัญชี",
	l01d003_inter_company    	smallint     comment "Def(En):
Def(Th): รหัสบริษัทในการหักค่าใช้จ่ายระหว่างบริษัทในเครือ",
	l01d003_intra_company    	integer      comment "Def(En):
Def(Th): รหัสบริษัทในการหักค่าใช้จ่ายระหว่างฝ่ายงาน",
	l01d003_project          	smallint     comment "Def(En):
Def(Th): รหัสโครงการ",
	l01d003_product_code     	integer      comment "Def(En):
Def(Th): รหัสผลิตภัณฑ์",
	l01d003_acct_type        	smallint     comment "Def(En):
Def(Th): ประเภทเครดิต",
	ppn_tms                  	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_stm_id               	smallint     comment "Def(En): Source System Code
Def(Th): เลขที่แสดงระบบงาน",
	load_tms                 	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id               	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                 	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                   	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                   	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_lpm_as400/lpm_as400_ar_inf' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);