-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_mx_acup.sql
# Area: mx
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-08   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_MX.MX_ACUP
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_mx.mx_acup (
	pos_dt           	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	m_ogl_coa        	string       comment "Def(En): OGL COA
Def(Th):",
	m_entity         	string       comment "Def(En): Product Entity
Def(Th):",
	m_rc             	string       comment "Def(En): OGL Segment (Responsibility Center)
Def(Th):",
	m_account        	string       comment "Def(En): OGL Segment (Account Number)
Def(Th):",
	m_function       	string       comment "Def(En): OGL Segment (Function on)
Def(Th):",
	m_lob            	string       comment "Def(En): OGL Segment (Line of Business)
Def(Th):",
	m_product_code   	string       comment "Def(En): OGL Segment (Product Code)
Def(Th):",
	m_product_feature	string       comment "Def(En): OGL Segment (Product Future)
Def(Th):",
	m_inter_com      	string       comment "Def(En): OGL Segment (Inter Company)
Def(Th):",
	m_intra_com      	string       comment "Def(En): OGL Segment (Intra Company)
Def(Th):",
	m_project        	string       comment "Def(En): OGL Segment (Project)
Def(Th):",
	m_future1        	string       comment "Def(En): OGL Segment (Future Use 1)
Def(Th):",
	m_future2        	string       comment "Def(En): OGL Segment (Future Use 2)
Def(Th):",
	m_value_date     	date         comment "Def(En): Value date
Def(Th):",
	m_en_date        	date         comment "Def(En): Entry date
Def(Th):",
	m_nb             	bigint       comment "Def(En): Trade number
Def(Th):",
	m_deal_status    	string       comment "Def(En): Deal status
Def(Th):",
	m_account_type   	string       comment "Def(En): Accounting type
Def(Th):",
	m_en_cd          	string       comment "Def(En): Debit / Credit Indicator
Def(Th):",
	m_en_amtc        	decimal(19,2) comment "Def(En): Credit amount
Def(Th):",
	m_en_amtd        	decimal(19,2) comment "Def(En): Debit amount
Def(Th):",
	m_en_cur         	string       comment "Def(En): Currency code
Def(Th):",
	m_en_type        	smallint     comment "Def(En): Entry type
Def(Th):",
	m_portfolio      	string       comment "Def(En): Portfolio
Def(Th):",
	m_mid_rate       	decimal(14,8) comment "Def(En): Mid rate
Def(Th):",
	m_nostro_cor     	string       comment "Def(En): Nostro Corespondent
Def(Th):",
	m_counterparty   	string       comment "Def(En): Counterparty
Def(Th):",
	m_trn_fmly       	string       comment "Def(En): Product Family
Def(Th):",
	m_trn_grp        	string       comment "Def(En): Product Group
Def(Th):",
	m_trn_type       	string       comment "Def(En): Product Type
Def(Th):",
	m_trn_typo       	string       comment "Def(En): Product Typology
Def(Th):",
	m_en_comment     	string       comment "Def(En): Entry comment
Def(Th):",
	m_nb_rule        	integer      comment "Def(En): Accounting rule number
Def(Th):",
	m_acc_sec        	string       comment "Def(En): Accounting section
Def(Th):",
	m_orgsys         	string       comment "Def(En): Original system
Def(Th):",
	m_origin_ref     	bigint       comment "Def(En): Original reference
Def(Th):",
	m_nb_rule_label  	string       comment "Def(En): Accounting rule description
Def(Th):",
	load_tms         	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id       	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy         	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm           	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd           	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_mx/mx_acup' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);