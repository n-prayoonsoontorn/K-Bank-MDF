-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_sfv_mnul_ar_excp_tdr_reshd.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-07-30   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_SFV.SFV_MNUL_AR_EXCP_TDR_RESHD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_sfv.sfv_mnul_ar_excp_tdr_reshd (
	pos_dt          	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	ar_id           	string       comment "Def(En): Arrangement ID
Def(Th): เลขที่บัญชี
(กรณีเป็นหมายเลขบัตรเครดิตจะเก็บเป็นค่า encrypt)",
	ovrd_eft_dt     	date         comment "Def(En): Effective Date
Def(Th): วันที่ข้อมูลเริ่มมีผล",
	ovrd_ast_clss_st	string       comment "Def(En): Assest Class Status for TDR or Rechedule Exception
Def(Th): สถานะการจัดชั้นของสินทรัพย์ที่ยกเว้นการคิด TDR หรือ Reschedule",
	load_tms        	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id      	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy        	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm          	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd          	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_sfv/sfv_mnul_ar_excp_tdr_reshd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);