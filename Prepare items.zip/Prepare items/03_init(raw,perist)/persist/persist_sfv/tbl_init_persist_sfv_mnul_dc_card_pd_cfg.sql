-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_sfv_mnul_dc_card_pd_cfg.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-01   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_SFV.SFV_MNUL_DC_CARD_PD_CFG
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_sfv.sfv_mnul_dc_card_pd_cfg (
	pos_dt         	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	cardtypeid     	string       comment "Def(En):
Def(Th):",
	cardstylecode  	string       comment "Def(En):
Def(Th):",
	pd_ftr_cd      	string       comment "Def(En):
Def(Th):",
	pd_ftr_dsc_th  	string       comment "Def(En):
Def(Th):",
	pd_ftr_dsc_en  	string       comment "Def(En):
Def(Th):",
	cardflag       	string       comment "Def(En):
Def(Th):",
	category       	string       comment "Def(En):
Def(Th):",
	cardtype       	string       comment "Def(En):
Def(Th):",
	carddescription	string       comment "Def(En):
Def(Th):",
	debitview1     	string       comment "Def(En):
Def(Th):",
	debitview2     	string       comment "Def(En):
Def(Th):",
	debitview3     	string       comment "Def(En):
Def(Th):",
	debitview4     	string       comment "Def(En):
Def(Th):",
	debitview5     	string       comment "Def(En):
Def(Th):",
	format         	string       comment "Def(En):
Def(Th):",
	map            	string       comment "Def(En):
Def(Th):",
	load_tms       	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id     	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy       	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm         	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd         	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_sfv/sfv_mnul_dc_card_pd_cfg' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);