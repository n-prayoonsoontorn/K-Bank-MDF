-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_sfv_mnul_fsdf_ogl_cfg.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-01   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_SFV.SFV_MNUL_FSDF_OGL_CFG
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_sfv.sfv_mnul_fsdf_ogl_cfg (
	pos_dt               	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	pd_nm                	string       comment "Def(En): 
Def(Th): ชื่อผลิตภัณฑ์",
	ogl_tp_cd            	string       comment "Def(En): 
Def(Th): ประเภท OGL",
	ogl_tp_desc          	string       comment "Def(En): 
Def(Th): คำอธิบาย ประเภท OGL",
	coa_rspl_cntr        	string       comment "Def(En):Chart of Account (Responsibility Centre)
Responsibility code can be determined by mapping from the domicile branch of the TCB account.
Def(Th):รหัสหน่วยงานตามโครงสร้างองค์กร",
	coa_ac               	string       comment "Def(En): Chart of Account (OGL Account Number)
 Function of the responsibility center. 
If COA_AC is CA Account then value is same as PSV_COA_AC.
If COA_AC is OD Account then value is same as NEG_COA_AC.
Def(Th):รหัสบัญชีแยกประเภทตามผังการลงบัญชีใหม่ของธนาคาร (KBANK New GL-account number)
ถ้า COA_AC เป็นบัญชี CA ข้อมูลเลขบัญชีจะตรงกับเลขบัญชีใน PSV_COA_AC
ถ้า COA_AC เป็นบัญชี OD ข้อมูลเลขบัญชีจะตรงกับเลขบัญชีใน NEG_COA_AC",
	coa_pd               	string       comment "Def(En):COA Product
If COA_PD is CA Account then value is same as PSV_COA_PD.
If COA_PD is OD Account then value is same as NEG_COA_PD.
Def(Th):รหัสผลิตภัณฑ์
ถ้า COA_PD เป็นบัญชี CA ข้อมูลเลขบัญชีจะตรงกับเลขบัญชีใน PSV_COA_PD
ถ้า COA_PD เป็นบัญชี OD ข้อมูลเลขบัญชีจะตรงกับเลขบัญชีใน NEG_COA_PD",
	coa_pd_ftr_cd        	string       comment "Def(En): Product code 9 digits 
Def(Th):",
	coa_lgl_ent          	string       comment "Def(En):COA Legal Entity
Def(Th):รหัสหน่วยงาน

Responsibility code can be determined by mapping from the domicile branch of the TCB account.",
	coa_prj              	string       comment "Def(En):Project Code of OGL
Def(Th):รหัสสำหรับโครงการ",
	coa_bsn_line         	string       comment "Def(En):Line of Business Code of OGL
GL-product code can be determined from the first 6 digits of the KBank product code for the arrangement.
Def(Th):รหัสสำหรับสายงาน",
	coa_fcn              	string       comment "Def(En):Function Code of OGL
Def(Th):รหัสสำหรับกลุ่มงาน",
	coa_intco            	string       comment "Def(En):Intra Company Number
TCB will set this value to '0000'
Def(Th):หมายเลขกลุ่มบริษัท Intra Company",
	coa_intrco           	string       comment "Def(En):Inter Company Number
See mapping rules in SID appendix
Def(Th):หมายเลขกลุ่มบริษัท Inter Company",
	coa_futr_use1        	string       comment "Def(En):COA Future Used1
This field will filler by 0
Def(Th):ข้อมูลสำหรับการใช้งานในอนาคต1",
	coa_futr_use2        	string       comment "Def(En):COA Future Used2
Def(Th):ข้อมูลสำหรับการใช้งานในอนาคต2",
	coa_ac_acr_int       	string       comment "Def(En): GL code of Accrued interest 
Def(Th):",
	coa_ac_int_incm      	string       comment "Def(En): GL code of Interest income
Def(Th):",
	coa_ac_memo_acr_int  	string       comment "Def(En): GL code of Memo accrued interest 
Def(Th):",
	coa_ac_memo_int_incm 	string       comment "Def(En): GL code of Memo interest income
Def(Th):",
	coa_ac_wrtof_pnp     	string       comment "Def(En): 
Def(Th):",
	coa_ac_wrtof_int     	string       comment "Def(En):
Def(Th):",
	coa_ac_rvrs_wrtof    	string       comment "Def(En):
Def(Th):",
	coa_ac_rvrs_acr_int  	string       comment "Def(En):
Def(Th):",
	coa_ac_rvrs_late_chrg	string       comment "Def(En):
Def(Th):",
	coa_ac_memo_late_chrg	string       comment "Def(En):
Def(Th):",
	load_tms             	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id           	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy             	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm               	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd               	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_sfv/sfv_mnul_fsdf_ogl_cfg' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);