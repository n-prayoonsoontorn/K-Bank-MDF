-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_sfv_mnul_prod_mapping.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-07-30   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_SFV.SFV_MNUL_PROD_MAPPING
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_sfv.sfv_mnul_prod_mapping (
	pos_dt                	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	coa_ac                	string       comment "Def(En): GL Account
Def(Th):",
	coa_pd                	string       comment "Def(En): Product code 6 digits
Def(Th):",
	coa_pd_ftr_cd         	string       comment "Def(En): Product code 9 digits
Def(Th):",
	coa_pd_nm_ogl         	string       comment "Def(En): Product name-OGL
Def(Th):",
	prod_fam              	string       comment "Def(En): Product Family
Def(Th):",
	prod_grp_cd           	string       comment "Def(En): Product Group Code
Def(Th):",
	prod_grp_dsc          	string       comment "Def(En): Product Group Desc
Def(Th):",
	sub_prod              	string       comment "Def(En): SubProduct
Def(Th):",
	commfactorcalc_flag   	string       comment "Def(En): CommFactorCalc_Flag
Def(Th):",
	scrd_loan_f           	string       comment "Def(En): SecureLoan_Flag
Def(Th):",
	retail_secure_unsecure	string       comment "Def(En): Other secured loan flag and Other unsecured loan flag
Def(Th):",
	load_tms              	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id            	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy              	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_sfv/sfv_mnul_prod_mapping' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);