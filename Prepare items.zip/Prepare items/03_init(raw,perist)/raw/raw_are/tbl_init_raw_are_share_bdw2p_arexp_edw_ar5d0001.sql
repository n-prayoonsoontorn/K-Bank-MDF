-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_are_share_bdw2p_arexp_edw_ar5d0001.sql
# Area: are
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-09   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_ARE.ARE_SHARE_BDW2P_AREXP_EDW_AR5D0001
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_are.are_share_bdw2p_arexp_edw_ar5d0001 (
	pos_dt            	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	rectype           	string       comment "Def(En): Record ID = 01 for Detail Record
Def(Th):",
	lineno            	string       comment "Def(En): Detail line number in file
Def(Th):",
	srcname           	string       comment "Def(En): Oracle GL User Journal Source Name
Def(Th):",
	segment1          	string       comment "Def(En): Legal Entity
Def(Th):",
	segment2          	string       comment "Def(En): Responsibility Center
Def(Th):",
	segment3          	string       comment "Def(En): Account
Def(Th):",
	segment4          	string       comment "Def(En): Function
Def(Th):",
	segment5          	string       comment "Def(En): Line of Business
Def(Th):",
	segment6          	string       comment "Def(En): Product
Def(Th):",
	segment7          	string       comment "Def(En): Inter-Company
Def(Th):",
	segment8          	string       comment "Def(En): Intra-Company
Def(Th):",
	segment9          	string       comment "Def(En): Project
Def(Th):",
	segment10         	string       comment "Def(En): FICS Account
Def(Th):",
	segment11         	string       comment "Def(En): Future Used
Def(Th):",
	accountingdt      	string       comment "Def(En): Accounting Date
Def(Th):",
	currencycode      	string       comment "Def(En): ISO currency code of transaction eg. THB,USD
Def(Th):",
	originalamt       	string       comment "Def(En): Ending balance amount in original currency
Def(Th):",
	functionalamt     	string       comment "Def(En): Ending balance amount in base currency (THB equivalent)
Def(Th):",
	lastupdatedt      	string       comment "Def(En): Date of create ending balance data
Def(Th):",
	arrangementid     	string       comment "Def(En): Arrangement Id is KBANK original account number. This account number must be unique
Def(Th):",
	productfeaturecode	string       comment "Def(En): Kbank product feature code 9 digits
Def(Th):",
	filler            	string       comment "Def(En): -
Def(Th):",
	businessdt        	string       comment "Def(En): Business date or extract date of the file.
Def(Th):",
	filler            	string       comment "Def(En): -
Def(Th):",
	load_tms          	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id        	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy          	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm            	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd            	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_are/are_share_bdw2p_arexp_edw_ar5d0001' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);