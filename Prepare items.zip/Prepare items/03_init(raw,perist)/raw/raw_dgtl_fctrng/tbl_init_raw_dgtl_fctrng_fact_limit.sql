-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_dgtl_fctrng_fact_limit.sql
# Area: dgtl_fctrng
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-06   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_DGTL_FCTRNG.DGTL_FCTRNG_FACT_LIMIT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_dgtl_fctrng.dgtl_fctrng_fact_limit (
	pos_dt               	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	cis_id               	string       comment "Def(En): CIS ID of Trade Customer 
Def(Th):",
	parent_cis_id        	string       comment "Def(En): CIS ID of parent 
ถ้าไม่มีบริษัทแม่ให้ส่ง Blank
Def(Th):",
	limit_id             	string       comment "Def(En): Limit ID 
Unique key by LIMIT_ID
Def(Th):",
	limit_level          	string       comment "Def(En): Level of limit
เลขที่ level ของวงเงิน
Def(Th):",
	prod_code            	string       comment "Def(En): Product Code
Def(Th):",
	facility_description 	string       comment "Def(En): Description of  Facility id
Def(Th):",
	type_of_loan         	string       comment "Def(En): To define Contigent or loan
Def(Th):",
	upper_limitid        	string       comment "Def(En): Uppper Limit ID (Concat FACILITY ID and Customer Acronym/abbreviation)
Incase Limit ID is Root Facility , this field put Limit ID. 
Def(Th):",
	upper_facilityid     	string       comment "Def(En): Facility ID in upper level of Faciltiy ID 

Incase Facility ID is Root Facility , this field put Facility ID. 
Def(Th):",
	root_limitid         	string       comment "Def(En): Limit ID of customer level (CL/OV)
Def(Th):",
	root_facilityid      	string       comment "Def(En): Facility ID of Customer level (CL/OV)
Def(Th):",
	second_facilitypid   	string       comment "Def(En): Secenod Facility ID in BankTrade
Def(Th):",
	kbank_pd_code        	string       comment "Def(En): Kbank Product Code of Facility (as Facility product mapping with Kbank product code) 



Def(Th):",
	limit_ccy            	string       comment "Def(En): Limit amount of this Facility in CCY
Def(Th):",
	used_amount_ccy      	string       comment "Def(En): Used amount of this Facility in CCY


Def(Th):",
	available_amount_ccy 	string       comment "Def(En): Available amount of this Facility in CCY


Def(Th):",
	pending_amount_ccy   	string       comment "Def(En): Amount earmark during create/update transaction pending for approval 
กรณีสร้างรายการแต่ยังไม่ได้ approve วงเงินจะถูก earmark
Def(Th):",
	lccy                 	string       comment "Def(En): LIMIT currency e.g. THB, USD 
Def(Th):",
	hold_flag            	string       comment "Def(En): hold flag (ถ้ามีการ hold amount field นี้จะมีค่าเป็น Y และ field Hold amount จะต้องมีค่ามากกว่า 0)
Y - hold
N - No
Def(Th):",
	limit_thb            	string       comment "Def(En): Limit amount  in THB
Def(Th):",
	used_amount_thb      	string       comment "Def(En): Used amount in THB
Def(Th):",
	available_amount_thb 	string       comment "Def(En): Available amount of this Facility
Def(Th):",
	pending_amount_thb   	string       comment "Def(En): Amount earmark during create/update transaction pending for approval 
Def(Th):",
	kbank_midrate        	string       comment "Def(En): KBank Mid Rate that use to convert TXN_AMT_CCY to TXN_AMT
Def(Th):",
	borrower_type        	string       comment "Def(En): Type of borrower
Def(Th):",
	share_limit_flag     	string       comment "Def(En): Share Limit Flag
Def(Th):",
	limit_contract_date  	string       comment "Def(En): contract start date  จะไม่มีการเปลี่ยนแปลงค่านี้ 
Def(Th):",
	update_date          	string       comment "Def(En): Last update date (Approve date)
Note : 
ถ้ามีการเพิ่ม/ลด วงเงิน รวมถึง update information ต่างๆ ของวงเงิน ค่านี้จะต้องมีค่าเปลี่ยนแปลงตามวันที่เกิด Event นั้นๆ 
ถ้าเป็นการเปิดวงเงินครั้งแรก จะมีค่าเดียวกันกับ LIMIT_CONTRACT_DATE
Def(Th):",
	expiry_date          	string       comment "Def(En): Expire date 
Def(Th):",
	revision_date        	string       comment "Def(En): Review date ของวงเงิน (วันที่ทบทวนวงเงินครั้งสุดท้าย)
- plan for next review date
- Last review date
Def(Th):",
	closed_date          	string       comment "Def(En): Closed dated : 
Def(Th): วันที่ปิดวงเงิน",
	limit_status         	string       comment "Def(En): Limit status
If closed date is null , limit status is active
else Inactive
1=Active
2= Inactive
Def(Th):",
	approve_flag         	string       comment "Def(En): Approve flag
Digital Factoring จะส่งเฉพาะ วงเงินที่ได้รับการ approve เรียบร้อยแล้วจะมีค่า เป็น Y ได้อย่างเดียว
Def(Th):",
	uncommitted_type     	string       comment "Def(En): Committed type 
Def(Th):",
	revolving_type       	string       comment "Def(En): Revolving type
Def(Th):",
	approverid           	string       comment "Def(En): Approver ID (KBANK USER ID)  
Def(Th):",
	makerid              	string       comment "Def(En): Create / Issue User :Maker ID (KBANK USER ID)
Def(Th):",
	tenor                	string       comment "Def(En): Tenor day of limit
Def(Th):  ใช้สำหรับ validate ระดับตั๋ว ว่าตั๋วภายใต้ วงเงินนั้นจะต้องมี Tenor ไม่เกิน Tenor ของ limit
ถ้ามีค่าเป็น 0 คือ open-end",
	prod_trade           	string       comment "Def(En): Internal Trade product : liability code 
Def(Th):",
	exposure             	string       comment "Def(En): 
Def(Th): ยอดความเสี่ยงที่ธนาคารต้องแบกรับภาระ   (ยอดวงเงินที่ยังไม่เบิกใช้ +  ยอดเงินต้นคงค้าง)

#1. กรณี Limit ที่ยังไม่ expired
Exposure =  Limit amount

#2.กรณี Limit ที่ถึง Expired แล้ว
    Exposure = Used amount",
	business_code        	string       comment "Def(En): 
Def(Th): ประเภทธุรกิจ ระดับ วงเงิน",
	allocate_limit_ccy   	string       comment "Def(En): Allocated limit 
- กรณีเป็นวงเงิน Share ให้ใช้สูตรการคำนวณ Allocate Limit 
- กรณีไม่มีการ Share วงเงิน ให้ใช้ค่า Limit_CCY มาส่ง
Allocated limit ส่งเฉพาะ กรณี share limit เท่านั้น
กรณีเป็นเงิน THB ค่าใน field นี้ จะเหมือนกันกับ ALLOCATE_LIMIT_THB
Def(Th):",
	allocate_limit_thb   	string       comment "Def(En): Allocated limit 
- กรณีเป็นวงเงิน Share ให้ใช้สูตรการคำนวณ Allocate Limit 
- กรณีไม่มีการ Share วงเงิน ให้ใช้ค่า Limit_THB มาส่ง
Allocated limit ส่งเฉพาะ กรณี share limit เท่านั้น
กรณีเป็นเงิน THB ค่าใน field นี้ จะเหมือนกันกับ ALLOCATE_LIMIT_CCY
Def(Th):",
	contract_limit_amt   	string       comment "Def(En): Contract Limit (วงเงินที่เซ็นต์สัญญา) เพื่อใช้สำหรับส่ง NCB 
Def(Th):",
	hold_amt             	string       comment "Def(En): 
Def(Th): จำนวนเงินที่ Hold ไว้ (Hold amount)
ไม่สามารถใช้วงเงินได้ตามจำนวนเงินที่ระบุ ไว้และต้องไม่เกิน Allocate Limit Amount",
	group_limit_no       	string       comment "Def(En): 
Def(Th): เลขที่วงเงินกลุ่ม",
	group_limit_amount   	string       comment "Def(En): 
Def(Th): จำนวนเงินของวงเงินกลุ่ม",
	main_group_limit_flag	string       comment "Def(En): 
Def(Th): Flag แสดงว่าใครเป็น Main ของ Group วงเงิน",
	load_tms             	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id           	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy             	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm               	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd               	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_dgtl_fctrng/dgtl_fctrng_fact_limit' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);