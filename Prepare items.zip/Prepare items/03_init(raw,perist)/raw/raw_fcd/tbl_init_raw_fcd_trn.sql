-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_fcd_trn.sql
# Area: fcd
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-06   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_FCD.FCD_TRN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_fcd.fcd_trn (
	pos_dt                	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	businessdt            	string       comment "Def(En): Position date
Def(Th): วันที่ของข้อมูล",
	srcappid              	string       comment "Def(En): Application ID, from KBank Registry, of the application from which the information was sourced. (Application ID of from the originator of the transaction)
Def(Th): เลขระบบงานต้นทางของรายการ",
	origrquid             	string       comment "Def(En): Original Unique Request ID 
Def(Th):",
	trnuniqueid           	string       comment "Def(En): FCD Transaction Id
Def(Th):",
	trngroupid            	string       comment "Def(En): FCD Transaction GroupId
Def(Th):",
	relatedorigtrnuniqueid	string       comment "Def(En): FCD Transaction Id to identify the reverse transaction  
Def(Th):",
	acctid                	string       comment "Def(En): Account Number
Def(Th):",
	subacctid             	string       comment "Def(En): Sub Account Number (FCD internal uses 11 digits)
Def(Th):",
	from_toacctid         	string       comment "Def(En): From_To-Account Number
Def(Th):",
	from_tosubacctid      	string       comment "Def(En): From_To-Sub Account Number (FCD internal uses 11 digits)
Def(Th):",
	trnamtsign            	string       comment "Def(En): Sign of Net transaction amount.
Def(Th):",
	trnamt                	string       comment "Def(En): Net transaction amount (CCY)
Def(Th):",
	accruedintamtsign     	string       comment "Def(En): Sign of Accrued interest amount.
Def(Th):",
	accruedintamt         	string       comment "Def(En): Accrued interest amount (CCY)
Def(Th):",
	taxamtsign            	string       comment "Def(En): Sign of Tax amount
Def(Th):",
	taxamt                	string       comment "Def(En): Tax amount (CCY)
Def(Th):",
	penaltyamtsign        	string       comment "Def(En): Sign of Penalty amount
Def(Th):",
	penaltyamt            	string       comment "Def(En): Penalty amount (CCY)
Def(Th):",
	svcbranchid           	string       comment "Def(En): Service Branch 
Def(Th):",
	trndt                 	string       comment "Def(En): FCD Audit Stamp Date (for accounting)
Def(Th):",
	trntime               	string       comment "Def(En): FCD Audit Stamp Time (for accounting)
Def(Th):",
	valuedt               	string       comment "Def(En): Value Date
Def(Th):",
	operationtype         	string       comment "Def(En): Type of Operation
Def(Th):",
	suboperationcode      	string       comment "Def(En): CBS Sub Operation Code
Def(Th):",
	acctbalsign           	string       comment "Def(En): Sign of Accounting Balance of the arrangement
Def(Th):",
	acctbal               	string       comment "Def(En): Accounting Balance of the arrangement
Def(Th):",
	chknum                	string       comment "Def(En): Cheque Number
Def(Th):",
	userid                	string       comment "Def(En): User ID per Kbank Security Guidelines
Def(Th):",
	terminalid            	string       comment "Def(En): TerminalID (sometimes with workstation id value) per Kbank Security Guidelines
Def(Th):",
	authuserid            	string       comment "Def(En): UserID as per KBank security guideline to determine whether the financial transaction is authorized
Def(Th):",
	comment               	string       comment "Def(En): Data stored in FCD and depends on the legacy.
Def(Th):",
	sub_ar                	string       comment "Def(En): Arrangement
Def(Th): เลขที่บัญชีระดับ Sub",
	fm_to_sub_ar          	string       comment "Def(En):: Arrangement
Def(Th): เลขที่บัญชีระดับ Sub",
	inr_txn_cd            	string       comment "Def(En): Transaction Code
Def(Th):",
	currency              	string       comment "Def(En): Currency
Def(Th): สกุลเงิน",
	transactionrate       	string       comment "Def(En): Exchange Rate
Def(Th):",
	passbook_no           	string       comment "Def(En): Passbook Serial No
Def(Th):",
	tso                   	string       comment "Def(En): Transaction Source of Funds
Def(Th):",
	other_ref             	string       comment "Def(En):
Def(Th): เลขที่อ้างอิงอื่น ๆ
เลขอ้างอิงจาก Trade Finance",
	foreign_bank_charge   	string       comment "Def(En): Foreign Bank Charge
Def(Th): วิธีการ Charge ค่าธรรมเนียม(Charge ที่ต้นทาง หรือ ปลายทาง)",
	reverseflag           	string       comment "Def(En): Reverse Flag
Def(Th): flag ที่บอกว่าเป็นรายการยกเลิก",
	closetrnflag          	string       comment "Def(En): Close Transaction Flag
Def(Th):",
	intpaidamtsign        	string       comment "Def(En): Sign of Interest Paid amount (only close account transaction)
Def(Th):",
	intpaidamt            	string       comment "Def(En): Interest Paid amount (only close account transaction) (CCY)
Def(Th):",
	load_tms              	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id            	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy              	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_fcd/fcd_trn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);