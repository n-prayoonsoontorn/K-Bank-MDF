-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_fcl_common_sub_type.sql
# Area: fcl
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-02   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_FCL.FCL_COMMON_SUB_TYPE
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_fcl.fcl_common_sub_type (
	pos_dt      	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	pd_grp      	string       comment "Def(En): Product Group 
LN : Consumer
COM : Commercial
Def(Th):",
	sub_typ_code	string       comment "Def(En): Sub type code
Def(Th):",
	sub_typ_dsc 	string       comment "Def(En): Sub type description
Def(Th):",
	lnd_brw_flg 	string       comment "Def(En): Lending or Borrowing Flag
L - Lending
B - Borrowing
Def(Th):",
	load_tms    	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id  	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy    	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm      	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd      	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_fcl/fcl_common_sub_type' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);