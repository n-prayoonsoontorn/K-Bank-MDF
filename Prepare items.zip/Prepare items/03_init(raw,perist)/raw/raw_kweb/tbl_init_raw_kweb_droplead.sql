-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_kweb_droplead.sql
# Area: kweb
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-22   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_KWEB.KWEB_DROPLEAD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_kweb.kweb_droplead (
	`pos_dt`            	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	`rectype`           	string       comment "Def(En): Type of record, this will be data.
Def(Th):",
	`national_id`       	string       comment "Def(En): Identification ID
Def(Th): หมายเลขบัตรประชาชน
** ถ้า RegistType = 'I' :Individual",
	`start_date`        	string       comment "Def(En): Start Date
Def(Th): วันที่ของข้อมูลที่ลูกค้ามาสมัครครั้งแรกที่กรอก",
	`end date`          	string       comment "Def(En): End Date
Def(Th):  วันที่ของข้อมูลที่ลูกค้ามาสมัคร  + 30 วัน เพื่อกำหนดเป็นวันสิ้นสุดให้ทาง TeleSale ติดต่อลูกค้า",
	`salutation`        	string       comment "Def(En): Salutation Name
Def(Th): คำนำหน้าชื่อ โดยใช้คำว่า คุณ ทั้งหมด",
	`first name`        	string       comment "Def(En): First Name
Def(Th): ชื่อ",
	`last name`         	string       comment "Def(En): Last Name
Def(Th): นามสกุล",
	`mobile_no`         	string       comment "Def(En): Mobile Number
Def(Th): เบอร์โทรศัพท์",
	`email`             	string       comment "Def(En): Email Address
Def(Th):",
	`product_holding`   	string       comment "Def(En): Product Holding Flag
Def(Th):",
	`offered_product`   	string       comment "Def(En): Offered Product
Def(Th): ชื่อผลิตภัณฑ์ที่ลูกค้าสนใจ",
	`customer_income`   	string       comment "Def(En): Customer Income
Def(Th):  ข้อมูลรายได้",
	`ref_code_c`        	string       comment "Def(En): Reference Code (Running no.)
Def(Th): จำนวนคนที่สมัคร",
	`utm_medium`        	string       comment "Def(En): UTM-medium
Def(Th): ประเภทสื่อโฆษณา",
	`utm_source`        	string       comment "Def(En): UTM-source
Def(Th): ช่องทางที่ลูกค้าสมัคร",
	`utm_campaign`      	string       comment "Def(En): UTM-campaign
Def(Th): ชือ campaign",
	`utm_content`       	string       comment "Def(En): UTM-Content
Def(Th): รายละเอียดของ campaign",
	`complete_form`     	string       comment "Def(En): Complete form flag
Def(Th):",
	`data_date`         	string       comment "Def(En): Data Date
Def(Th): วันเดือนที่รับข้อมูลจาก K-website",
	`utm_kw`            	string       comment "Def(En): UTM-keyword
Def(Th): UTM-keyword",
	`districtcode`      	string       comment "Def(En): District
Def(Th): อำเภอ",
	`provincecode`      	string       comment "Def(En): Province
Def(Th): จังหวัด",
	`rccode`            	string       comment "Def(En): RCCODE
Def(Th): RCCODE",
	`branch_name`       	string       comment "Def(En): Branch name
Def(Th): ชื่อสาขา",
	`registtype`        	string       comment "Def(En): Register product as Organize or  Individual
Def(Th): สนใจผลิตภัณฑ์ในนาม",
	`companyregisttype` 	string       comment "Def(En): Registration type
Def(Th): ประเภทการจดทะเบียน",
	`company_name`      	string       comment "Def(En): Company / Store Name
Def(Th): ชื่อบริษัท/ร้านค้า
** ถ้า RegistType = 'O' Organization",
	`butype`            	string       comment "Def(En): Business type
Def(Th): ประเภทธุรกิจ",
	`fi_amount`         	string       comment "Def(En): financial amount
Def(Th): วงเงินที่ต้องการ",
	`other_interest_pro`	string       comment "Def(En): Other products of interest
Def(Th): ผลิตภัณฑ์อื่นๆ ที่สนใจ",
	`other`             	string       comment "Def(En): Other
Def(Th): อื่นๆ โปรดระบุ",
	`buexperience`      	string       comment "Def(En): Business experience
Def(Th): ประสบการณ์ธุรกิจ",
	`onlinestore`       	string       comment "Def(En): Is there an online store?
Def(Th): มีร้านค้าออนไลน์หรือไม่",
	`interestfiamounttype`	string       comment "Def(En): Interest financial amount type
Def(Th): ประเภทวงเงินที่สนใจ หรือ ประเภทวงเงินสินเชื่อ",
	`guarantee`         	string       comment "Def(En): Is there a guarantee?
Def(Th): มีหลักประกันหรือไม่",
	`occ_pt`            	string       comment "Def(En): Occupation
Def(Th):  อาชีพ",
	`banner_id`         	string       comment "Def(En): Banner ID
Def(Th):",
	`cnt_tms`           	string       comment "Def(En): Contact Time
Def(Th): ช่วงเวลาที่สะดวกให้ติดต่อกลับ",
	`corporate_id`      	string       comment "Def(En): Corporate_ID
Def(Th): หมายเลขนิติบุคคล
** ถ้า RegistType = 'O' Organization",
	`cisno`             	string       comment "Def(En): 
Def(Th): หมายเลข CIS Number",
	`objectiveloan`     	string       comment "Def(En): 
Def(Th): วัตถุประสงค์การกู้",
	`interesthomeflag`  	string       comment "Def(En): 
Def(Th): Flag สนใจสินเชื่อบ้านหรือไม่ (Y/N)",
	`pfs_propertyno`    	string       comment "Def(En): 
Def(Th): รหัสทรัพย์บนระบบ PFS",
	`pfs_url`           	string       comment "Def(En): 
Def(Th): URL รายละเอียดชิ้นทรัพย์",
	`pfs_ao`            	string       comment "Def(En): 
Def(Th): Emp ID ของ AO ที่ดูแลทรัพย์",
	`pfs_aoname`        	string       comment "Def(En): 
Def(Th): Name surname ของ AO ที่ดูแลทรัพย์",
	`pfs_an`            	string       comment "Def(En): 
Def(Th): AN ที่ดูแลทรัพย์ (ชื่อหน่วยงาน)",
	`pfs_anname`        	string       comment "Def(En): 
Def(Th): AN ที่ดูแลทรัพย์ (ชื่อ)",
	`pfs_warmlead_by`   	string       comment "Def(En): 
Def(Th): เพื่อบอกว่าทรัพย์ชิ้นนี้ให้ AO หรือ AN เป็นคน warm lead",
	`pfs_chanel`        	string       comment "Def(En): 
Def(Th): ช่องทาง เช่น Kbank Banner, DD Property, Baannia, ตลาดนัดบ้าน, ….",
	`utm_uuid`          	string       comment "Def(En): 
Def(Th): UUID number K+ reference ถ้ากรณีเรียกผ่าน K+ เจาะช่อง drop lead",
	`campgn_name1`      	string       comment "Def(En): 
Def(Th): สำหรับระบุ campaignname ที่สนใจ",
	`campgn_name2`      	string       comment "Def(En): 
Def(Th): สำหรับระบุ campaignname ที่สนใจ",
	`campgn_chosen1`    	string       comment "Def(En): 
Def(Th): สำหรับระบุ product/offer ที่สนใจ",
	`campgn_chosen2`    	string       comment "Def(En): 
Def(Th): สำหรับระบุ product/offer ที่สนใจ",
	`campgn_chosen3`    	string       comment "Def(En): 
Def(Th): สำหรับระบุ product/offer ที่สนใจ",
	`campgn_chosen4`    	string       comment "Def(En): 
Def(Th): สำหรับระบุ product/offer ที่สนใจ",
	`campgn_chosen5`    	string       comment "Def(En): 
Def(Th): สำหรับระบุ product/offer ที่สนใจ",
	`emp_name_recommend`	string       comment "Def(En): 
Def(Th): ชื่อ-นามสกุล พนักงานผู้แนะนำ",
	`emp_id_recommend`  	string       comment "Def(En): 
Def(Th): รหัสพนักงานผู้แนะนำ",
	`reference_api`     	string       comment "Def(En): 
Def(Th): Reference Code ที่ได้มาจากการทดสอบต่อ API Product",
	`mgm code`          	string       comment "Def(En): 
Def(Th): รหัสของเพื่อนผู้แนะนำ",
	`additionalfield1`  	string       comment "Def(En): 
Def(Th): เพื่อใช้ในวัตถุประสงค์ใดๆ ในอนาคต",
	`additionalfield2`  	string       comment "Def(En): 
Def(Th): เพื่อใช้ในวัตถุประสงค์ใดๆ ในอนาคต",
	`additionalfield3`  	string       comment "Def(En): 
Def(Th): เพื่อใช้ในวัตถุประสงค์ใดๆ ในอนาคต",
	`additionalfield4`  	string       comment "Def(En): 
Def(Th): เพื่อใช้ในวัตถุประสงค์ใดๆ ในอนาคต",
	`additionalfield5`  	string       comment "Def(En): 
Def(Th): เพื่อใช้ในวัตถุประสงค์ใดๆ ในอนาคต",
	`additionalfield6`  	string       comment "Def(En): 
Def(Th): เพื่อใช้ในวัตถุประสงค์ใดๆ ในอนาคต",
	`additionalfield7`  	string       comment "Def(En): 
Def(Th): เพื่อใช้ในวัตถุประสงค์ใดๆ ในอนาคต",
	`load_tms`          	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	`src_sys_id`        	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	`ptn_yyyy`          	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	`ptn_mm`            	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	`ptn_dd`            	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_kweb/kweb_droplead' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);