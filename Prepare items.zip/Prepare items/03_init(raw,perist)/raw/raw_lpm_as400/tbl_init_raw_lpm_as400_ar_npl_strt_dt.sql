-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_lpm_as400_ar_npl_strt_dt.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-07-26   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_AR_NPL_STRT_DT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_ar_npl_strt_dt (
	pos_dt                	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	l01w188_yyyymm        	string       comment "Def(En):Position Month
Def(Th):ปีและเดือนของข้อมูล",
	l01w188_cust_no       	string       comment "Def(En): LPM Customer ID
Def(Th): เลขที่ลูกค้าบนระบบ LPM",
	l01w188_acct_no       	string       comment "Def(En): Arrangement ID
Def(Th): เลขที่บัญชี
(กรณีเป็นหมายเลขบัตรเครดิตจะเก็บเป็นค่า encrypt)",
	l01w188_first_npl_date	string       comment "Def(En): First date that arrangement is NPL(Non-Performing Loan)
Def(Th): วันที่เป็น NPL(สินเชื่อที่ไม่ก่อให้เกิดรายได้) ครั้งแรกของบัญชี",
	ppn_tms               	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_stm_id            	string       comment "Def(En): Source System Code
Def(Th): เลขที่แสดงระบบงาน",
	load_tms              	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id            	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy              	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_ar_npl_strt_dt' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);