-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_lpm_as400_clt_dtl.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-07-26   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_CLT_DTL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_clt_dtl (
	pos_dt                 	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt             	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	l10w909_coll_id        	string       comment "Def(En): Collateral Identifier
Def(Th): เลขที่หลักประกัน",
	l10w909_contract_id    	string       comment "Def(En): Contract Identifier
Def(Th): เลขที่สัญญานิติกรรม",
	l10w909_limit_no       	string       comment "Def(En): The number represents limit in LPM system. 
Def(Th): เลขที่ระดับวงเงินในระบบ LPM",
	l10w909_cust_no        	string       comment "Def(En): The number represents customer in LPM system. 
Def(Th): เลขที่ลูกหนี้ในระบบ LPM",
	l10w909_acct_type      	string       comment "Def(En): The arrangement type code. 
Def(Th): ประเภทบัญชีตามกลุ่มผลิตภัณฑ์",
	l10w909_coll_type      	string       comment "Def(En): Collateral Type Code
Def(Th) : ประเภทหลักประกัน",
	l10w909_coll_type_cms  	string       comment "Def(En): Collateral Type CMS Code
Def(Th): ประเภทหลักประกัน (CMS)",
	l10w909_coll_sub_type  	string       comment "Def(En): Collateral Sub Type Code
Def(Th): ประเภทหลักประกันย่อย (CMS)",
	l10w909_bot_type       	string       comment "Def(En): Collateral Type BOT Code
Def(Th): ประเภทหลักประกัน BOT",
	l10w909_type           	string       comment "Def(En): Collateral Document Type Code
Def(Th): ประเภทเอกสารสิทธิ",
	l10w909_mor_type       	string       comment "Def(En): Mortgage type Code
Def(Th): ประเภทภาระติดพัน",
	l10w909_appr_val2      	string       comment "Def(En): Appraisal amount
Def(Th): ราคาประเมินล่าสุด",
	l10w909_appr_date2     	string       comment "Def(En): Appraisal Date
Def(Th): ปีเดือนวันที่ประเมินล่าสุด",
	l10w909_contract_date  	string       comment "Def(En): Contract Date
Def(Th): วันที่ทำนิติกรรม",
	l10w909_seq            	string       comment "Def(En): Collateral sequence number
Def(Th): ลำดับการจำนองที่",
	l10w909_coll_limit     	string       comment "Def(En): Collateral Limit Amount
Def(Th) : วงเงินจำนองของลำดับการจำนองที่",
	l10w909_coll_val       	string       comment "Def(En): Collateral spread amount
Def(Th): ราคาประเมินที่กระจายแล้ว",
	l10w909_sele_per       	string       comment "Def(En): Selected Percent
Def(Th): เปอร์เซ็นต์ที่นำไปคำนวณสำรอง",
	l10w909_coll_tot_limit 	string       comment "Def(En): Collateral Total Limit
Def(Th): มูลค่าจำนองที่กระจายแล้ว",
	l10w909_coll_dis_val   	string       comment "Def(En): Collateral Discount Amount
Def(Th): หลักประกันที่หักส่วนลดแล้ว",
	l10w909_sele_val       	string       comment "Def(En): Selected Value Amount
Def(Th): หลักประกันที่เลือกใช้ โดยเลือกระหว่าง CLT_TOT_LMT หรือ CLT_DCN_AMT ที่ต่ำที่สุด",
	l10w909_outs_flag      	string       comment "Def(En): Outstanding Flag
Def(Th): Flag ยอดหนี้",
	l10w909_appr_flag      	string       comment "Def(En): Appraisal Type Code
Def(Th): Flag การประเมิน",
	l10w909_coll_dis_val80 	string       comment "Def(En): Collateral Discount Value 80% Amount
Def(Th): หลักประกันที่หักส่วนลด 80%
(กรณีประเมินทันคิด 80% ,  ไม่ทันคิด 50%)",
	l10w909_sele_val80     	string       comment "Def(En): Selected Value 80% Amount
Def(Th): หลักประกันแบบ 80% ที่เลือกใช้",
	l10w909_coll_dis_val_kb	string       comment "Def(En): Collateral Discount Amount Kbank
Def(Th): ราคาเฉลี่ยแบบหักส่วนลดแล้วของ Kbank",
	l10w909_sele_val_kb    	string       comment "Def(En): Selected Value Amount Kbank
Def(Th): หลักประกันที่เลือกใช้ kbank",
	l10w909_sele_per_kb    	string       comment "Def(En): Selected Percent Kbank
Def(Th):  %ที่หักหลักประกัน kbank",
	l10w909_coll_grp       	string       comment "Def(En): Collateral Group Code
Def(Th): COLLGRP",
	l10w909_bond_flag      	string       comment "Def(En): Bond Type Code
Def(Th): BONDFLAG",
	ppn_tms                	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_stm_id             	string       comment "Def(En): Source System Code
Def(Th): เลขที่แสดงระบบงาน",
	load_tms               	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id             	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy               	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                 	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                 	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_clt_dtl' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);