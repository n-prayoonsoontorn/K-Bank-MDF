-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_lpm_as400_cst_dtl.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-07-26   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_CST_DTL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_cst_dtl (
	pos_dt                   	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt               	string       comment "Def(En):Position Date
Def(Th):วันที่ของข้อมูล",
	l01w180_cust_no          	string       comment "Def(En): LPM Customer ID
Def(Th): เลขที่ลูกหนี้บนระบบ LPM",
	l01w180_gr_no            	string       comment "Def(En): Customer Group Number
Def(Th): เลขที่กลุ่มลูกค้า",
	l01w180_cust_title       	string       comment "Def(En): Customer Title
Def(Th): คำนำหน้าชื่อลูกหนี้",
	l01w180_cust_name        	string       comment "Def(En): Customer Name
Def(Th): ชื่อลูกหนี้",
	l01w180_prv_branch_no    	string       comment "Def(En): Customer Branch Number
Def(Th): สาขาที่มียอดหนี้สูงสุด",
	l01w180_prv_dept_no      	string       comment "Def(En): Customer Department Number
Def(Th): สังกัดที่มียอดหนี้สูงสุด",
	l01w180_prv_bus_code     	string       comment "Def(En): Kbank Industry Classification Code (Business Code ID)
Def(Th): รหัสธุรกิจของกสิกรที่มียอดหนี้สูงสุด",
	l01w180_prv_bus_group    	string       comment "Def(En): Kbank Industry Group Code
Def(Th): รหัสกลุ่มธุรกิจตาม รหัสธุรกิจ",
	l01w180_prv_bus_grp_seq  	string       comment "Def(En): Kbank Industry Group Sequence
Def(Th): ลำดับกลุ่มธุรกิจ",
	l01w180_prv_bus_bot      	string       comment "Def(En): BOT Industry Classification Code
Def(Th): รหัสธรุกิจตามBOT",
	l01w180_prv_min_day_diff 	string       comment "Def(En): Minimum Delinquent Days
Def(Th): วันค้างต่ำสุด",
	l01w180_prv_max_day_diff 	string       comment "Def(En): Maximum Delinquent Days
Def(Th): วันค้างสูงสุด",
	l01w180_prv_group1       	string       comment "Def(En): Good Debt Indicator
Def(Th): จัดชั้น 2 ระดับ 
1-มีหนี้ดีมากกว่าเท่ากับ 90% 
0-ไม่มี",
	l01w180_prv_group2       	string       comment "Def(En): Classification Level Code
Def(Th): ระดับการจัดชั้นมีค่า 1-6",
	l01w180_prv_limit        	string       comment "Def(En): Total Limit Amount
Def(Th): วงเงินรวมทั้งหมดของลูกค้า",
	l01w180_prv_npl_prin     	string       comment "Def(En): NPL Principal Amount
Def(Th): ยอดหนี้ที่เป็น NPL(เงินต้น)",
	l01w180_prv_outs         	string       comment "Def(En): After Write-off Outstanding Balance
Def(Th): ยอดหนี้หลังตัดสูญ",
	l01w180_prv_accru        	string       comment "Def(En): After Write-off Accrued Interest Amount
Def(Th): ยอดด/บค้างรับหลังตัดสูญ",
	l01w180_cal_outs_12      	string       comment "Def(En): Good Debt After Write-off Outstanding Balance
Def(Th): ยอดคงค้างหนี้ดีหลังตัดสูญ(เฉพาะบ/ชค้างไม่เกิน 30วัน)",
	l01w180_cal_accru_12     	string       comment "Def(En): Good Debt After Write-off Accrued Interest Amount
Def(Th): ยอดด/บหนี้ดีหลังตัดสูญ(เฉพาะบ/ชค้างไม่เกิน 30วัน)",
	l01w180_cal_outs_34      	string       comment "Def(En): Bad Debt After Write-off Outstanding Balance
Def(Th): ยอดคงค้างหนี้เสียหลังตัดสูญ(เฉพาะบ/ชค้างเกิน 30วัน)",
	l01w180_cal_accru_34     	string       comment "Def(En): Bad Debt After Write-off Accrued Interest Amount
Def(Th): ยอดด/บหนี้เสียหลังตัดสูญ(เฉพาะบ/ชค้างเกิน 30วัน)",
	l01w180_coll_limit       	string       comment "Def(En): Total Collateral Limit Amount
Def(Th): รวมวงเงินจำนอง",
	l01w180_coll_val         	string       comment "Def(En): Total Appraisal Amount
Def(Th): รวมราคาหลักประกัน",
	l01w180_coll_dis         	string       comment "Def(En): Collateral Discount Amount
Def(Th): รวมราคาหลักประกันที่ลดค่าตามกฎธปท",
	l01w180_coll_sel         	string       comment "Def(En): Select Collateral Amount
Def(Th): รวมค่าน้อยระหว่างวงเงินจำนวน กับราคาประเมินที่ลดค่าแล้ว",
	l01w180_cover_coll       	string       comment "Def(En): Cover Collateral Amount
Def(Th): ยอดหลักฯกรณี่ที่มีหลักประกันคุ้มยอดหนี้",
	l01w180_cover_outs       	string       comment "Def(En): Cover Outstanding Balance
Def(Th): ยอดคงค้างกรณีที่มีหลักประกันคุ้มยอดหนี้",
	l01w180_coll_cover       	string       comment "Def(En): Select Cover Collateral Amount
Def(Th): มูลหนี้กรณีที่หลักประกันคุ้มหนี้",
	l01w180_coll_not_cover   	string       comment "Def(En): Select Non Cover Collateral Amount
Def(Th): มูลค่าหลักฯกรณีที่หลักประกันไม่คุ้มหนี้",
	l01w180_coll_res         	string       comment "Def(En): Provision Collateral Amount
Def(Th): ยอดรวมหลักฯที่นำมาหักสำรอง",
	l01w180_cal_res_outs_12  	string       comment "Def(En): Good Debt Provision Amount
Def(Th): ยอดหนี้หลังตัดสูญเฉพาะบ/ชค้างไม่เกิน 30 วัน ที่นำมาคำนวณสำรองหนี้",
	l01w180_cal_res_outs_34  	string       comment "Def(En): Bad Debt Provision Amount
Def(Th): ยอดหนี้หลังตัดสูญเฉพาะบ/ชค้างเกิน 30 วัน ที่นำมาคำนวณสำรองหนี้",
	l01w180_res_outs_12      	string       comment "Def(En): Good Debt Reserve Amount
Def(Th): ยอดสำรองเฉพาะบ/ชที่ค้างไม่เกิน 30 วัน(หนี้ดี)",
	l01w180_res_outs_34      	string       comment "Def(En): Bad Debt Reserve Amount
Def(Th): ยอดสำรองเฉพาะบ/ชที่ค้างเกิน 30 วัน(หนี้เสีย)",
	l01w180_tot_pay          	string       comment "Def(En): Total Payment Amount
Def(Th): ยอดชำระรวม",
	l01w180_class_flag       	string       comment "Def(En): Classification Status Code
Def(Th): รหัสสถานะการจัดชั้น",
	l01w180_amc_type         	string       comment "Def(En): ACM Type Code
Def(Th): รหัสที่ระบุว่าลูกค้ามีผลิตภัณฑ์อะไรบ้าง",
	l01w180_tdr_flag         	string       comment "Def(En): TDR Status Code
Def(Th): สถานะการปรับโครงสร้างหนี้",
	l01w180_lec_status       	string       comment "Def(En): Legal Control System (LEC) Status
Def(Th): รหัสการดำเนินการในการดำเนินคดีLEC",
	l01w180_old_group2       	string       comment "Def(En): Previous Class Level Code
Def(Th): การจัดชั้นหนี้เดือนก่อนหน้า",
	l01w180_acct_ofc_tdr     	string       comment "Def(En): TDR Account Officer
Def(Th): รหัสผู้ดูแล",
	l01w180_b_cal_outs_12    	string       comment "Def(En): Good Debt Before Write-off Outstanding Balance
Def(Th): ยอดคงค้างหนี้ดีก่อนตัดสูญ(เฉพาะบ/ชค้างไม่เกิน 30วัน)",
	l01w180_b_cal_accru_12   	string       comment "Def(En): Good Debt Before Write-off Accured Interest Amount
Def(Th): ยอดด/บหนี้ดีก่อนตัดสูญ(เฉพาะบ/ชค้างไม่เกิน 30วัน)",
	l01w180_b_cal_outs_34    	string       comment "Def(En): Bad Debt Before Write-off Outstanding Balance
Def(Th): ยอดคงค้างหนี้เสียก่อนตัดสูญ(เฉพาะบ/ชค้างเกิน 30วัน)",
	l01w180_b_cal_accru_34   	string       comment "Def(En): Bad Debt Before Write-off Accrued Interest Amount
Def(Th): ยอดด/บหนี้เสียก่อนตัดสูญ(เฉพาะบ/ชค้างเกิน 30วัน)",
	l01w180_b_cal_res_outs_12	string       comment "Def(En): Good Debt Before Write-off Provision Amount
Def(Th): ยอดหนี้ก่อนตัดสูญเฉพาะบ/ชค้างไม่เกิน 30 วัน ที่นำมาคำนวณสำรองหนี้",
	l01w180_b_cal_res_outs_34	string       comment "Def(En): Bad Debt Before Write-off Provision Amount
Def(Th): ยอดหนี้ก่อนตัดสูญเฉพาะบ/ชค้างเกิน 30 วัน ที่นำมาคำนวณสำรองหนี้",
	l01w180_b_res_outs_12    	string       comment "Def(En): Good Debt Before Write-off Reserved Amount
Def(Th): ยอดสำรองก่อนตัดสูญเฉพาะบ/ชที่ค้างไม่เกิน 30 วัน(หนี้ดี)",
	l01w180_b_res_outs_34    	string       comment "Def(En): Bad Debt Before Write-off Reserved Amount
Def(Th): ยอดสำรองก่อนตัดสูญเฉพาะบ/ชที่ค้างเกิน 30 วัน(หนี้เสีย)",
	l01w180_center           	string       comment "Def(En): Account Officer Center Code
Def(Th): รหัสสังกัด 10 หลัก ของ ACCTOFCTDR",
	l01w180_acct_ofc_gb      	string       comment "Def(En): Good Debt Account Officer
Def(Th): รหัสผู้ดูแลกรณี AO 944/957 จะเก็บรหัส good bank",
	l01w180_main_status      	string       comment "Def(En): Tracking Main Status Code
Def(Th): สถานะหลักจาก LPM Tracking DRT12700",
	l01w180_sub_status       	string       comment "Def(En): Tracking Sub Status Code
Def(Th): สถานะย่อยจาก LPM Tracking DRT12700",
	l01w180_lec_oper         	string       comment "Def(En): Legal Control System (LEC) Code
Def(Th): สังกัดที่ดำเนินงาน LEC",
	l01w180_cust_type        	string       comment "Def(En): Involve Party Type Code
Def(Th): ประเภทลูกหนี้",
	l01w180_bef_npl_prin     	string       comment "Def(En): Before Write-off NPL Principal Amount
Def(Th): ยอดNPL ก่อนตัดสูญ",
	l01w180_first_tdr_date   	string       comment "Def(En): First TDR Date
Def(Th): วันที่ลงนามปรับครั้งแรก(หามาจากบ/ชที่ปรับฯใช้วันที่ลงนามแรกสุด)",
	l01w180_last_tdr_date    	string       comment "Def(En): Last TDR Date
Def(Th): วันที่ลงนามปรับครั้งล่าสุด(หามาจากบ/ชที่ปรับฯใช้วันที่ลงนามล่าสุด) ภายใต้บัญชีหาวันลงนามปรับ  โดย acct ไปอ่าน drd07200",
	l01w180_max_tdr_seq      	string       comment "Def(En): Last TDR Sequence
Def(Th): ลำดับการปรับครั้งล่าสุดของทุกบ/ช โดย acct ไปอ่าน drd07600",
	l01w180_tdr_method       	string       comment "Def(En): TDR Method Code
Def(Th): วิธีการปรับฯโดยดูรวมจากทุกบ/ชที่มีการปรับฯ ภายใต้บัญชีหาวิธีการปรับครั้งล่าสุดของทุกบ/ช โดย acct ไปอ่าน drd07200
TDRMETHOD INITIAL 000000000
ดูว่าในทุกบัญชีหากมีปรับฯวิธีใด bit นั้นจะเท่ากับ 1",
	l01w180_tdr_remark       	string       comment "Def(En): TDR Other Method Code
Def(Th): หมายเหตุวิธีการปรับฯ โดยดูรวมทุกบ/ชที่ปรับฯ
ภายใต้ทุกบ/ช acctไปอ่าน drd07200-TDR-REMARK BIT ที่ 1-4 มีค่า 0-1
TDRREMARK INITIAL 0000
หากมีปรับฯวิธีใด bit นั้นจะเท่ากับ 1
bit1 =  ลดเงินต้นก่อนและคิดดอกเบี้ยจากเงินต้นที่ลด
bit2 =  ขายหลักประกันให้บุคคลภายนอก     
bit3 =  ปิดบัญชีเงินฝากชำระหนี้         
bit4 =  อื่นๆ (พร้อมระบุรายละเอียดใน F10)",
	l01w180_acct_ofc_co      	string       comment "Def(En): Base Account Officer
Def(Th): รหัสสังกัดผู้ดูแลเดือนฐาน(รายล/น) kpi1d01",
	l01w180_asset_fg         	string       comment "Def(En): Account Officer Asset Code
Def(Th): รหัสสินทรัพย์ระดับลูกหนี้(รายล/น)",
	l01w180_tdr_res_cond     	string       comment "Def(En): TDR Condition Code
Def(Th): เงื่อนไขปรับโครงสร้าง",
	l01w180_cust_block_w     	string       comment "Def(En): Block W Indicator
Def(Th): flag เพื่อระบุว่าลูกหนี้มีบัตรที่ติด block code W หรือไม่
1-มีบัตรที่ติด block W  
0-ไม่มีบัตรที่ติด block W",
	l01w180_tot_liab         	string       comment "Def(En): Total Contingent Amount
Def(Th): ยอดภาระผุกพัน",
	l01w180_min_dr_day_diff  	string       comment "Def(En): Minimum TDR Delinquent Days
Def(Th): วันค้างต่ำสุดจากการปรับฯ(คล)(จากบ/ช cls-day-diff)",
	l01w180_max_dr_day_diff  	string       comment "Def(En): Maximum TDR Delinquent Days
Def(Th): วันค้างมากสุดจากการปรับฯ(คล)(จากบ/ช cls-day-diff)",
	l01w180_w_outs           	string       comment "Def(En): Total Write-off Outstanding Balance
Def(Th): ยอดหนี้รวมของบัตรที่ตัดสูญ (จะไม่นำยอดนี้ไปรวมกับยอดก่อนตัดสูญทางบัญขี)",
	l01w180_w_accru          	string       comment "Def(En): Total Write-off Acrued Interest Amount
Def(Th): ดอกเบี้ยค้างรับรวมของบัตรที่ตัดสูญ",
	l01w180_sys_max_day_diff 	string       comment "Def(En): System Maximum Delinguency Days
Def(Th): วันค้างสูงสุด (จากระบบ)",
	l01w180_sys_min_day_diff 	string       comment "Def(En): System Minimum Delinguency Days
Def(Th): วันค้างต่ำสุด (จากระบบ)",
	l01w180_memo_accru       	string       comment "Def(En): Total Memo Accrued Interest Amount
Def(Th): ยอดดอกเบี้ยนอกการ์ด",
	l01w180_reverse_accru    	string       comment "Def(En): Total Reverse Interest Amount
Def(Th): ยอดดอกเบี้ย Reverse",
	l01w180_overdue_amt      	string       comment "Def(En): Overdue Amount
Def(Th): ยอดค้างชำระ",
	l01w180_pay_prin         	string       comment "Def(En): Principal Payment Amount
Def(Th): ยอดชำระเงินต้น",
	l01w180_pay_int          	string       comment "Def(En): Interest Payment Amount
Def(Th): ยอดชำระดอกเบี้ย",
	l01w180_pay_memo         	string       comment "Def(En): Memo Payment Amount
Def(Th): ยอดชำระดอกเบี้ยนอกการ์ด",
	l01w180_pay              	string       comment "Def(En): Outstanding Payment Amount
Def(Th): ยอดชำระยอดหนี้",
	l01w180_bef_outs         	string       comment "Def(En): Before Write-off Outstanding Balance
Def(Th): ยอดหนี้ก่อนตัดสูญ",
	l01w180_bef_prin         	string       comment "Def(En): Before Write-off Principal Amount
Def(Th): ยอดเงินต้นก่อนตัดสูญ",
	l01w180_bef_accru        	string       comment "Def(En): Before Write-off Accrued Interest Amount
Def(Th): ยอดดอกเบี้ยก่อนตัดสูญ",
	l01w180_res_outs_5       	string       comment "Def(En): BOT Reserve Amount
Def(Th): ยอดสำรองเพิ่มตามเกณฑ์ ธปท.",
	l01w180_tracking_flag    	string       comment "Def(En): Tracking Status Code
Def(Th): สถานะการติดตามหนี้ของระบบ LPM-Tracking ที่ส่งให้ระบบ LEC",
	l01w180_flag_del         	string       comment "Def(En): Legal Control System (LEC) Status Code
Def(Th): สถานะการฟ้องในระบบ LEC",
	l01w180_ao_in_date       	string       comment "Def(En): Account Officer Start Date
Def(Th): วันที่ย้ายเข้ามาอยู่ใน AO นี้",
	l01w180_yyyymm_bb        	string       comment "Def(En): Bad Debt Start Year Month
Def(Th): ปีเดือนที่เริ่มเป็น Bad Bank",
	l01w180_tdr_ltg_flag     	string       comment "Def(En): TDR/LTG Code
Def(Th): รหัสที่บอกว่าเป็น TDR หรือ LTG 
T= TDR
L=LTG",
	l01w180_id_no            	string       comment "Def(En): Identification Number
Def(Th): รหัสประจำตัว ได้แก่ 
- เลขที่บัตรประจำตัวประชาชน(กรณีบุคคลธรรมดา)
- เลขจดทะเบียนนิติบุคคล(กรณี บจก.)",
	l01w180_id_no_hash       	string       comment "Def(En): Identification Number (Hash)
Def(Th): รหัสประจำตัวในรูปแบบ hash ได้แก่ 
- เลขที่บัตรประจำตัวประชาชน(กรณีบุคคลธรรมดา)
- เลขจดทะเบียนนิติบุคคล(กรณี บจก.)",
	l01w180_sale_segment     	string       comment "Def(En): Segment Code
Def(Th): Segment ณ.วันสิ้นเดือน",
	ppn_tms                  	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_stm_id               	string       comment "Def(En): Source System Code
Def(Th): เลขที่แสดงระบบงาน",
	load_tms                 	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id               	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                 	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                   	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                   	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_cst_dtl' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);