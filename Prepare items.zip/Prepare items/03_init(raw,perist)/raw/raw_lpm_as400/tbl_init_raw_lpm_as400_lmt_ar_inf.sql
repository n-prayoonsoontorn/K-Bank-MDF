-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_lpm_as400_lmt_ar_inf.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-09   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_LMT_AR_INF
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_lmt_ar_inf (
	pos_dt                  	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt              	string       comment "Def(En):Position Date
Def(Th):วันที่ของข้อมูล",
	lmd24000_cust_no        	string       comment "Def(En): 
Def(Th): เลขที่ลูกหนี้ LPM",
	lmd24000_acct_type      	string       comment "Def(En): 
Def(Th): ประเภทเครดิต",
	lmd24000_acct_no        	string       comment "Def(En): 
Def(Th): หมายเลขบัญชี",
	lmd24000_acct_type_sub  	string       comment "Def(En): 
Def(Th): ประเภท Product ระดับ SUB หรือ เลขที่บัญชีระดับ SUB",
	lmd24000_cust_no_tr     	string       comment "Def(En): 
Def(Th): เลขที่ลูกค้า Trade",
	lmd24000_sub_tr         	string       comment "Def(En): 
Def(Th): ลำดับวงเงินของ Trade",
	lmd24000_fics_acct_no   	string       comment "Def(En): 
Def(Th): ประเภทหัวบัญชี",
	lmd24000_br_no          	string       comment "Def(En): 
Def(Th): สาขา",
	lmd24000_acct_flag      	string       comment "Def(En): 
Def(Th): 0 = บัญชีปิดแล้ว
1 = บัญชียังไม่ปิด",
	lmd24000_fg_pod         	string       comment "Def(En): 
Def(Th): Flag POD เพื่อใช้แยกกรณีมี Acct-type = 2
0 = ไม่เป็น POD
1 = เป็น POD",
	lmd24000_limit_sub      	string       comment "Def(En): 
Def(Th): วงเงินอนุมัติ (ระดับ ACCT-TYPE-SUB)",
	lmd24000_limit_port     	string       comment "Def(En): 
Def(Th): วงเงินอนุมัติ (ระดับ ACCT-TYPE-SUB)
ที่หักยอดที่ซ้ำออกแล้ว
สามารถนำมารวมได้เป็นวงเงินภาระผูกพันทั้ง Port ของธนาคาร",
	lmd24000_used_limit     	string       comment "Def(En): 
Def(Th): วงเงินที่ใช้ไปแล้ว",
	lmd24000_bef_prin       	string       comment "Def(En): 
Def(Th): เงินต้นก่อนตัดสูญ",
	lmd24000_bef_accru      	string       comment "Def(En): 
Def(Th): ดอกเบี้ยก่อนตัดสูญ",
	lmd24000_bef_memo       	string       comment "Def(En): 
Def(Th): Memoก่อนตัดสูญ",
	lmd24000_prv_prin       	string       comment "Def(En): 
Def(Th): เงินต้นหลังตัดสูญ",
	lmd24000_prv_accru      	string       comment "Def(En): 
Def(Th): ดอกเบี้ยหลังตัดสูญ",
	lmd24000_prv_memo       	string       comment "Def(En): 
Def(Th): Memoหลังตัดสูญ",
	lmd24000_due_date1      	string       comment "Def(En): 
Def(Th): วันที่ครบกำหนดสัญญา  1",
	lmd24000_cont_date1     	string       comment "Def(En): 
Def(Th): วันที่เริ่มสัญญา  1",
	lmd24000_due_date2      	string       comment "Def(En): 
Def(Th): วันที่ครบกำหนดสัญญา  2",
	lmd24000_cont_date2     	string       comment "Def(En): 
Def(Th): วันที่เริ่มสัญญา  2",
	lmd24000_due_date3      	string       comment "Def(En): 
Def(Th): วันที่ครบกำหนดสัญญา  3",
	lmd24000_cont_date3     	string       comment "Def(En): 
Def(Th): วันที่เริ่มสัญญา  3",
	lmd24000_due_date4      	string       comment "Def(En): 
Def(Th): วันที่ครบกำหนดสัญญา  4",
	lmd24000_cont_date4     	string       comment "Def(En): 
Def(Th): วันที่เริ่มสัญญา  4",
	lmd24000_due_date5      	string       comment "Def(En): 
Def(Th): วันที่ครบกำหนดสัญญา  5",
	lmd24000_cont_date5     	string       comment "Def(En): 
Def(Th): วันที่เริ่มสัญญา  5",
	lmd24000_due_date6      	string       comment "Def(En): 
Def(Th): วันที่ครบกำหนดสัญญา  6",
	lmd24000_cont_date6     	string       comment "Def(En): 
Def(Th): วันที่เริ่มสัญญา  6",
	lmd24000_due_date7      	string       comment "Def(En): 
Def(Th): วันที่ครบกำหนดสัญญา  7",
	lmd24000_cont_date7     	string       comment "Def(En): 
Def(Th): วันที่เริ่มสัญญา  7",
	lmd24000_block_code     	string       comment "Def(En): 
Def(Th): รหัสการติด Code",
	lmd24000_cancel_flag    	string       comment "Def(En): 
Def(Th): รหัสการ Cancel",
	lmd24000_fg_limit_used3 	string       comment "Def(En): 
Def(Th): Flag ของ Aval/Acceptance",
	lmd24000_limit_no       	string       comment "Def(En): 
Def(Th): ลำดับที่ของวงเงิน",
	lmd24000_jl_id          	string       comment "Def(En): 
Def(Th): เลขที่ของ Joint limit",
	lmd24000_dummy_acct_fg  	string       comment "Def(En): 
Def(Th): Flag ว่าเป็น Dummy",
	lmd24000_debit_amt      	string       comment "Def(En): 
Def(Th): ยอดที่เบิกใช้ เฉพาะ Loan",
	lmd24000_product_type   	string       comment "Def(En): 
Def(Th): ประเภท Product ของวงเงิน",
	lmd24000_product_limit  	string       comment "Def(En): 
Def(Th): วงเงินระดับ Product
วงเงินระดับ Product ที่ระบบ Trade ใช้ควบคุมการใช้ (ซึ่งรวมกันหลาย Product อาจจะเกินวงเงินระดับลูกค้า)",
	lmd24000_unuse_limit    	string       comment "Def(En): 
Def(Th): วงเงินที่ใช้คำนวณวงเงินคงเหลือ Unuse Limit (ระดับ ACCT-TYPE-SUB)",
	lmd24000_group_id       	string       comment "Def(En): 
Def(Th): เลขที่กลุ่มลูกค้า Trade",
	lmd24000_group_cust_no  	string       comment "Def(En): 
Def(Th): เลขที่กลุ่มลูกค้า LPM",
	lmd24000_group_limit    	string       comment "Def(En): 
Def(Th): วงเงินระดับกลุ่มลูกค้า ที่ได้รับอนุมัติ",
	lmd24000_limit_flag     	string       comment "Def(En): 
Def(Th): การนับวงเงินว่าอนุญาตให้ใช้หรือไม่ให้ใช้วงเงิน
0 = NAL (Disabled)
1 = Normal customer (Enabled)
(เพราะมีบางกรณี หยุดคิดดอกเบี้ย แต่ยังอนุญาตให้ใช้วงเงินเป็นกรณีพิเศษ)",
	lmd24000_legal_entity   	string       comment "Def(En): 
Def(Th): รหัสบริษัท",
	lmd24000_resp_center    	string       comment "Def(En): 
Def(Th): รหัสสังกัด",
	lmd24000_gl_account     	string       comment "Def(En): 
Def(Th): รหัสบัญชีประเภทเครดิต",
	lmd24000_function       	string       comment "Def(En): 
Def(Th): รหัสฟังก์ชันงาน",
	lmd24000_line_business  	string       comment "Def(En): 
Def(Th): รหัสประเภทธุรกิจ",
	lmd24000_gl_product_code	string       comment "Def(En): 
Def(Th): รหัสผลิตภัณฑ์สำหรับการบันทึกบัญชี",
	lmd24000_inter_company  	string       comment "Def(En): 
Def(Th): รหัสบริษัทในการหักค่าใช้จ่ายระหว่างบริษัทในเครือ",
	lmd24000_intra_company  	string       comment "Def(En): 
Def(Th): รหัสบริษัทในการหักค่าใช้จ่ายระหว่างฝ่ายงาน",
	lmd24000_project        	string       comment "Def(En): 
Def(Th): รหัสโครงการ",
	lmd24000_gl_filler1     	string       comment "Def(En): 
Def(Th): สำหรับใช้ในอนาคต",
	lmd24000_gl_filler2     	string       comment "Def(En): 
Def(Th): สำหรับใช้ในอนาคต",
	lmd24000_product_code   	string       comment "Def(En): 
Def(Th): รหัสผลิตภัณฑ์",
	ppn_tms                 	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_stm_id              	string       comment "Def(En): Source System Code
Def(Th): เลขที่แสดงระบบงาน",
	load_tms                	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id              	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                  	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                  	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_lmt_ar_inf' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);