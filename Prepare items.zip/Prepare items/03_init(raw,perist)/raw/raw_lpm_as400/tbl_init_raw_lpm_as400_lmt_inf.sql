-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_lpm_as400_lmt_inf.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-09   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_LMT_INF
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_lmt_inf (
	pos_dt                       	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt                   	string       comment "Def(En):Position Date
Def(Th):วันที่ของข้อมูล",
	lmd24100_cust_no             	string       comment "Def(En): LPM Customer ID
Def(Th): เลขที่ลูกหนี้บนระบบ LPM",
	lmd24100_acct_type           	string       comment "Def(En): Product Group Type Code
Def(Th): ประเภทเครดิต",
	lmd24100_acct_type_sub       	string       comment "Def(En): Limit Account Arrangement to identify the limit number for each Arrangement
Def(Th): เลขที่บัญชีระดับวงเงิน",
	lmd24100_prod_mode           	string       comment "Def(En): Product Category Code
Def(Th): หมวดของ Product
01=สินเชื่อ         
02=ภาระผูกพัน
03=สินทรัพย์         
04=เงินลงทุน (ในระบบ LPM)
05=เงินลงทุน (นอกระบบ LPM)
99=อื่นๆ",
	lmd24100_br_no               	string       comment "Def(En):Owner Branch of Arrangement
Def(Th): สาขาเจ้าของบัญชี",
	lmd24100_acct_tp_sub_lim     	string       comment "Def(En): Limit amount (at Limit level)
Def(Th): วงเงินอนุมัติ (ระดับวงเงิน)",
	lmd24100_acct_tp_sub_lim_port	string       comment "Def(En): Allocated Limit Amount (at Limit level)
Def(Th): วงเงินอนุมัติ (ระดับวงเงิน) ที่หักยอดที่ซ้ำออกแล้ว
สามารถนำมารวมได้เป็นวงเงินภาระผูกพันทั้ง Port ของธนาคาร เช่น
- LN, PN: จะมีค่าเท่ากับค่า setup limit ในฟิลด์ LMT_AMT ยกเว้นกรณีที่วงเงิน inactive ฟิลด์นี้จะถูกปรับค่าเป็น 0 ในขณะที่ฟิลด์ LMT_AMT จะคงค่าไว้
- LI/Aval/Acceptance: มีค่าเท่ากับ setup limit ในฟิลด์ LMT_AMT แต่จะมีการกระจายระดับลูกค้ากรณีเป็น shared limit
- CA/OD: วงเงินรวมของ CA/OD ทุกวง มีค่าเท่ากับ LMT_AMT
เป็นต้น",
	lmd24100_acct_tp_sub_bef_prin	string       comment "Def(En): Principal Amount before Write-off (at Limit level)
Def(Th): เงินต้นก่อนตัดสูญ (ระดับวงเงิน)",
	lmd24100_acct_tp_sub_bef_accr	string       comment "Def(En): Accrued Interest Amount before Write-off (at Limit level)
Def(Th): ดอกเบี้ยก่อนตัดสูญ (ระดับวงเงิน)",
	lmd24100_acct_tp_sub_prv_prin	string       comment "Def(En): Principal Amount after Write-off (at Limit level)
Def(Th): เงินต้นหลังตัดสูญ (ระดับวงเงิน)",
	lmd24100_acct_tp_sub_prv_accr	string       comment "Def(En): Accrued Interest Amount after Write-off (at Limit level)
Def(Th): ดอกเบี้ยหลังตัดสูญ (ระดับวงเงิน)",
	lmd24100_acct_tp_sub_con_dte1	string       comment "Def(En): Contract Date of Limit 1
Def(Th): วันที่เริ่มสัญญาของวงเงินที่ 1
(ถ้าเป็น product อื่นๆที่ไม่ใช่ OD จะมีวงเงินเดียว)",
	lmd24100_acct_tp_sub_due_dte1	string       comment "Def(En): Due Date of Limit 1
Def(Th): วันที่ครบกำหนดสัญญาของวงเงินที่ 1
(ถ้าเป็น product อื่นๆที่ไม่ใช่ OD จะมีวงเงินเดียว)",
	lmd24100_acct_tp_sub_con_dte2	string       comment "Def(En): Contract Date of Limit 2
Def(Th): วันที่เริ่มสัญญาของวงเงินที่ 2
(มีค่าเฉพาะ product OD เท่านั้น)",
	lmd24100_acct_tp_sub_due_dte2	string       comment "Def(En): Due Date of Limit 2
Def(Th): วันที่ครบกำหนดสัญญาของวงเงินที่ 2
(มีค่าเฉพาะ product OD เท่านั้น)",
	lmd24100_acct_tp_sub_con_dte3	string       comment "Def(En): Contract Date of Limit 3
Def(Th): วันที่เริ่มสัญญาของวงเงินที่ 3
(มีค่าเฉพาะ product OD เท่านั้น)",
	lmd24100_acct_tp_sub_due_dte3	string       comment "Def(En): Due Date of Limit 3
Def(Th): วันที่ครบกำหนดสัญญาของวงเงินที่ 3
(มีค่าเฉพาะ product OD เท่านั้น)",
	lmd24100_acct_tp_sub_con_dte4	string       comment "Def(En): Contract Date of Limit 4
Def(Th): วันที่เริ่มสัญญาของวงเงินที่ 4
(มีค่าเฉพาะ product OD เท่านั้น)",
	lmd24100_acct_tp_sub_due_dte4	string       comment "Def(En): Due Date of Limit 4
Def(Th): วันที่ครบกำหนดสัญญาของวงเงินที่ 4
(มีค่าเฉพาะ product OD เท่านั้น)",
	lmd24100_acct_tp_sub_con_dte5	string       comment "Def(En): Contract Date of Limit 5
Def(Th): วันที่เริ่มสัญญาของวงเงินที่ 5
(มีค่าเฉพาะ product OD เท่านั้น)",
	lmd24100_acct_tp_sub_due_dte5	string       comment "Def(En): Due Date of Limit 5
Def(Th): วันที่ครบกำหนดสัญญาของวงเงินที่ 5
(มีค่าเฉพาะ product OD เท่านั้น)",
	lmd24100_acct_tp_sub_con_dte6	string       comment "Def(En): Contract Date of Limit 6
Def(Th): วันที่เริ่มสัญญาของวงเงินที่ 6
(มีค่าเฉพาะ product OD เท่านั้น)",
	lmd24100_acct_tp_sub_due_dte6	string       comment "Def(En): Due Date of Limit 6
Def(Th): วันที่ครบกำหนดสัญญาของวงเงินที่ 6
(มีค่าเฉพาะ product OD เท่านั้น)",
	lmd24100_acct_tp_sub_con_dte7	string       comment "Def(En): Contract Date of Limit 7
Def(Th): วันที่เริ่มสัญญาของวงเงินที่ 7
(ยังไม่มีการใช้งาน)",
	lmd24100_acct_tp_sub_due_dte7	string       comment "Def(En): Due Date of Limit 7
Def(Th): วันที่ครบกำหนดสัญญาของวงเงินที่ 7
(ยังไม่มีการใช้งาน)",
	lmd24100_fg_draw_down        	string       comment "Def(En): Available Limit Indicator; Flag to identify whether there is available limit
Def(Th): Flag การใช้วงเงินของเงินกู้
0 = ยังใช้วงเงินไม่หมด
1 = ใช้วงเงินหมดแล้ว",
	lmd24100_fg_pod              	string       comment "Def(En): POD Indicator; Flag to identify whether it is POD (KEC)
Def(Th): Flag POD เพื่อใช้แยกกรณีมีเป็นบัญชี POD (KEC)
0 = ไม่เป็น POD
1 = เป็น POD
(ไม่มีการใช้งานฟิลด์นี้แล้ว ก่อนหน้านี้ข้อมูล KEC อยู่ภายใต้ PD_GRP_TP_CD = 2 จึงต้องมี flag แยก แต่ปัจจุบันแยกไปเป็น PD_GRP_TP_CD = 13 แล้ว)",
	lmd24100_cust_trade_status   	string       comment "Def(En): Trade Indicator; Flag to identify whether it is Trade product
Def(Th): Flag เพื่อบอกว่าเป็น product Trade
0 = เป็นบัญชี Trade
1 = ไม่เป็นบัญชี Trade",
	lmd24100_fg_in_active        	string       comment "Def(En): Limit Status Indicator
Def(Th): Flag เพื่อบอกว่าวงเงินนั้น active อยู่หรือไม่
1 = ACTIVE  
0 = INACTIVE",
	lmd24100_limit_used          	string       comment "Def(En): Share Limit Indicator (for Aval/Acceptance)
Def(Th): Flag การใช้วงเงินร่วม (ของ Aval/Acceptance)
1 = เป็นวงเงินร่วมของ Aval/Acceptance
0 = ไม่เป็นวงเงินร่วมของ Aval/Acceptance
(ไม่มีการใช้งานฟิลด์นี้แล้วหลังจากโครงการ Profile Lending)",
	lmd24100_debit_amt           	string       comment "Def(En): Total debit amount/disbursement amount
Def(Th): ยอดที่เบิกใช้ทั้งหมด เฉพาะ Loan 
โดยถ้าเป็น Revolving Loan ก็ต้องนับจำนวนเงินที่เบิกออกมาทั้งหมดโดยไม่สนใจว่ามีการชำระคืนหรือไม่
(มีค่าเฉพาะ product Loan สำหรับ product อื่นๆจะมีค่าเป็น 0 ทั้งหมด)",
	lmd24100_exposure_amt        	string       comment "Def(En): Exposure Amount
Def(Th): ยอดภาระที่ธนาคารต้องแบกรับความเสี่ยง
เช่น Loan: จะได้มาจาก Available limit + Outstanding balance เป็นต้น",
	lmd24100_unuse_limit         	string       comment "Def(En): Unused Limit Amount
Def(Th): วงเงินที่ใช้คำนวณวงเงินคงเหลือ Unuse Limit (ระดับวงเงิน)",
	lmd24100_group_cust_no       	string       comment "Def(En): LPM Group ID
Def(Th): เลขที่กลุ่มลูกค้า LPM
(มีค่าเฉพาะ product Trade เท่านั้น)",
	lmd24100_group_limit         	string       comment "Def(En): Group Limit Amount
Def(Th): วงเงินระดับกลุ่มลูกค้า ที่ได้รับอนุมัติ",
	ppn_tms                      	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_stm_id                   	string       comment "Def(En): Source System Code
Def(Th): เลขที่แสดงระบบงาน",
	load_tms                     	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                   	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                     	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                       	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                       	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_lmt_inf' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);