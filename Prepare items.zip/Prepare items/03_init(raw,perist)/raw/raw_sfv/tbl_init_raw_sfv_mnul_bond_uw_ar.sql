-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_sfv_mnul_bond_uw_ar.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-07-26   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_SFV.SFV_MNUL_BOND_UW_AR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_sfv.sfv_mnul_bond_uw_ar (
	pos_dt          	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	hd              	string       comment "Def(En):
Def(Th):",
	ar_id           	string       comment "Def(En): Account Number
Def(Th): เลขที่บัญชี",
	lmt_ar_id       	string       comment "Def(En): Limit Arrangement ID
Def(Th): เลขที่วงเงิน",
	lpm_cst_id      	string       comment "Def(En): LPM Customer ID
Def(Th): เลขที่ลูกค้าระบบ LPM",
	ar_lcs_tp_cd    	string       comment "Def(En): Account status ID
Def(Th): สถานะของบัญชี",
	ip_id           	string       comment "Def(En):Id of involved party
Def(Th):เลขที่ลูกค้า
 สำหรับบัญชีร่วมจะเป็นเลขที่ลูกค้าหลัก",
	opn_dt          	string       comment "Def(En): Account open date
Def(Th): วันที่เปิดบัญชี (จอง)",
	eff_dt          	string       comment "Def(En):Effective Date/Account Activation Date
Def(Th):วันที่ Activate account หรือวันที่มีผลในการใช้บัญชี
กรณี SAFE Account จะเท่ากับ Account Opening Date 
กรณี TCB Account จะเป็น Activation Date",
	ctr_dt          	string       comment "Def(En): Contract Date 
Def(Th): วันที่ลูกค้าลงนามในสัญญา",
	cls_dt          	string       comment "Def(En): Closed Date 
Def(Th): วันที่ลง Accounting ล้างภาระผูกพัน",
	mat_dt          	string       comment "Def(En): Maturity Date 
Def(Th): วันที่ครบกำหนดตามระยะเวลาผ่อนผันและเริ่มนับวันค้าง (Issue Date)",
	coa_pd_ftr_cd   	string       comment "Def(En):KBANK COA Product Future Code
Def(Th):รหัสผลิตภัณฑ์ตามบัญชีธนาคาร 
**(Product code 6 หลัก + 001)
GOV – 330202
Coperate – 330201",
	pnp_coa_ac      	string       comment "Def(En) : COA AC of Principal Amount
Def(Th) :  ค่า GL Account สำหรับยอดเงินต้น 
ยอดหัวบัญชี 7 หลัก OGL Number",
	ccy_cd          	string       comment "Def(En):  Currency Code
Def(Th):  สกุลเงินหลัก",
	ccy_orig_pnp_amt	string       comment "Def(En): Original Principal Amount in Currency 
Def(Th): เงินต้นคงค้าง original ตามสกุลเงิน",
	orig_pnp_amt    	string       comment "Def(En): Original Principal Amount
Def(Th): เงินต้นคงค้าง original",
	kbank_idy_cl_cd 	string       comment "Def(En): Kbank Industry Classification Code (Business Code)
Def(Th): รหัสธุรกิจ",
	coa_rc_cd       	string       comment "Def(En): Chart of Account (Responsibility Centre)
Responsibility code can be determined by mapping from the domicile branch of the TCB account.
Def(Th):",
	acr_fee_amt     	string       comment "Def(En): Accrued Fee Amount in Baht
Def(Th): ค่าธรรมเนียมค้างรับที่บันทึกเป็นรายได้แล้วแต่ยังไม่ได้รับเงิน (หน่วย : บาท)",
	prtfl_id        	string       comment "Def(En): Portfolio Id
Def(Th): เลขที่อ้างอิงชื่อกลุ่มตามการบริหารธุรกิจ (Business Portfolio) ที่สถาบันการเงินกำหนดเพื่อใช้บริหารจัดการภายใน",
	domc_br_no      	string       comment "Def(En):Owner Branch of Arrangement
Def(Th):สาขาเจ้าของบัญชี",
	load_tms        	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id      	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy        	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm          	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd          	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_sfv/sfv_mnul_bond_uw_ar' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);