-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_sfv_mnul_clss_rsn_cd.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-07-30   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_SFV.SFV_MNUL_CLSS_RSN_CD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_sfv.sfv_mnul_clss_rsn_cd (
	pos_dt     	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	clsreason  	string       comment "Def(En): Classification Reason Code
Def(Th):รหัสเหตุผลตรวจทาน",
	by         	string       comment "Def(En): Classification Type Code
Def(Th):ประเภทการสอบทาน (หน่วยงานที่กำหนดรหัส)",
	class_level	string       comment "Def(En): Class level Code
Def(Th):ระดับชั้นของเหตุผล",
	load_tms   	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id 	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy   	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm     	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd     	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_sfv/sfv_mnul_clss_rsn_cd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);