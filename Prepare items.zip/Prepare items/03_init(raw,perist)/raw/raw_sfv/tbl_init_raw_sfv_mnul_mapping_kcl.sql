-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_sfv_mnul_mapping_kcl.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-07-26   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_SFV.SFV_MNUL_MAPPING_KCL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_sfv.sfv_mnul_mapping_kcl (
	pos_dt                	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	pd_tp_cd              	string       comment "Def(En): product type code
Def(Th):",
	pd_sub_tp_cd          	string       comment "Def(En): Product sub type code
Def(Th):",
	mkt_cd                	string       comment "Def(En): market code
Def(Th):",
	spcl_prj_cd           	string       comment "Def(En): special project code
Def(Th):",
	sub_pd_desc           	string       comment "Def(En): Sub Product description
Def(Th):",
	kcl_ln_tp             	string       comment "Def(En): 
Def(Th): flag ว่า config นี้ effective หรือไม่ สำหรับ product loan",
	use_mkt_cd_only       	string       comment "Def(En): 
Def(Th): flag ว่า config นี้ ใช้ field market code มาคิดด้วยหรือไม่",
	od_tp                 	string       comment "Def(En): OD type
Def(Th):",
	kcl_od_tp             	string       comment "Def(En): 
Def(Th): flag ว่า config นี้ effective หรือไม่ สำหรับ product OD",
	scrd_loan_f           	string       comment "Def(En): 
Def(Th): SecureLoan_Flag (เป็น secure loan หรือไม่)",
	prod_grp_cd           	string       comment "Def(En): Product Group Code
Def(Th):",
	prod_grp_dsc          	string       comment "Def(En): Product Group Desc
Def(Th):",
	commfactorcalc_flag   	string       comment "Def(En): CommFactorCalc_Flag
Def(Th):",
	retail_secure_unsecure	string       comment "Def(En): Other secured loan flag and Other unsecured loan flag
Def(Th):",
	load_tms              	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id            	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy              	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_sfv/sfv_mnul_mapping_kcl' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);