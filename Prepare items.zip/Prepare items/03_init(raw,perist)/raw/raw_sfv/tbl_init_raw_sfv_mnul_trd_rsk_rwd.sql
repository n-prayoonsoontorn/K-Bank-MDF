-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_sfv_mnul_trd_rsk_rwd.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-09   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_SFV.SFV_MNUL_TRD_RSK_RWD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_sfv.sfv_mnul_trd_rsk_rwd (
	pos_dt    	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	hd        	string       comment "Def(En):
Def(Th):",
	ste_val   	string       comment "Def(En): State value as R&R Req. sheet
Def(Th): ข้อหัวของธุรกรรมใน sheet excel สรุป Risk and Reward Requirement",
	rr_pa     	string       comment "Def(En): Risk and Reward Seller/Buyer (PA)
Def(Th):",
	rr_alm    	string       comment "Def(En): Risk and Reward Seller/Buyer (ALM)
Def(Th):",
	load_tms  	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_sfv/sfv_mnul_trd_rsk_rwd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);