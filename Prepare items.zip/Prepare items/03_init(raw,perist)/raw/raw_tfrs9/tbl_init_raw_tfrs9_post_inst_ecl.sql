-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_tfrs9_post_inst_ecl.sql
# Area: tfrs9
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-09   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_TFRS9.TFRS9_POST_INST_ECL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_tfrs9.tfrs9_post_inst_ecl (
	pos_dt           	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	rectype          	string       comment "Def(En): Record Type = 01 for Body Record
Def(Th):",
	entity_code      	string       comment "Def(En): Entity code
Def(Th):",
	instid           	string       comment "Def(En): Instrument Identifier for the exposure.
Def(Th): หมายเลขบัญชี/สัญญา",
	valdate          	string       comment "Def(En): Valuation date
Def(Th): วันที่วัดมูลค่ารายการ",
	counterpartyid   	string       comment "Def(En): Customer ID
Def(Th): หมายเลขลูกค้าจากระบบ CIS ของธนาคาร",
	ecl_12m_drawn    	string       comment "Def(En): ECL 12 months amount drawn part
Def(Th):",
	ecl_12m_undrawn  	string       comment "Def(En): ECL 12 months amount undrawn part
Def(Th):",
	ecl_lt_drawn     	string       comment "Def(En): ECL lifetime amount drawn part
Def(Th):",
	ecl_lt_undrawn   	string       comment "Def(En): ECL lifetime amount undrawn part
Def(Th):",
	system_ecl       	string       comment "Def(En): ECL amount which is calcuated by system
Def(Th):",
	overridden_ecl   	string       comment "Def(En): ECL amount which is overrided by users
Def(Th):",
	af_overridden_ecl	string       comment "Def(En): ECL after override
Def(Th):",
	ecl_cushion      	string       comment "Def(En): ECL after  management overlay 
Def(Th):",
	ecl_adj_thb      	string       comment "Def(En): ECL of Loan Adjustment - THB currency
Def(Th):",
	final_ecl_thb    	string       comment "Def(En): Final ECL amount use to booking GL
(FINAL_ECL_THB = ECL_DRAWN_THB + ECL_UNDRAWN_THB)
THB currency
(loan adjustment included in ECL_DRAWN_THB)
Def(Th):",
	ecl_drawn_thb    	string       comment "Def(En): ECL amount drawn part  THB currency (including loan adjustment)
Def(Th):",
	ecl_undrawn_thb  	string       comment "Def(En): ECL amount undrawn part THB currency
Def(Th):",
	system_stage     	string       comment "Def(En): Stage which is calculated by system
Def(Th): Stage คือ การจัดชั้นตามมาตรฐาน IFRS9
1 = Stage 1 - Performing
2 = Stage 2 - Under performing
3 = Stage 3 - Non performing",
	overridden_stage 	string       comment "Def(En): Stage which is overrided by users
Def(Th): Stage คือ การจัดชั้นตามมาตรฐาน IFRS9
1 = Stage 1 - Performing
2 = Stage 2 - Under performing
3 = Stage 3 - Non performing",
	final_stage      	string       comment "Def(En): Final Stage use to booking GL
Def(Th): Stage คือ การจัดชั้นตามมาตรฐาน IFRS9
1 = Stage 1 - Performing
2 = Stage 2 - Under performing
3 = Stage 3 - Non performing",
	insttype         	string       comment "Def(En): Instrument type
Def(Th):",
	credit_spread    	string       comment "Def(En): Spread for adjust discount curve
Def(Th):",
	derecognition_flg	string       comment "Def(En): Flag to identify significantly modified term
1 = significantly modified term
0 = not significantly modified term
Def(Th):",
	poci_flg         	string       comment "Def(En): Flag to identify poci contract
1 = poci contract
0 = not poci contract
Def(Th):",
	currency         	string       comment "Def(En): Original currency of contract
Def(Th):",
	rate             	string       comment "Def(En): Currency rate
Def(Th):",
	ecl_adj          	string       comment "Def(En): ECL of Loan Adjustment - original currency
Def(Th):",
	final_ecl        	string       comment "Def(En): Final ECL amount use to booking GL
(FINAL_ECL = ECL_DRAWN + ECL_UNDRAWN)
- original currency
(loan adjustment included in ECL_DRAWN)
Def(Th):",
	ecl_drawn        	string       comment "Def(En): ECL amount drawn part - original currency
(including loan adjustment)
Def(Th):",
	ecl_undrawn      	string       comment "Def(En): ECL amount undrawn part - original currency
Def(Th):",
	qauntitative_flg 	string       comment "Def(En): Flag to identify quantitative
1 =  quantitative
0 = not  quantitative
Def(Th):",
	npl_strt_dt      	string       comment "Def(En): NPL Start date
Def(Th): วันที่เป็น NPL ครั้งแรก",
	load_tms         	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id       	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy         	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm           	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd           	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_tfrs9/tfrs9_post_inst_ecl' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);