-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_ks_acctxcust.sql
# Area: ks
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-20         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_ks.ks_acctxcust
#--------------------------------------------------------------------------------------------------*/



-- COMMAND ----------
    
alter table ${catalog}.persist_ks.ks_acctxcust set tags ('rbac_table_ks');


-- COMMAND ----------
            
alter table ${catalog}.persist_ks.ks_acctxcust alter column card_id set tags ('rbac_rde_customer_id');


-- COMMAND ----------
            
alter table ${catalog}.persist_ks.ks_acctxcust alter column acct set tags ('rbac_rde_account_number');

