-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: set_tag_v_ks_acct_cst_rel_prfl.sql
# Area: ks
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-20         Nuttapol.P        Initial.
#
# Target table(s)/view(s): ${catalog}.persist_ks_view.v_ks_acct_cst_rel_prfl
#--------------------------------------------------------------------------------------------------*/



-- COMMAND ----------

alter table ${catalog}.persist_ks_view.v_ks_acct_cst_rel_prfl set tags ('rbac_table_ks');


-- COMMAND ----------

alter table ${catalog}.persist_ks_view.v_ks_acct_cst_rel_prfl alter column id_doc_num set tags ('rbac_rde_customer_id');


-- COMMAND ----------

alter table ${catalog}.persist_ks_view.v_ks_acct_cst_rel_prfl alter column acct_num set tags ('rbac_rde_account_number');

