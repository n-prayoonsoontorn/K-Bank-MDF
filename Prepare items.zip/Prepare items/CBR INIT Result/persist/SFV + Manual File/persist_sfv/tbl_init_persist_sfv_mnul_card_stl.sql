-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_sfv_mnul_card_stl.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-04-26   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_SFV.SFV_MNUL_CARD_STL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_sfv.sfv_mnul_card_stl (
	pos_dt     	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	card_tp_cd 	string       comment "Def(En): Card Type Code
Def(Th):",
	card_stl_cd	string       comment "Def(En): Card Style Code
Def(Th):",
	card_f     	string       comment "Def(En): Card Flag
Def(Th):",
	card_cgy   	string       comment "Def(En): Card Category
Def(Th):",
	card_tp    	string       comment "Def(En): Card Type
Def(Th):",
	card_dsc   	string       comment "Def(En): Card Description
Def(Th):",
	db_view1   	string       comment "Def(En): Debit Card View1
Def(Th):",
	db_view2   	string       comment "Def(En): Debit Card View2
Def(Th):",
	db_view3   	string       comment "Def(En): Debit Card View3
Def(Th):",
	db_view4   	string       comment "Def(En): Debit Card View4
Def(Th):",
	db_view5   	string       comment "Def(En): Debit Card View5
Def(Th):",
	fmt        	string       comment "Def(En): Format
Def(Th):",
	load_tms   	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id 	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy   	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm     	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd     	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_sfv/sfv_mnul_card_stl' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);