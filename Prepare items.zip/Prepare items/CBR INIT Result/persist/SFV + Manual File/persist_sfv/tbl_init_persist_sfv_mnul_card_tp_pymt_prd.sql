-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_sfv_mnul_card_tp_pymt_prd.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-04-26   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_SFV.SFV_MNUL_CARD_TP_PYMT_PRD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_sfv.sfv_mnul_card_tp_pymt_prd (
	pos_dt     	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	card_tp_cd 	string       comment "Def(En):
Def(Th):",
	afinty_dsc 	string       comment "Def(En):
Def(Th):",
	card_tp_grp	string       comment "Def(En):
Def(Th):",
	card_tp_dsc	string       comment "Def(En):
Def(Th):",
	cyc_stmt   	string       comment "Def(En):
Def(Th):",
	pymt_prd   	integer      comment "Def(En):
Def(Th):",
	grc_prd    	integer      comment "Def(En):
Def(Th):",
	load_tms   	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id 	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy   	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm     	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd     	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_sfv/sfv_mnul_card_tp_pymt_prd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);