-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_sfv_mnul_prty_fnd.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-04-26   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_SFV.SFV_MNUL_PRTY_FND
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_sfv.sfv_mnul_prty_fnd (
	pos_dt           	date         comment "Derived Business date value From Control-M",
	fnd_id           	string       comment "Right Trim and Direct Move",
	fnd_tp_dsc       	string       comment "Right Trim and Direct Move",
	survy_f          	string       comment "Right Trim and Direct Move",
	fnd_sub_grp_1    	string       comment "Right Trim and Direct Move",
	fnd_sub_grp_2    	string       comment "Right Trim and Direct Move",
	fnd_sub_grp_3    	string       comment "Right Trim and Direct Move",
	fnd_sub_grp_4    	string       comment "Right Trim and Direct Move",
	fnd_sub_grp_5    	string       comment "Right Trim and Direct Move",
	fnd_sub_grp_6    	string       comment "Right Trim and Direct Move",
	fnd_sub_grp_7    	string       comment "Right Trim and Direct Move",
	fnd_sub_grp_8    	string       comment "Right Trim and Direct Move",
	fnd_sub_grp_9    	string       comment "Right Trim and Direct Move",
	fnd_sub_grp_10   	string       comment "Right Trim and Direct Move",
	lbdu_fundtype_dsc	string       comment "Right Trim and Direct Move",
	coa_pd_ftr_cd    	string       comment "Right Trim and Direct Move",
	opn_dt           	timestamp    comment "Cast opn_dt as 'yyyy-MM-dd HH:mm:ss.SSSSSS'",
	due_dt           	timestamp    comment "Cast due_dt as 'yyyy-MM-dd HH:mm:ss.SSSSSS'",
	tfr_dt           	timestamp    comment "Cast tfr_dt as 'yyyy-MM-dd HH:mm:ss.SSSSSS'",
	tfr_cnl_dsc      	string       comment "Right Trim and Direct Move",
	rate_pct         	decimal(7,4) comment "Direct Move",
	prd_mo           	string       comment "Right Trim and Direct Move",
	mstr_fnd_id      	string       comment "Right Trim and Direct Move",
	adl_inf_1        	string       comment "Right Trim and Direct Move",
	adl_inf_2        	string       comment "Right Trim and Direct Move",
	adl_inf_3        	string       comment "Right Trim and Direct Move",
	adl_inf_4        	string       comment "Right Trim and Direct Move",
	adl_inf_5        	string       comment "Right Trim and Direct Move",
	adl_inf_6        	string       comment "Right Trim and Direct Move",
	adl_inf_7        	string       comment "Right Trim and Direct Move",
	adl_inf_8        	string       comment "Right Trim and Direct Move",
	adl_inf_9        	string       comment "Right Trim and Direct Move",
	adl_inf_10       	string       comment "Right Trim and Direct Move",
	data_src         	string       comment "Right Trim and Direct Move",
	amc_cd           	string       comment "Right Trim and Direct Move",
	rsk_dsclr_th     	string       comment "Right Trim and Direct Move",
	rsk_dsclr_en     	string       comment "Right Trim and Direct Move",
	load_tms         	timestamp    comment "Current Timestamp ('yyyy-MM-dd HH:mm:ss.SSSSSS')",
	src_sys_id       	string       comment "Set to '710'",
	ptn_yyyy         	string       comment "Cast pos_dt as string ('YYYY')​",
	ptn_mm           	string       comment "Cast pos_dt as string ('MM')​",
	ptn_dd           	string       comment "Cast pos_dt as string ('DD')​"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_sfv/sfv_mnul_prty_fnd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);