-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_mnul_gnrl_de_cl.sql
# Area: mnul
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-04-23   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_MNUL.MNUL_GNRL_DE_CL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_mnul.mnul_gnrl_de_cl (
	pos_dt         	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	cl_cd          	string       comment "Def(En): Code
Def(Th):",
	eng_desc       	string       comment "Def(En): English Description
Def(Th):",
	th_desc        	string       comment "Def(En): Thai Description
Def(Th):",
	topic          	string       comment "Def(En): Topic
Def(Th):",
	topic_cd       	string       comment "Def(En): Topic Code
Def(Th):",
	od_grp         	string       comment "Def(En): OD Group
Def(Th):",
	orig_src_sys_id	string       comment "Def(En): Original System ID
Def(Th):",
	load_tms       	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id     	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy       	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm         	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd         	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (topic_cd, ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_mnul/mnul_gnrl_de_cl' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);