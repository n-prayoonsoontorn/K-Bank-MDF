-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_sfv_mnul_credit_pd_lvl.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-04-26   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_SFV.SFV_MNUL_CREDIT_PD_LVL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_sfv.sfv_mnul_credit_pd_lvl (
	pos_dt      	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	pd_lvl1     	string       comment "Def(En): Product Level1: Type of products
Def(Th):",
	pd_lvl2     	string       comment "Def(En): Product Level2: Group of products
Def(Th):",
	pd_lvl3     	string       comment "Def(En): Product Levle3: Product code 9 Degits(COA_PD_FTR_CD)
Def(Th):",
	pd_lvl4     	string       comment "Def(En): Product Level4: Blank
Def(Th):",
	pd_grp_tp_cd	string       comment "Def(En): Product Group Type Code
Def(Th):",
	rmrk        	string       comment "Def(En): Remark
Def(Th):",
	ppn_tms     	string       comment "Def(En):
Def(Th):",
	load_tms    	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id  	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy    	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm      	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd      	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_sfv/sfv_mnul_credit_pd_lvl' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);