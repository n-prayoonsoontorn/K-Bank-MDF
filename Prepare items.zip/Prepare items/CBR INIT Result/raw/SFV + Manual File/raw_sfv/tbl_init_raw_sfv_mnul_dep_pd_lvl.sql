-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_sfv_mnul_dep_pd_lvl.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-04-26   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_SFV.SFV_MNUL_DEP_PD_LVL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_sfv.sfv_mnul_dep_pd_lvl (
	pos_dt       	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	coa_pd_ftr_cd	string       comment "Def(En): Chart of Accounts product feature code is KBANK New GL-product number 
 1st - 2nd digits = Product Group
 3rd - 4th digits = Product Sub-Group 
 5th - 6th digits = Product (or service)
 7th - 9th digits = Product Feature (not in the new GL system)
Def(Th): รหัสผลิตภัณฑ์ตามระบบบํญชีใหม่ของธนาคาร (KBANK New Chart of Accounts)",
	pd_lvl1      	string       comment "Def(En): Product Level1
Def(Th): ชื่อผลิตภัณฑ์ระดับ1",
	pd_lvl2      	string       comment "Def(En): Product Level2 (Sub Product)
Def(Th): ชื่อผลิตภัณฑ์ระดับ2 (ผลิตภัณฑ์ย่อย)",
	pd_lvl3      	string       comment "Def(En): Product Level3 (Sub Product)
Def(Th): ชื่อผลิตภัณฑ์ระดับ3 (ผลิตภัณฑ์ย่อย)",
	pd_lvl4      	string       comment "Def(En): Product Level4 (Sub Product)
Def(Th): ชื่อผลิตภัณฑ์ระดับ4 (ผลิตภัณฑ์ย่อย)",
	rmrk         	string       comment "Def(En): Remark
Def(Th):",
	pd_grp       	string       comment "Def(En): Product Group
Def(Th): กรณีที่ Chart of Accounts product feature code ของ FCD ซ้ำกับ Thai Baht ต้องระบุ product group เพิ่มไว้ที่ FCD",
	pd_cd        	string       comment "Def(En): Deposit Product Group
Def(Th):",
	pd_ftr_dsc_th	string       comment "Def(En): Product Name Thai
Def(Th): ชื่อผลิตภัณฑ์ภาษาไทย",
	pd_ftr_dsc_en	string       comment "Def(En): Product Name English
Def(Th): ชื่อผลิตภัณฑ์ภาษาอังกฤษ",
	load_tms     	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id   	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy     	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm       	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd       	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_sfv/sfv_mnul_dep_pd_lvl' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);