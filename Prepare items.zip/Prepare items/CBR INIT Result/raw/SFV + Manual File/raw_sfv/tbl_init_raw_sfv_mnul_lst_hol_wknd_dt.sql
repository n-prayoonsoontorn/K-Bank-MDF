-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_sfv_mnul_lst_hol_wknd_dt.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-04-26   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_SFV.SFV_MNUL_LST_HOL_WKND_DT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_sfv.sfv_mnul_lst_hol_wknd_dt (
	pos_dt    	string       comment "Derived Business date value From Control-M",
	holiday   	string       comment "Cast holiday as 'yyyy-MM-dd'",
	load_tms  	string       comment "Current Timestamp ('yyyy-MM-dd HH:mm:ss.SSSSSS')",
	src_sys_id	string       comment "Set to '710'",
	ptn_yyyy  	string       comment "Cast pos_dt as string ('YYYY')​",
	ptn_mm    	string       comment "Cast pos_dt as string ('MM')​",
	ptn_dd    	string       comment "Cast pos_dt as string ('DD')​"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_sfv/sfv_mnul_lst_hol_wknd_dt' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);