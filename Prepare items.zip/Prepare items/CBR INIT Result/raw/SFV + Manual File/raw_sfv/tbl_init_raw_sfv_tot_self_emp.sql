-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_sfv_tot_self_emp.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-04-26   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_SFV.SFV_TOT_SELF_EMP
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_sfv.sfv_tot_self_emp (
	pos_dt       	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	ip_id        	string       comment "Def(En): CIS no.
Def(Th): เลขที่ลูกค้า",
	se_field_name	string       comment "Def(En): FIELD NAME in Table SE 
Def(Th): ชื่อ FIELD ใน Table SE",
	manual_source	string       comment "Def(En): Manual Source
Def(Th): ชื่อของ Source ที่ต้องเอาข้อมูลขึ้นแบบ Maunal",
	manual_date  	string       comment "Def(En): MANUAL DATE
Def(Th): วันที่โหลดข้อมูลขึ้นแบบ Maunal",
	load_tms     	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id   	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy     	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm       	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd       	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_sfv/sfv_tot_self_emp' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);