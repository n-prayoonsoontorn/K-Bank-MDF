-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_hris_emp_eban.sql
# Area: hris
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-07-24   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_HRIS.HRIS_EMP_EBAN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_hris.hris_emp_eban (
	pos_dt                   	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	rec_type                 	string       comment "Def(En): Record Type - This is to indicate the body record type (Detail record)
Def(Th):",
	emplid                   	string       comment "Def(En): Employee ID
Def(Th): รหัสพนักงาน",
	thai_prefix              	string       comment "Def(En): Title in Thai
Def(Th): คำนำหน้าชื่อไทย",
	thai_firstname           	string       comment "Def(En): First name in Thai
Def(Th): ชื่อไทย",
	thai_lastname            	string       comment "Def(En): Surname in Thai
Def(Th): นามสกุลไทย",
	eng_prefix               	string       comment "Def(En): Title in English
Def(Th): คำนำหน้าชื่ออังกฤษ",
	eng_firstname            	string       comment "Def(En): First name in English
Def(Th): ชื่อภาษาอังกฤษ",
	eng_lastname             	string       comment "Def(En): Surname in English
Def(Th): นามสกุลอังกฤษ",
	deptid                   	string       comment "Def(En): Current Center Code of employee
Def(Th):",
	deptthainame             	string       comment "Def(En): Center Thai Name
Def(Th):",
	deptengname              	string       comment "Def(En): Center English Name
Def(Th):",
	bline_deptid             	string       comment "Def(En): Level 1- Center Code of HR Line Business
Def(Th):",
	bline_deptthainame       	string       comment "Def(En): Level 1- Division Center Thai Description
Def(Th):",
	bline_thai_short_name    	string       comment "Def(En): Level 1- Division Center Thai Short Description
Def(Th):",
	bline_deptengname        	string       comment "Def(En): Level 1- Division Center English Name
Def(Th):",
	bline_eng_short_name     	string       comment "Def(En): Level 1- Division Center English Short Description
Def(Th):",
	parent_deptid            	string       comment "Def(En): Current Parent Center Code of employee
Def(Th): อาจจะเป็น Level ใดก็ได้ ขึ้นกับว่าโครงสร้างองค์กรจะมี level เป็นอย่างไร parent center code อาจมาจาก lvl2 หรือ lvl1 ก็ได้ ซึ่ง column Parent จะแสดงค่า center code จาก level บนถัดไปที่มีค่า",
	parent_deptthainame      	string       comment "Def(En): Parent Center Thai Name
Def(Th):",
	parent_deptthainame_short	string       comment "Def(En): Parent Center Thai Short Name
Def(Th):",
	parent_deptengname       	string       comment "Def(En): Parent Center English Name
Def(Th):",
	parent_deptengname_short 	string       comment "Def(En): Parent Center English Name Name
Def(Th):",
	regname                  	string       comment "Def(En): Region Number
Def(Th):",
	zonename                 	string       comment "Def(En): Zone Number
Def(Th):",
	jobcode                  	string       comment "Def(En): Employee Job
Def(Th):",
	jobthainame              	string       comment "Def(En): Employee Job Thainame
Def(Th):",
	jobengname               	string       comment "Def(En): Employee Job English Name
Def(Th):",
	cotilecode               	string       comment "Def(En): Employee Co title Code
Def(Th):",
	cotilethainame           	string       comment "Def(En): Employee Co title Thainame
Def(Th):",
	cotileengname            	string       comment "Def(En): Employee Co title English Name
Def(Th):",
	kbank_area_no            	string       comment "Def(En): Area that Kbank that located
Def(Th):",
	network_center_code      	string       comment "Def(En): Level 2- Center Code of Network
Def(Th):",
	network_thai_name        	string       comment "Def(En): Level 2- Center ThaiName of Network
Def(Th):",
	network_thai_short_name  	string       comment "Def(En): Level 2- Center Thai Short Description of Network
Def(Th):",
	network_eng_name         	string       comment "Def(En): Level 2- Center English Name of Network
Def(Th):",
	network_eng_short_name   	string       comment "Def(En): Level 2- Center Thai Short Description of Network
Def(Th):",
	dept_center_code         	string       comment "Def(En): Level 3- Center Code of Department/Region
Def(Th):",
	dept_thai_name           	string       comment "Def(En): Level 3- Center ThaiName of Department/Region
Def(Th):",
	dept_thai_short_name     	string       comment "Def(En): Level 3- Center Thai Short Description of Department/Region
Def(Th):",
	dept_eng_name            	string       comment "Def(En): Level 3- Center English Name of Department/Region
Def(Th):",
	dept_eng_short_name      	string       comment "Def(En): Level 3- Center English Short Description of Department/Region
Def(Th):",
	unit_center_code         	string       comment "Def(En): Level 4- Center Code of Unit/Zone,Network of IN. Dept.
Def(Th):",
	unit_thai_name           	string       comment "Def(En): Level 4- Center ThaiName of Unit/Zone,Network of IN. Dept.
Def(Th):",
	unit_thai_short_name     	string       comment "Def(En): Level 4- Center Thai Short Description of Unit/Zone,Network of IN. Dept.
Def(Th):",
	unit_eng_name            	string       comment "Def(En): Level 4- Center English Name of Unit/Zone,Network of IN. Dept.
Def(Th):",
	unit_eng_short_name      	string       comment "Def(En): Level 4- Center English Short Description of Unit/Zone,Network of IN. Dept.
Def(Th):",
	sub_unit_center_code     	string       comment "Def(En): Level 5- Center Code of Sub-unit , Center of IN. Dept.
Def(Th):",
	sub_unit_thai_name       	string       comment "Def(En): Level 5- Center ThaiName of Sub-unit , Center of IN. Dept.
Def(Th):",
	sub_unit_thai_short_name 	string       comment "Def(En): Level 5- Center Thai Short Description of Sub-unit , Center of IN. Dept.
Def(Th):",
	sub_unit_eng_name        	string       comment "Def(En): Level 5- Center English Name of Sub-unit , Center of IN. Dept.
Def(Th):",
	sub_unit_eng_short_name  	string       comment "Def(En): Level 5- Center English Short Description of Sub-unit , Center of IN. Dept.
Def(Th):",
	kbank_br_no              	string       comment "Def(En): Kbank Branch No
Def(Th): เลขที่สาขา",
	center_code_type         	string       comment "Def(En): Type of Center Code
Def(Th):",
	location_code            	string       comment "Def(En): Location code of branch 
Def(Th):",
	location_thai_name       	string       comment "Def(En): Location Thai Name
Def(Th):",
	email_addr               	string       comment "Def(En): E-mail address
Def(Th):",
	nationalid               	string       comment "Def(En): National ID
Def(Th):",
	office_phone1            	string       comment "Def(En): Employee Office Phone1
Def(Th):",
	office_phone1_ext        	string       comment "Def(En): Employee Office Phone1 extension
Def(Th):",
	office_phone2            	string       comment "Def(En): Employee Office Phone2
Def(Th):",
	office_phone2_ext        	string       comment "Def(En): Employee Office Phone2 extension
Def(Th):",
	office_phone3            	string       comment "Def(En): Employee Office Phone3
Def(Th):",
	office_phone3_ext        	string       comment "Def(En): Employee Office Phone3 extension
Def(Th):",
	fax_phone1               	string       comment "Def(En): Employee Office Fax
Def(Th):",
	fax_phone1_ext           	string       comment "Def(En): Employee Office Fax extension
Def(Th):",
	cell_phone1              	string       comment "Def(En): Employee Mobile1
Def(Th):",
	cell_phone2              	string       comment "Def(En): Employee Mobile2
Def(Th):",
	person_status            	string       comment "Def(En): Employee type code
Def(Th): ประเภทพนักงาน",
	person_status_desc       	string       comment "Def(En): Description of Employee status
Def(Th):",
	hr_status                	string       comment "Def(En): Employee status code (HR Status)
Def(Th): สถานะ",
	empl_status              	string       comment "Def(En): Employee life cycle status type code
Def(Th): สถานะพนักงาน",
	officer_cd               	string       comment "Def(En): Employee officer type code
Def(Th): ประเภทพนักงาน",
	empl_class               	string       comment "Def(En): Employment Contract type code
Def(Th): ประเภทสัญญาจ้าง",
	birthdate                	string       comment "Def(En): Birth Date
Def(Th): วันเกิด",
	hire_dt                  	string       comment "Def(En): Employed Date
Def(Th): วันที่เข้าทำงาน",
	effdt                    	string       comment "Def(En): Employee Employment Position Date
Def(Th): วันที่มีผลของการย้ายสังกัด หรือเปลี่ยนแปลงตำแหน่งงาน",
	terminate_dt             	string       comment "Def(En): Termination Date of employee data
Def(Th):",
	gender                   	string       comment "Def(En):
Def(Th):",
	ethnic_group             	string       comment "Def(En):
Def(Th):",
	compcode                 	string       comment "Def(En): Termination Date of employee data
Def(Th):",
	supervisor               	string       comment "Def(En): Supervisor ID
Def(Th):",
	monkhood                 	string       comment "Def(En): Monk Status
Def(Th): ข้อมูลการลาบวช/ฮัจย์",
	birthstate               	string       comment "Def(En): Birth State
Def(Th): รหัสจังหวัดที่เกิด",
	depthiring               	string       comment "Def(En): Department Hiring Descibe
Def(Th): ข้อมูลสังกัดแรกเข้า",
	probation_dt             	string       comment "Def(En): Probation Date 
Def(Th): วันที่บรรจุ",
	prob_extend_flag         	string       comment "Def(En): Protibition Extend Flag
Def(Th): ขยายทดลองงาน",
	disciplin_flag           	string       comment "Def(En): Disciplin Flag
Def(Th): ติดสอบสวน",
	exceed_claim_flag        	string       comment "Def(En): Over Limit Claim Flag
Def(Th): เบิกเกินสิทธิ์",
	pend_doc_flag            	string       comment "Def(En): Claim Pending Document Code
Def(Th): เอกสารค้างส่ง",
	qualification            	string       comment "Def(En): Education Qualification
Def(Th): วุฒิการศึกษา/สาขาวิชา/สถาบัน;วุฒิการศึกษา/สาขาวิชา/สถาบัน;",
	education_lvl            	string       comment "Def(En): Lasted Education Level
Def(Th):",
	education_deg            	string       comment "Def(En): Lasted Education Degree
Def(Th):",
	education_ins            	string       comment "Def(En): Lasted Education Institute
Def(Th):",
	job_layer                	string       comment "Def(En): Job Layer
Def(Th):",
	ldp_flag                 	string       comment "Def(En): Leadership Program Flag
Def(Th):",
	top_bottom_flag          	string       comment "Def(En): Staff Performance Flag
Def(Th):",
	strategic_pos_flag       	string       comment "Def(En): Strategic Position Flag
Def(Th):",
	terminate_reas_cd        	string       comment "Def(En): Reason of Leaving Code
Def(Th):",
	terminate_reas_descr     	string       comment "Def(En): Action&Reason Describe
Def(Th):",
	action_reas_cd           	string       comment "Def(En): Action&Reason Code
Def(Th):",
	action_reas_descr        	string       comment "Def(En): Action&Reason Describe
Def(Th):",
	prv_per_status           	string       comment "Def(En): Employee Status before Termination
Def(Th):",
	prv_per_status_descr     	string       comment "Def(En): Employee Status before Termination Describe
Def(Th):",
	load_tms                 	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id               	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                 	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                   	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                   	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_hris/hris_emp_eban' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);