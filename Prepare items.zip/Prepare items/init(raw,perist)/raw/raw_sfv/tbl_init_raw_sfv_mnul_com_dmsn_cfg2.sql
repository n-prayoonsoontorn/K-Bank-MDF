-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_sfv_mnul_com_dmsn_cfg2.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-07-23   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_SFV.SFV_MNUL_COM_DMSN_CFG2
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_sfv.sfv_mnul_com_dmsn_cfg2 (
	pos_dt     	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	div_cntr_cd	string       comment "Def(En): Level 1- Center Code of HR Line Business
Def(Th):",
	dept_cd    	string       comment "Def(En): Level 3- Center Code of Department/Region
Def(Th):",
	rc_cd      	string       comment "Def(En): Chart of Account (Responsibility Centre)
Def(Th):",
	cst_seg_cd 	string       comment "Def(En): Code of segment which is a group of customer 
Def(Th): รหัสกลุ่มลูกค้า",
	rm_seg_cd  	string       comment "Def(En): RM Segment Code
Def(Th): Segment ผู้ดูแลลูกค้า",
	pd_div_cd  	string       comment "Def(En): Product Division
Def(Th):",
	sale_div_cd	string       comment "Def(En): Sales Division
Def(Th):",
	load_tms   	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id 	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy   	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm     	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd     	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_sfv/sfv_mnul_com_dmsn_cfg2' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);