-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_sfv_mnul_dual_seg_crit.sql
# Area: sfv
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-07-24   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_SFV.SFV_MNUL_DUAL_SEG_CRIT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_sfv.sfv_mnul_dual_seg_crit (
	pos_dt         	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	hd              string       comment "Def(En):
Def(Th):",
	coa_pd_ftr_cd  	string       comment "Def(En): Product Code 9 digits
Def(Th): รหัสผลิตภัณฑ์ 9 หลัก",
	dsc            	string       comment "Def(En): Product Description
Def(Th): คำอธิบายผลิตภัณฑ์",
	dual_seg_crit  	string       comment "Def(En): Dual Segment Criteria
Def(Th): เงื่อนไขในการเลือก Segment",
	dflt_cst_seg_cd	string       comment "Def(En): Default Customer Segment Code
Def(Th):",
	dflt_rm_seg_cd 	string       comment "Def(En): Default Sales Segment Code
Def(Th):",
	load_tms       	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id     	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy       	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm         	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd         	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_sfv/sfv_mnul_dual_seg_crit' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);