-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cis_conttp.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-22    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CIS.CIS_CONTTP
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cis.cis_conttp (
	pos_dt           	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	conttp_cd        	string       comment "Def(En): Contact Type code
Def(Th): รหัสประเภท Contact",
	conttp_local_desc	string       comment "Def(En): Contact Type description in Local language
Def(Th): คำอธิบายประเภท Contact ภาษาท้องถิ่น",
	conttp_en_desc   	string       comment "Def(En): Contact Type description in English
Def(Th): คำอธิบายประเภท Contact ภาษาอังกฤษ",
	conttp_user_id   	string       comment "Def(En): User id
Def(Th): รหัสผู้ทำรายการ",
	conttp_upd_dt    	timestamp    comment "Def(En): Update date time
Def(Th): วันและเวลาที่ทำรายการ",
	load_tms         	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id       	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy         	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm           	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd           	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cis/cis_conttp' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);