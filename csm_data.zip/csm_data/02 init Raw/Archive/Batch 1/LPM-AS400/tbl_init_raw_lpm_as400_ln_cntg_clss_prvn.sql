-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_lpm_as400_ln_cntg_clss_prvn.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-22    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_LN_CNTG_CLSS_PRVN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_ln_cntg_clss_prvn (
	pos_dt                    	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	l01w909_cust_no           	bigint       comment "Def(Th): เลขที่ลูกหนี้",
	l01w909_acct_type         	smallint     comment "Def(Th): ประเภทบัญชี
01  =  LOAN02  =  OD
03  =  CARD PACK  
04  =  BILL DOMESTIC05  =  TRADE        
06  =  บง   
07  =  ธล       
08  =  BIBF   
09  =  สต     
10  =  ADVANCE  
11  =  เงินสดและการชำระเงิน
12  =  เงินให้กู้ยืมแก่ผู้เช่าซื้อ
14  =  หนังสือค้ำประกันและภาระผูกพัน
99  =   อื่นๆ",
	l01w909_acct_no           	string       comment "Def(Th): เลขที่บัญชี",
	l01w909_cr_type           	smallint     comment "Def(Th): ประเภทเครดิต",
	l01w909_fics_type         	integer      comment "Def(Th): ประเภทหัวบัญชี",
	l01w909_acct_cust_type    	smallint     comment "Def(Th): ประเภทลูกค้า ( ระดับบัญชี )",
	l01w909_staff_flag        	smallint     comment "Def(Th): FLAG พนักงาน",
	l01w909_close_date        	integer      comment "Def(Th): ปีเดือนวันที่ปิดบัญชี",
	l01w909_npl_date          	integer      comment "Def(Th): ปีเดือนวันที่เป็น NPL",
	l01w909_bus_code          	integer      comment "Def(Th): รหัสธุรกิจ 9 หลัก ( กสิกร )",
	l01w909_bus_bot           	smallint     comment "Def(Th): รหัสธุรกิจ ธปท.",
	l01w909_bus_group         	smallint     comment "Def(Th): ลำดับกลุ่มธุรกิจ",
	l01w909_bus_grp_seq       	smallint     comment "Def(Th): ลำดับกลุ่มธุรกิจย่อย",
	l01w909_branch_no         	smallint     comment "Def(Th): รหัสสาขา",
	l01w909_dept_no           	smallint     comment "Def(Th): รหัสสังกัด",
	l01w909_prv_int_fg        	smallint     comment "Def(Th): FLAG การคิดดอกเบี้ยเดือนที่แล้ว 
0=คิดดอกเบี้ยปกติ ,1= พัก/งดคิดดอกเบี้ย",
	l01w909_prv_stop_date     	integer      comment "Def(Th): ปีเดือนวันที่พักดอกเบี้ยเดือนที่แล้ว",
	l01w909_acct_group        	smallint     comment "Def(Th): การจัดชั้นระดับบัญชีเชิงปริมาณ",
	l01w909_prv_day_diff      	smallint     comment "Def(Th): จำนวนวันค้างชำระสิ้นเดือน(จากระบบ)",
	l01w909_class_level       	smallint     comment "Def(Th): ระดับการจัดชั้น
1- ปกติ 2-กล่าวถึง3-ต่ำกว่ามาตราฐาน4-สงสัย 
5-สงสัยจะสูญ 6-สูญ  9-ยกเลิกการสอบทาน/ปรับโครงสร้าง",
	l01w909_class_from        	smallint     comment "Def(Th): จัดชั้นคุณภาพจาก 1-สอบทาน ,2- ปรับโครงสร้าง",
	l01w909_class_reason      	smallint     comment "Def(Th): เหตุผลการจัดชั้น",
	l01w909_acct_res_group    	smallint     comment "Def(Th): การจัดชั้นระดับบัญชีเชิงคุณภาพ",
	l01w909_acct_npl_group    	smallint     comment "Def(Th): ระดับ NPL",
	l01w909_r_prv_outs        	decimal(13,2) comment "Def(Th): ยอดจากระบบ",
	l01w909_prv_outs          	decimal(13,2) comment "Def(Th): ยอดคงค้างสิ้นเดือน(หลังตัดสูญทางบัญชี)",
	l01w909_prv_accru         	decimal(13,2) comment "Def(Th): ยอดดอกเบี้ยค้างรับสิ้นเดือน(หลังตัดสูญทางบัญชี)",
	l01w909_limit             	decimal(13,2) comment "Def(Th): วงเงิน",
	l01w909_npl_outs          	decimal(13,2) comment "Def(Th): ยอดคงค้าง NPL",
	l01w909_npl_accru         	decimal(13,2) comment "Def(Th): ดอกเบี้ยค้างรับ NPL",
	l01w909_prv_pay           	decimal(13,2) comment "Def(Th): ยอดชำระเดือนที่แล้ว",
	l01w909_prv_ext_pay       	decimal(13,2) comment "Def(Th): ยอดชำระนอกการ์ดเดือนที่แล้ว",
	l01w909_enter_date        	integer      comment "Def(Th): ปีเดือนวันที่เข้ามาในระบบ",
	l01w909_cr_bot            	smallint     comment "Def(Th): ประเภทสินทรัพย์ธปท.",
	l01w909_src_br            	smallint     comment "Def(Th): รหัสสาขาที่รายงานธปท.",
	l01w909_src_br_seq        	smallint     comment "Def(Th): ลำดับที่สาขาที่รายงานธปท.",
	l01w909_area_code         	smallint     comment "Def(Th): รหัสพื้นที่",
	l01w909_reg_code          	smallint     comment "Def(Th): รหัสภาค",
	l01w909_zone_code         	smallint     comment "Def(Th): รหัสเขต",
	l01w909_div_code          	smallint     comment "Def(Th): รหัสสาขา",
	l01w909_acct_res_group_old	smallint     ,
	l01w909_center_branch     	smallint     comment "Def(Th): รหัสศูนยธุรกิจกรณีหนี้ exim bill / รหัส in-out out-out BIBF
BIBF = (ACCT TYPE = 8, 001 = IN-OUT, 002 = OUT-OUT)",
	l01w909_currency          	smallint     comment "Def(Th): รหัสสกุล",
	l01w909_bef_outs          	decimal(13,2) comment "Def(Th): ยอดหนี้ก่อนตัดสูญ",
	l01w909_bef_accru         	decimal(13,2) comment "Def(Th): ยอดด/บค้างรับก่อนตัดสูญ",
	l01w909_wrt_bot_flag      	smallint     comment "Def(En): flag writeoff Bot
0=No write-off
1=Write-off",
	l01w909_wrt_tfb_flag      	smallint     comment "Def(En): flag writeoff Tfb
0=No write-off
1=Write-off",
	l01w909_rec_flag          	smallint     comment "Def(En): flag receive",
	l01w909_prv_reverse_flag  	smallint     comment "Def(Th): flag reverse accruยกเลิกการรับรู้รายได้
0 ไม่พักดอกเบี้ย = คิดดอกเบี้ย รับรู้เป็นรายได้ 
1  ระงับรับรู้รายได้    พักดอกเบี้ยตั้งแต่  1 มค 2543  โดยระบบต้นทาง 
2 ระงับรับรู้รายได้    พักดอกเบี้ยตั้งแต่  1 มค 2543  โดยระบบ LPM เมื่อ บัญชีมีสถานะคิดดอกเบี้ย แต่ มีการจัดชั้นระดับบัญชี ตั้งแต่ 4  ขึ้นไป 
3 ระงับรับรู้รายได้    พักดอกเบี้ยก่อน 1 มค 2543    แต่ต้องการให้ระบบคำนวนดอกเบี้ยนอกการ์ด
4 ดอกเบี้ยนอกการ์ด",
	l01w909_prv_reverse_date  	integer      comment "Def(Th): วันที่ยกเลิกการรับรู้รายได้",
	l01w909_prv_reverse_accru 	decimal(13,2) comment "Def(Th): ยอดด/บที่ยกเลิกรับรู้รายได้",
	l01w909_prv_memo_accru    	decimal(13,2) comment "Def(Th): ยอดดอกเบี้ยนอกการ์ดเมื่อมีการยกเลิกการรับรู้รายได้",
	l01w909_class_date        	integer      comment "Def(Th): วันที่จัดชั้นจากการปรับโครงสร้าง/สอบทาน",
	l01w909_dr_memo_flag      	smallint     comment "Def(Th): 0 = บ/ช ปกติ, 1 = บ/ช ที่แปลงหนี้มาจากด/บ, 2 = Kbank priviledge
4= Home-Equity",
	l01w909_cls_day_diff      	smallint     comment "Def(Th): จำนวนวันค้างชำระที่นับหลังปรํบโครงสร้างกรณี",
	l01w909_npl_day_diff      	smallint     comment "Def(Th): วันค้าง NPL",
	l01w909_bot_acct_group    	smallint     comment "Def(Th): จัดชั้นระดับบัญชีตามธปท.",
	l01w909_acct_coll_res     	decimal(13,2) comment "Def(Th): หลักประกันที่นำมาสำรองรายบัญชี",
	l01w909_acct_res_outs     	decimal(13,2) comment "Def(Th): ยอดสำรองรายบัญชี",
	l01w909_acct_b_coll_res   	decimal(13,2) comment "Def(Th): หลักประกันที่นำมาสำรองรายบัญชีก่อนตัดสูญ",
	l01w909_acct_b_res_outs   	decimal(13,2) comment "Def(Th): ยอดสำรองรายบัญชีก่อนตัดสูญ",
	l01w909_rec_type          	smallint     comment "Def(Th): ประเภทของ Record 
 1 = สินเชื่อ, 2 = Credit card block W, 3 = Trade contingent , 4 = LI , 5 = Aval  , 6 = Acceptance , 7 = ADL , 8 = ADI
 9 = Ploy, 0 = Dummy trade",
	l01w909_acct_res_outs_5   	decimal(13,2) ,
	l01w909_acct_npv_prov     	decimal(13,2) ,
	l01w909_acct_cushion      	decimal(13,2) ,
	l01w909_bef_reverse_accru 	decimal(13,2) ,
	l01w909_bef_memo_accru    	decimal(13,2) ,
	l01w909_acct_coll_res_kb  	decimal(13,2) ,
	l01w909_acct_res_outs_kb  	decimal(13,2) ,
	l01w909_acct_res_outs_5_kb	decimal(13,2) ,
	l01w909_acct_npv_prov_kb  	decimal(13,2) ,
	l01w909_provision_basel   	decimal(13,2) ,
	l01w909_legal_entity      	smallint     ,
	l01w909_resp_center       	smallint     ,
	l01w909_gl_account        	integer      ,
	l01w909_function          	smallint     ,
	l01w909_line_business     	smallint     ,
	l01w909_gl_product_code   	integer      ,
	l01w909_inter_company     	smallint     ,
	l01w909_intra_company     	smallint     ,
	l01w909_project           	smallint     ,
	l01w909_gl_filler1        	integer      ,
	l01w909_gl_filler2        	smallint     ,
	l01w909_product_code      	integer      ,
	l01w909_filler            	string       ,
	load_tms                  	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_ln_cntg_clss_prvn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);