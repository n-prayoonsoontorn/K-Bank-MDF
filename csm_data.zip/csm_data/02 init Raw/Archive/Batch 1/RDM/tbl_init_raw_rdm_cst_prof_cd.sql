-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_rdm_cst_prof_cd.sql
# Area: rdm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-22    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_RDM.RDM_CST_PROF_CD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_rdm.rdm_cst_prof_cd (
	pos_dt         	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	name           	string       comment "Def(En):Description in Thai
Def(Th):คำอธิบายภาษาไทย",
	code           	string       comment "Def(En):Code of profession
Def(Th):รหัสสาขาอาชีพ",
	dsc_en         	string       comment "Def(En):Description in English
Def(Th):คำอธิบายภาษาอังกฤษ",
	rsk_f          	string       comment "Def(En):Flag that use to identify risk on the profession in term of bank's credit policy
Def(Th):มีความเสี่ยงในเชิงนโยบายเครดิตหรือไม่",
	actv_f_code    	string       comment "Def(En):Active Flag Code
Def(Th):รหัสบ่งชี้สถานะ",
	actv_f_name    	string       comment "Def(En):Active Flag Name",
	dspl_seq       	decimal(38,0) comment "Def(En): Display Sequence",
	enterdatetime  	timestamp    comment "Description (Eng)Enter Date time
Def(Th):วันที่ใส่ข้อมูล",
	enterusername  	string       comment "Def(En):Enter User Name
Def(Th):ผู้ใส่ข้อมูล",
	lastchgdatetime	timestamp    comment "Def(En):Update Date
Def(Th):วันที่อัพเดทข้อมูล",
	lastchgusername	string       comment "Def(En):Update User Name
Def(Th):ผู้อัพเดทข้อมูล",
	load_tms       	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id     	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy       	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm         	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd         	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_rdm/rdm_cst_prof_cd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);