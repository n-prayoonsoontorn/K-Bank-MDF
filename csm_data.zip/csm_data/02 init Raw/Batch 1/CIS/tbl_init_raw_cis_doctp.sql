-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cis_doctp.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-05    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CIS.CIS_DOCTP
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cis.cis_doctp (
	pos_dt          	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	doctp_cd        	string       comment "Def(En): Document Type code
Def(Th): รหัสประเภทเอกสาร",
	doctp_local_desc	string       comment "Def(En): Document Type description in Local language
Def(Th): คำอธิบายประเภทเอกสาร ภาษาท้องถิ่น",
	doctp_en_desc   	string       comment "Def(En): Document Type description in English
Def(Th): คำอธิบายประเภทเอกสาร ภาษาอังกฤษ",
	doctp_user_id   	string       comment "Def(En): User id
Def(Th): รหัสผู้ทำรายการ",
	doctp_upd_dt    	string       comment "Def(En): Update date time
Def(Th): วันและเวลาที่ทำรายการ",
	load_tms        	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id      	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy        	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm          	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd          	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cis/cis_doctp' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);