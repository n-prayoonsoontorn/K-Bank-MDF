-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cis_idv.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-05    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CIS.CIS_IDV
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cis.cis_idv (
	pos_dt          	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	method          	string       comment "Def(En): Ingestion Method
Def(Th): วิธีการนำเข้า",
	idv_ip_id       	string       comment "Def(En): Customer id
Def(Th): เลขที่ลูกค้า",
	idv_nation      	string       comment "Def(En): Nationality
Def(Th): รหัสสัญชาติ",
	idv_gender      	string       comment "Def(En): Gender code
Def(Th): รหัสเพศ",
	idv_marital_stat	string       comment "Def(En): Marital status code
Def(Th): รหัสสถานภาพสมรส",
	idv_edu_level   	string       comment "Def(En): Education level
Def(Th): รหัสระดับการศึกษา",
	idv_income      	string       comment "Def(En): Income range
Def(Th): รหัสรายได้ต่อเดือน",
	idv_fmly_inc    	string       comment "Def(En): Family income range
Def(Th): รหัสรายได้ครอบครัวต่อเดือน",
	idv_ocp         	string       comment "Def(En): Occupation code
Def(Th): รหัสอาชีพ",
	idv_position    	string       comment "Def(En): Job position code
Def(Th): รหัสตำแหน่งงาน",
	idv_prof        	string       comment "Def(En): Profession code
Def(Th): รหัสสาขาอาชีพ",
	idv_prof_oth    	string       comment "Def(En): Profession (Other)
Def(Th): สาขาอาชีพอื่น ๆ",
	idv_dth_flg     	string       comment "Def(En): Death flag
Def(Th): Flag การเสียชีวิต",
	idv_dth_dt      	string       comment "Def(En): Death date
Def(Th): วันที่เสียชีวิต",
	idv_no_child    	string       comment "Def(En): No. of child
Def(Th): จำนวนบุตร",
	idv_user_id     	string       comment "Def(En): User id
Def(Th): รหัสผู้ทำรายการ",
	idv_upd_dt      	string       comment "Def(En): Update date time
Def(Th): วันและเวลาที่ทำรายการ",
	load_tms        	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id      	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy        	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm          	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd          	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cis/cis_idv' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);