-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_csm_downstreamconfig.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-04    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CSM.CSM_DOWNSTREAMCONFIG
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_csm.csm_downstreamconfig (
	pos_dt      	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dsc_form_id 	string       comment "Def(En): Form Id
Def(Th): รหัส Form",
	dsc_rule_id 	string       comment "Def(En):Rule Id
Def(Th):รหัส Rule",
	dsc_upd_user	string       comment "Def(En):Update by UserID
Def(Th):User ที่แก้ไขข้อมูล",
	dsc_upd_dt  	string       comment "Def(En):Update date
Def(Th):วันที่อัพเดทข้อมูล",
	load_tms    	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id  	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy    	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm      	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd      	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_csm/csm_downstreamconfig' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);