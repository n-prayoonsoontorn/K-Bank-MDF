-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_csm_receivertype.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-04    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CSM.CSM_RECEIVERTYPE
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_csm.csm_receivertype (
	pos_dt         	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	recvtp_cd      	string       comment "Def(En): Receiver type code
Def(Th): รหัสประเภทของ receiver",
	recvtp_th_desc 	string       comment "Def(En):Receiver Thai description
Def(Th):รายละเอียดภาษาไทย",
	recvtp_en_desc 	string       comment "Def(En):Receiver English description
Def(Th):รายละเอียดภาษาอังกฤษ",
	recvtp_status  	string       comment "Def(En):Receiver type status
Def(Th):สถานะของ Receiver type",
	recvtp_upd_user	string       comment "Def(En):Update by UserID
Def(Th):user ที่แก้ไขข้อมูล",
	recvtp_upd_dt  	string       comment "Def(En):Update date
Def(Th):วันที่อัพเดทข้อมูล",
	load_tms       	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id     	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy       	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm         	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd         	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_csm/csm_receivertype' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);