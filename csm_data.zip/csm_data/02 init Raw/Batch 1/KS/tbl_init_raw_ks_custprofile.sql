-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_ks_custprofile.sql
# Area: ks
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-04    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_KS.KS_CUSTPROFILE
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_ks.ks_custprofile (
	pos_dt                	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt            	string       comment "Def(En): Date of data generated 
Def(Th): วันที่ข้อมูล",
	card_id               	string       comment "Def(En): Customer identification number 
Def(Th): เลขบัตรประชาชน/หนังสือเดินทาง",
	cust_cd               	string       comment "Def(En): Customer reference number 
Def(Th): รหัสลูกค้าตามประเภทการเปิดบัญชี",
	cust_since_date       	string       comment "Def(En): Account approve date
Def(Th): วันที่ลูกค้าเปิดบัญชีประเภทต่างๆตาม",
	document_type         	string       comment "Def(En): Document type
Def(Th): ประเภทเอกสารยืนยันตัวตน",
	birthday              	string       comment "Def(En): Dath of birth
Def(Th): วันเกิด",
	cust_type             	string       comment "Def(En):
Def(Th): ชนิดของลูกค้า
1 - ลูกค้าทั่วไป (Regular Customer)
2 - ลูกค้าต่างประเทศ (Foreign Customer)
3 - Sub-Broker หรือ Broker (เช่นกรณีซื้อขาย OTC)
4 - ลูกค้าที่เป็นกองทุน (Fund)
5 - Port ของบริษัท (Company Portfolio)",
	person_cd             	string       comment "Def(En):
Def(Th): เลขอ้างอิงประเภทบุคคล
personCode = 1 (บุคคลธรรมดา ในประเทศ)
personCode = 3 (บุคคลธรรมดา นอกประเทศ)
personCode = 0 (นิติบุคคล ในประเทศ)
personCode = 2 (นิติบุคคล ต่างประเทศ)",
	gndr                  	string       comment "Def(En): Gender
Def(Th): เพศ (M,F,O)",
	marital               	string       comment "Def(En):
Def(Th):
0 โสด
1 สมรส(จดทะเบียน)
2 หม้าย
3 หย่าร้าง
4 สมรส(ไม่จดทะเบียน)",
	income                	string       comment "Def(En): Income
Def(Th): รายได้(ตามลูกค้ากรอก)",
	hnw_name              	string       comment "Def(En):
Def(Th):",
	crr_score             	string       comment "Def(En):
Def(Th):",
	crr_grade             	string       comment "Def(En):
Def(Th):",
	crr_reviewed_date     	string       comment "Def(En):
Def(Th):",
	next_crr_reviewed_date	string       comment "Def(En):
Def(Th):",
	load_tms              	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id            	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy              	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_ks/ks_custprofile' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);