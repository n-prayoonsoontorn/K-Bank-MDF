-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_ks_fundmaster.sql
# Area: ks
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-04    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_KS.KS_FUNDMASTER
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_ks.ks_fundmaster (
	pos_dt          	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt      	string       comment "Def(En): Date of data generated 
Def(Th): วันที่ข้อมูล",
	fundid          	string       comment "Def(En): Fund ID 
Def(Th): รหัสกองทุนที่ Ksec สร้างเอง",
	fundcode        	string       comment "Def(En): Fund code 
Def(Th): ชื่อย่อกองทุน",
	amcid           	string       comment "Def(En): AMC ID 
Def(Th): รหัสบริษัทหลัก",
	thaifundunitname	string       comment "Def(En): Fund name thai 
Def(Th): ชื่อกองทุนภาษาไทย",
	engfundunitname 	string       comment "Def(En): Fund name eng 
Def(Th): ชื่อกองทุนภาษาอังกฤษ",
	fundtype        	string       comment "Def(En): Fund type 
Def(Th): ประเภทกองทุน",
	nametype        	string       comment "Def(En): Name type 
Def(Th): ชื่อประเภทกองทุนภาษาไทย",
	risklevel       	string       comment "Def(En): Risk level 
Def(Th): ระดับความเสี่ยง",
	nav             	string       comment "Def(En): NAV 
Def(Th): ราคาตลาดต่อหน่วย",
	navdate         	string       comment "Def(En): NAV date
Def(Th): วันที่ออก NAV ล่าสุด",
	load_tms        	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id      	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy        	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm          	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd          	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_ks/ks_fundmaster' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);