-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_lpm_as400_lmt_inf_bfr_wrtof.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-06    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_LMT_INF_BFR_WRTOF
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_lmt_inf_bfr_wrtof (
	pos_dt                       	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	lmd23500_cust_no             	string       comment "Def(En):
Def(Th): เลขที่ลูกหนี้ LPM",
	lmd23500_acct_type           	string       comment "Def(En):
Def(Th): ประเภทเครดิต",
	lmd23500_acct_type_sub       	string       comment "Def(En):
Def(Th): ประเภท Product ระดับ SUB หรือ เลขที่บัญชีระดับ SUB",
	lmd23500_prod_mode           	string       comment "Def(En):
Def(Th): หมวดของ Product
01=สินเชื่อ         
02=ภาระผูกพัน
03=สินทรัพย์         
04=เงินลงทุน (ในระบบ LPM)
05=เงินลงทุน (นอกระบบ LPM)
99=อื่นๆ",
	lmd23500_br_no               	string       comment "Def(En):
Def(Th): สาขา",
	lmd23500_acct_tp_sub_lim     	string       comment "Def(En):
Def(Th): วงเงินอนุมัติ (ระดับ ACCT-TYPE-SUB)",
	lmd23500_acct_tp_sub_lim_port	string       comment "Def(En):
Def(Th): วงเงินอนุมัติ (ระดับ ACCT-TYPE-SUB)
ที่หักยอดที่ซ้ำออกแล้ว
สามารถนำมารวมได้เป็นวงเงินภาระผูกพันทั้ง Port ของธนาคาร",
	lmd23500_acct_tp_sub_prin    	string       comment "Def(En):
Def(Th): เงินต้น (ระดับ ACCT-TYPE-SUB)",
	lmd23500_acct_tp_sub_accr    	string       comment "Def(En):
Def(Th): ดอกเบี้ย  (ระดับ ACCT-TYPE-SUB)",
	lmd23500_acct_tp_sub_con_dte1	string       comment "Def(En):
Def(Th): วันที่เริ่มสัญญา 1",
	lmd23500_acct_tp_sub_due_dte1	string       comment "Def(En):
Def(Th): วันที่ครบกำหนดสัญญา 1",
	lmd23500_acct_tp_sub_con_dte2	string       comment "Def(En):
Def(Th): วันที่เริ่มสัญญา 2",
	lmd23500_acct_tp_sub_due_dte2	string       comment "Def(En):
Def(Th): วันที่ครบกำหนดสัญญา 2",
	lmd23500_acct_tp_sub_con_dte3	string       comment "Def(En):
Def(Th): วันที่เริ่มสัญญา 3",
	lmd23500_acct_tp_sub_due_dte3	string       comment "Def(En):
Def(Th): วันที่ครบกำหนดสัญญา 3",
	lmd23500_acct_tp_sub_con_dte4	string       comment "Def(En):
Def(Th): วันที่เริ่มสัญญา 4",
	lmd23500_acct_tp_sub_due_dte4	string       comment "Def(En):
Def(Th): วันที่ครบกำหนดสัญญา 4",
	lmd23500_acct_tp_sub_con_dte5	string       comment "Def(En):
Def(Th): วันที่เริ่มสัญญา 5",
	lmd23500_acct_tp_sub_due_dte5	string       comment "Def(En):
Def(Th): วันที่ครบกำหนดสัญญา 5",
	lmd23500_acct_tp_sub_con_dte6	string       comment "Def(En):
Def(Th): วันที่เริ่มสัญญา 6",
	lmd23500_acct_tp_sub_due_dte6	string       comment "Def(En):
Def(Th): วันที่ครบกำหนดสัญญา 6",
	lmd23500_acct_tp_sub_con_dte7	string       comment "Def(En):
Def(Th): วันที่เริ่มสัญญา 7",
	lmd23500_acct_tp_sub_due_dte7	string       comment "Def(En):
Def(Th): วันที่ครบกำหนดสัญญา 7",
	lmd23500_fg_draw_down        	string       comment "Def(En):
Def(Th): Flag การใช้วงเงินของเงินกู้
0 = ยังใช้วงเงินไม่หมด
1 = ใช้วงเงินหมดแล้ว",
	lmd23500_fg_pod              	string       comment "Def(En):
Def(Th): Flag POD เพื่อใช้แยกกรณีมี Acct-type = 2
0 = ไม่เป็น POD
1 = เป็น POD",
	lmd23500_cust_trade_status   	string       comment "Def(En):
Def(Th): สถานะการใช้วงเงินของลูกค้า Trade",
	lmd23500_fg_in_active        	string       comment "Def(En): Flag Inactive
1 = ACTIVE  
0 = INACTIVE
Def(Th):",
	lmd23500_limit_used          	string       comment "Def(En):
Def(Th): Flag ของ Aval/Acceptance",
	lmd23500_debit_amt           	string       comment "Def(En):
Def(Th): ยอดที่เบิกใช้ เฉพาะ Loan",
	lmd23500_exposure_amt        	string       comment "Def(En):
Def(Th): ยอดที่ใช้",
	lmd23500_unuse_limit         	string       comment "Def(En):
Def(Th): วงเงินที่ใช้คำนวณวงเงินคงเหลือ Unuse Limit (ระดับ ACCT-TYPE-SUB)",
	lmd23500_group_cust_no       	string       comment "Def(En):
Def(Th): เลขที่กลุ่มลูกค้า LPM",
	lmd23500_group_limit         	string       comment "Def(En):
Def(Th): วงเงินระดับกลุ่มลูกค้า ที่ได้รับอนุมัติ",
	load_tms                     	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                   	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                     	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                       	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                       	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_lmt_inf_bfr_wrtof' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);