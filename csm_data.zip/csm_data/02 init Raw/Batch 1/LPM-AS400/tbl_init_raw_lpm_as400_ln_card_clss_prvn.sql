-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_lpm_as400_ln_card_clss_prvn.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-04    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_LN_CARD_CLSS_PRVN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_ln_card_clss_prvn (
	pos_dt                     	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	l01w181_cust_no            	string       comment "Def(En):
Def(Th): เลขที่ลูกหนี้",
	l01w181_cust_title         	string       comment "Def(En):
Def(Th): คำนำหน้า",
	l01w181_cust_name          	string       comment "Def(En):
Def(Th): ชื่อลูกหนี้",
	l01w181_acct_type          	string       comment "Def(En):
Def(Th): ประเภทบัญชี",
	l01w181_acct_no            	string       comment "Def(En):
Def(Th): เลขที่บ/ช",
	l01w181_cr_type            	string       comment "Def(En):
Def(Th): ประเภทเครดิต",
	l01w181_fics_type          	string       comment "Def(En):
Def(Th): รหัสหัวบัญชี fics",
	l01w181_bus_code           	string       comment "Def(En):
Def(Th): รหัสธุรกิจ",
	l01w181_bus_bot            	string       comment "Def(En):
Def(Th): รหัสธุรกิจธปท.",
	l01w181_bus_group          	string       comment "Def(En):
Def(Th): รหัสกลุ่มธุรกิจ",
	l01w181_bus_grp_seq        	string       comment "Def(En):
Def(Th): ลำดับรหัสกลุ่มธุรกิจ",
	l01w181_branch_no          	string       comment "Def(En):
Def(Th): สาชา",
	l01w181_dept_no            	string       comment "Def(En):
Def(Th): สังกัด",
	l01w181_prv_int_fg         	string       comment "Def(En):
Def(Th): รหัสพักด/บ 0-ไม่พัก 1-พักด/บ",
	l01w181_prv_stop_date      	string       comment "Def(En):
Def(Th): วันที่พักด/บ",
	l01w181_acct_group         	string       comment "Def(En):
Def(Th): ระดับตามวันค้างจากระบบ",
	l01w181_prv_day_diff       	string       comment "Def(En):
Def(Th): วันค้างชำระถูกต้อง",
	l01w181_class_level        	string       comment "Def(En):
Def(Th): ระดับจากการปรับฯหรือ สอบทาน",
	l01w181_acct_res_group     	string       comment "Def(En):
Def(Th): ระดับตามการปรับฯ หากไม่ปรับจะเท่ากับระดับตามวันค้างระบบ",
	l01w181_prv_outs           	string       comment "Def(En):
Def(Th): ยอดคงค้างเงินต้นหลังตัดสูญ",
	l01w181_prv_accru          	string       comment "Def(En):
Def(Th): ยอดด/บคงค้างหลังตัดสูญ",
	l01w181_limit              	string       comment "Def(En):
Def(Th): วงเงิน",
	l01w181_prv_pay            	string       comment "Def(En):
Def(Th): ยอดชำระ",
	l01w181_acct_npl_group     	string       comment "Def(En):
Def(Th): ระดับ NPL",
	l01w181_class_from         	string       comment "Def(En):
Def(Th): ปรับระดับการจัดชั้นจาก 1-สอบทาน 2- ปรับฯ 0-ไม่ทำ",
	l01w181_class_reason       	string       comment "Def(En):
Def(Th): เหตุผลการปรับระดับการจัดชั้น",
	l01w181_group2             	string       comment "Def(En):
Def(Th): ระดับการจัดชั้นรายลูกหนี้",
	l01w181_gr_no              	string       comment "Def(En):
Def(Th): เลขที่กลุ่มล/น",
	l01w181_sign_bef_outs      	string       comment "Def(En):
Def(Th): เครื่องหมาย +/-",
	l01w181_bef_outs           	string       comment "Def(En):
Def(Th): ยอดคงค้างเงินต้นก่อนตัดสูญ",
	l01w181_sign_bef_accru     	string       comment "Def(En):
Def(Th): เครื่องหมาย +/-",
	l01w181_bef_accru          	string       comment "Def(En):
Def(Th): ยอดด/บคงค้างก่อนตัดสูญ",
	l01w181_cust_tdr_flag      	string       comment "Def(En):
Def(Th): ผลการปรับฯ จากระดับล/น 0-ไม่ปรับ1-ไม่ได้2-รอ3ได้ 4 ได้ทันที
มาจาก L12W909 ระดับลูกหนี้",
	l01w181_old_group2         	string       comment "Def(En):
Def(Th): ระดับการจัดชั้นรายลูกหนี้เดือนก่อนหน้า
เช่น control 254510 ต้องการเดือนก่อนหน้า
มาจาก L01D042 CUST-NO + YYYYMM -control read greater",
	l01w181_f1                 	string       comment "Def(En):
Def(Th): เครื่องหมาย+/-",
	l01w181_pay                	string       comment "Def(En):
Def(Th): ยอดชำระรวม",
	l01w181_f2                 	string       comment "Def(En):
Def(Th): เครื่องหมาย+/-",
	l01w181_pay_principal      	string       comment "Def(En):
Def(Th): ชำระเงินต้น",
	l01w181_f3                 	string       comment "Def(En):
Def(Th): เครื่องหมาย+/-",
	l01w181_pay_int            	string       comment "Def(En):
Def(Th): ชำระดอกในการ์ด",
	l01w181_f4                 	string       comment "Def(En):
Def(Th): เครื่องหมาย+/-",
	l01w181_pay_memo           	string       comment "Def(En):
Def(Th): ชำระส่วนด/บนอกการ์ด",
	l01w181_f5                 	string       comment "Def(En):
Def(Th): เครื่องหมาย+/-",
	l01w181_pay_misc           	string       comment "Def(En):
Def(Th): ชำระอื่นๆ",
	l01w181_sign_receive       	string       comment "Def(En):
Def(Th):",
	l01w181_int_receive        	string       comment "Def(En):
Def(Th): รายได้ดอกเบี้ยรับ",
	l01w181_old_npl            	string       comment "Def(En):
Def(Th): ระดับ NPLเดือนที่แล้ว(นำบ/ชและปีเดือนที่แล้วไปหา L01D041)
กรณีเป็นบ/ชใหม่(อ่านไม่พบ) มีค่าเท่ากับ 0",
	l01w181_acct_ofc_tdr       	string       comment "Def(En):
Def(Th): สังกัดผู้ดูแล",
	l01w181_center             	string       comment "Def(En):
Def(Th): สังกัดผู้ดูแล 10 หลัก",
	l01w181_acct_ofc_gb        	string       comment "Def(En):
Def(Th): รหัสผู้ดูแลกรณี AO 944/957 จะเก็บรหัส good bank จาก L12W909",
	l01w181_bot_acct_group     	string       comment "Def(En):
Def(Th): ระดับการจัดชั้นรายบัญชี",
	l01w181_acct_res_outs      	string       comment "Def(En):
Def(Th): ยอดสำรองรายบัญชี",
	l01w181_npl_prin           	string       comment "Def(En):
Def(Th): ยอดเงินต้น  npl รายบ/ช",
	l01w181_first_tdr_date     	string       comment "Def(En):
Def(Th): วันที่ลงนามแรกจากการปรับฯ drd07200 แรก",
	l01w181_last_tdr_date      	string       comment "Def(En):
Def(Th): วันที่ลงนามหลังสุดจากการปรับฯ drd07200 ล่าสุด",
	l01w181_tdr_seq            	string       comment "Def(En):
Def(Th): ลำดับการปรับฯ ล่าสุด",
	l01w181_tdr_method         	string       comment "Def(En):
Def(Th): วิธีการปรับของการปรับฯล่าสุด",
	l01w181_tdr_remark         	string       comment "Def(En):
Def(Th): หมายเหตุวิธีการปรับของการปรับฯล่าสุด",
	l01w181_dr_day_diff        	string       comment "Def(En):
Def(Th): วันที่จากการปรับฯ (จากคล)",
	l01w181_tdr_res_cond       	string       comment "Def(En):
Def(Th): เงื่อนไขปลดปกติ
0-ไม่มีการปรับฯ 1-ปรับแบบปลดปกติคุ้มด/บ 2-ปรับแบบไม่คุ้มด/บ",
	l01w181_prv_class_reason   	string       comment "Def(En):
Def(Th): รหัสเหตุผลการปรับก่อนหน้า
หาก class-date/class-level/class-reason <> 0 
นำ acct-no + class-date  ไปอ่าน L01D027key-desc 
หา record ถัดมาที่บ/ชเดียวกันแต่ class-date จะน้อยกว่า
หากพบข้อมูลดังกล่าวให้move class-reason มาใส่",
	l01w181_acct_ofc_prod_fg   	string       comment "Def(En):
Def(Th): รหัสสินทรัพย์ระดับบ/ช",
	l01w181_block_w            	string       comment "Def(En):
Def(Th): 1-เป็นบัตรเครดิตติด block W 0-ไม่ใช้",
	l01w181_acct_coll_res      	string       comment "Def(En):
Def(Th): ยอดหลักประกันที่นำมาคำนวณสำรอง",
	l01w181_sex                	string       comment "Def(En):
Def(Th): เพศ
'M' = MALE  
'F' = FEMALE",
	l01w181_birth_date         	string       comment "Def(En):
Def(Th): วันเกิด",
	l01w181_occupation         	string       comment "Def(En):
Def(Th): อาชีพ",
	l01w181_alt_cust_no        	string       comment "Def(En):
Def(Th): เลขที่บัตรเสริม",
	l01w181_acct_center        	string       comment "Def(En):
Def(Th): รหัสสังกัด (ที่ลงบัญชี)",
	l01w181_sys_day_diff       	string       comment "Def(En):
Def(Th): วันค้าง (จากระบบ)",
	l01w181_cr_line_amt        	string       comment "Def(En):
Def(Th): วงเงินระดับลูกค้า",
	l01w181_sign_bef_prin      	string       comment "Def(En):
Def(Th): เครื่องหมาย+/-",
	l01w181_bef_prin           	string       comment "Def(En):
Def(Th): เงินต้นก่อนตัดสูญ",
	l01w181_sign_memo_accru    	string       comment "Def(En):
Def(Th): เครื่องหมาย+/-",
	l01w181_memo_accru         	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยนอกการ์ด",
	l01w181_sign_reverse_accru 	string       comment "Def(En):
Def(Th): เครื่องหมาย+/-",
	l01w181_reverse_accru      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ย Reverse",
	l01w181_overdue_amt        	string       comment "Def(En):
Def(Th): ยอดค้างชำระ",
	l01w181_overlimit_amt      	string       comment "Def(En):
Def(Th): ยอดที่เกินวงเงิน",
	l01w181_overlimit_percent  	string       comment "Def(En):
Def(Th): เปอร์เซ็นของวงเงินที่เกิน",
	l01w181_minimum_payment    	string       comment "Def(En):
Def(Th): ยอดขั้นต่ำที่ต้องชำระ (เฉพาะ Card)",
	l01w181_block_code         	string       comment "Def(En):
Def(Th): Block Code (เฉพาะ Card)",
	l01w181_cycle              	string       comment "Def(En):
Def(Th): Cycle (เฉพาะ Card)",
	l01w181_user_code3         	string       comment "Def(En):
Def(Th): รหัส User Code 3 (เฉพาะ Card)",
	l01w181_last_pay_date      	string       comment "Def(En):
Def(Th): วันจ่ายชำระครั้งสุดท้าย (เฉพาะ Card)",
	l01w181_due_date           	string       comment "Def(En):
Def(Th): วันครบกำหนดชำระ",
	l01w181_sub_prod_type_code 	string       comment "Def(En):
Def(Th): ประเภทผลิตภัณฑ์ย่อย",
	l01w181_open_date          	string       comment "Def(En):
Def(Th): วันเปิดบัญชี",
	l01w181_int_rate           	string       comment "Def(En):
Def(Th): ประเภทอัตราดอกเบี้ย",
	l01w181_sign_stmt_balance  	string       comment "Def(En):
Def(Th): เครื่องหมาย+/-",
	l01w181_stmt_balance       	string       comment "Def(En):
Def(Th): จำนวนเงินที่ส่ง statement ไปเรียกเก็บลูกค้า",
	l01w181_sign_cash_balance  	string       comment "Def(En):
Def(Th):",
	l01w181_cash_balance       	string       comment "Def(En):
Def(Th): จำนวนเงินที่ถอนเงินสด",
	l01w181_sign_retail_balance	string       comment "Def(En):
Def(Th): เครื่องหมาย+/-",
	l01w181_retail_balance     	string       comment "Def(En):
Def(Th): จำนวนเงินใช้ซื้อสินค้าและบริการ",
	l01w181_fpd_flag           	string       comment "Def(En):
Def(Th): Flag ว่าเป็นการผิดนัดชำระครั้งแรกหรือไม่",
	l01w181_lec_status         	string       comment "Def(En):
Def(Th): สถานะ LEC ของลูกหนี้",
	l01w181_sign_ext_pay       	string       comment "Def(En):
Def(Th): เครื่องหมาย+/-",
	l01w181_ext_pay            	string       comment "Def(En):
Def(Th): ส่วนลดรับคงเหลือ",
	l01w181_sign_res_outs_5    	string       comment "Def(En):
Def(Th): เครื่องหมาย+/-",
	l01w181_acct_res_outs_5    	string       comment "Def(En):
Def(Th): ยอดสำรองเพิ่มตามเกณฑ์ ธปท.",
	l01w181_ao_in_date         	string       comment "Def(En):
Def(Th):",
	l01w181_issue_date         	string       comment "Def(En):
Def(Th):",
	l01w181_block_date         	string       comment "Def(En):
Def(Th):",
	l01w181_tdr_ltg_flag       	string       comment "Def(En):
Def(Th): Flag TDR/LTG  โดย T= TDR L=LTG",
	l01w181_id_no              	string       comment "Def(En):
Def(Th):",
	l01w181_legal_entity       	string       comment "Def(En):
Def(Th): รหัสบริษัท",
	l01w181_resp_center        	string       comment "Def(En):
Def(Th): รหัสสังกัด",
	l01w181_gl_account         	string       comment "Def(En):
Def(Th): รหัสบัญชีประเภทเครดิต",
	l01w181_function           	string       comment "Def(En):
Def(Th): รหัสฟังก์ชันงาน",
	l01w181_line_business      	string       comment "Def(En):
Def(Th): รหัสประเภทธุรกิจ",
	l01w181_gl_product_code    	string       comment "Def(En):
Def(Th): รหัสผลิตภัณฑ์สำหรับการบันทึกบัญชี",
	l01w181_inter_company      	string       comment "Def(En):
Def(Th): รหัสบริษัทในการหักค่าใช้จ่ายระหว่างบริษัทในเครือ",
	l01w181_intra_company      	string       comment "Def(En):
Def(Th): รหัสบริษัทในการหักค่าใช้จ่ายระหว่างฝ่ายงาน",
	l01w181_project            	string       comment "Def(En):
Def(Th): รหัสโครงการ",
	l01w181_gl_filler1         	string       comment "Def(En):
Def(Th): สำหรับใช้ในอนาคต",
	l01w181_gl_filler2         	string       comment "Def(En):
Def(Th): สำหรับใช้ในอนาคต",
	l01w181_product_code       	string       comment "Def(En):
Def(Th): รหัสผลิตภัณฑ์",
	l01w181_provision_id       	string       comment "Def(En):
Def(Th):",
	load_tms                   	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                 	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                   	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                     	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                     	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_ln_card_clss_prvn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);