-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_mx_src_murx_deal_ar.sql
# Area: mx
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-04    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_MX.MX_SRC_MURX_DEAL_AR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_mx.mx_src_murx_deal_ar (
	pos_dt         	string        comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	header3        	string        comment "Def(En):
Def(Th):",
	dealref        	string        comment "Def(En):
Def(Th):",
	package_id     	string        comment "Def(En):
Def(Th):",
	contract       	string        comment "Def(En):
Def(Th):",
	nb             	string        comment "Def(En):
Def(Th):",
	trn_fmly       	string        comment "Def(En):
Def(Th):",
	trn_grp        	string        comment "Def(En):
Def(Th):",
	trn_type       	string        comment "Def(En):
Def(Th):",
	trn_typology   	string        comment "Def(En):
Def(Th):",
	portfolio      	string        comment "Def(En):
Def(Th):",
	cisid          	string        comment "Def(En):
Def(Th):",
	ctpy_short_name	string        comment "Def(En):
Def(Th):",
	prinamt        	string        comment "Def(En):
Def(Th):",
	princcy        	string        comment "Def(En):
Def(Th):",
	tradedate      	string        comment "Def(En):
Def(Th):",
	valuedate      	string        comment "Def(En):
Def(Th):",
	matdate        	string        comment "Def(En):
Def(Th):",
	sbtthb         	string        comment "Def(En):
Def(Th):",
	intrate        	string        comment "Def(En):
Def(Th):",
	intbasis       	string        comment "Def(En):
Def(Th):",
	ai_tdy_day     	string        comment "Def(En):
Def(Th):",
	ai_tdy_amt     	string        comment "Def(En):
Def(Th):",
	ai_mat_day     	string        comment "Def(En):
Def(Th):",
	ai_mat_amt     	string        comment "Def(En):
Def(Th):",
	intamt_ytd     	string        comment "Def(En):
Def(Th):",
	intamt_mtd     	string        comment "Def(En):
Def(Th):",
	si_method      	string        comment "Def(En):
Def(Th):",
	trader         	string        comment "Def(En):
Def(Th):",
	dealstatus     	string        comment "Def(En):
Def(Th):",
	dealtype       	string        comment "Def(En):
Def(Th):",
	buysell        	string        comment "Def(En):
Def(Th):",
	prem_disc      	string        comment "Def(En):
Def(Th):",
	ogl_acc        	string        comment "Def(En):
Def(Th):",
	interest_index 	string        comment "Def(En):
Def(Th):",
	spread         	string        comment "Def(En):
Def(Th):",
	notional       	string        comment "Def(En):
Def(Th):",
	int_pay_freq   	string        comment "Def(En):
Def(Th):",
	notional_move  	string        comment "Def(En):
Def(Th):",
	interest_move  	string        comment "Def(En):
Def(Th):",
	mop_status     	string        comment "Def(En):
Def(Th):",
	related_deal   	string        comment "Def(En):
Def(Th):",
	load_tms       	string        comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id     	string        comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy       	string        comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm         	string        comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd         	string        comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_mx/mx_src_murx_deal_ar' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);