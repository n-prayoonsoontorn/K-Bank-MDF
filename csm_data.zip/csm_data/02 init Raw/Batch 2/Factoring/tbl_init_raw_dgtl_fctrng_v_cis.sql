-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_dgtl_fctrng_v_cis.sql
# Area: dgtl_fctrng
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_DGTL_FCTRNG.DGTL_FCTRNG_V_CIS
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_dgtl_fctrng.dgtl_fctrng_v_cis (
	pos_dt        	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	cisno         	string       comment "Def(En): Factor ID
Def(Th):",
	kbankid       	string       comment "Def(En): KBANK CIS No
Def(Th):",
	riskrate      	string       comment "Def(En):
Def(Th): ลูกค้าระดับ (ตามปปง)",
	psname        	string       comment "Def(En): Ps Name
Def(Th):",
	psmobile      	string       comment "Def(En): PS mobile
Def(Th):",
	psemail       	string       comment "Def(En): Ps Email
Def(Th):",
	rmid          	string       comment "Def(En): RM ID
Def(Th):",
	rmname        	string       comment "Def(En): Rm Name
Def(Th):",
	rmmobile      	string       comment "Def(En): Rm Mobile
Def(Th):",
	rmemail       	string       comment "Def(En): Rm Email
Def(Th):",
	comptype      	string       comment "Def(En): Client/Customer/CilientCustomer
Def(Th):",
	holidaycode   	string       comment "Def(En): HolidayGroup
Def(Th):",
	contactperson 	string       comment "Def(En): Contact Person
Def(Th):",
	contactmobile 	string       comment "Def(En): Mobile Phone
Def(Th):",
	contacttel    	string       comment "Def(En): Phone
Def(Th):",
	contacttelext 	string       comment "Def(En): Phone Ext
Def(Th):",
	contactemail  	string       comment "Def(En): Email
Def(Th):",
	contactfax    	string       comment "Def(En): Fax
Def(Th):",
	contactremarks	string       comment "Def(En):
Def(Th): ข้อมูลเพิ่มเติม",
	residence     	string       comment "Def(En): Resident (Y/N)
Def(Th):",
	colplanningrem	string       comment "Def(En): Remark for Collection Planning
Def(Th):",
	maxsublm      	decimal(18,2) comment "Def(En): Max sub-limit
Def(Th):",
	docremarks    	string       comment "Def(En): Remark for Document
Def(Th):",
	docgovtissue  	string       comment "Def(En): Document Government Issued
Def(Th):",
	createby      	string       comment "Def(En):
Def(Th): ผู้บันทึก",
	createdate    	date         comment "Def(En):
Def(Th): วันที่บันทึก",
	createtime    	string       comment "Def(En):
Def(Th): เวลาบันทึก",
	updateby      	string       comment "Def(En):
Def(Th): ผู้แก้ไข",
	updatedate    	date         comment "Def(En):
Def(Th): วันที่แก้ไข",
	updatetime    	string       comment "Def(En):
Def(Th): เวลาแก้ไข",
	orgcode       	string       comment "Def(En): Internal Use for multi-company system
Def(Th):",
	branch        	string       comment "Def(En):
Def(Th): สาขา",
	load_tms      	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id    	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy      	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm        	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd        	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_dgtl_fctrng/dgtl_fctrng_v_cis' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);