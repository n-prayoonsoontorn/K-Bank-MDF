-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_kplus_odsmbl_mbl_fnc_txn.sql
# Area: kplus
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_KPLUS.KPLUS_ODSMBL_MBL_FNC_TXN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_kplus.kplus_odsmbl_mbl_fnc_txn (
	pos_dt      	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	txn_id      	string       comment "Def(En):
Def(Th):",
	txn_tms     	timestamp    comment "Def(En):
Def(Th):",
	mbl_no      	string       comment "Def(En):
Def(Th):",
	mbl_svc_opr 	string       comment "Def(En):
Def(Th):",
	txn_tp      	string       comment "Def(En):
Def(Th):",
	fm_ar_id    	string       comment "Def(En):
Def(Th):",
	fm_ar_tp    	string       comment "Def(En):
Def(Th):",
	to_ar_id    	string       comment "Def(En):
Def(Th):",
	to_mrch_id  	string       comment "Def(En):
Def(Th):",
	refr1       	string       comment "Def(En):
Def(Th):",
	refr2       	string       comment "Def(En):
Def(Th):",
	refr3       	string       comment "Def(En):
Def(Th):",
	txn_amt     	decimal(18,3) comment "Def(En):
Def(Th):",
	svc_itm     	string       comment "Def(En):
Def(Th):",
	st          	string       comment "Def(En):
Def(Th):",
	rmrk        	string       comment "Def(En):
Def(Th):",
	rqs_id      	string       comment "Def(En):
Def(Th):",
	rsp_txn_id  	string       comment "Def(En):
Def(Th):",
	refr_err_cd 	string       comment "Def(En):
Def(Th):",
	refr_err_dsc	string       comment "Def(En):
Def(Th):",
	chrg_f      	string       comment "Def(En):
Def(Th):",
	benf_bnk_id 	string       comment "Def(En):
Def(Th):",
	ip_adr      	string       comment "Def(En):
Def(Th):",
	to_mrch     	string       comment "Def(En):
Def(Th):",
	nbr_of_refr 	smallint     comment "Def(En):
Def(Th):",
	tfr_tp      	string       comment "Def(En):
Def(Th):",
	orgp_cd     	string       comment "Def(En):
Def(Th):",
	sms_out     	string       comment "Def(En):
Def(Th):",
	sms_lng_cd  	string       comment "Def(En):
Def(Th):",
	refr_txn_cd 	string       comment "Def(En):
Def(Th):",
	fee_amt     	decimal(18,3) comment "Def(En):
Def(Th):",
	pstcd       	string       comment "Def(En):
Def(Th):",
	resp_info   	string       comment "Def(En):
Def(Th):",
	due_dt      	timestamp    comment "Def(En):
Def(Th):",
	part_py_f   	string       comment "Def(En):
Def(Th):",
	prmpt_msg   	string       comment "Def(En):
Def(Th):",
	mn_amt      	decimal(18,4) comment "Def(En):
Def(Th):",
	to_ar_nm_th 	string       comment "Def(En):
Def(Th):",
	to_ar_nm_en 	string       comment "Def(En):
Def(Th):",
	th_ar_nck   	string       comment "Def(En):
Def(Th):",
	en_ar_nck   	string       comment "Def(En):
Def(Th):",
	avl_bal     	decimal(18,3) comment "Def(En):
Def(Th):",
	pymt_tp     	string       comment "Def(En):
Def(Th):",
	refr3_real  	string       comment "Def(En):
Def(Th):",
	adl_note    	string       comment "Def(En):
Def(Th):",
	ltt         	decimal(12,8) comment "Def(En):
Def(Th):",
	lgt         	decimal(12,8) comment "Def(En):
Def(Th):",
	cgy_cd      	string       comment "Def(En):
Def(Th):",
	fnc_rquid   	string       comment "Def(En):
Def(Th):",
	fm_menu     	string       comment "Def(En):
Def(Th):",
	adl_data1   	string       comment "Def(En):
Def(Th):",
	adl_data2   	string       comment "Def(En):
Def(Th):",
	adl_data3   	string       comment "Def(En):
Def(Th):",
	adl_data4   	string       comment "Def(En):
Def(Th):",
	adl_data5   	string       comment "Def(En):
Def(Th):",
	ppn_tms     	timestamp    comment "Def(En):
Def(Th):",
	pnt         	decimal(18,2) comment "Def(En):
Def(Th):",
	avl_pnt     	decimal(18,2) comment "Def(En):
Def(Th):",
	load_tms    	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id  	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy    	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm      	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd      	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_kplus/kplus_odsmbl_mbl_fnc_txn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);