-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_kplus_view_jmobile_log.sql
# Area: kplus
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_KPLUS.KPLUS_VIEW_JMOBILE_LOG
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_kplus.kplus_view_jmobile_log (
	pos_dt                    	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	mobileno                  	string       comment "Def(En):
Def(Th): หมายเลขโทรศัพท์",
	mobileoperator            	string       comment "Def(En):
Def(Th): เครือข่ายโทรศัพท์",
	pinerrorcount             	smallint     comment "Def(En):
Def(Th): จำนวนครั้งที่ระบุ PIN ผิด",
	language                  	string       comment "Def(En):
Def(Th): ภาษา",
	status                    	string       comment "Def(En):
Def(Th): สถานะลูกค้า",
	registeredcardno          	string       comment "Def(En):
Def(Th): หมายเลขบัตรที่ใช้ทำการสมัคร
** Hash",
	cardtype                  	string       comment "Def(En):
Def(Th): ประเภทของบัตร",
	financialflag             	string       comment "Def(En):
Def(Th): Flag แสดงสิทธิ์การโอนเติมจ่าย
0: ทำรายการไม่ได้
1: ทำรายการได้",
	thirdfundtransferflag     	string       comment "Def(En):
Def(Th): Flag แสดงสิทธิ์การโอนเงินบัญชีภายในธนาคาร(ยกเว้นบัญชีตัวเอง) และ บัญชีต่างธนาคาร
0: ทำรายการไม่ได้
1: ทำรายการได้",
	usedthirdfundtransferamt  	decimal(18,2) comment "Def(En):
Def(Th): จำนวนเงินใช้ไปสำหรับโอนเงินบัญชีภายในธนาคาร(ยกเว้นบัญชีตัวเอง) และ บัญชีต่างธนาคาร",
	thirdfundtransferlimit    	decimal(18,2) comment "Def(En):
Def(Th): จำนวนเงินสูงสุดสำหรับโอนเงินบัญชีภายในธนาคาร(ยกเว้นบัญชีตัวเอง) และ บัญชีต่างธนาคาร",
	usedfundtransferamt       	decimal(18,2) comment "Def(En):
Def(Th): จำนวนเงินใช้ไปสำหรับโอนเงินบัญชีตัวเองที่ทำการผูกกับ K-Mobile Banking PLUS",
	fundtransferlimit         	decimal(18,2) comment "Def(En):
Def(Th): จำนวนเงินสูงสุดสำหรับโอนเงินบัญชีตัวเองที่ทำการผูกกับ K-Mobile Banking PLUS",
	usedbillpaymentamt        	decimal(18,2) comment "Def(En):
Def(Th): จำนวนเงินใช้ไปสำหรับเติมบิลหรือจ่ายบิล",
	billpaymentlimit          	decimal(18,2) comment "Def(En):
Def(Th): จำนวนเงินสูงสุดสำหรับเติมบิลหรือจ่ายบิล",
	limitamount               	decimal(18,2) comment "Def(En):
Def(Th): จำนวนเงินสูงสุดสำหรับทุกรายการโอน เติม จ่าย",
	registerdate              	timestamp    comment "Def(En):
Def(Th): วันที่สมัคร",
	usedorftamt               	decimal(18,2) comment "Def(En):
Def(Th): จำนวนเงินใช้ไปสำหรับโอนเงินต่างธนาคาร (ปัจจุบันไม่ได้ใช้งาน)",
	orftlimit                 	decimal(18,2) comment "Def(En):
Def(Th): จำนวนเงินสูงสุดสำหรับโอนเงินต่างธนาคาร (ปัจจุบันไม่ได้ใช้งาน)",
	emailaddress              	string       comment "Def(En): Email
Def(Th):",
	consolidateflag           	string       comment "Def(En):
Def(Th): (ปัจจุบันไม่ได้ใช้งาน)",
	allowftflag               	string       comment "Def(En):
Def(Th): Flag แสดงสิทธิ์การรับโอนเงินผ่านเบอร์มือถือ
0: ทำรายการไม่ได้
1: ทำรายการได้",
	citizenid                 	string       comment "Def(En):
Def(Th): หมายเลขบัตรประชาชน
**Hash",
	cifid                     	string       comment "Def(En):
Def(Th): เลขประจำตัวผู้ถือหน่วยลงทุนสำหรับทำรายการเกี่ยวกับกองทุน",
	customercrr               	smallint     comment "Def(En):
Def(Th): เก็บค่าความเสี่ยงของลูกค้าสำหรับทำรายการเกี่ยวกับกองทุน",
	lastchangepin             	timestamp    comment "Def(En):
Def(Th): เปลี่ยน Pin ครั้งสุดท้ายเมื่อไหร่",
	forcechangepinflag        	string       comment "Def(En):
Def(Th): Flag บังคับให้ลูกค้าเปลี่ยน PIN ตอนสมัครครั้งแรก",
	usedpromptpayamt          	decimal(18,2) comment "Def(En):
Def(Th): จำนวนเงินใช้ไปสำหรับการทำรายการผ่าน Quick pay",
	promptpaylimit            	decimal(18,2) comment "Def(En):
Def(Th): วงเงินสูงสุดสำหรับการทำรายการผ่าน Quick pay
-1: ไม่เคยทำการ Set Quick pay
0 : Set Quick pay แบบให้ถาม PIN ทุกครั้ง
มากกว่า 0: วงเงินสูงสุดสำหรับการทำรายการผ่าน Quick pay",
	kmerchantaccount          	string       comment "Def(En):
Def(Th): Username ของร้าน KPLUS Shop",
	consentrtpflag            	string       comment "Def(En):
Def(Th): เปิดรับบริการเรียกเก็บเงิน",
	id                        	smallint     comment "Def(En):
Def(Th): runing no ของ Jmobile ฟิลด์นี้สำหรับ dev ไว้ใช้",
	usedcardlessamt           	decimal(18,2) comment "Def(En):
Def(Th): จำนวนเงินใช้ไปสำหรับการถอนเงินผ่านตู้ ATM โดยไม่ใช้บัตร",
	cardlesslimit             	decimal(18,2) comment "Def(En):
Def(Th): จำนวนเงินสูงสุดสำหรับการถอนเงินผ่านตู้ ATM โดยไม่ใช้บัตร",
	lastlogin                 	timestamp    comment "Def(En):
Def(Th): วันเวลาที่ลูกค้าเข้าใช้บริการ KPLUS ล่าสุด",
	usedcrossborderpaymentamt 	decimal(18,2) comment "Def(En):
Def(Th): วงเงินสำหรับการโอนเงินข้ามเขต Scan QR ของต่างประเทศ",
	crossborderpaymentlimit   	decimal(18,2) comment "Def(En):
Def(Th): จำกัดวงเงินสำหรับการโอนเงินข้ามเขต Scan QR ของต่างประเทศต่อวัน",
	pinlockcount              	smallint     comment "Def(En):
Def(Th): จำนวนครั้งที่ทำ pin lock (reset เป็น 0 เสมอ ถ้า unlock pin แล้วใส่ pin ถูก)",
	pinlockerrcount           	smallint     comment "Def(En):
Def(Th): จำนวนครั้งที่กรอกเลข citizen id ผิด สำหรับการ unlock pin (reset เป็น 0 เสมอ ถ้า กรอกเลข citizen id ถูก)",
	unlockpinflag             	string       comment "Def(En):
Def(Th): Flag ใช้สำหรับตรวจสอบว่า ลค. สามารถ unlock pin ด้วยตัวเองได้หรือไม่ (Y = ได้, N= ไม่ได้)",
	unlockpininprocessflag    	string       comment "Def(En):
Def(Th):  Flag ใช้สำหรับตรวจสอบว่า ลค. อยู่ระหว่างดำเนินการ unlock pin ด้วยตัวเองหรือไม่",
	authenticator             	string       comment "Def(En):
Def(Th): Authenticator Flag ใช้สำหรับ ตรวจสอบว่า ลค. เคยทำการ verify ใบหน้า ผูกกับเบอร์โทรศัพท์ เบอร์นี้แล้ว (authen framework)",
	facestatus                	string       comment "Def(En):
Def(Th):  ใช้สำหรับเก็บสถานะ face ของ ลค. (authen framework)",
	faceerrcount              	smallint     comment "Def(En):
Def(Th): จำนวนครั้งที่ ลค. scan face ผิด (authen framework) (reset เป็น 0 เสมอ ถ้า scan face ถูก)",
	registerprofiletype       	string       comment "Def(En):
Def(Th): Type ที่บอกว่าลูกค้าสมัคร K+ มาด้วยบัตรเครดิต หรือบัญชี",
	currentprofiletype        	string       comment "Def(En):
Def(Th): Type ที่บอกว่าปัจจุบันลูกค้า K+ มี Profile เป็นประเภทไหน",
	profileupdateddate        	timestamp    comment "Def(En):
Def(Th): วันที่ที่แสดงวันเวลาที่ลูกค้ามีการ updatetype profile จาก CARD เป็น FULL",
	lastunlockdatebycallcenter	timestamp    comment "Def(En):
Def(Th): วันที่ที่ Unlock Pin บน Mobile BackOffice",
	tempblockflag             	string       comment "Def(En):
Def(Th): Flag เพื่อแสดงว่าลูกค้าคนนี้สามารถเข้าใช้งาน K+ ได้หรือไม่",
	tempblockreason           	string       comment "Def(En):
Def(Th): เหตุผลว่าทำไมลูกค้าคนนี้ถึงไม่สามารถใช้งาน K+ ได้",
	tempblockupdateddate      	timestamp    comment "Def(En):
Def(Th): วันที่ที่ Update Temp Block Flag ล่าสุด",
	load_tms                  	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_kplus/kplus_view_jmobile_log' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);