-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_gts_kbgt_limit_allocated.sql
# Area: gts
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_GTS.GTS_KBGT_LIMIT_ALLOCATED
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_gts.gts_kbgt_limit_allocated (
	pos_dt              	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	limit_id            	string       comment "Def(En):
Def(Th):",
	limit_level         	string       comment "Def(En):
Def(Th):",
	facility_id         	string       comment "Def(En):
Def(Th):",
	facility_description	string       comment "Def(En):
Def(Th):",
	upper_limitid       	string       comment "Def(En):
Def(Th):",
	upper_facilityid    	string       comment "Def(En):
Def(Th):",
	root_limitid        	string       comment "Def(En):
Def(Th):",
	root_facilityid     	string       comment "Def(En):
Def(Th):",
	second_facilitypid  	string       comment "Def(En):
Def(Th):",
	kbank_pd_code       	string       comment "Def(En):
Def(Th):",
	prod_trade          	string       comment "Def(En):
Def(Th):",
	type_of_loan        	string       comment "Def(En):
Def(Th):",
	andor_limit_flag    	string       comment "Def(En):
Def(Th):",
	limit_status        	string       comment "Def(En):
Def(Th):",
	borrower_type       	string       comment "Def(En):
Def(Th):",
	custid              	string       comment "Def(En):
Def(Th):",
	parent_custid       	string       comment "Def(En):
Def(Th):",
	business_code       	string       comment "Def(En):
Def(Th):",
	tenor               	smallint     comment "Def(En):
Def(Th):",
	issue_date          	date         comment "Def(En):
Def(Th):",
	update_date         	date         comment "Def(En):
Def(Th):",
	expiry_date         	date         comment "Def(En):
Def(Th):",
	revision_date       	date         comment "Def(En):
Def(Th):",
	closed_date         	date         comment "Def(En):
Def(Th):",
	block_flag          	string       comment "Def(En):
Def(Th):",
	uncommitted_type    	string       comment "Def(En):
Def(Th):",
	revolving_type      	string       comment "Def(En):
Def(Th):",
	approve_flag        	string       comment "Def(En):
Def(Th):",
	approverid          	string       comment "Def(En):
Def(Th):",
	makerid             	string       comment "Def(En):
Def(Th):",
	lccy                	string       comment "Def(En):
Def(Th):",
	limit_ccy           	decimal(18,2) comment "Def(En):
Def(Th):",
	used_amount_ccy     	decimal(18,2) comment "Def(En):
Def(Th):",
	avaiable_amount_ccy 	decimal(18,2) comment "Def(En):
Def(Th):",
	pending_amount_ccy  	decimal(18,2) comment "Def(En):
Def(Th):",
	limit_thb           	decimal(18,2) comment "Def(En):
Def(Th):",
	used_amount_thb     	decimal(18,2) comment "Def(En):
Def(Th):",
	avaiable_amount_thb 	decimal(18,2) comment "Def(En):
Def(Th):",
	pending_amount_thb  	decimal(18,2) comment "Def(En):
Def(Th):",
	kbank_midrate       	decimal(11,7) comment "Def(En):
Def(Th):",
	exposure            	decimal(18,2) comment "Def(En):
Def(Th):",
	allocate_limit_ccy  	decimal(18,2) comment "Def(En):
Def(Th):",
	allocate_limit_thb  	decimal(18,2) comment "Def(En):
Def(Th):",
	load_tms            	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id          	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy            	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm              	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd              	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_gts/gts_kbgt_limit_allocated' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);