-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_pcb_dep_cb2d0005_odencitd_sam.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_PCB_DEP.PCB_DEP_CB2D0005_ODENCITD_SAM
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_pcb_dep.pcb_dep_cb2d0005_odencitd_sam (
	pos_dt       	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	ar_id        	string       comment "Def(En): CA arrangement number.
Def(Th):",
	lmt_ar_id    	string       comment "Def(En): OD/ENC/ITD sequence number.
Def(Th):",
	domc_br_no   	string       comment "Def(En): The code to identify the domicile branch.
Def(Th):",
	crn_lmt_sign 	string       comment "Def(En): Sign for Current Limit to indicate positive / negative.
Def(Th):",
	crn_lmt_amt  	decimal(15,2) comment "Def(En): Current Limit Amount
Def(Th):",
	drvd_lmt_sign	string       comment "Def(En): Sign for ENC usage limit to indicate positive / negative.
Def(Th):",
	drvd_lmt_amt 	decimal(15,2) comment "Def(En): The ENC usage limit by deposit cheque. (Applicable only ENC)
Def(Th):",
	utlz_lmt_sign	string       comment "Def(En): Sign for Used Limit to indicate positive / negative.
Def(Th):",
	utlz_lmt_amt 	decimal(15,2) comment "Def(En): Used Limit Amount. 
Def(Th):",
	otsnd_sign   	string       comment "Def(En): Sign for Outstanding balance to indicate positive / negative.
Def(Th):",
	otsnd_bal    	decimal(15,2) comment "Def(En): Outstanding Balance Amount. 
Def(Th):",
	frz_lmt_sign 	string       comment "Def(En): Sign for Freeze Limit to indicate positive / negative.
Def(Th):",
	frz_lmt_amt  	decimal(15,2) comment "Def(En): Freeze limit Amount
Def(Th):",
	avl_lmt_sign 	string       comment "Def(En): Sign for Available Limit to indicate positive / negative. 
Def(Th):",
	avl_lmt_amt  	decimal(15,2) comment "Def(En): Available Limit Amount
Def(Th):",
	lmt_type     	string       comment "Def(En): Limit Type
Def(Th):",
	ar_lcs_tp_cd 	string       comment "Def(En): The unique identifier of the Arrangement according to its Life Cycle Status.  
Def(Th):",
	opn_dt       	date         comment "Def(En): Open date. (Contract Date)
Def(Th):",
	cls_dt       	date         comment "Def(En): Close date. (Expiry Date)
Def(Th):",
	filler       	string       comment "Def(En): Padding for fixed length file formats
Def(Th):",
	load_tms     	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id   	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy     	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm       	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd       	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_pcb_dep/pcb_dep_cb2d0005_odencitd_sam' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);