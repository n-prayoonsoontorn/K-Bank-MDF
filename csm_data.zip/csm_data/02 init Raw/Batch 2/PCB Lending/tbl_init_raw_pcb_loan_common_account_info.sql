-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_pcb_loan_common_account_info.sql
# Area: pcb_loan
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_PCB_LOAN.PCB_LOAN_COMMON_ACCOUNT_INFO
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_pcb_loan.pcb_loan_common_account_info (
	pos_dt                   	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	ac_ar_id                 	string       comment "Def(En): Account Number 
Def(Th):",
	prfl_ac_ar_id            	string       comment "Def(En): Profile Account Number 
Def(Th):",
	cst_id                   	string       comment "Def(En): CIS ID 
Def(Th):",
	loan_pps_typ_id          	string       comment "Def(En): Loan purpose type ID 
Def(Th):",
	lmt_ac_ar_id             	string       comment "Def(En): Limit Account ID 
Def(Th):",
	root_ac_ar_id            	string       comment "Def(En): Root Commitment Account ID 
Def(Th):",
	opn_dt                   	date         comment "Def(En): Account Opening Date - CC (YYYYMMDD) 
Def(Th):",
	eff_dt                   	date         comment "Def(En): Effective Date/ Account Activation Date
Def(Th):",
	ctr_dt                   	date         comment "Def(En): Contract Date
Def(Th):",
	ctr_mat_dt               	date         comment "Def(En): Contract Maturity Date
Def(Th):",
	cls_dt                   	date         comment "Def(En): Close Date
Def(Th):",
	ctr_ar_term_prd          	smallint     comment "Def(En): Contract Account term period
Def(Th):",
	ctr_ar_term_unit_id      	string       comment "Def(En): Contract Account Term Period Unit
Def(Th):",
	lmt_amt                  	decimal(18,2) comment "Def(En): Limit Amount
Def(Th):",
	ccy_amt                  	decimal(18,2) comment "Def(En): Currency Amount
Def(Th):",
	ccy_code                 	string       comment "Def(En): Currency
Def(Th):",
	ccy_rate                 	decimal(9,5) comment "Def(En): Currency Rate
Def(Th):",
	fee_rate                 	decimal(9,5) comment "Def(En): 
Def(Th): อัตราค่าธรรมเนียม LI",
	eff_int_rate             	decimal(9,5) comment "Def(En): Effective interest rate
Def(Th):",
	eff_int_rate_typ_id      	string       comment "Def(En): Effective Interest rate type ID
Def(Th):",
	eff_sprd_int_sign        	string       comment "Def(En): Effective Spread Interest Rate
Def(Th):",
	eff_sprd_int_rate        	decimal(9,5) comment "Def(En): Effective Spread Interest Rate
Def(Th):",
	pnp_amt                  	decimal(18,2) comment "Def(En): Principal Amount
Def(Th):",
	acr_int_amt              	decimal(18,2) comment "Def(En): Accrued Interest Amount
Def(Th):",
	rvrs_int_amt             	decimal(18,2) comment "Def(En): Reverse Interest Amount
Def(Th):",
	memo_acr_int_amt         	decimal(18,2) comment "Def(En): Memo Accrual Interest Amount
Def(Th):",
	int_late_chrg_amt        	decimal(18,2) comment "Def(En): Interest Late Charge
Def(Th):",
	late_int_rate_tp_id      	string       comment "Def(En):
Def(Th):",
	rvrs_flg                 	smallint     comment "Def(En): Indicate reverse accrue interest.
Def(Th):",
	rvrs_dt                  	date         comment "Def(En): Reverse accrue interest date.
Def(Th):",
	otsnd_bal_amt            	decimal(18,2) comment "Def(En): Outstanding Balance Amount
Def(Th):",
	upd_fee                  	decimal(18,2) comment "Def(En): Unpaid Fee Amount
Def(Th):",
	upd_expn                 	decimal(18,2) comment "Def(En): Unpaid Expense Amount
Def(Th):",
	tot_dr_txn_amt           	decimal(18,2) comment "Def(En): Total Debit Transaction Amount
Def(Th):",
	dsbt_dt                  	date         comment "Def(En): Disbursement Date
Def(Th):",
	refr_ddcn_ac             	string       comment "Def(En): Reference Deduction Account Number
Def(Th):",
	last_pymt_dt             	date         comment "Def(En): Last Payment Date
Def(Th):",
	upd_bill_amt             	decimal(18,2) comment "Def(En): Unpaid Bill Amount 
Def(Th):",
	upd_int_bill_amt         	decimal(18,2) comment "Def(En): Unpaid Interest Bill Amount
Def(Th):",
	ac_typ_flg               	smallint     comment "Def(En): Account Type Flag
Def(Th):",
	acm_rpymt_amt            	decimal(18,2) comment "Def(En): Accumulate Repayment Amount
Def(Th):",
	ac_sts_id                	string       comment "Def(En): Account status ID
Def(Th):",
	ar_nm_th                 	string       comment "Def(En): Arrangement Thai Name
Def(Th):",
	ar_nm_eng                	string       comment "Def(En): Arrangement English Name
Def(Th):",
	br_nbr                   	string       comment "Def(En): Branch Number of that Account Arrangement
(Owner Branch) 
Def(Th):",
	pd_grp                   	string       comment "Def(En): Profile Product Group
Def(Th):",
	pd_typ                   	string       comment "Def(En): Profile Product Type Def(Th):",
	sub_typ                  	string       comment "Def(En): Profile Product Sub Type Def(Th):",
	mkt_code                 	string       comment "Def(En): Profile Market Code Def(Th):",
	kbank_pd_code            	string       comment "Def(En): Kbank Product Code Def(Th):",
	cst_typ_id               	string       comment "Def(En): Customer Type ID Def(Th):",
	bsn_code_id              	string       comment "Def(En): Kbank Business code Def(Th):",
	aprv_id                  	string       comment "Def(En): Approver ID Def(Th):",
	mx_int_rate              	decimal(9,5) comment "Def(En): Maximum Interest Rate Def(Th):",
	pny_int_rate             	decimal(9,5) comment "Def(En): Penalty Interest Rate Def(Th):",
	grc_prd                  	smallint     comment "Def(En): Grace Period for Principal or Principal&Interest (unit in month),  Def(Th):",
	int_chg_flg              	smallint     comment "Def(En): Interest Change Flag Def(Th):",
	act_int_amt_in_mo        	decimal(18,2) comment "Def(En): The interest which system calculate in this month
Def(Th): รายได้ดอกเบี้ยรับในเดือน)

Data As of วันสิ้นเดือน (Calendar day) - กรณีที่ไม่ใช่สิ้นเดือนจะเป็นค่าของ Last Calendar Day of Previous Month

Remark
กรณีบัญชีปิดระหว่างเดือน Profile จะต้องคำนวณค่า Interest ตั้งแต่วันที่ 1 จนถึงวันปิดบัญชี",
	bot_rdcn_flg             	smallint     comment "Def(En): BOT reduction flag
Def(Th):",
	ddc_int_typ              	smallint     comment "Def(En): Deducted Interest Type
Def(Th):",
	net_dcn_amt              	decimal(18,2) comment "Def(En): Net discount amount
Def(Th):",
	lpm_class                	smallint     comment "Def(En): LPM Classification Level
Def(Th):",
	coa_lgl_ent_pnp          	string       comment "Def(En): Chart of Account (Legal Entity): Company Code
Def(Th):",
	coa_rspl_cntr_pnp        	string       comment "Def(En): Chart of Account (Responsibility Centre)
Def(Th):",
	coa_ac_pnp               	string       comment "Def(En): Chart of Account (OGL Account Number)
Def(Th):",
	coa_fnc_pnp              	string       comment "Def(En): Chart of Account (Function)
Def(Th):",
	coa_line_of_bsn_pnp      	string       comment "Def(En): Chart of Account (Line of Business)
Def(Th):",
	coa_pd_pnp               	string       comment "Def(En): Chart of Account (Product)
Def(Th):",
	coa_intco_pnp            	string       comment "Def(En): Chart of Account (Inter Company)
Def(Th):",
	coa_inrco_pnp            	string       comment "Def(En): Chart of Account (Intra Company)
Def(Th):",
	coa_prj_pnp              	string       comment "Def(En): Chart of Account (Project)
Def(Th):",
	coa_futr_used1_pnp       	string       comment "Def(En): Chart of Account (Future Use 1)
Def(Th):",
	coa_futr_used2_pnp       	string       comment "Def(En): Chart of Account (Future Use 2)
Def(Th):",
	coa_pd_ftr_code_pnp      	string       comment "Def(En): Chart of Account (Product Feature Code)
Def(Th):",
	coa_lgl_ent_acr          	string       comment "Def(En): Chart of Account (Legal Entity) 
Def(Th):",
	coa_rspl_cntr_acr        	string       comment "Def(En): Chart of Account (Responsibility Centre)
Def(Th):",
	coa_ac_acr               	string       comment "Def(En): Chart of Account (OGL Account Number)
Def(Th):",
	coa_fnc_acr              	string       comment "Def(En): Chart of Account (Function)
Def(Th):",
	coa_line_of_bsn_acr      	string       comment "Def(En): Chart of Account (Line of Business)
Def(Th):",
	coa_pd_acr               	string       comment "Def(En): Chart of Account (Product)
Def(Th):",
	coa_intco_acr            	string       comment "Def(En): Chart of Account (Inter Company)
Def(Th):",
	coa_inrco_acr            	string       comment "Def(En): Chart of Account (Intra Company)
Def(Th):",
	coa_prj_acr              	string       comment "Def(En): Chart of Account (Project)
Def(Th):",
	coa_futr_used1_acr       	string       comment "Def(En): Chart of Account (Future Use 1)
Def(Th):",
	coa_futr_used2_acr       	string       comment "Def(En): Chart of Account (Future Use 2)
Def(Th):",
	coa_pd_ftr_code_acr      	string       comment "Def(En): Chart of Account (Product Feature Code)
Def(Th):",
	coa_lgl_ent_rvrs         	string       comment "Def(En): Chart of Account (Legal Entity) 
Def(Th):",
	coa_rspl_cntr_rvrs       	string       comment "Def(En): Chart of Account (Responsibility Centre)
Def(Th):",
	coa_ac_rvrs              	string       comment "Def(En): Chart of Account (OGL Account Number)
Def(Th):",
	coa_fnc_rvrs             	string       comment "Def(En): Chart of Account (Function)
Def(Th):",
	coa_line_of_bsn_rvrs     	string       comment "Def(En): Chart of Account (Line of Business)
Def(Th):",
	coa_pd_rvrs              	string       comment "Def(En): Chart of Account (Product)
Def(Th):",
	coa_intco_rvrs           	string       comment "Def(En): Chart of Account (Inter Company)
Def(Th):",
	coa_inrco_rvrs           	string       comment "Def(En): Chart of Account (Intra Company)
Def(Th):",
	coa_prj_rvrs             	string       comment "Def(En): Chart of Account (Project)
Def(Th):",
	coa_futr_used1_rvrs      	string       comment "Def(En): Chart of Account (Future Use 1)
Def(Th):",
	coa_futr_used2_rvrs      	string       comment "Def(En): Chart of Account (Future Use 2)
Def(Th):",
	coa_pd_ftr_code_rvrs     	string       comment "Def(En): Chart of Account (Product Feature Code)
Def(Th):",
	coa_lgl_ent_mem          	string       comment "Def(En): 
Def(Th): ที่อยู่ 1 (ระดับบัญชี)",
	coa_rspl_cntr_mem        	string       comment "Def(En): 
Def(Th): ที่อยู่ 2 (ระดับบัญชี)",
	coa_ac_mem               	string       comment "Def(En): 
Def(Th): จำนวนงวดตลอดอายุสัญญา
(รวมงวดผ่อนผันด้วย)
eg. 60 งวด",
	coa_fnc_mem              	string       comment "Def(En): 
Def(Th): ส่วนลดรับคงเหลือที่ยังไม่กระจายเป็นรายได้
(มีเฉพาะ PN)",
	coa_line_of_bsn_mem      	string       comment "Def(En): 
Def(Th): ยอดชำระเงินต้น
(สะสมจนถึงปัจจุบัน)",
	coa_pd_mem               	string       comment "Def(En): 
Def(Th): ยอดชำระดอกเบี้ยค้างรับทั้งหมด
(สะสมจนถึงปัจจุบัน)",
	coa_intco_mem            	string       comment "Def(En): 
Def(Th): ยอดชำระดอกเบี้ยผิดนัด(สะสมจนถึงปัจจุบัน)",
	coa_inrco_mem            	string       comment "Def(En): 
Def(Th): ยอดชำระค่าธรรมเนียม 
(สะสมจนถึงปัจจุบัน)",
	coa_prj_mem              	string       comment "Def(En): 
Def(Th): ยอดที่ต้องชำระ / ยอดเรียกเก็บเฉพาะล่าสุด",
	coa_futr_used1_mem       	string       comment "Def(En): 
Def(Th): ยอดค้างชำระ",
	coa_futr_used2_mem       	string       comment "Def(En): 
Def(Th): ยอดที่ต้องชำระทั้งหมด
(ยอดค้างชำระ + ยอดที่ต้องชำระ)",
	coa_pd_ftr_code_mem      	string       comment "Def(En): 
Def(Th): วันที่ครบกำหนดชำระล่าสุด
เช่นชำระทุกวันที่ 30 , Current Date 25/7/2016 
DT_PAY_DUE = 30/6/2016",
	coa_lgl_ent_late_chrg    	string       comment "Def(En): 
Def(Th): จำนวนวันค้างชำระ

LI aval acceptance = 0
จำนวนวันค้างต้นหรือดอก",
	coa_rspl_cntr_late_chrg  	string       comment "Def(En): 
Def(Th): จำนวนงวดที่ค้างชำระ",
	coa_ac_late_chrg         	string       comment "Def(En): 
Def(Th): วันที่เริ่มค้างชำระ",
	coa_fnc_late_chrg        	string       comment "Def(En): 
Def(Th): รหัสผู้รับผลประโยชน์",
	coa_line_of_bsn_late_chrg	string       comment "Def(En): 
Def(Th): Commission - จำนวนเงินค่าธรรมเนียมที่เรียกเก็บจากลูกค้าในแต่ละรอบ",
	coa_pd_late_chrg         	string       comment "Def(En): 
Def(Th): รหัสวิธีการจ่ายค่าธรรมเนียม
0 ชำระด้วยตัวเอง

2 หักบัญชีเงินฝากอัตโนมัติ",
	coa_intco_late_chrg      	string       comment "Def(En): 
Def(Th): หมายเหตุ
(Profile Account Note)",
	coa_inrco_late_chrg      	string       comment "Def(En): 
Def(Th): จำนวนเดือนที่ไม่คิดค่าธรรมเนียม",
	coa_prj_late_chrg        	string       comment "Def(En): 
Def(Th): สาขาที่ขอให้ออก L/I",
	coa_futr_used1_late_chrg 	string       comment "Def(En): 
Def(Th): รหัสการคำนวณค่าธรรมเนียม
1: คิดตามเกณฑ์
2: คิดตามจริง มีค่าธรรมเนียมขั้นต่ำ
3: คิดตามจริง มีระยะเวลาขั้นต่ำ
7: คิดครั้งแรก 1 เดือน",
	coa_futr_used2_late_chrg 	string       comment "Def(En): Roll Over Account
Def(Th):",
	coa_pd_ftr_code_late_chrg	string       comment "Def(En): Next Payment Date
Def(Th):",
	ac_adr1                  	string       comment "Def(En): Next Payment Amount
Def(Th):",
	ac_adr2                  	string       comment "Def(En): Original Account Advancement Link
Def(Th):",
	tot_instl                	smallint     comment "Def(En): Reschedule Flag (Classified Loan )
Def(Th):",
	un_amrz_amt              	decimal(18,2) comment "Def(En): Effective Interest rate type ID Profile
Def(Th):",
	acm_act_pnp              	decimal(18,2) comment "Def(En): Special Project Code
Def(Th):",
	acm_act_acr_mem          	decimal(18,2) comment "Def(En): LG Channel
Def(Th):",
	acm_act_late_chrg        	decimal(18,2) comment "Def(En): Auto/Manual Flag
Def(Th):",
	acm_act_fee              	decimal(18,2) comment "Def(En): Rate Flag
Def(Th):",
	due_amt                  	decimal(18,2) comment "Def(En): Billing sequence number
Def(Th):",
	odue_amt                 	decimal(18,2) comment "Def(En): Maturity Renewal Code
Def(Th):",
	tot_due_amt              	decimal(18,2) comment "Def(En): Related Deposit Account
Def(Th):",
	dt_pay_due               	date         comment "Def(En): Related Deposit Sub Sequence
Def(Th):",
	del_inq_day              	smallint     comment "Def(En): Fixed Interest Rate Differential
Def(Th):",
	odue_prd                 	smallint     comment "Def(En): Payment Due Action Grid
Def(Th):",
	odue_dt                  	date         comment "Def(En): 
Def(Th): วันที่เริ่มค้างชำระ",
	benf_code                	integer      comment "Def(Th): รหัสผู้รับผลประโยชน์ Def(Th):",
	cmsn                     	decimal(18,2) comment "Def(Th): Commission - จำนวนเงินค่าธรรมเนียมที่เรียกเก็บจากลูกค้าในแต่ละรอบ Def(Th):",
	py_code                  	smallint     comment "Def(En): 
Def(Th): รหัสวิธีการจ่ายค่าธรรมเนียม
0 ชำระด้วยตัวเอง

2 หักบัญชีเงินฝากอัตโนมัติ",
	remark                   	string       comment "Def(En): Profile Account Note
Def(Th): หมายเหตุ",
	stop_compute             	smallint     comment "Def(En): 
Def(Th): จำนวนเดือนที่ไม่คิดค่าธรรมเนียม",
	tfr_br                   	string       comment "Def(En): 
Def(Th): สาขาที่ขอให้ออก L/I",
	clc_code                 	smallint     comment "Def(En): 
Def(Th): รหัสการคำนวณค่าธรรมเนียม
1: คิดตามเกณฑ์
2: คิดตามจริง มีค่าธรรมเนียมขั้นต่ำ
3: คิดตามจริง มีระยะเวลาขั้นต่ำ
7: คิดครั้งแรก 1 เดือน",
	rlov_ac                  	string       comment "Def(En): Roll Over Account
Def(Th):",
	nxt_pymt_dt              	date         comment "Def(En): Next Payment Date
Def(Th):",
	nxt_pymt_amt             	decimal(18,2) comment "Def(En): Next Payment Amount
Def(Th):",
	orn_ac_adv_lk            	string       comment "Def(En): Original Account Advancement Link
Def(Th):",
	resch_flg                	smallint     comment "Def(En): Reschedule Flag (Classified Loan )
Def(Th):",
	eff_int_rate_typ_prfl    	string       comment "Def(En): Effective Interest rate type ID Profile
Def(Th):",
	special_proj_code        	string       comment "Def(En): Special Project Code
Def(Th):",
	lg_channel               	smallint     comment "Def(En): LG Channel
Def(Th):",
	auto_flg                 	smallint     comment "Def(En): Auto/Manual Flag
Def(Th):",
	rate_flg                 	smallint     comment "Def(En): Rate Flag
Def(Th):",
	bill_seq_no              	smallint     comment "Def(En): Billing sequence number
Def(Th):",
	ren_code                 	string       comment "Def(En): Maturity Renewal Code
Def(Th):",
	rel_ac_ar_id             	string       comment "Def(En): Related Deposit Account
Def(Th):",
	rel_ac_ar_id_sub         	string       comment "Def(En): Related Deposit Sub Sequence
Def(Th):",
	rel_ac_sign_sprd         	decimal(9,5) comment "Def(En): Fixed Interest Rate Differential
Def(Th):",
	pmt_act_grid             	string       comment "Def(En): Payment Due Action Grid
Def(Th):",
	load_tms                 	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id               	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                 	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                   	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                   	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_pcb_loan/pcb_loan_common_account_info' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);