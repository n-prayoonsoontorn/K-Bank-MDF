-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_pcb_loan_common_loan_purpose_table.sql
# Area: pcb_loan
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_PCB_LOAN.PCB_LOAN_COMMON_LOAN_PURPOSE_TABLE
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_pcb_loan.pcb_loan_common_loan_purpose_table (
	pos_dt          	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	finality_code   	string       comment "Def(En): Loan purpose or Finality code
Def(Th): รหัสวัตถุประสงค์เงินกู้",
	finality_dsc_eng	string       comment "Def(En): Loan purpose or Finality code description in English
Def(Th): คำอธิบายของรหัสวัตถุประสงค์เงินกู้ ภาษาอังกฤษ",
	finality_dsc_th 	string       comment "Def(En): Loan purpose or Finality code description in Thai
Def(Th): คำอธิบายของรหัสวัตถุประสงค์เงินกู้ ภาษาไทย",
	load_tms        	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id      	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy        	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm          	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd          	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_pcb_loan/pcb_loan_common_loan_purpose_table' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);