-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_pcb_loan_common_market_code.sql
# Area: pcb_loan
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_PCB_LOAN.PCB_LOAN_COMMON_MARKET_CODE
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_pcb_loan.pcb_loan_common_market_code (
	pos_dt      	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	pd_grp      	string       comment "Def(En): Product Group 
LN : Consumer
COM : Commercial
Def(Th):",
	pd_typ      	string       comment "Def(En): Product type code
Def(Th):",
	sub_typ_code	string       comment "Def(En): Sub type code
Def(Th):",
	mkt_code    	string       comment "Def(En): Market code
Def(Th):",
	mkt_code_dsc	string       comment "Def(En): Market code description
Def(Th):",
	pd_cgy      	string       comment "Def(En): Product Type Category
ประเภทของ Product
LN, PN, LI, AVAL, ACCEPTANCE, ADVANCE LI, ADVANCE AVAL, ADVANCE ACCEPTANCE
Def(Th):",
	mx_lmt      	decimal(17,2) comment "Def(En): Max limit of Market code
Def(Th):",
	load_tms    	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id  	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy    	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm      	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd      	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_pcb_loan/pcb_loan_common_market_code' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);