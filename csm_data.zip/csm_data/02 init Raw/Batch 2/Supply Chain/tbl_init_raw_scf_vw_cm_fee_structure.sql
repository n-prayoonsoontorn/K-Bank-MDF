-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_scf_vw_cm_fee_structure.sql
# Area: scf
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_SCF.SCF_VW_CM_FEE_STRUCTURE
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_scf.scf_vw_cm_fee_structure (
	pos_dt            	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	strsponsorid      	string       comment "Def(En): Sponsor ID
Def(Th):",
	strbuysellid      	string       comment "Def(En): Buyer / Seller ID
Def(Th):",
	strprodtype       	string       comment "Def(En): Product Type (BFP = Buyer Financing Program, SFP = Supplier Finance Program)
Def(Th):",
	inttradingno      	integer      comment "Def(En): Trading No
Def(Th):",
	strfeecode        	string       comment "Def(En): Fee Code
Def(Th):",
	strefftdate       	date         comment "Def(En): Effective Date
Def(Th):",
	stramtpercflag    	string       comment "Def(En): Amount or Percent Flag
Def(Th):",
	decfeeperc        	decimal(11,8) comment "Def(En): Fee Percentage
Def(Th):",
	decfeeamt         	decimal(15,2) comment "Def(En): Fee Amount
Def(Th):",
	decminfeeamt      	decimal(15,2) comment "Def(En): Minimum Fee Amount
Def(Th):",
	strbaseon         	string       comment "Def(En): Base On (In Case Percent)
Def(Th):",
	strtimetiertype   	string       comment "Def(En): Time Tier Type
Def(Th):",
	intperioddays     	decimal(3,0) comment "Def(En): Period Days (In Case Time Tier Type = Period)
Def(Th):",
	strchargefeefor   	string       comment "Def(En): Charge Fee For (SP = Sponsor, BS = Buyer / Seller)
Def(Th):",
	strchargefeetype  	string       comment "Def(En): Charge Fee Type 
Def(Th): ถ้า SCM_FEE_CODE.STRFEEFLAG = AF (Annual Fee) แสดง SI = Start Installment, EI = End Installment
ถ้า SCM_FEE_CODE.STRFEEFLAG = MF (Monthly Fee) แสดง SM = Start Month, EM = End Month 
ถ้า SCM_FEE_CODE.STRFEEFLAG = TF (Transaction Fee) แสดง OD= On due, MN = Monthly, TD = Transaction Date",
	stractiveflag     	string       comment "Def(En): Active Flag
Def(Th):",
	strprocessflag    	string       comment "Def(En): Process Flag
Def(Th):",
	strverifyflag     	string       comment "Def(En): Verify Flag
Def(Th):",
	strverifyby       	string       comment "Def(En): Verify By
Def(Th):",
	strverifydate     	date         comment "Def(En): Verify Date
Def(Th):",
	strreturnflag     	string       comment "Def(En): Return Flag
Def(Th):",
	strreturnrem      	string       comment "Def(En): Return Remark
Def(Th):",
	strdelverifyflag  	string       comment "Def(En): Delete Verify Flag (P = Pending,  V = Verify)
Def(Th):",
	strdelverifyby    	string       comment "Def(En): Delete Verify By
Def(Th):",
	strdelverifydate  	date         comment "Def(En): Delete Verify Date
Def(Th):",
	strcreateuser     	string       comment "Def(En): Create User
Def(Th):",
	dtecreatedate     	timestamp    comment "Def(En): Create Date
Def(Th):",
	strupduser        	string       comment "Def(En): Update User
Def(Th):",
	dteupddate        	timestamp    comment "Def(En): Update Date
Def(Th):",
	strfeetype        	string       comment "Def(En): Fee Type (FT = Flat , PC = Percent, TT = Time Tier, AT = Amount Tier)
Def(Th):",
	strmonperinstall  	string       comment "Def(En): Months per Installment
Def(Th):",
	strtieramtpercflag	string       comment "Def(En): Tier Amount or Percent Flag
Def(Th):",
	stramendverifyflag	string       comment "Def(En): Amend Verify Flag
Def(Th):",
	stramendby        	string       comment "Def(En): Amend By
Def(Th):",
	stramenddate      	date         comment "Def(En): Amend Date
Def(Th):",
	stramendverifyby  	string       comment "Def(En): Amend Verify By
Def(Th):",
	stramendverifydate	date         comment "Def(En): Amend Verify Date
Def(Th):",
	load_tms          	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id        	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy          	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm            	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd            	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_scf/scf_vw_cm_fee_structure' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);