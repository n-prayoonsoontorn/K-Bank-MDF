-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_scf_vw_sct_book_loan.sql
# Area: scf
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_SCF.SCF_VW_SCT_BOOK_LOAN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_scf.scf_vw_sct_book_loan (
	pos_dt                	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	strloanref            	string       comment "Def(En): Loan Reference
Def(Th):",
	strsponsorid          	string       comment "Def(En): Sponsor ID
Def(Th):",
	strbuysellid          	string       comment "Def(En): Buyer / Seller ID
Def(Th):",
	strprodtype           	string       comment "Def(En): Product Type 
Def(Th):",
	inttradingno          	integer      comment "Def(En): Trading No
Def(Th):",
	strtransdate          	date         comment "Def(En): Transaction Date
Def(Th):",
	strtranstime          	string       comment "Def(En): Transaction Time
Def(Th):",
	strdrawdownno         	string       comment "Def(En): Drawdown No
Def(Th):",
	strdrawdowndate       	date         comment "Def(En): Drawdown Date
Def(Th):",
	strmatdate            	date         comment "Def(En): Maturity Date
Def(Th):",
	inttenor              	smallint     comment "Def(En): Tenor Days
Def(Th):",
	decintrate            	decimal(11,8) comment "Def(En): Interest Rate
Def(Th):",
	decinvoiceamt         	decimal(15,2) comment "Def(En): Invoice Amount
Def(Th):",
	decloanamt            	decimal(15,2) comment "Def(En): Loan Amount
Def(Th):",
	decballoanamt         	decimal(15,2) comment "Def(En): Balance Loan Amount
Def(Th):",
	decintamt             	decimal(15,2) comment "Def(En): Interest Amount
Def(Th):",
	decbalintamt          	decimal(15,2) comment "Def(En): Balance Interest Amount
Def(Th):",
	decfeeamt             	decimal(15,2) comment "Def(En): Fee Amount
Def(Th):",
	decbalfeeamt          	decimal(15,2) comment "Def(En): Balance Fee Amount
Def(Th):",
	decintestamt          	decimal(15,2) comment "Def(En): Interest Estimate Amount
Def(Th):",
	strlastaccruedate     	date         comment "Def(En): Last Accrual Date
Def(Th):",
	strverifyflag         	string       comment "Def(En): Verify Flag
Def(Th):",
	strtransstate         	string       comment "Def(En): Transaction State
Def(Th):",
	strremark             	string       comment "Def(En): Remark
Def(Th):",
	strverifyby           	string       comment "Def(En): Verify By
Def(Th):",
	strverifydate         	date         comment "Def(En): Verify Date
Def(Th):",
	strverifytime         	string       comment "Def(En): Verify Time
Def(Th):",
	strbooktype           	string       comment "Def(En): Booking Type
Def(Th):",
	strfuturesuccess      	string       comment "Def(En): Future Drawdown Success 
Def(Th):",
	strprocessstatus      	string       comment "Def(En): Process Status
Def(Th):",
	strpayinttype         	string       comment "Def(En): Payment Interest Type 
Def(Th):",
	strchargefeefor       	string       comment "Def(En): Charge Fee For
Def(Th):",
	strchargefeetype      	string       comment "Def(En): Charge Fee Type
Def(Th):",
	strclosedate          	date         comment "Def(En): Close Date
Def(Th):",
	stroddate             	date         comment "Def(En): Over Due Date
Def(Th):",
	stronlineflag         	string       comment "Def(En): Online Flag (Y = Yes, N = No)
Def(Th):",
	strcreateuser         	string       comment "Def(En): Create User
Def(Th):",
	dtecreatedate         	timestamp    comment "Def(En): Create Date
Def(Th):",
	strupduser            	string       comment "Def(En): Update User
Def(Th):",
	dteupddate            	timestamp    comment "Def(En): Update Date
Def(Th):",
	strsendemailflag      	string       comment "Def(En): Send E-mail Flag
Def(Th):",
	strsendemaildate      	date         comment "Def(En): Send E-mail Date
Def(Th):",
	stremailid            	string       comment "Def(En): E-mail ID
Def(Th):",
	strnoticeemailflag    	string       comment "Def(En): Notice E-mail Flag
Def(Th):",
	strnoticeemaildate    	date         comment "Def(En): Notice E-mail Date
Def(Th):",
	strnoticeemailid      	string       comment "Def(En): Notice E-mail ID
Def(Th):",
	strlastpayintdate     	date         comment "Def(En): Last Payment Interest Date
Def(Th):",
	strintflag            	string       comment "Def(En): Interest Flag
Def(Th):",
	strintcode            	string       comment "Def(En): Interest Code
Def(Th):",
	decintbasis           	decimal(11,8) comment "Def(En): Interest Basis
Def(Th):",
	decintspread          	decimal(11,8) comment "Def(En): Interest Spread
Def(Th):",
	decintfix             	decimal(11,8) comment "Def(En): Interest Fix
Def(Th):",
	strdealintflag        	string       comment "Def(En): Dealint Flag
Def(Th):",
	deccancelintamt       	decimal(15,2) comment "Def(En): Cancel int
Def(Th):",
	strprocessingflag     	string       comment "Def(En): Processing Flag
Def(Th):",
	strsendflag           	string       comment "Def(En): Send Flag
Def(Th):",
	declatecharge         	decimal(11,8) comment "Def(En):
Def(Th):",
	declatechargeamt      	decimal(15,2) comment "Def(En):
Def(Th):",
	decballatechargeamt   	decimal(15,2) comment "Def(En):
Def(Th):",
	intaging              	integer      comment "Def(En):
Def(Th):",
	deccancellatechargeamt	decimal(15,2) comment "Def(En):
Def(Th):",
	decodintamt           	decimal(15,2) comment "Def(En):
Def(Th):",
	decbalodintamt        	decimal(15,2) comment "Def(En):
Def(Th):",
	deccancelodintamt     	decimal(15,2) comment "Def(En):
Def(Th):",
	strlastlatechargedate 	date         comment "Def(En):
Def(Th):",
	strfcflag             	string       comment "Def(En):
Def(Th):",
	load_tms              	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id            	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy              	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_scf/scf_vw_sct_book_loan' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);