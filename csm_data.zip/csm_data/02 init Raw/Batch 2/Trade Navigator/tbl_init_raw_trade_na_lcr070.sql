-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_trade_na_lcr070.sql
# Area: trade_na
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_TRADE_NA.TRADE_NA_LCR070
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_trade_na.trade_na_lcr070 (
	pos_dt    	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	lprcty    	string       comment "Def(En): Record Type
Def(Th):",
	lc1ref    	string       comment "Def(En): FIRST REFERENCE
Def(Th):",
	lc2ref    	string       comment "Def(En): SECOND REFERENCE
Def(Th):",
	lcacno    	string       comment "Def(En): C/L ACCOUNT
Def(Th):",
	lccust    	string       comment "Def(En): CUSTOMER ID
Def(Th):",
	lccrcy    	string       comment "Def(En): CURRENCY
Def(Th):",
	lcrate    	decimal(17,7) comment "Def(En): EXCHANGE RATE
Def(Th):",
	lcfamt    	decimal(17,2) comment "Def(En): FC AMOUNT
Def(Th):",
	lcfout    	decimal(17,2) comment "Def(En): FC OUTSTANDING
Def(Th):",
	lcfint    	decimal(17,2) comment "Def(En): INTEREST OUTSTANDING
Def(Th):",
	lcfchr    	decimal(9,2) comment "Def(En): CHARGE FEE
Def(Th):",
	lclsrt    	string       comment "Def(En): LAST EXCHANGE RATE
Def(Th):",
	lcvdte    	date         comment "Def(En): VALUE DATE
Def(Th):",
	lcddte    	date         comment "Def(En): DUE DATE
Def(Th):",
	lccncd    	string       comment "Def(En): CENTER CODE
Def(Th):",
	lcofcr    	integer      comment "Def(En): ACCOUNT OFFICER
Def(Th):",
	lcinfg    	string       comment "Def(En): RATE FLAG
Def(Th):",
	lccndt    	date         comment "Def(En): CANCEL RATE DATE
Def(Th):",
	lcinto    	decimal(17,2) comment "Def(En): INTEREST ACCRUED
Def(Th):",
	lcfics    	string       comment "Def(En): FICS NO
Def(Th):",
	lcovdy    	integer      comment "Def(En): OVERDUE DAYS
Def(Th):",
	lcrtty    	integer      comment "Def(En): RATE TYPE
Def(Th):",
	lcsign    	integer      comment "Def(En): SIGN
Def(Th):",
	lcrtsp    	decimal(7,4) comment "Def(En): SPREAD RATE
Def(Th):",
	lcefrt    	decimal(7,4) comment "Def(En): EFFECTIVE RATE
Def(Th):",
	lcrvfg    	integer      comment "Def(En): Reverse Flag
Def(Th):",
	lcrvdt    	date         comment "Def(En): Reverse Date
Def(Th):",
	lcrvac    	decimal(13,2) comment "Def(En): Reverse Accrue
Def(Th):",
	lcmoac    	decimal(13,2) comment "Def(En): Memo Accrue
Def(Th):",
	lcbrac    	integer      comment "Def(En): BRANCH NO.
Def(Th):",
	lcprod    	string       comment "Def(En): PRODUCT NAME
Def(Th):",
	lcdcty    	string       comment "Def(En): DOCUMENT TYPE
Def(Th):",
	lcspty    	string       comment "Def(En): SPECIAL TYPE
Def(Th):",
	lpmno     	integer      comment "Def(En): LPM No.
Def(Th):",
	lcrole    	string       comment "Def(En): Legal Entity
Def(Th):",
	lcrorc    	string       comment "Def(En): Respon Center
Def(Th):",
	lcroan    	string       comment "Def(En): Account
Def(Th):",
	lcrofn    	string       comment "Def(En): Function On
Def(Th):",
	lcrolb    	string       comment "Def(En): Line Of Business
Def(Th):",
	lcropd    	string       comment "Def(En): Product Code
Def(Th):",
	lcroic    	string       comment "Def(En): Inter Company
Def(Th):",
	lcroit    	string       comment "Def(En): Intra Company
Def(Th):",
	lcropj    	string       comment "Def(En): Project
Def(Th):",
	lcrof1    	string       comment "Def(En): Future Used1
Def(Th):",
	lcrof2    	string       comment "Def(En): Future Used2
Def(Th):",
	lcrspd    	string       comment "Def(En): Sub Product
Def(Th):",
	load_tms  	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_trade_na/trade_na_lcr070' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);