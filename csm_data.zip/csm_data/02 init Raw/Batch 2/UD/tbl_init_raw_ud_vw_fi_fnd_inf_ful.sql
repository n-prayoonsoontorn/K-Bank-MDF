-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_ud_vw_fi_fnd_inf_ful.sql
# Area: ud
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_UD.UD_VW_FI_FND_INF_FUL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_ud.ud_vw_fi_fnd_inf_ful (
	pos_dt                        	date          comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt                    	date          comment "Def(En): FCIS Application Date
Def(Th):",
	fund_id                       	string        comment "Def(En): FUND ID
Def(Th):",
	fund_status                   	string        comment "Def(En): Fund Status  
Y=Active 
N= Inactive (Disabled)
Def(Th):",
	fund_payin_acct_no            	string        comment "Def(En): Fund Pay-In account Number
Def(Th):",
	fund_short_name_eng           	string        comment "Def(En): Fund Abbreviation Name
Def(Th):",
	add_info_7                    	string        comment "Def(En): Fund Type Desc in English
Def(Th):",
	fund_name_thai                	string        comment "Def(En): Fund Name Thai
Def(Th):",
	fund_name_eng                 	string        comment "Def(En): Fund Name English
Def(Th):",
	amc_name_thai                 	string        comment "Def(En): AMC Name Thai
Def(Th):",
	amc_name_eng                  	string        comment "Def(En): AMC Name ENGLISH
Def(Th):",
	fund_type_code                	smallint      comment "Def(En): Fund Type Code
Def(Th):",
	fund_type_desc_eng            	string        comment "Def(En): Fund Type Desc in English
Def(Th):",
	add_info_8                    	string        comment "Def(En): Fund Type Desc in Thai
Def(Th):",
	aimc_fund_type                	string        comment "Def(En): Fund Type (based on AIMC clarification) : use to generate batch out interface AIMC Report
Add Info
Def(Th):",
	thai_individual_uh_count      	bigint        comment "Def(En): Number of UH ID,  number of unitholders of Thai nationality, Individual
Thai Country Code is TH
Def(Th):",
	thai_juristic_uh_count        	bigint        comment "Def(En): number of unitholders of Thai nationality, juristic(corporate  type)
Thai Country Code is TH
Def(Th):",
	foreign_individual_uh_count   	bigint        comment "Def(En): Number of unitholders of Foreign nationality, Individual
Def(Th):",
	foreign_juristic_uh_count     	bigint        comment "Def(En): number of unitholders of Foreign nationality, juristic (corporate  type)
Def(Th):",
	total_count_uh                	bigint        comment "Def(En): Total number of unitholders
Def(Th):",
	thai_individual_cust_count    	bigint        comment "Def(En): Number of CIF, Number of customers Thai nationality, individual  type
Def(Th):",
	thai_juristic_cust_count      	bigint        comment "Def(En): Number of customers Thai nationality, corporate  type
Thai Country Code is TH
Def(Th):",
	foreign_individual_cust_count 	bigint        comment "Def(En): Number of customers(CIF) Foreign  nationality, individual  type
Def(Th):",
	foreign_juristic_cust_count   	bigint        comment "Def(En): Number of customers Foreign  nationality, (corporate  type)
Def(Th):",
	total_count_cust              	bigint        comment "Def(En): Total number of customers
Def(Th):",
	thai_individual_uh_unitbalance	decimal(27,12) comment "Def(En): Unit Balance(Confirmed) of Individual unitholders, Thai nationality
Thai Country Code is TH
Def(Th):",
	thai_juristic_uh_unitbalance  	decimal(27,12) comment "Def(En): Unit Balance(Confirmed) of juristic unitholders, Thai nationality(corporate  type)
Thai Country Code is TH
Def(Th):",
	foreign_individual_uh_unitbal 	decimal(27,12) comment "Def(En): Unit Balance(Confirmed) of Individual unitholders, Foreign nationality
Def(Th):",
	foreign_juristic_uh_unitbal   	decimal(27,12) comment "Def(En): Unit Balance(Confirmed) of juristic unitholders, Foreign  nationality (corporate  type)
Def(Th):",
	total_unitbalance_uh          	decimal(27,12) comment "Def(En): Total unit balance (Confirmed)
Def(Th):",
	thai_individual_uh_amount     	decimal(30,12) comment "Def(En): Unit Balance(Confirmed)*Latest NAV of Individual unitholders, Thai nationality
Thai Country Code is TH
Def(Th):",
	thai_juristic_uh_amount       	decimal(30,12) comment "Def(En): Unit Balance(Confirmed)*Latest NAV of juristic unitholders, Thai nationality (corporate  type)
Thai Country Code is TH
Def(Th):",
	foreign_individual_uh_amount  	decimal(30,12) comment "Def(En): Unitholder Amount of Individual unitholders, Foreign nationality (Unit Balance(Confirmed)*Latest NAV)
Def(Th):",
	foreign_juristic_uh_amount    	decimal(30,12) comment "Def(En): Unit Balance(Confirmed)*Latest NAV of juristic unitholders, (corporate  type)Foreign  nationality
Def(Th):",
	total_amount_uh               	decimal(30,12) comment "Def(En): Total Amount (Total unit balance(Confirmed)*Latest NAV)
Def(Th):",
	extraction_date_time          	timestamp     comment "Def(En): FCIS extraction DB server Date Time
Def(Th):",
	allocation_date               	date          comment "Def(En): Lastest Allocation Date
Def(Th):",
	keystring                     	string        comment "Def(En): Unique Key for each extraction
Def(Th):",
	security_type                 	string        comment "Def(En): Fund Type Code
Def(Th):",
	fund_risk_level               	smallint      comment "Def(En): Fund Risk Level (Refer Additional CR Lot1)
Def(Th):",
	fund_fx_risk_accept_flag      	string        comment "Def(En): Fund Foreign Exchange Rate  risk acceptance  (Refer Additional CR Lot1)
Def(Th):",
	provisional_unit              	decimal(30,12) comment "Def(En): Provisional Unit on Allocation Date
Def(Th):",
	exit_fee_rate                 	decimal(17,8) comment "Def(En): Exit fee rate
1 load may have many slab
Maximum Exit fee rate of each fund
Def(Th):",
	front_fee_rate                	decimal(17,8) comment "Def(En): FrontEnd fee rate
1 load may have many slab
Maximum FrontEnd fee rate of each fund
Def(Th):",
	fund_exit_fee_rate            	decimal(17,8) comment "Def(En): Exit fee rate for fund
Def(Th):",
	fund_payout_acct_no           	string        comment "Def(En): Fund Pay-Out account Number
Def(Th):",
	fund_tax_no                   	string        comment "Def(En): Fund Tax No.
(Fund tax ID)
Def(Th):",
	max_buy_amount                	decimal(30,12) comment "Def(En): MAXIMUM BUY AMOUNT
Def(Th):",
	max_sel_amount                	decimal(30,12) comment "Def(En): MAXIMUM SELL AMOUNT
Def(Th):",
	min_buy_amount                	decimal(30,12) comment "Def(En): MINIMUM BUY AMOUNT
Def(Th):",
	min_sel_amount                	decimal(30,12) comment "Def(En): MINIMUM SELL AMOUNT
Def(Th):",
	nav_div_total_count_fore_ind  	decimal(30,12) comment "Def(En): NAV divide by Count of UHID(Foreign Individual Person)  /1,000,000
Def(Th):",
	nav_div_total_count_fore_jur  	decimal(30,12) comment "Def(En): NAV divide by Count of UHID(Foreign Individual Person)  /1,000,000
Def(Th):",
	nav_div_total_count_thai_ind  	decimal(30,12) comment "Def(En): NAV divide by Count of UHID(THAI Individual Person)  /1,000,000
Def(Th):",
	nav_div_total_count_thai_jur  	decimal(30,12) comment "Def(En): NAV divide by Count of UHID(Thai Juristic Person)  /1,000,000
Def(Th):",
	nav_div_total_count_uh        	decimal(30,12) comment "Def(En): NAV divide by Count of UHID /1,000,000
Def(Th):",
	par_value                     	decimal(17,8) comment "Def(En): PAR value
Def(Th):",
	previous_bid                  	decimal(17,8) comment "Def(En): PREVIOUS BID price
(highest slab of load)
Def(Th):",
	previous_offer                	decimal(17,8) comment "Def(En): PREVIOUS Offer price
(highest slab of load)
Def(Th):",
	price_date                    	date          comment "Def(En): highest slab of load
Def(Th):",
	price_per_unit                	decimal(17,8) comment "Def(En): Lastest Price per Unit/Lastest Nav Rate/Lastest Nav per Unit
Def(Th):",
	trustee_name                  	string        comment "Def(En): Fund Trustee Name.
Def(Th):",
	add_info_12                   	string        comment "Def(En): User license level that can perform transaction on this fund.
Def(Th):",
	add_info_13                   	string        comment "Def(En): Job code list (comma seperator). This field is used to identify list of employee job code whose can perform transaction on this fund.
Def(Th):",
	load_tms                      	timestamp     comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                    	string        comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                      	string        comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                        	string        comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                        	string        comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_ud/ud_vw_fi_fnd_inf_ful' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);