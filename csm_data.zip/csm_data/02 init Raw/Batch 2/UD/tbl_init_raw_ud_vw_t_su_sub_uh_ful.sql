-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_ud_vw_t_su_sub_uh_ful.sql
# Area: ud
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_UD.UD_VW_T_SU_SUB_UH_FUL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_ud.ud_vw_t_su_sub_uh_ful (
	pos_dt                     	date          comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt                 	date          comment "Def(En): Application Date
Def(Th):",
	acct_no                    	string        comment "Def(En): Unitholder ID
Def(Th):",
	sub_no                     	string        comment "Def(En): Sub Account Number
Def(Th):",
	cif_number                 	string        comment "Def(En): CIF Number
Def(Th):",
	keystring                  	string        comment "Def(En): Keystring
Def(Th):",
	full_name                  	string        comment "Def(En): FULL NAME THAI
Def(Th):",
	title                      	string        comment "Def(En): Title  (Thai)
Def(Th):",
	uh_firstname_en            	string        comment "Def(En): This field will store the value of First name(EN) at UH level.
Def(Th):",
	uh_lastname_en             	string        comment "Def(En): This field will store the value of Last name(EN) at UH level
Def(Th):",
	first_name                 	string        comment "Def(En): First name (Thai)
Def(Th):",
	last_name                  	string        comment "Def(En): Last name  (Thai)
Def(Th):",
	card_id                    	string        comment "Def(En): Identification number
Def(Th):",
	tax_id                     	string        comment "Def(En): TAX ID
Def(Th):",
	tax_type                   	string        comment "Def(En): TAX TYPE
Def(Th):",
	birth_date                 	date          comment "Def(En): Unit Holder Birth date
Def(Th):",
	address_1                  	string        comment "Def(En): Address line1 + Address line 2
Def(Th):",
	address_2                  	string        comment "Def(En): Sub district + District + City
Def(Th):",
	home_no                    	string        comment "Def(En): Home number
Def(Th):",
	country_code               	string        comment "Def(En): Contact Address - Country Code
Def(Th):",
	country_desc               	string        comment "Def(En): Contact Address - Description
Def(Th):",
	province_code              	string        comment "Def(En): Province (State)
Def(Th):",
	nationality_type           	string        comment "Def(En): Nationality Type
Def(Th):",
	nationality_desc           	string        comment "Def(En): Nationality Description
Def(Th):",
	home_phone                 	string        comment "Def(En): HOME PHONE
Def(Th):",
	office_phone               	string        comment "Def(En): OFFICE PHONE
Def(Th):",
	agency_br                  	smallint      comment "Def(En): Agency Branch Code
Def(Th):",
	agency_br_name             	string        comment "Def(En): Agency Branch Name
Def(Th):",
	agency_id                  	string        comment "Def(En): Agency ID (Domicile Sub Account level)
Def(Th):",
	amount_bal                 	decimal(15,2) comment "Def(En): Amount balance
Def(Th):",
	as_of_date                 	date          comment "Def(En): As of date of Unit Balance
Def(Th):",
	average_cost               	decimal(30,12) comment "Def(En): Average Cost per Unit of buy
Def(Th):",
	average_ending             	decimal(15,2) comment "Def(En): Average Ending as of last month
Def(Th):",
	avgcost_rmf_after_1mar08   	decimal(30,12) comment "Def(En): RMF Avg Cost of the Unit holder >=  1 Mar 2008
Def(Th):",
	avgcost_rmf_before_1mar08  	decimal(30,12) comment "Def(En): RMF Avg Cost of the Unit holder < 1 Mar 2008
Def(Th):",
	bank_code                  	smallint      comment "Def(En): Bank Code of Default redemption bank account.
Def(Th):",
	book_number                	string        comment "Def(En): Passbook Number
Def(Th):",
	card_type_pwm              	string        comment "Def(En): Identification number Type Code for PWM
 return from function
Def(Th):",
	card_type_sec              	string        comment "Def(En): Identification number Type Code for SEC
Def(Th):",
	card_type_ss               	string        comment "Def(En): Identification number Type Code for SS
Def(Th):",
	choice_auto_redeem         	string        comment "Def(En): Choice for auto redeem Yes / No
Applicable for K-Life fund
Def(Th):",
	consent_flag               	string        comment "Def(En): Consent Flag for publishing customer info
Def(Th):",
	cost_amount                	decimal(20,2) comment "Def(En): Cost Amount
Def(Th):",
	dep_acct_no                	string        comment "Def(En): Default redemption bank account.
Def(Th):",
	dep_acct_no_weekly         	string        comment "Def(En): Default bank account.
Def(Th):",
	ending_bal                 	string        comment "Def(En): Ending Balance Table
Def(Th):",
	flag_31                    	string        comment "Def(En): Valid Record for interface 3.1
Def(Th):",
	flag_313                   	string        comment "Def(En): Valid Record for interface 3.13
Def(Th):",
	flag_35                    	string        comment "Def(En): Valid Record for interface 3.5
Def(Th):",
	flag_353                   	string        comment "Def(En): Valid Record for interface 3.53
Def(Th):",
	flag_355                   	string        comment "Def(En): Valid Record for interface 3.55
Def(Th):",
	flag_369                   	string        comment "Def(En): Valid Record for interface 3.69
Def(Th):",
	flag_378                   	string        comment "Def(En): Valid Record for interface 3.78
Def(Th):",
	flag_904                   	string        comment "Def(En): Valid Record for interface 904
Def(Th):",
	fund_id                    	string        comment "Def(En): FUND ID
Def(Th):",
	fund_name_thai             	string        comment "Def(En): Fund Name (TH)
Def(Th):",
	fund_register_no           	string        comment "Def(En): Fund Register Number
Def(Th):",
	fund_register_yyyy         	string        comment "Def(En): Fund Register Year
Def(Th):",
	fund_short_name            	string        comment "Def(En): Fund Short Name in English
Def(Th):",
	fund_domicile_br_code      	smallint      comment "Def(En): Fund Domicile Branch Code
Def(Th):",
	fund_domicile_br_code_sub  	smallint      comment "Def(En): Fund Domicile Branch Code for Sub Account
Def(Th):",
	juristic_number            	string        comment "Def(En): Juristic Number
Def(Th):",
	juristic_register_date     	date          comment "Def(En): Juristic Register Date
Def(Th):",
	last_allot_uh_sub_date     	date          comment "Def(En): Last Allot _UH Sub Date
Def(Th):",
	last_fcis_eodprocess_date  	date          comment "Def(En): Last Fcis EOD Process Date
Def(Th):",
	last_trans_date            	date          comment "Def(En): Last Transaction date
Def(Th):",
	liquidation_preference     	string        comment "Def(En): Reinvestment option
This will store the value of liquidation preference.
Def(Th):",
	ltf_cost_amount            	decimal(30,12) comment "Def(En): Cost amount of LTF transaction
Accumulated cost of the unit at sub level
Def(Th):",
	market_amount              	decimal(20,2) comment "Def(En): Market Amount
Unit Balance confirmed * NAV
Def(Th):",
	misc_code                  	string        comment "Def(En): MiscCode at Sub account level
Def(Th):",
	native                     	string        comment "Def(En): NATIVE
Def(Th):",
	nav                        	decimal(23,4) comment "Def(En): Net Asset value of fund, as of last business day of year. All cleared transactions and Latest NAV to be considered.
Def(Th):",
	nav_date                   	date          comment "Def(En): Lastest NAV Date
Def(Th):",
	nav_per_unit               	decimal(25,10) comment "Def(En): Lastest NAV of process date
Def(Th):",
	nav_uh                     	decimal(23,4) comment "Def(En): Avaliable Unit of all Unit trust holder account under fund
Def(Th):",
	person_type_sec            	string        comment "Def(En): PersonType for SS
Def(Th):",
	person_type_ss             	string        comment "Def(En): PersonType for SEC
Def(Th):",
	reinvest_fund_id           	string        comment "Def(En): Fund ID for reinvestment
Def(Th):",
	reinvest_uh_id             	string        comment "Def(En): Unit holder account number for reinvestment
Def(Th):",
	reject_code                	string        comment "Def(En): REJECT CODE
Def(Th):",
	remark_kci                 	string        comment "Def(En): Remark KCI
Def(Th):",
	rmf_unit_after_1mar08      	decimal(27,12) comment "Def(En): RMF_UNIT_AFTER_1MAR08
Def(Th):",
	rmf_unit_before_1mar08     	decimal(27,12) comment "Def(En): RMF_UNIT_BEFORE_1MAR08
Def(Th):",
	sex_code_sec               	string        comment "Def(En): Sex Code for SS 
Def(Th):",
	sex_code_ss                	string        comment "Def(En): Sex Code for SEC
Def(Th):",
	special_cost               	decimal(30,12) comment "Def(En): Special Cost per Unit of Buy. This will be applicable for KSTAR, KLIFE and ROLLOVER funds
This field will be optional in the extract
Def(Th):",
	stock2fund                 	string        comment "Def(En): If there are funds of UH ID apply Stock2Fund then Y else N.
Def(Th):",
	sub_no_pwm                 	string        comment "Def(En): Unit Holder Sub  Account Number
Def(Th):",
	total_unitbalance_uh       	decimal(23,5) comment "Def(En): Available Unit balance of fund as of process date, only cleared transactions to be considered.
Def(Th):",
	acct_open_date             	date          comment "Def(En): Unitholder Account Open Date
Def(Th):",
	acct_open_time             	string        comment "Def(En): Unitholder Account Open Time
Def(Th):",
	uh_close_date              	date          comment "Def(En):
Def(Th):",
	uh_status                  	string        comment "Def(En): Unit Holder Status
Def(Th):",
	uh_sub_account_open_date   	date          comment "Def(En): Unit Holder Sub Open Date
Def(Th):",
	uh_sub_domicile_branch_code	string        comment "Def(En): Unit Holder Sub Domicile Branch Code
Def(Th):",
	uh_sub_intermediary_ao     	string        comment "Def(En): Unit Holder Sub Intermediary
Def(Th):",
	unit_bal_exempt            	decimal(15,4) comment "Def(En): Non taxable unit for LTF and RMF, RMF-PVD,SSF,SSFX,Thai ESG Fund type
Def(Th):",
	unit_balance_confirmed     	decimal(30,12) comment "Def(En): UnitHolder Balance Only confirmed unit
Def(Th):",
	unit_balance_provisional   	decimal(27,12) comment "Def(En): Unit Balance Provisional
Def(Th):",
	zip_code                   	string        comment "Def(En): Contact Address - Zipcode
Def(Th):",
	maker_id                   	string        comment "Def(En): Maker ID
Def(Th):",
	uh_risk_level              	smallint      comment "Def(En): Unit Holder Risk Level
Def(Th):",
	fund_risk_level            	smallint      comment "Def(En): Fund Risk Level
Def(Th):",
	checker_id                 	string        comment "Def(En): Checker ID
Def(Th):",
	fund_close_date            	date          comment "Def(En): Fund Close Date
Def(Th):",
	fund_name_eng              	string        comment "Def(En): Fund Name (ENG)
Def(Th):",
	vat_code                   	string        comment "Def(En): This will store the value of branch no displayed in UTDUH Client Preference & ID Details tab
Def(Th):",
	uh_domicile_agency_code    	string        comment "Def(En): Agency code at unit holder level
Def(Th):",
	ao_code_at_uhintermediary  	string        comment "Def(En): Account Officer ID at unit holder level
Def(Th):",
	load_tms                   	timestamp     comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                 	string        comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                   	string        comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                     	string        comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                     	string        comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_ud/ud_vw_t_su_sub_uh_ful' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);