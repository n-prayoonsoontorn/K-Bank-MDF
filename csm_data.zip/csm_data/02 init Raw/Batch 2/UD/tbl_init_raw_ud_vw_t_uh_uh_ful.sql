-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_ud_vw_t_uh_uh_ful.sql
# Area: ud
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_UD.UD_VW_T_UH_UH_FUL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_ud.ud_vw_t_uh_uh_ful (
	pos_dt                      	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt                  	date         comment "Def(En): Application Date
Def(Th):",
	uh_acc_number               	string       comment "Def(En): Unitholder ID
Def(Th):",
	cif_number                  	string       comment "Def(En): CIF Number
Def(Th):",
	keystring                   	string       comment "Def(En): Keystring
Def(Th):",
	full_name                   	string       comment "Def(En): UH Full Name 
Def(Th):",
	uh_fullname_thai            	string       comment "Def(En): UH Full Name in Thai
Def(Th):",
	eng_name                    	string       comment "Def(En): English Name
Def(Th):",
	title                       	string       comment "Def(En): Title  (Thai)
Def(Th):",
	first_name                  	string       comment "Def(En): First name (Thai)
Def(Th):",
	last_name                   	string       comment "Def(En): Last name (Thai)
Def(Th):",
	card_no                     	string       comment "Def(En): Identification number
Def(Th):",
	tax_id                      	string       comment "Def(En): Tax ID
Def(Th):",
	tax_type                    	string       comment "Def(En): Tax Type
Def(Th):",
	contact_address1            	string       comment "Def(En): Address line1 + Address line 2
Def(Th):",
	contact_address2            	string       comment "Def(En): Sub district + District + City
Def(Th):",
	country_code                	string       comment "Def(En): Contact Address - Country Code
Def(Th):",
	contact_tambon              	string       comment "Def(En): Sub district
Def(Th):",
	contact_amphur              	string       comment "Def(En): District
Def(Th):",
	contact_province            	string       comment "Def(En): Province
Def(Th):",
	contact_zipcode             	string       comment "Def(En): Zipcode
Def(Th):",
	contact_tel_no_home         	string       comment "Def(En): Home Phone
Def(Th):",
	contact_tel_no_office       	string       comment "Def(En): Office Phone
Def(Th):",
	uh_alternate_addr_cell_phone	string       comment "Def(En): Customer’s mobile phone, UH Alternate Address cell phone
Def(Th):",
	contact_address_cell_phone  	string       comment "Def(En): Contact Address Cell Phone (OTP in KCI)
Def(Th):",
	email                       	string       comment "Def(En): Email
Def(Th):",
	contact_person              	string       comment "Def(En): Contact Person
Def(Th):",
	contact_relation            	string       comment "Def(En): Contact Relation
Def(Th):",
	i_3_12_card_type            	string       comment "Def(En): Identification number Type for interface 3.12
Def(Th):",
	i_3_54_id_type              	string       comment "Def(En): Identification number Type  for interface 3.54 
Def(Th):",
	i_3_12_birth_date           	date         comment "Def(En): Birth Date in CE for interface 3.12
Def(Th):",
	i_3_54_birth_date           	date         comment "Def(En): Birth Date in CE for interface 3.54
Def(Th):",
	i_3_12_sex_code             	string       comment "Def(En): Sex Code for interface 3.12
Def(Th):",
	i_3_54_sex_code             	string       comment "Def(En): Sex Code for interface 3.54
Def(Th):",
	i_3_12_cust_type            	string       comment "Def(En): Customer Category Code like(eg 0707 - Staff) for interface 3.12
Def(Th):",
	investor_type               	string       comment "Def(En): Unitholder Type, Individual Corporate, Individual / Corporate
Def(Th):",
	i_3_12_dep_acct_no          	string       comment "Def(En): Default redemption bank account for interface 3.12
Def(Th):",
	i_3_54_dep_acct_no          	string       comment "Def(En): Default redemption bank account for interface 3.54
Def(Th):",
	uh_bank_detail              	string       comment "Def(En): All UH Bank Account Detail
<BANKCODE>~<BRANCHCODE>~<ACCOUNTNUMBER>~<ACCOUNTNAME>~<VERIFICATION_FLAG>~<CONFIRM_REJECT_REASON>~<REFERAL_AGENCY_BRANCH>~<REFERAL_ID>~<DEFAULT_BANK_ACC_FLAG>~<DIRECTDEBIT_APPLICABLE_FLAG>(*;*)
Def(Th):",
	uh_bank_account_name        	string       comment "Def(En): Unitholder Bank Account Name
Def(Th):",
	open_date                   	date         comment "Def(En): Unitholder Account Open Date
Def(Th):",
	last_modify_date            	date         comment "Def(En): Last Modify Date
Def(Th):",
	record_status               	string       comment "Def(En): UH Status, Modify Flag
Def(Th):",
	agency_id                   	string       comment "Def(En): UH Agency ID
Def(Th):",
	uh_status                   	string       comment "Def(En): Unit Holder Status
Def(Th):",
	uh_agency_name              	string       comment "Def(En): UH Agent Name in, Domicile Agency Name of UH
UH Intermediary Agent 
Def(Th):",
	uh_agency_branch_code       	string       comment "Def(En): UH Agency Branch number Intermediary Branch (UHlevel)
Def(Th):",
	uh_agency_branch_name       	string       comment "Def(En): UH Agency Branch Name  (UH Intermediary/Domicile Agency Branch)
Def(Th):",
	uh_ao_id                    	string       comment "Def(En): UH AO ID
(Intermediary Account Officer ID)
Def(Th):",
	uh_ao_name                  	string       comment "Def(En): UH AO Name
(Intermediary Account Officer name)
Def(Th):",
	uh_bank_code                	string       comment "Def(En): Unitholder Bank Code
Def(Th):",
	acc_operation_type          	string       comment "Def(En): A/C Operation Type
Def(Th):",
	uh_risk_level               	smallint     comment "Def(En): UH Risk Level
** Not used
Def(Th):",
	uh_fx_risk_accept_flag      	string       comment "Def(En): UH Foreign Exchange Rate Risk Acceptance 
Def(Th):",
	uh_risk_date                	date         comment "Def(En): UH Risk Date
Def(Th):",
	uh_risk_exp_date            	date         comment "Def(En): UH Risk Expire Date
Def(Th):",
	miscode                     	string       comment "Def(En): Unit holder miscode
Def(Th):",
	extraction_date_time        	timestamp    comment "Def(En): Extraction Date with Time
Def(Th):",
	ref_number                  	string       comment "Def(En): Reference Number
Def(Th):",
	reject_code                 	string       comment "Def(En): Reject Code                         
This field will have NULL value as multiple Miscellaneous code mapping

Def(Th):",
	consent_flag                	string       comment "Def(En): Consent Flag for publishing customer info
Def(Th):",
	joint_holder1_id            	string       comment "Def(En): Identification Number of Joint Holder 1
This field will have value only for Joint Account

Def(Th):",
	joint_holder2_id            	string       comment "Def(En): Identification Number of Joint Holder 2
This field will have value only for Joint Account

Def(Th):",
	joint_holder3_id            	string       comment "Def(En): Identification Number of Joint Holder 3
This field will have value only for Joint Account

Def(Th):",
	nationality_code            	string       comment "Def(En): Nationality Code (English)
Def(Th):",
	first_joint_cif_number      	string       comment "Def(En): First Joint CIF Number, First Joint Holder CIF which is mapped to the primary unit holder
Def(Th):",
	first_uh_joint_title        	string       comment "Def(En): First UH Joint Account Title
Def(Th):",
	first_uh_joint_firstname    	string       comment "Def(En): First UH Joint Account First name
Def(Th):",
	first_uh_joint_lastname     	string       comment "Def(En): First UH Joint Account Last name
Def(Th):",
	second_joint_cif_number     	string       comment "Def(En): Second  Joint CIF Number, Second Joint Holder CIF which is mapped to the primary unit holder
Def(Th):",
	second_uh_joint_title       	string       comment "Def(En): Second  UH Joint Account Title
(Refer Additional CR Lot 2 for Title)
Def(Th):",
	second_uh_joint_firstname   	string       comment "Def(En): Second  UH Joint Account First name
Def(Th):",
	second_uh_joint_lastname    	string       comment "Def(En): Second  UH Joint Account Last name
Def(Th):",
	third_joint_cif_number      	string       comment "Def(En): Third Joint CIF Number, Third Joint Holder CIF which is mapped to the primary unit holder
Def(Th):",
	third_uh_joint_title        	string       comment "Def(En): Third UH Joint Account Title
(Refer Additional CR Lot 2 for Title)
Def(Th):",
	third_uh_joint_firstname    	string       comment "Def(En): Third UH Joint Account First name
Def(Th):",
	third_uh_joint_lastname     	string       comment "Def(En): Third UH Joint Account Last name
Def(Th):",
	auth_rep_id                 	string       comment "Def(En): Authorization Rep ID, ID Card, In case account holder(บัญชีโดย) 
Def(Th):",
	auth_rep_name               	string       comment "Def(En): Authorization Rep Name (TITLE+FIRST+LAST)
Def(Th):",
	add_info_1                  	string       comment "Def(En): Additional Information 1
Def(Th):",
	add_info_2                  	string       comment "Def(En): Additional Information 2
Def(Th):",
	add_info_3                  	string       comment "Def(En): Additional Information 3
Def(Th):",
	add_info_4                  	string       comment "Def(En): Additional Information 4
Def(Th):",
	add_info_5                  	string       comment "Def(En): Additional Information 5
Def(Th):",
	add_info_6                  	string       comment "Def(En): Additional Information 6
Def(Th):",
	add_info_7                  	string       comment "Def(En): Additional Information 7
Def(Th):",
	add_info_8                  	string       comment "Def(En): Additional Information 8
Def(Th):",
	add_info_9                  	string       comment "Def(En): Additional Information 9
Def(Th):",
	add_info_10                 	string       comment "Def(En): Additional Information 10
Def(Th):",
	add_info_11                 	string       comment "Def(En): Additional Information 11
Def(Th):",
	add_info_12                 	string       comment "Def(En): Additional Information 12
Def(Th):",
	add_info_13                 	string       comment "Def(En): Additional Information 13
Def(Th):",
	add_info_14                 	string       comment "Def(En): Additional Information 14
Def(Th):",
	add_info_15                 	string       comment "Def(En): Additional Information 15
Def(Th):",
	add_info_16                 	string       comment "Def(En): Additional Information 16
Def(Th):",
	add_info_17                 	string       comment "Def(En): Additional Information 17
Def(Th):",
	add_info_18                 	string       comment "Def(En): Additional Information 18
Def(Th):",
	add_info_19                 	string       comment "Def(En): Additional Information 19
Def(Th):",
	add_info_20                 	string       comment "Def(En): Additional Information 20
Def(Th):",
	add_info_21                 	string       comment "Def(En): Additional Information 21
Def(Th):",
	add_info_22                 	string       comment "Def(En): Additional Information 22
Def(Th):",
	add_info_23                 	string       comment "Def(En): Additional Information 23
Def(Th):",
	add_info_24                 	string       comment "Def(En): Additional Information 24
Def(Th):",
	add_info_25                 	string       comment "Def(En): Additional Information 25
Def(Th):",
	add_info_26                 	string       comment "Def(En): Additional Information 26
Def(Th):",
	add_info_27                 	string       comment "Def(En): Additional Information 27
Def(Th):",
	add_info_28                 	string       comment "Def(En): Additional Information 28
Def(Th):",
	add_info_29                 	string       comment "Def(En): Additional Information 29
Def(Th):",
	add_info_30                 	string       comment "Def(En): Additional Information 30
Def(Th):",
	all_kci_recieve_flag        	string       comment "Def(En): All the requested KCI documentation has been received
Def(Th):",
	apply_kinvest_flag          	string       comment "Def(En): Apply K-Cyber Invest flag
Def(Th):",
	max_doc_receive_date        	date         comment "Def(En): Maximum Document Receive Date
Def(Th):",
	min_doc_receive_date        	date         comment "Def(En): Minimum Document Receive Date
Def(Th):",
	occupation                  	string       comment "Def(En): Occupation Code at UH level, This field has value only individual investor
Refer parameterization for occupation description (ParamCode: OCCUPATIONTYPE)
Def(Th):",
	ref_agy_br_kci              	string       comment "Def(En): Referral agency branch which apply KCI
Def(Th):",
	ref_agy_br_kci_agent_id     	string       comment "Def(En): Agent ID of Referral agency branch
which apply KCI
Def(Th):",
	ref_agy_br_kci_user_id      	string       comment "Def(En): Referral person (maker id) who apply KCI
Def(Th):",
	ref_agy_br_kci_user_ao_flag 	string       comment "Def(En): A/O Flag : Maker ID who apply KCI is A/O or not
Def(Th):",
	load_tms                    	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                  	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                    	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                      	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                      	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_ud/ud_vw_t_uh_uh_ful' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);