-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_csm_custxformxconsentderivedlog.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-20    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CSM.CSM_CUSTXFORMXCONSENTDERIVEDLOG
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_csm.csm_custxformxconsentderivedlog (
	pos_dt                	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	lcustfcdr_cust_id     	smallint      comment "Description (Eng): Cust ID (CIS ID)
Description (Thai): เลขที่ลูกค้า (CIS ID)",
	lcustfcdr_formappr_cd 	string        comment "Description (Eng): Form APPR ID
Description (Thai): รหัสของวัตถุประสงค์ของฟอร์มสำหรับใส่ระดับ derived",
	lcustfcdr_consent_flag	string        comment "Description (Eng):Consent flag
Description (Thai):ค่า consent ที่ลูกค้าให้",
	lcustfcdr_upd_user    	string        comment "Description (Eng):Update by UserID
Description (Thai):User ที่แก้ไขข้อมูล",
	lcustfcdr_upd_dt      	timestamp     comment "Description (Eng):Update date
Description (Thai):วันที่อัพเดทข้อมูล",
	lcustfcdr_upd_dt_group	timestamp     comment "Description (Eng):Update date group
Description (Thai):วันที่ใช้สำหรับ group ข้อมูลที่ update เป็นชุดเดียวกัน",
	lcustfcdr_upd_user_l  	string        comment "Description (Eng):Update by UserID
Description (Thai):User ที่แก้ไขข้อมูล",
	lcustfcdr_upd_dt_l    	timestamp     comment "Description (Eng):Update log date
Description (Thai):วันที่ log ข้อมูล",
	load_tms              	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id            	string        comment "Source system ID",
	ptn_yyyy              	string        comment "Partition field - year",
	ptn_mm                	string        comment "Partition field - month",
	ptn_dd                	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_csm/csm_custxformxconsentderivedlog' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);