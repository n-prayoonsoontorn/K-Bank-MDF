-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_csm_custxformxconsentlog.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-20    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CSM.CSM_CUSTXFORMXCONSENTLOG
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_csm.csm_custxformxconsentlog (
	pos_dt                   	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	lcustfc_cust_id          	integer       comment "Def(En): Cust ID (CIS ID)
Def(Th): เลขที่ลูกค้า (CIS ID)",
	lcustfc_form_id          	integer       comment "Def(En): Form ID
Def(Th): เลขที่ฟอร์มสำหรับกรอก consent",
	lcustfc_consent_eff_date 	timestamp     comment "Def(En):Effective date
Def(Th):วันที่ให้ consent",
	lcustfc_consent_exp_date 	timestamp     comment "Def(En):Expire date
Def(Th):วันที่สิ้นสุดค่า consent",
	lcustfc_re_consent_date  	date          comment "Def(En):Reconsent date
Def(Th):วันที่ต้องถาม consent ใหม่",
	lcustfc_channel_cd       	string        comment "Def(En):Channel code
Def(Th):ช่องทางที่ให้ consent",
	lcustfc_originate_product	string        comment "Def(En):Originate product
Def(Th):product ที่ทำรายการที่ให้ consent",
	lcustfc_evidence_url     	string        comment "Def(En):Evidence URL
Def(Th):URL รูปภาพหลักฐานการให้ consent",
	lcustfc_consent_flag     	string        comment "Def(En):Consent flag
Def(Th):ค่า consent ที่ลูกค้าให้",
	lcustfc_upd_user         	string        comment "Def(En):Update by UserID
Def(Th):user ที่แก้ไขข้อมูล",
	lcustfc_upd_user_name    	string        comment "Def(En):Update by User name
Def(Th):ชื่อ-นามสกุล ของ user
(No value in phase1)",
	lcustfc_upd_user_deptcd  	string        comment "Def(En):Department code of user
Def(Th):รหัสหน่วยงานหรือสาขาของ user ที่ทำรายการ",
	lcustfc_upd_user_deptnm  	string        comment "Def(En):Department name of user
Def(Th):ชื่อหน่วยงานของ user ที่ทำรายการ
(No value in phase1)",
	lcustfc_upd_dt           	timestamp     comment "Def(En):Update date
Def(Th):วันที่อัพเดทข้อมูล",
	lcustfc_upd_dt_group     	timestamp     comment "Def(En):Update date group
Def(Th):วันที่ใช้สำหรับ group ข้อมูลที่ update เป็นชุดเดียวกัน",
	lcustfc_upd_user_l       	string        comment "Def(En):UserID log
Def(Th):UserID ที่ทำรายการ log",
	lcustfc_upd_dt_l         	timestamp     comment "Def(En):Update log date
Def(Th):วันที่ log ข้อมูล",
	load_tms                 	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id               	string        comment "Source system ID",
	ptn_yyyy                 	string        comment "Partition field - year",
	ptn_mm                   	string        comment "Partition field - month",
	ptn_dd                   	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_csm/csm_custxformxconsentlog' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);