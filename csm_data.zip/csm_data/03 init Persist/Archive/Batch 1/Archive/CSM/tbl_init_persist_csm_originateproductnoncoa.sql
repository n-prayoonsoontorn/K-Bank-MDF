-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_csm_originateproductnoncoa.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-20    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CSM.CSM_ORIGINATEPRODUCTNONCOA
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_csm.csm_originateproductnoncoa (
	pos_dt              	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	oriprodncoa_cd      	string        comment "Description (Eng): Non COA product code
Description (Thai): รหัส product แบบ non COA",
	oriprodncoa_th_desc 	string        comment "Description (Eng):Non COA product Thai description
Description (Thai):รายละเอียดภาษาไทย",
	oriprodncoa_en_desc 	string        comment "Description (Eng):Non COA product English description
Description (Thai):รายละเอียดภาษาอังกฤษ",
	oriprodncoa_status  	string        comment "Description (Eng):Non COA product status
Description (Thai):สถานะของ Non COA product",
	oriprodncoa_upd_user	string        comment "Description (Eng):Update by UserID

Description (Thai):user ที่แก้ไขข้อมูล",
	oriprodncoa_upd_dt  	timestamp     comment "Description (Eng):Update date
Description (Thai):วันที่อัพเดทข้อมูล",
	load_tms            	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id          	string        comment "Source system ID",
	ptn_yyyy            	string        comment "Partition field - year",
	ptn_mm              	string        comment "Partition field - month",
	ptn_dd              	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_csm/csm_originateproductnoncoa' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);