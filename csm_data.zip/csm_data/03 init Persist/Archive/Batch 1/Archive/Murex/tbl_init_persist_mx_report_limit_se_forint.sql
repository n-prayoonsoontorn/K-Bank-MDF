-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_mx_report_limit_se_forint.sql
# Area: mx
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-21    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_MX.MX_REPORT_LIMIT_SE_FORINT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_mx.mx_report_limit_se_forint (
	pos_dt           	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	record_type      	smallint     ,
	key              	string       comment "Description (Eng):Original customer ID
Description (Thai):เลขที่บัญชี",
	fullname         	string       comment "Description (Eng):Original customer name
Description (Thai):ชื่อเต็มของบัญชี",
	parent           	string       comment "Description (Eng):Parent original customer ID for check share limit 
Description (Thai):เลขที่บัญชีของ Parent สำหรับตรวจสอบการใช้วงเงินร่วมกัน",
	risk             	string       comment "Description (Eng):Risk level
Description (Thai):ระดับความเสี่ยง",
	limit_type       	string       comment "Description (Eng):Limit type code
Description (Thai):ประเภทวงเงิน",
	maxreallocation  	string       comment "Description (Eng):Reallocation and temporary increase/decrease detail
Description (Thai):รายละเอียดการเพิ่มหรือลดวงเงินและระยะเวลาธุรกรรม",
	limit_parameter  	string       comment "Description (Eng):Limit Parameter
Description (Thai):พารามิเตอร์ที่แสดงว่าอนุมัติวงเงินหรือไม่",
	limit_currency   	string       comment "Description (Eng):Limit currency code
Description (Thai):สกุลของวงเงินที่อนุมัติ",
	limit_amount     	decimal(24,0) comment "Description (Eng):Limit Amount
Description (Thai):วงเงิน",
	maxexpirydate    	date         comment "Description (Eng):Expiry date of revolving limit, temporary increase/decrease limit and reallocation limit 
Description (Thai):วันที่ครบกำหนดชำระ/วันทบทวน",
	maxsuspensiondate	date         comment "Description (Eng):Last suspension date
Description (Thai):วันที่ระงับธุรกรรม",
	maxcomment       	string       comment "Description (Eng):Comment field
Description (Thai):Remark field ที่เก็บข้อมูลผสม",
	cis_id           	string       comment "Description (Eng):Id of involved party
Description (Thai):เลขที่ลูกค้า CIS",
	load_tms         	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id       	string       comment "Source system ID",
	ptn_yyyy         	string       comment "Partition field - year",
	ptn_mm           	string       comment "Partition field - month",
	ptn_dd           	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_mx/mx_report_limit_se_forint' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);