-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_pcb_dep_src_pf_txn_mis_eft_dly.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-21    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_PCB_DEP.PCB_DEP_SRC_PF_TXN_MIS_EFT_DLY
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_pcb_dep.pcb_dep_src_pf_txn_mis_eft_dly (
	pos_dt            	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	rec_type          	string        comment "Record Type - This is to indicate the body record type (Detail record)",
	orig_txn_id       	string        comment "Def(En): Profile unique running number",
	txn_dt            	date          comment "Def(En): Transaction Date
Def(Th): วันที่ทำรายการ",
	txn_val_dt        	date          comment "Def(En): The date that the transaction takes effect. For example, for check deposits, this will differ from the book date by the time it takes to clear the check; for Trades, this will be the settled date; etc.
Def(Th): วันที่รายการมีผล",
	txn_code          	string        ,
	txn_tm            	string        comment "Def(En): Time of entry of the trasaction.This is the time assocoated with the Entry Date
Def(Th): เวลาที่ทำรายการ",
	cnl_id            	string        comment "Def(En): Channel identifies the different delivery and communications mechanisms through which products and services are made available to a customer and by which the Financial Institution and customers communicate with each other. Application Id
Def(Th): ระบบที่ทำรายการ",
	fm_ar_id          	string        comment "Def(En): From Arrangement Id
Def(Th): บัญชีของผู้ทำรายการ",
	to_ar_id          	string        comment "Def(En): To Arrangement Id
Def(Th): บัญชีผู้รับ",
	intzon_id         	string        ,
	txn_amt           	decimal(18,2) comment "Def(En): Transaction Amount
Def(Th): จำนวนเงินที่ทำรายการ",
	txn_cmsn          	decimal(18,2) ,
	txn_tel_fee       	decimal(18,2) ,
	act_txn_amt       	decimal(18,2) ,
	wv_fee_amt        	decimal(18,2) comment "Def(En): Waive Fee 
Def(Th): จำนวนเงินลดหย่อน",
	fm_br_no          	string        ,
	to_br_no          	string        ,
	fm_ar_domc_br_no  	string        ,
	fm_ar_pd_tp_id    	string        ,
	to_ar_pd_tp_id    	string        ,
	fm_coa_pd_ftr_code	string        ,
	to_coa_pd_ftr_code	string        ,
	eft_co_th_nm      	string        ,
	eft_co_en_nm      	string        ,
	eft_cst_nm        	string        ,
	eft_usr_id        	string        ,
	eft_txn_tp        	string        ,
	eft_chk_nbr       	string        ,
	eft_chk_bnk_code  	string        ,
	load_tms          	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id        	string        comment "Source system ID",
	ptn_yyyy          	string        comment "Partition field - year",
	ptn_mm            	string        comment "Partition field - month",
	ptn_dd            	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_pcb_dep/pcb_dep_src_pf_txn_mis_eft_dly' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);