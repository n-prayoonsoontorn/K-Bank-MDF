-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cis_ar.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-22    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CIS.CIS_AR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cis.cis_ar (
	pos_dt         	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	method         	string       comment "Def(En): Ingestion Method
Def(Th): วิธีการนำเข้า",
	ar_id          	bigint       comment "Def(En): Arrangement id
Def(Th): เลขที่ arrangement",
	ar_ip_id       	integer      comment "Def(En): Customer id
Def(Th): เลขที่ลูกค้า",
	ar_src_stm_no_1	string       comment "Def(En): Arrangement source system no. 1
Def(Th): รหัสชนิดธุรกรรมจากแต่ละระบบ#1 (cust ref)",
	ar_src_stm_no_2	string       comment "Def(En): Arrangement source system no. 2
Def(Th): รหัสชนิดธุรกรรมจากแต่ละระบบ#2 (product)",
	ar_src_stm_no_3	string       comment "Def(En): Arrangement source system no. 3
Def(Th): รหัสชนิดธุรกรรมจากแต่ละระบบ#3 (sub product)",
	ar_src_stm     	string       comment "Def(En): Arrangement Source System
Def(Th): รหัสของ Product group",
	ar_pd_cd       	string       comment "Def(En): Arrangement Product code
Def(Th): รหัสของ Product sub group",
	ar_pd_cd_9     	string       comment "Def(En): Arrangement Product code 9 digits
Def(Th): รหัสของ Product sub group 9 หลัก",
	ar_br_no       	string       comment "Def(En): Arrangement Branch no.
Def(Th): สาขาที่ทำธุรกรรม",
	ar_term_prd    	string       comment "Def(En): Arrangement Term Period
Def(Th): รหัสความสัมพันธ์ทางบัญชี",
	ar_stat        	string       comment "Def(En): Arrangement Status code
Def(Th): รหัสสถานะของ arrangement",
	ar_begin_dt    	date         comment "Def(En): Arrangement Begin date
Def(Th): วันที่เริ่มผูกหรือเปลี่ยนความสัมพันธ์",
	ar_end_dt      	date         comment "Def(En): Arrangement End date
Def(Th): วันที่ยกเลิกความสัมพันธ์",
	ar_user_id     	string       comment "Def(En): User id
Def(Th): รหัสผู้ทำรายการ",
	ar_upd_dt      	timestamp    comment "Def(En): Update date time
Def(Th): วันและเวลาที่ทำรายการ",
	load_tms       	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id     	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy       	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm         	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd         	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cis/cis_ar' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);