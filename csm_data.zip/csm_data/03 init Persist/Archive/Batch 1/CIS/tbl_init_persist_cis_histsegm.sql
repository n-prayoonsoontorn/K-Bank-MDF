-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cis_histsegm.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-22    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CIS.CIS_HISTSEGM
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cis.cis_histsegm (
	pos_dt               	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	method               	string       comment "Def(En): Ingestion Method
Def(Th): วิธีการนำเข้า",
	hstsgm_id            	bigint       comment "Def(En): Hist Segment running no.
Def(Th): เลข running สำหรับประวัติ segment",
	hstsgm_ip_id         	integer      comment "Def(En): Customer id
Def(Th): เลขที่ลูกค้า",
	hstsgm_segm_tp       	string       comment "Def(En): Segment type
Def(Th): รหัสประเภท segment",
	hstsgm_segm_cd       	string       comment "Def(En): Segment code
Def(Th): รหัส segment ของลูกค้า",
	hstsgm_segm_dt       	date         comment "Def(En): Segment update date
Def(Th): วันที่เปลี่ยนแปลง segment",
	hstsgm_chg_cd        	string       comment "Def(En): Segment changed Reason code
Def(Th): สาเหตุของการเปลี่ยน Segment",
	hstsgm_ipsegm_act    	string       comment "Def(En): Action on IPSEGMENT table
Def(Th): Action ที่กระทำกับ record ใน table IPSEGMENT",
	hstsgm_ipsegm_dt     	date         comment "Def(En): Action date on IPSEGMENT table
Def(Th): วันที่ที่กระทำกับ record ใน table IPSEGMENT",
	hstsgm_ipsegm_user_id	string       comment "Def(En): User id from IPSEGMENT table
Def(Th): รหัสผู้ทำรายการจาก table IPSEGMENT",
	hstsgm_ipsegm_upd_dt 	timestamp    comment "Def(En): Update date time from IPSEGMENT table
Def(Th): วันและเวลาที่ทำรายการจาก table IPSEGMENT",
	hstsgm_user_id       	string       comment "Def(En): User id
Def(Th): รหัสผู้ทำรายการ",
	hstsgm_upd_dt        	timestamp    comment "Def(En): Update date time
Def(Th): วันและเวลาที่ทำรายการ",
	load_tms             	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id           	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy             	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm               	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd               	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cis/cis_histsegm' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);