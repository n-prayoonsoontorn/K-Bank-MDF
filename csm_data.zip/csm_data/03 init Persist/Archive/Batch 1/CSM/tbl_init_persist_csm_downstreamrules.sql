-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_csm_downstreamrules.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-22    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CSM.CSM_DOWNSTREAMRULES
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_csm.csm_downstreamrules (
	pos_dt            	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dsr_rule_id       	smallint     comment "Def(En):Rule Id
Def(Th):รหัส Rule",
	dsr_subject       	string       comment "Def(En):Condition
Def(Th):เงื่อนไขที่เลือกมาทั้งหมดใน Rule นี้",
	dsr_parameter     	string       comment "Def(En):Parameter
Def(Th):Parameter",
	dsr_description   	string       comment "Def(En):Description Rule
Def(Th):รายละเอียดของ Rule",
	dsr_parameter_flag	string       comment "Def(En):Parameter Flag
Def(Th):Parameter Flag",
	dsr_condition_000 	string       comment "Def(En):Condition 000
Def(Th):เงื่อนไขรหัส 000",
	dsr_condition_100 	string       comment "Def(En):Condition 100
Def(Th):เงื่อนไขรหัส 100",
	dsr_condition_101 	string       comment "Def(En):Condition 101
Def(Th):เงื่อนไขรหัส 101",
	dsr_condition_102 	string       comment "Def(En):Condition 102
Def(Th):เงื่อนไขรหัส 102",
	dsr_condition_103 	string       comment "Def(En):Condition 103
Def(Th):เงื่อนไขรหัส 103",
	dsr_condition_104 	string       comment "Def(En):Condition 104
Def(Th):เงื่อนไขรหัส 104",
	dsr_condition_105 	string       comment "Def(En):Condition 105
Def(Th):เงื่อนไขรหัส 105",
	dsr_condition_106 	string       comment "Def(En):Condition 106
Def(Th):เงื่อนไขรหัส 106",
	dsr_condition_107 	string       comment "Def(En):Condition 107
Def(Th):เงื่อนไขรหัส 107",
	dsr_condition_108 	string       comment "Def(En):Condition 108
Def(Th):เงื่อนไขรหัส 108",
	dsr_condition_109 	string       comment "Def(En):Condition 109
Def(Th):เงื่อนไขรหัส 109",
	dsr_condition_110 	string       comment "Def(En):Condition 110
Def(Th):เงื่อนไขรหัส 110",
	dsr_condition_111 	string       comment "Def(En):Condition 111
Def(Th):เงื่อนไขรหัส 111",
	dsr_upd_user      	string       comment "Def(En):Update by UserID
Def(Th):User ที่แก้ไขข้อมูล",
	dsr_upd_dt        	timestamp    comment "Def(En):Update date
Def(Th):วันที่อัพเดทข้อมูล",
	load_tms          	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id        	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy          	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm            	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd            	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_csm/csm_downstreamrules' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);