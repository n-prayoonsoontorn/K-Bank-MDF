-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_csm_originateproductcoa.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-22    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CSM.CSM_ORIGINATEPRODUCTCOA
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_csm.csm_originateproductcoa (
	pos_dt             	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	oriprodcoa_cd      	string       comment "Def(En): COA product code
Def(Th): รหัส product แบบ COA",
	oriprodcoa_th_desc 	string       comment "Def(En):COA product Thai description
Def(Th):รายละเอียดภาษาไทย",
	oriprodcoa_en_desc 	string       comment "Def(En):COA product English description
Def(Th):รายละเอียดภาษาอังกฤษ",
	oriprodcoa_status  	string       comment "Def(En):COA product status
Def(Th):สถานะของ COA product",
	oriprodcoa_upd_user	string       comment "Def(En):Update by UserID
Def(Th):User ที่แก้ไขข้อมูล",
	oriprodcoa_upd_dt  	timestamp    comment "Def(En):Update date
Def(Th):วันที่อัพเดทข้อมูล",
	load_tms           	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id         	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy           	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm             	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd             	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_csm/csm_originateproductcoa' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);