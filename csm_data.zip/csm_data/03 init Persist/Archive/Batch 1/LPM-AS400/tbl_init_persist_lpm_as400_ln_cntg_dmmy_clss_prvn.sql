-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_lpm_as400_ln_cntg_dmmy_clss_prvn.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-22    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_LPM_AS400.LPM_AS400_LN_CNTG_DMMY_CLSS_PRVN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_lpm_as400.lpm_as400_ln_cntg_dmmy_clss_prvn (
	pos_dt                       	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	l01w769_tm_id                	integer      comment "Def(Th): เดือนที่ประมวลผล",
	l01w769_acct_no              	string       comment "Def(Th): เลขที่บัญชี",
	l01w769_acct_type            	smallint     comment "Def(Th): ประเภทบัญชี",
	l01w769_cr_type              	smallint     comment "Def(Th): ประเภทเครดิต",
	l01w769_cust_no              	bigint       comment "Def(Th): เลขที่ลูกหนี้",
	l01w769_title                	string       comment "Def(Th): คำนำหน้า",
	l01w769_name                 	string       comment "Def(Th): ชื่อลูกหนี้",
	l01w769_branch_no            	smallint     comment "Def(Th): รหัสสาขา",
	l01w769_dept_no              	smallint     comment "Def(Th): รหัสสังกัด",
	l01w769_acct_bus_code        	integer      comment "Def(Th): รหัสประเภทธุรกิจ ระดับบัญชี",
	l01w769_cust_bus_code        	integer      comment "Def(Th): รหัสประเภทธุรกิจ ระดับลูกหนี้",
	l01w769_fics_type            	integer      comment "Def(Th): ประเภทหัวบัญชี",
	l01w769_prv_day_diff         	smallint     comment "Def(Th): จำนวนวันขาดผ่อน",
	l01w769_sign_prv_outs        	string       comment "Def(Th): เครื่องหมาย PRVOUTS",
	l01w769_prv_outs             	decimal(13,2) comment "Def(Th): ยอดหนี้รวมดอกเบี้ย",
	l01w769_sign_prv_accru       	string       comment "Def(Th): เครื่องหมาย PRVACCR",
	l01w769_prv_accru            	decimal(13,2) comment "Def(Th): ยอดดอกเบี้ยค้างรับ",
	l01w769_prv_int_fg           	smallint     comment "Def(Th): Flag ดอกเบี้ย, 0-คิดดอกเบี้ย, 1-งดคิดดอกเบี้ย",
	l01w769_acct_cust_type       	smallint     comment "Def(Th): ประเภทลูกค้า (ระดับบัญชี)",
	l01w769_limit                	decimal(13,2) comment "Def(Th): วงเงิน ระดับบัญชี",
	l01w769_dept_code            	smallint     comment "Def(Th): รหัสสังกัด",
	l01w769_bibf_in_out          	smallint     comment "Def(En): Flag BIBF, 1 - OUT-IN, 2 - OUT-OUT, 3 - PERSONAL OD",
	l01w769_contract_date        	integer      comment "Def(Th): วันที่ทำสัญญา",
	l01w769_rate_type            	smallint     comment "Def(Th): ประเภทอัตราดอกเบี้ย",
	l01w769_sign                 	smallint     comment "Def(En): 0 =  + ,  1 =  -",
	l01w769_spread               	decimal(6,4) comment "Def(Th): ผลต่างของดอกเบี้ย",
	l01w769_center_branch        	smallint     comment "Def(Th): ศูนย์ธุรกิจต่างประเทศ",
	l01w769_acct_ofc_tdr         	smallint     comment "Def(Th): สังกัดผู้ดูแล",
	l01w769_due_date             	integer      comment "Def(Th): วันครบกำหนด",
	l01w769_sign_bef_outs        	string       comment "Def(Th): เครื่องหมาย BEFOUTS",
	l01w769_bef_outs             	decimal(13,2) comment "Def(Th): ยอดหนี้ก่อนตัดสูญ",
	l01w769_sign_bef_accru       	string       comment "Def(Th): เครื่องหมาย BEFACCR",
	l01w769_bef_accru            	decimal(13,2) comment "Def(Th): ยอดดอกเบี้ยคงค้างก่อนตัดสูญ",
	l01w769_group2               	smallint     comment "Def(Th): จัดชั้นกลุ่ม 2",
	l01w769_asset_flag           	smallint     comment "Def(Th): FLAG สินทรัพย์",
	l01w769_sign_prv_ext_pay     	string       comment "Def(Th): เครื่องหมาย PRVEXTPAY",
	l01w769_prv_ext_pay          	decimal(13,2) comment "Def(Th): ยอดส่วนลดรับ",
	l01w769_cust_type            	smallint     comment "Def(Th): ประเภทลูกค้า (ระดับลูกหนี้)",
	l01w769_bot_acct_group       	smallint     comment "Def(Th): หนี้จัดชั้นตามธนาคารแห่งประเทศไทย",
	l01w769_class_from           	smallint     comment "Def(Th): รหัสการปรับโครงสร้างหนี้ 0, 1, 2, 3",
	l01w769_sign_date            	integer      comment "Def(Th): ปีเดือนวันที่ปรับโครงสร้างหนี้",
	l01w769_class_reason         	smallint     comment "Def(Th): รหัสเหตุผลการปรับ เช่น 601, 901, 902",
	l01w769_asset_group          	smallint     comment "Def(Th): 01-CG, 02-RT, 03-DR, 04-RN, 05-OTHERS (ฝ่าย นค)",
	l01w769_product_name         	smallint     comment "Def(Th): ชื่อผลิตภัณฑ์ของธนาคาร (ฝ่าย นค)",
	l01w769_segment              	smallint     comment "Def(Th): กลุ่มผู้เป็นเจ้าของสินทรัพย์ หรือผู้ดูแล (ฝ่าย นค)",
	l01w769_segment_geo          	smallint     comment "Def(Th): กลุ่มผู้เป็นเจ้าของสินทรัพย์ หรือผู้ดูแล (ฝ่าย นค)",
	l01w769_indus_index_97       	string       comment "Def(Th): อุตสาหกรรม 97 อุตฯ  และผลิตภัณฑ์ (ฝ่าย นค)",
	l01w769_indus_index_100      	string       comment "Def(Th): อุตสาหกรรม 100 อุตฯ  และผลิตภัณฑ์ (ฝ่าย นค)",
	l01w769_loans_aging_group    	smallint     comment "Def(Th): จำแนกกลุ่มตามช่วงของวันค้าง แบบที่ 1",
	l01w769_loans_aging_group2   	smallint     comment "Def(Th): จำแนกกลุ่มตามช่วงของวันค้าง แบบที่ 2",
	l01w769_indus_index_con_97   	string       comment "Def(Th): การจำแนกอุตสาหกรรม 97 อย่างมีเงื่อนไข",
	l01w769_indus_index_con_100  	string       comment "Def(Th): การจำแนกอุตสาหกรรม 100 อย่างมีเงื่อนไข",
	l01w769_int_risk_ind97       	smallint     comment "Def(Th):  อัตราดอกเบี้ย ตามความเสี่ยงของอุตสาหกรรม 97",
	l01w769_int_risk_ind97_con   	smallint     comment "Def(Th): อัตราดอกเบี้ย ตามความเสี่ยงของอุตสาหกรรม 97",
	l01w769_limit_sub            	decimal(13,2) comment "Def(Th):  ยอด Principal ลดลง หรือ Account หายไป)",
	l01w769_due_date1            	integer      comment "Def(Th): วันครบกำหนด",
	l01w769_cont_date            	integer      comment "Def(Th): วันทำสัญญา",
	l01w769_cancel_flag          	string       comment "Def(Th): Flag การยกเลิกของ Credit card",
	l01w769_block_code           	string       comment "Def(Th): Block code ของ Credit card",
	l01w769_real_rec_flag        	string       ,
	l01w769_asset_type           	string       comment "Def(Th): ประเภทสินทรัพย์",
	l01w769_lec_status           	decimal(4,2) comment "Def(Th): รหัสการดำเนินการในการดำเนินคดีLEC",
	l01w769_coll_limit           	decimal(15,2) comment "Def(Th): วงเงินหลักประกัน",
	l01w769_coll_val             	decimal(15,2) comment "Def(Th): ราคาประเมินที่กระจายแล้ว",
	l01w769_acct_ofc_flag        	smallint     comment "Def(Th): Flag A/O รายบัญชี",
	l01w769_loan_purpose         	string       comment "Def(Th): จุดประสงค์การกู้เงิน",
	l01w769_pay_flag             	string       comment "Def(Th): Flag การจ่ายเงิน",
	l01w769_bad_center           	string       comment "Def(En): Bad Center",
	l01w769_acct_res_outs        	decimal(13,2) comment "Def(Th): ยอดหนี้สำรองระดับบัญชี",
	l01w769_npl_outs             	decimal(13,2) comment "Def(Th): ยอดเงินต้น+ดอกเบี้ยค้างรับที่เป็น NPL",
	l01w769_npl_accru            	decimal(13,2) comment "Def(Th): ยอดดอกเบี้ยค้างรับที่เป็น NPL",
	l01w769_sign_int_receive     	string       comment "Def(Th): เครื่องหมาย INTREC",
	l01w769_int_receive          	decimal(13,2) comment "Def(Th): รายได้ดอกเบี้ย(เดือน)รายบัญชีที่ธนาคารรับรู้รายได้แล้ว",
	l01w769_pl_status            	smallint     comment "Def(En): 0=PL, 1=PRL
IF ACCT NPL GRP = 1,2 CLASS_FROM = 0,1  = PL
IF ACCT NPL GRP = 1,2 CLASS_FROM = 2  = PRL",
	l01w769_acct_ofc_rev         	smallint     comment "Def(Th): ผู้ดูแลลูกค้าก่อนหน้า (ผู้ดูแลลูกค้าเดิม)",
	l01w769_eff_date             	integer      comment "Def(Th): ปีเดือนวันที่เงื่อนไขการผ่อนชำระมีผลครั้งแรก",
	l01w769_pay_year             	smallint     comment "Def(Th): ระยะเวลาที่ต้องผ่อนชำระ (เดือน)",
	l01w769_npl_yyyymm           	integer      comment "Def(Th): วันที่เริ่มเป็น NPL ล่าสุด",
	l01w769_pay_maturity         	smallint     ,
	l01w769_fg_draw_down         	smallint     comment "Def(Th): 0 = ใช้วงเงินไม่หมด
1 = ใช้วงเงินหมด",
	l01w769_cust_trade_status    	smallint     comment "Def(Th): สถานะการเป็นลูกค้า Trade",
	l01w769_s_act_tp_sub_lim_port	decimal(15,2) comment "Def(Th): เครื่องหมาย ACTPSLIMP",
	l01w769_acct_tp_sub_lim_port 	decimal(15,2) comment "Def(Th): วงเงินอนุมัติ (ระดับ ACCT-TYPE-SUB)
ที่หักยอดที่ซ้ำออกแล้ว
สามารถนำมารวมได้เป็นวงเงินภาระผูกพันทั้ง Port ของธนาคาร",
	l01w769_sign_exposure_amt    	string       comment "Def(Th): เครื่องหมาย EXPOSAMT",
	l01w769_exposure_amt         	decimal(13,2) comment "Def(Th): ยอด Exposure",
	l01w769_asset_owner          	string       ,
	l01w769_loan_size            	string       comment "Def(Th): จัดขนาดกลุ่มตามช่วงของ exposure",
	l01w769_sign_prin            	string       comment "Def(Th): เครื่องหมาย PRINCIPAL",
	l01w769_principal            	decimal(15,2) comment "Def(Th): ยอดเงินต้น",
	l01w769_segment_group        	string       comment "Def(Th): ประเภทกลุ่มผู้เป็นเจ้าของสินทรัพย์ หรือผู้ดูแล (ฝ่าย นค)",
	l01w769_asset_owner_group    	string       ,
	l01w769_legal_entity         	smallint     comment "Def(Th): รหัสบริษัท",
	l01w769_resp_center          	smallint     comment "Def(Th): รหัสสังกัด",
	l01w769_gl_account           	integer      comment "Def(Th): รหัสบัญชีประเภทเครดิต",
	l01w769_function             	smallint     comment "Def(Th): รหัสฟังก์ชันงาน",
	l01w769_line_business        	smallint     comment "Def(Th): รหัสประเภทธุรกิจ",
	l01w769_gl_product_code      	integer      comment "Def(Th): รหัสผลิตภัณฑ์สำหรับการบันทึกบัญชี",
	l01w769_inter_company        	smallint     comment "Def(Th): รหัสบริษัทในการหักค่าใช้จ่ายระหว่างบริษัทในเครือ",
	l01w769_intra_company        	smallint     comment "Def(Th): รหัสบริษัทในการหักค่าใช้จ่ายระหว่างฝ่ายงาน",
	l01w769_project              	smallint     comment "Def(Th): รหัสโครงการ",
	l01w769_gl_filler1           	integer      comment "Def(Th): สำหรับใช้ในอนาคต",
	l01w769_gl_filler2           	smallint     comment "Def(Th): สำหรับใช้ในอนาคต",
	l01w769_product_code         	integer      comment "Def(Th): รหัสผลิตภัณฑ์",
	load_tms                     	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                   	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                     	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                       	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                       	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_lpm_as400/lpm_as400_ln_cntg_dmmy_clss_prvn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);