-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_mx_report_limit_pse_forint.sql
# Area: mx
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-22    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_MX.MX_REPORT_LIMIT_PSE_FORINT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_mx.mx_report_limit_pse_forint (
	pos_dt         	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	record_type    	smallint     ,
	key            	string       comment "Def(En):Original customer ID
Def(Th):เลขที่บัญชี",
	fullname       	string       comment "Def(En):Original customer name
Def(Th):ชื่อเต็มของบัญชี",
	parent         	string       comment "Def(En):Parent original customer ID for check share limit 
Def(Th):เลขที่บัญชีของ Parent สำหรับตรวจสอบการใช้วงเงินร่วมกัน",
	cis_id         	string       comment "Def(En):Id of involved party
Def(Th):เลขที่ลูกค้า CIS",
	risk           	string       comment "Def(En):Risk level
Def(Th):ระดับความเสี่ยง",
	group          	string       comment "Def(En):Product group code
Def(Th):ประเภทผลิตภัณฑ์",
	pillar         	string       comment "Def(En):Pillar
Def(Th):ระยะเวลาธุรกรรม",
	limit_type     	string       comment "Def(En):Limit type code
Def(Th):ประเภทวงเงิน",
	maxreallocation	string       comment "Def(En):Reallocation and temporary increase/decrease detail
Def(Th):รายละเอียดการเพิ่มหรือลดวงเงินและระยะเวลาธุรกรรม",
	limit_parameter	string       comment "Def(En):Limit Parameter
Def(Th):พารามิเตอร์ที่แสดงว่าอนุมัติวงเงินหรือไม่",
	limit_currency 	string       comment "Def(En):Limit Currency code
Def(Th):สกุลของวงเงินที่อนุมัติ",
	limit_amount   	decimal(24,2) comment "Def(En):Limit Amount
Def(Th):วงเงิน",
	maxexpirydate  	date         comment "Def(En):Expiry date of revolving limit, temporary increase/decrease limit and reallocation limit 
Def(Th):วันที่ครบกำหนดชำระ/วันทบทวน",
	csa_active     	string       comment "Def(En):CSA Active flag
Def(Th):สถานะของ CSA",
	maxcomment     	string       comment "Def(En):Comment field
Def(Th):Remark field ที่เก็บข้อมูลผสม",
	enginedate     	date         comment "Def(En):Source system  date
Def(Th):วันที่ของระบบ source",
	load_tms       	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id     	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy       	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm         	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd         	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_mx/mx_report_limit_pse_forint' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);