-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_mx_src_murx_deal_ar.sql
# Area: mx
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-22    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_MX.MX_SRC_MURX_DEAL_AR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_mx.mx_src_murx_deal_ar (
	pos_dt         	date          comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	rec_type       	smallint      ,
	header3        	integer       ,
	dealref        	string        ,
	package_id     	string        ,
	contract       	decimal(10,0) ,
	nb             	decimal(10,0) ,
	trn_fmly       	string        ,
	trn_grp        	string        ,
	trn_type       	string        ,
	trn_typology   	string        ,
	portfolio      	string        ,
	cisid          	string        ,
	ctpy_short_name	string        ,
	prinamt        	decimal(19,2) ,
	princcy        	string        ,
	tradedate      	integer       ,
	valuedate      	integer       ,
	matdate        	integer       ,
	sbtthb         	decimal(19,2) ,
	intrate        	decimal(19,6) ,
	intbasis       	string        ,
	ai_tdy_day     	decimal(5,0)  ,
	ai_tdy_amt     	decimal(16,2) ,
	ai_mat_day     	decimal(5,0)  ,
	ai_mat_amt     	decimal(16,2) ,
	intamt_ytd     	decimal(19,2) ,
	intamt_mtd     	decimal(19,2) ,
	si_method      	string        ,
	trader         	string        ,
	dealstatus     	string        ,
	dealtype       	string        ,
	buysell        	string        ,
	prem_disc      	decimal(19,2) ,
	ogl_acc        	string        ,
	interest_index 	string        ,
	spread         	decimal(24,11) ,
	notional       	decimal(25,8) ,
	int_pay_freq   	string        ,
	notional_move  	decimal(25,0) ,
	interest_move  	decimal(25,0) ,
	mop_status     	string        ,
	related_deal   	bigint        ,
	load_tms       	timestamp     comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id     	string        comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy       	string        comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm         	string        comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd         	string        comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_mx/mx_src_murx_deal_ar' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);