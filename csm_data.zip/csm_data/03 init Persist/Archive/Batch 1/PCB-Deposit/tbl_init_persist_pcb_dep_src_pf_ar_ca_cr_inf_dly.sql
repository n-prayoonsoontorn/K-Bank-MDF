-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_pcb_dep_src_pf_ar_ca_cr_inf_dly.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-22    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_PCB_DEP.PCB_DEP_SRC_PF_AR_CA_CR_INF_DLY
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_pcb_dep.pcb_dep_src_pf_ar_ca_cr_inf_dly (
	pos_dt             	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	rec_type           	string       comment "Def(En): Record Type - This is to indicate the body record type (Detail record)",
	header3            	string       ,
	accountnumber      	string       ,
	reverseflag        	string       ,
	reversedate        	timestamp    ,
	delinquencyday     	string       ,
	delinquencydate    	timestamp    ,
	penaltyrttype      	string       ,
	penaltyrtsign      	string       ,
	penaltyrtspread    	string       ,
	maxrttype          	string       ,
	maxrtsign          	string       ,
	maxrtspread        	string       ,
	actualintamtinmonth	string       ,
	clearingamt        	string       ,
	legalentity        	string       ,
	responsibilitycode 	string       ,
	function           	string       ,
	linebusiness       	string       ,
	intercompany       	string       ,
	intracompany       	string       ,
	project            	string       ,
	load_tms           	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id         	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy           	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm             	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd             	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_pcb_dep/pcb_dep_src_pf_ar_ca_cr_inf_dly' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);