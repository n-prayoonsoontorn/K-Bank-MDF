-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_rdm_idy_cl_cd.sql
# Area: rdm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-22    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_RDM.RDM_IDY_CL_CD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_rdm.rdm_idy_cl_cd (
	pos_dt                	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	name                  	string       comment "Def(En):Description in Thai
Def(Th):คำอธิบายประเภทธุรกิจภาษาไทย",
	code                  	string       comment "Def(En):Industry Classification Code/ Business Code
Def(Th):รหัสประเภทธุรกิจ",
	name_en_std           	string       comment "Def(En):Description in English (After Approval)
Def(Th):คำอธิบายประเภทธุรกิจภาษาอังกฤษ",
	keyword_std           	string       comment "Def(En): Long Description (After Approval)
Def(Th): รายละเอียด/คำอธิบายแบบยาว",
	idy_cl_sub_grp_cd_name	string       comment "Def(En):Industry Classification Sub Group Name
Def(Th):คำอธิบายกลุ่มอุตสาหกรรมย่อย",
	idy_cl_sub_grp_cd_std 	string       comment "Def(En):Industry Classification Sub Group Code
Def(Th):รหัสกลุ่มอุตสาหกรรมย่อย",
	idy_isic_cd_name      	string       comment "Def(En): Industry ISIC Name",
	idy_isic_cd_std       	string       comment "Def(En): Industry ISIC Code",
	dgtl_cnl_f_std        	string       comment "Def(En): Digital Channel Flag",
	dgtl_dsc_th_std       	string       comment "Def(En): Digital Description Thai",
	dgtl_grp_nm_th_std    	string       comment "Def(En): Digital Group Name Thai",
	dgtl_off_f_std        	string       comment "Def(En): Digital Offline Flag",
	dgtl_off_dsc_th_std   	string       comment "Def(En): Digital Offline Description Thai",
	dgtl_off_grp_nm_th_std	string       comment "Def(En): Digital Offline Group Name Thai",
	dgtl_ol_f_std         	string       comment "Def(En): Digital Online Flag",
	dgtl_ol_dsc_th_std    	string       comment "Def(En): Digital Online Description Thai",
	polcy_rsk_ind_name    	string       comment "Def(En): Policy Risk Indicator Name",
	polcy_rsk_ind_std     	string       comment "Def(En): Policy Risk Indicator Code",
	ol_dspl_seq_std       	decimal(38,0) comment "Def(En): Online Display Sequence",
	off_dspl_seq_std      	decimal(38,0) comment "Def(En): Offline Display Sequence",
	subchn_cd_name        	string       comment "Def(En): Subchain Name
Def(Th): คำอธิบายกลุ่มประเภทธุรกิจระดับ Subchain",
	subchn_cd_std         	string       comment "Def(En): Subchain Code
Def(Th): รหัสกลุ่มประเภทธุรกิจระดับ Subchain",
	modl_inr_tp_name      	string       comment "Def(En): Model Internal Type Name
Def(Th): รหัสคำอธิบายกลุ่มประเภทธุรกิจสำหรับ Model Internal ของธนาคาร",
	modl_inr_tp_std       	string       comment "Def(En): Model Internal Type Code
Def(Th): กลุ่มประเภทธุรกิจสำหรับ Model Internal ของธนาคาร",
	prof_cd_std           	string       comment "Def(En): Profession Code (After Approval)
Def(Th): รหัสสาขาอาชีพ",
	actv_f_name           	string       comment "Def(En):Active Flag
Def(Th):คำอธิบายบ่งชี้สถานะ",
	actv_f_std            	string       comment "Def(En):Active Flag
Def(Th):รหัสบ่งชี้สถานะ",
	load_tms              	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id            	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy              	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_rdm/rdm_idy_cl_cd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);