-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_ud_ka_fundcode.sql
# Area: ud
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-22    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_UD.UD_KA_FUNDCODE
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_ud.ud_ka_fundcode (
	pos_dt                    	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	rectype                   	string       comment "Def(Th): Type of record, this will be detail (D01)",
	fundid                    	string       comment "Def(En): Primary Key of Fund Product of K-Cyber Invest",
	fund_code                 	string       comment "Def(Th): ชื่อย่อ หรือ รหัสกองทุน",
	fund_full_eng_name        	string       comment "Def(Th): ชื่อกองทุน ภาษาอังกฤษ",
	fund_full_thai_name       	string       comment "Def(Th): ชื่อกองทุน ภาษาไทย",
	fund_type                 	string       comment "Def(Th): รหัสประเภทกองทุน (KA ไม่ maintain แล้ว)",
	fund_type_eng_name        	string       comment "Def(Th): ขื่อประเภทกองทุน ภาษาอังกฤษ (KA ไม่ maintain แล้ว)",
	fund_type_thai_name       	string       comment "Def(Th): ชื่อประเภทกองทุน ภาษาไทย (KA ไม่ maintain แล้ว)",
	fund_group_name           	string       comment "Def(Th): ชื่อกลุ่มของกองทุน ยกตัวอย่างเช่น LTF, RMF, SSF, SSFX, Fixed Term, Normal (สำหรับกลุ่มอื่น ๆ ที่นอกเหนือจาก LTF, RMF, SSF, SSFX, Fixed Term)",
	nav                       	decimal(9,4) comment "Def(Th): ค่า NAV ต่อหน่วย",
	nav_date                  	date         comment "Def(Th): วันที่ของค่า NAV",
	fund_period               	string       comment "Def(Th): ระยะเวลาของกองทุน (มีเฉพาะการทุนที่มีอายุโครงการ)",
	risk_level_of_fund        	decimal(3,0) comment "Def(Th): ระดับความเสี่ยงของกองทุน",
	exchange_rate_risk_flag   	string       comment "Def(Th): รหัสแสดงความเสี่ยงของกองทุนในด้านอัตราแลกเปลี่ยน",
	inception_date            	date         comment "Def(Th): วันที่จัดตั้งกองทุน",
	maturity_date             	date         comment "Def(Th): วันที่ครบกำหนดของกองทุน",
	bid                       	decimal(9,4) comment "Def(Th): ราคารับซื้อคืน (Bid) (บาท/หน่วย)",
	offer                     	decimal(9,4) comment "Def(Th): ราคาขาย (Offer) (บาท/หน่วย)",
	fund_size                 	decimal(21,2) comment "Def(Th): มูลค่าทรัพย์สินสุทธิ (Fund Size) (บาท)",
	dividend_policy           	string       comment "Def(Th): จ่ายเงินปันผล (Y/N)",
	initial_purchase_th       	string       comment "Def(Th): มูลค่าขั้นต่ำของการสั่งซื้อครั้งแรก (Thai)",
	initial_purchase_en       	string       comment "Def(Th): มูลค่าขั้นต่ำของการสั่งซื้อครั้งแรก (Eng)",
	min_purchase_th           	string       comment "Def(Th): มูลค่าขั้นต่ำของการสั่งซื้อครั้งถัดไป (Thai)",
	min_purchase_en           	string       comment "Def(Th): มูลค่าขั้นต่ำของการสั่งซื้อครั้งถัดไป (Eng)",
	investment_policy_th_full 	string       comment "Def(Th): นโยบายการลงทุน (Thai) - Full",
	investment_policy_en_full 	string       comment "Def(Th): นโยบายการลงทุน (Eng) - Full",
	start_ipo_date            	date         comment "Def(Th): วันเสนอขาย วันแรก",
	end_ipo_date              	date         comment "Def(Th): วันเสนอขาย วันสุดท้าย",
	fund_objective_type_th    	string       comment "Def(Th): ประเภทกองทุนตามวัตถุประสงค์ (Thai)",
	fund_objective_type_en    	string       comment "Def(Th): ประเภทกองทุนตามวัตถุประสงค์ (Eng)",
	flag_ship_flag            	string       comment "Def(Th): กองทุนที่แนะนำ หรือไม่",
	recommend_flag            	string       comment "Def(Th): กองทุนที่เหมาะสม หรือไม่",
	investment_policy_th_short	string       comment "Def(Th): นโยบายการลงทุน (Thai) - Short",
	investment_policy_en_short	string       comment "Def(Th): นโยบายการลงทุน (Eng) - Short",
	issuer_high_concentration 	string       comment "Def(Th): ลงทุนกระจุกตัวรายผู้ออก หรือไม่",
	sector_high_concentration 	string       comment "Def(Th): ลงทุนกระจุกตัวรายหมวดอุตสาหกรรม หรือไม่",
	country_high_concentration	string       comment "Def(Th): ลงทุนกระจุกตัวรายประเทศ หรือไม่",
	fund_objective_type       	string       comment "Def(Th): ประเภทกองทุนตามวัตถุประสงค์",
	asset_type                	string       comment "Def(Th): Asset Class กองทุนตามสินทรัพย์ - Code",
	asset_type_th             	string       comment "Def(Th): Asset Class กองทุนตามสินทรัพย์ - DescriptionTH",
	asset_type_en             	string       comment "Def(Th): Asset Class กองทุนตามสินทรัพย์ - DescriptionEng",
	subscription_end_time     	string       comment "Def(Th): ระยะเวลาปิดรับคำสั่งซื้อ",
	redemption_end_time       	string       comment "Def(Th): ระยะเวลาปิดรับคำสั่งขาย",
	settlement_period         	string       comment "Def(Th): ระยะเวลารับเงินค่าขายคืน",
	front_end_fee_th          	string       comment "Def(Th): ค่าธรรมเนียมซื้อ จำนวน พร้อมหน่วย - TH",
	front_end_fee_en          	string       comment "Def(Th): ค่าธรรมเนียมซื้อ จำนวน พร้อมหน่วย - Eng",
	exit_fee_th               	string       comment "Def(Th): ค่าธรรมเนียมขาย จำนวน พร้อมหน่วย - TH",
	exit_fee_en               	string       comment "Def(Th): ค่าธรรมเนียมขาย จำนวน พร้อมหน่วย - Eng",
	brokerage_in_fee_th       	string       comment "Def(Th): ค่าธรรมเนียมซื้อหลักทรัพย์ขาเข้า จำนวน พร้อมหน่วย - TH",
	brokerage_in_fee_en       	string       comment "Def(Th): ค่าธรรมเนียมซื้อหลักทรัพย์ขาเข้า จำนวน พร้อมหน่วย - Eng",
	brokerage_out_fee_th      	string       comment "Def(Th): ค่าธรรมเนียมซื้อหลักทรัพย์ขาออก จำนวน พร้อมหน่วย - TH",
	brokerage_out_fee_en      	string       comment "Def(Th): ค่าธรรมเนียมซื้อหลักทรัพย์ขาออก จำนวน พร้อมหน่วย - Eng",
	minimum_redemption_th     	string       comment "Def(Th): มูลค่าขั้นต่ำของการขายคืน - TH",
	minimum_redemption_en     	string       comment "Def(Th): มูลค่าขั้นต่ำของการขายคืน - ENG",
	fund_obj_desc_general_th  	string       comment "Def(Th): คำอธิบายทั่วไป ประเภทกองทุนตามวัตถุประสงค์ (Thai)",
	fund_obj_desc_general_en  	string       comment "Def(Th): คำอธิบายทั่วไป ประเภทกองทุนตามวัตถุประสงค์ (Eng)",
	fund_desc_th              	string       comment "Def(Th): คำโปรยของกองทุนแนะนำ (Thai)",
	fund_desc_en              	string       comment "Def(Th): คำโปรยของกองทุนแนะนำ (Eng)",
	sec_special_desc_th       	string       comment "Def(Th): คำเตือน กลต. (Thai)",
	sec_special_desc_en       	string       comment "Def(Th): คำเตือน กลต. (Eng)",
	ka_special_desc_th        	string       comment "Def(Th): คำเตือน KA (Thai)",
	ka_special_desc_en        	string       comment "Def(Th): คำเตือน KA (Eng)",
	morningstar               	string       comment "Def(Th): Morning star Rating",
	isshow_mornigstar         	string       comment "Def(Th): แสดง icon Morning star",
	best_seller               	smallint     comment "Def(Th): Score กองทุนขายดี",
	dividend_policy_th        	string       comment "Def(Th): รายละเอียดการพิจารณาจ่ายปันผล (TH)",
	dividend_policy_en        	string       comment "Def(Th): รายละเอียดการพิจารณาจ่ายปันผล (EN)",
	sec_fund_type_th          	string       comment "Def(Th): ประเภทกองทุนรวม / กลุ่มกองทุนรวม (TH)",
	sec_fund_type_en          	string       comment "Def(Th): ประเภทกองทุนรวม / กลุ่มกองทุนรวม (EN)",
	masterfund_name_th        	string       comment "Def(Th): ชื่อกองทุน กองทุนหลัก (TH)",
	masterfund_name_en        	string       comment "Def(Th): ชื่อกองทุน กองทุนหลัก (EN)",
	masterfund_link_url       	string       comment "Def(Th): URL กองทุนหลัก",
	masterfund_isincode       	string       comment "Def(Th): ISIN Code กองทุนหลัก",
	masterfund_bloombergcode  	string       comment "Def(Th): Bloomberg Code กองทุน",
	subscription_date_time_th 	string       comment "Def(Th): วัน - เวลา ทำการซื้อ (TH)",
	subscription_date_time_en 	string       comment "Def(Th): วัน - เวลา ทำการซื้อ (EN)",
	redemption_date_time_th   	string       comment "Def(Th): วัน - เวลา ทำการขายคืน (TH)",
	redemption_date_time_en   	string       comment "Def(Th): วัน - เวลา ทำการขายคืน (EN)",
	settlement_other_th       	string       comment "Def(Th): วันที่ประกาศ NAV / ระยะเวลาการรับเงินค่าขายคืน (TH)",
	settlement_other_en       	string       comment "Def(Th): วันที่ประกาศ NAV / ระยะเวลาการรับเงินค่าขายคืน (EN)",
	management_fee_th         	string       comment "Def(Th): ค่าธรรมเนียมการจัดการ (TH)",
	management_fee_en         	string       comment "Def(Th): ค่าธรรมเนียมการจัดการ (EN)",
	mutualfund_fees_remark_th 	string       comment "Def(Th): หมายเหตุ ค่าธรรมเนียมที่เรียกเก็บจากกองทุนรวม (TH)",
	mutualfund_fees_remark_en 	string       comment "Def(Th): หมายเหตุ ค่าธรรมเนียมที่เรียกเก็บจากกองทุนรวม (EN)",
	unitholder_fees_remark_th 	string       comment "Def(Th): หมายเหตุ ค่าธรรมเนียมที่เรียกเก็บจากผู้ถือหน่วย (TH)",
	unitholder_fees_remark_en 	string       comment "Def(Th): หมายเหตุ ค่าธรรมเนียมที่เรียกเก็บจากผู้ถือหน่วย (EN)",
	fundmaturityinfo          	string       comment "Def(Th): อายุโครงการ",
	startinvestdate           	date         comment "Def(Th): วันเริ่มการลงทุน",
	redemptiondate            	date         comment "Def(Th): วันครบกำหนด/รับซื้อคืนกองทุน",
	investmentperiod          	integer      comment "Def(Th): ระยะเวลาที่ลงทุน",
	fundreturnsapprox         	string       comment "Def(Th): ผลตอบแทนโดยประมาณต่อปี",
	load_tms                  	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_ud/ud_ka_fundcode' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);