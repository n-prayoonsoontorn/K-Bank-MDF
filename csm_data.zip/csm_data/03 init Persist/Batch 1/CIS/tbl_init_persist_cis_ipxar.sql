-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cis_ipxar.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-05    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CIS.CIS_IPXAR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cis.cis_ipxar (
	pos_dt      	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	method      	string       comment "Def(En): Ingestion Method
Def(Th): วิธีการนำเข้า",
	ipar__ip_id 	bigint       comment "Def(En): Customer id
Def(Th): เลขที่ลูกค้า",
	ipar_ar_id  	bigint       comment "Def(En): Arrangement id
Def(Th): เลขที่ arrangement",
	ipar_rel_tp 	string       comment "Def(En): Customer and Arrangement Relationship Type
Def(Th): รหัสประเภทความสัมพันธ์ของลูกค้ากับ arrangement",
	ipar_stat   	string       comment "Def(En): Arrangement Status code
Def(Th): รหัสสถานะของ arrangement",
	ipar_eft_dt 	date         comment "Def(En): Arrangement Begin date
Def(Th): วันที่เริ่มผูกหรือเปลี่ยนความสัมพันธ์",
	ipar_exp_dt 	date         comment "Def(En): Arrangement End date
Def(Th): วันที่ยกเลิกความสัมพันธ์",
	ipar_user_id	string       comment "Def(En): User id
Def(Th): รหัสผู้ทำรายการ",
	ipar_upd_dt 	timestamp    comment "Def(En): Update date time
Def(Th): วันและเวลาที่ทำรายการ",
	load_tms    	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id  	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy    	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm      	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd      	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cis/cis_ipxar' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);