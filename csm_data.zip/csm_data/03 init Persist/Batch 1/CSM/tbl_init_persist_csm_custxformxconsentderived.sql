-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_csm_custxformxconsentderived.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-07    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CSM.CSM_CUSTXFORMXCONSENTDERIVED
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_csm.csm_custxformxconsentderived (
	pos_dt               	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	custfcdr_cust_id     	smallint     comment "Def(En): Cust ID (CIS ID)
Def(Th): เลขที่ลูกค้า (CIS ID)",
	custfcdr_formappr_cd 	string       comment "Def(En): Form APPR ID
Def(Th): รหัสของวัตถุประสงค์ของฟอร์มสำหรับใส่ระดับ derived",
	custfcdr_consent_flag	string       comment "Def(En):Consent flag
Def(Th):ค่า consent ที่ลูกค้าให้",
	custfcdr_upd_user    	string       comment "Def(En):Update by UserID
Def(Th):User ที่แก้ไขข้อมูล",
	custfcdr_upd_dt      	timestamp    comment "Def(En):Update date
Def(Th):วันที่อัพเดทข้อมูล",
	load_tms             	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id           	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy             	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm               	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd               	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน",
	upd_tms              	timestamp    comment "Def(En): Partition field - Record update timestamp
Def(Th):"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_csm/csm_custxformxconsentderived' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);