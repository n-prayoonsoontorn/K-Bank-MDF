-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_csm_formconsent.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-06    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CSM.CSM_FORMCONSENT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_csm.csm_formconsent (
	pos_dt                 	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	form_id                	bigint       comment "Def(En): Form ID
Def(Th): เลขที่ Form",
	form_abbr              	string       comment "Def(En): Form Abbreviation name
Def(Th): ชื่อย่อฟอร์ม",
	form_status            	string       comment "Def(En): Form Status
Def(Th): สถานะของฟอร์ม",
	form_progress          	string       comment "Def(En): Form progress
Def(Th): สถานะขั้นตอนของฟอร์ม",
	form_create_date       	date         comment "Def(En): Form create date
Def(Th): วันที่สร้างฟอร์ม",
	form_expire_date       	date         comment "Def(En): Form expired date
Def(Th): วันที่ยกเลิกใช้ฟอร์ม",
	form_renew_option      	string       comment "Def(En): Form renew option
Def(Th): สถานะการขอ consent จากลูกค้า",
	form_controller        	smallint     comment "Def(En): Form controller
Def(Th): บริษัทที่เก็บรวบรวม consent ของลูกค้า",
	form_appr_group        	smallint     comment "Def(En): Form APPR group
Def(Th): เลขที่ group วัตถุประสงค์ของฟอร์ม",
	form_display_level     	string       comment "Def(En): Form display level
Def(Th): ชื่อบริษัทหรือประเภทบริษัทที่ต้องการแสดง (receiver or receiver type)",
	form_display_sequence  	bigint       comment "Def(En): Form display sequence
Def(Th): ลำดับการแสดงฟอร์ม",
	form_maintain_by_kb_flg	string       comment "Def(En): Form maintain flag
Def(Th): สถานะการให้แก้ไขค่า consent ของฟอร์ม",
	form_upd_user          	string       comment "Def(En):Update by UserID
Def(Th):user ที่แก้ไขข้อมูล",
	form_upd_dt            	timestamp    comment "Def(En):Update date
Def(Th):วันที่อัพเดทข้อมูล",
	form_useract_cd        	string       comment "Def(En): User action code
Def(Th): รหัสเลขที่ action ที่บอกให้ทาง user ทราบว่าต้อง action เรื่อง consent อย่างไรกับลูกค้า",
	form_partner_group     	string       comment "Def(En): Form partner group
Def(Th): กลุ่มของฟอร์มแบบ partner เพื่อให้ front-end นำไปจัดกลุ่มได้",
	form_inactive_flag     	string       comment "Def(En): Form inactive flag
Def(Th): สถานะของฟอร์มว่าเป็นการยกเลิกฟอร์มแบบโมฆะหรือไม่",
	load_tms               	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id             	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy               	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                 	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                 	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_csm/csm_formconsent' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);