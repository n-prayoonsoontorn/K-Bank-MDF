-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_lec_lecp_lec3d18.sql
# Area: lec
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-04    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_LEC.LEC_LECP_LEC3D18
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_lec.lec_lecp_lec3d18 (
	pos_dt             	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	lec3d18_cust_no    	bigint       comment "Def(En):
Def(Th): เลขที่ลูกหนี้",
	lec3d18_legal_sub  	smallint     comment "Def(En):
Def(Th): ประเภทคดี",
	lec3d18_legal_dept 	smallint     comment "Def(En):
Def(Th): คดีลำดับที่",
	lec3d18_acct_no    	string       comment "Def(En):
Def(Th): เลขที่บัญชี",
	lec3d18_acct_type  	smallint     comment "Def(En):
Def(Th): ประเภทบัญชี",
	lec3d18_enter_date 	date         comment "Def(En):
Def(Th): วันที่บันทึก",
	lec3d18_acquit_flag	smallint     comment "Def(En):
Def(Th): สถานะการฟ้องของบัญชี",
	load_tms           	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id         	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy           	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm             	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd             	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_lec/lec_lecp_lec3d18' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);