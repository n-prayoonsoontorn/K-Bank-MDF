-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_pcb_dep_cls500029.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-04    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_PCB_DEP.PCB_DEP_CLS500029
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_pcb_dep.pcb_dep_cls500029 (
	pos_dt      	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	cl_scm_tp_id	string       comment "Def(En):Classification Scheme Type Id
Def(Th):",
	cl_scm_id   	string       comment "Def(En):Classification Scheme Id
Def(Th):",
	cl_id       	string       comment "Def(En):Classification Id
Def(Th):",
	eff_dt      	date         comment "Def(En):Effective Date
Def(Th):",
	prn_cl_id   	string       comment "Def(En):Parent Classification Id
Def(Th):",
	cl_nm_eng   	string       comment "Def(En):English Classification Name
Def(Th):",
	cl_nm_th    	string       comment "Def(En):Thai Classification Name
Def(Th):",
	cl_nm_used  	string       comment "Def(En):Name used for Classification
Def(Th):",
	sort_seq    	string       comment "Def(En):Sort Sequence
Def(Th):",
	arthm_opr   	string       comment "Def(En):Arithmetic Operator
Def(Th):",
	own         	string       comment "Def(En):Owner
Def(Th):",
	end_dt      	date         comment "Def(En):End Date
Def(Th):",
	mn_rng      	string       comment "Def(En):Minimum Range
Def(Th):",
	mx_rng      	string       comment "Def(En):Maximum Range
Def(Th):",
	load_tms    	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id  	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy    	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm      	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd      	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_pcb_dep/pcb_dep_cls500029' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);