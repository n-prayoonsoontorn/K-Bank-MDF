-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_rdm_cst_ip_lgl_stc_tp_cd.sql
# Area: rdm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-04    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_RDM.RDM_CST_IP_LGL_STC_TP_CD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_rdm.rdm_cst_ip_lgl_stc_tp_cd (
	pos_dt          	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	ip_lgl_stc_tp_cd	string       comment "Def(En):Code that refer to involved party legal structure type
Def(Th):รหัสบุคคล/นิติบุคคล",
	ip_tp_cd_code   	string       comment "Def(En):Code of involved party type  Code
Def(Th):รหัสประเภทลูกค้า",
	ip_tp_cd_name   	string       comment "Def(En):Code of involved party type Name
Def(Th):คำอธิบายรหัสประเภทลูกค้า",
	dsc_th          	string       comment "Def(En): Description in Thai
Def(Th): คำอธิบายรหัสบุคคล/นิติบุคคลภาษาไทย",
	dsc_en          	string       comment "Def(En): Description in English
Def(Th): คำอธิบายรหัสบุคคล/นิติบุคคลภาษาอังกฤษ",
	enterdatetime   	timestamp    comment "Def(En):Enter Date time
Def(Th):วันที่ใส่ข้อมูล",
	enterusername   	string       comment "Def(En):Enter User Name
Def(Th):ผู้ใส่ข้อมูล",
	lastchgdatetime 	timestamp    comment "Def(En):Update Date
Def(Th):วันที่อัพเดทข้อมูล",
	lastchgusername 	string       comment "Def(En):Update User Name
Def(Th):ผู้อัพเดทข้อมูล",
	load_tms        	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id      	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy        	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm          	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd          	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_rdm/rdm_cst_ip_lgl_stc_tp_cd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);