-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_rdm_pim_coa_pd.sql
# Area: rdm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-04    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_RDM.RDM_PIM_COA_PD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_rdm.rdm_pim_coa_pd (
	pos_dt           	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	pd_ftr_cd        	string       comment "Def(En): COA Product Feature Code
Def(Th): รหัสผลิตภัณฑ์",
	pd_ftr_dsc_en    	string       comment "Def(En): COA Product Name English
Def(Th): ชื่อผลิตภัณฑ์ภาษาอังกฤษ",
	pd_ftr_dsc_th    	string       comment "Def(En): COA Product Name Thai
Def(Th): ชื่อผลิตภัณฑ์ภาษาไทย",
	cmas_f           	string       comment "Def(En): CMAS Flag
Def(Th): ตัวบ่งชี้เพื่อแสดงสถานะว่ามีการใช้งานร่วมกับ CMAS หรือไม่",
	pd_line          	string       comment "Def(En): Product Line to represent COA Main Product Group
Def(Th): สายของผลิตภัณฑ์ เช่น เงินฝาก หรือ เงินกู้",
	pd_line_dsc_en   	string       comment "Def(En): Product Line Description in English
Def(Th): ชื่อสายของผลิตภัณฑ์ ภาษาอังกฤษ ซึ่งแสดงชื่อกลุ่มผลิตภัณฑ์หลัก",
	pd_grp_cd        	string       comment "Def(En): COA Product Group Code
Def(Th): รหัสกลุ่มผลิตภัณฑ์",
	pd_grp_dsc_en    	string       comment "Def(En): COA Product Group English
Def(Th): ชื่อกลุ่มผลิตภัณฑ์ ภาษาอังกฤษ",
	pd_sub_grp_cd    	string       comment "Def(En): COA Product sub-Group Code
Def(Th): รหัสกลุ่มผลิตภัณฑ์ย่อย",
	pd_sub_grp_dsc_en	string       comment "Def(En): COA Product sub-Group English
Def(Th): ชื่อกลุ่มผลิตภัณฑ์ย่อย ภาษาอังกฤษ",
	pd_cd            	string       comment "Def(En): COA Product in GL Code
Def(Th): รหัสผลิตภัณฑ์ตามหัวบัญชี",
	pd_dsc_en        	string       comment "Def(En): COA Product in GL English
Def(Th): ชื่อผลิตภัณฑ์ตามหัวบัญชี ภาษาอังกฤษ",
	pd_st_nm         	string       comment "Def(En): Product Status Code
Def(Th): สถานะของผลิตภัณฑ์",
	pbls_tms         	timestamp    comment "Def(En): Publish Date
Def(Th): วันที่ประกาศใช้ข้อมูล",
	load_tms         	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id       	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy         	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm           	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd           	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_rdm/rdm_pim_coa_pd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);