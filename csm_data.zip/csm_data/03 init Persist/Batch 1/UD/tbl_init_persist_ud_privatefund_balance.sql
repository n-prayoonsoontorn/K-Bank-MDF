-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_ud_privatefund_balance.sql
# Area: ud
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-04    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_UD.UD_PRIVATEFUND_BALANCE
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_ud.ud_privatefund_balance (
	pos_dt    	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt	date         comment "Def(En): Position Date
Def(Th): ยอดวันที่",
	ident_no  	string       comment "Def(En): Identify customer number
Def(Th): เลขที่บัตรประชาชน, เลขที่ passport ของผู้ถือหลักทรัพย์ ๆลๆ",
	otsnd_bal 	decimal(21,2) comment "Def(En):  Balance
Def(Th): ยอดคงเหลือของ Private fund",
	db_ac_no  	string       comment "Def(En):  Settlement account no (Debit)
Def(Th):  บัญชีชำระเงินของลูกค้า ที่ใช้ในการลงทุนโดย KA",
	ka_cst_no 	string       comment "Def(En):  PI number (private fund id) 
Def(Th):  ตัวเลขระบุกอง Private fund ของ KA (PI number)",
	doc_itm_cd	string       comment "Def(En):Code to identify type of document 
Def(Th):ประเภทเอกสารสำคัญ เช่น บัตรประชาชน, หนังสือเดินทาง",
	pv_type   	string       comment "Def(En):  Private Fund Type
Def(Th):",
	cont_dt   	date         comment "Def(En): Contract Date
Def(Th): วันเริ่มต้นสัญญา",
	load_tms  	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_ud/ud_privatefund_balance' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);