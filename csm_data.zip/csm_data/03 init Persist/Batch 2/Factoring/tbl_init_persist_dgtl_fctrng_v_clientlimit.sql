-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_dgtl_fctrng_v_clientlimit.sql
# Area: dgtl_fctrng
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_DGTL_FCTRNG.DGTL_FCTRNG_V_CLIENTLIMIT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_dgtl_fctrng.dgtl_fctrng_v_clientlimit (
	pos_dt    	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	clientcode	string       comment "Def(En): Limit Number
Def(Th):",
	seq       	integer      comment "Def(En): running (within ClientCode & StartDate)
Def(Th):",
	limittype 	string       comment "Def(En):
Def(Th): ประเภทวงเงิน
M=Main Credit
T=Temp Credit",
	startdate 	date         comment "Def(En): Effective from Date
Def(Th):",
	enddate   	date         comment "Def(En): Effective to Date
Def(Th):",
	crlimit   	decimal(18,2) comment "Def(En): Credit Limit/Temp Limit
Def(Th):",
	reason    	string       comment "Def(En):
Def(Th): เหตุผลการอนุมัติ มีค่าตาม Reason.Reason
(ScreenCode =  'S310')",
	reasontxt 	string       comment "Def(En): Remark
Def(Th):",
	load_tms  	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_dgtl_fctrng/dgtl_fctrng_v_clientlimit' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);