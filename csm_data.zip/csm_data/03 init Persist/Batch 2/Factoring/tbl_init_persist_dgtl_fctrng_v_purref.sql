-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_dgtl_fctrng_v_purref.sql
# Area: dgtl_fctrng
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_DGTL_FCTRNG.DGTL_FCTRNG_V_PURREF
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_dgtl_fctrng.dgtl_fctrng_v_purref (
	pos_dt    	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	purrefno  	string       comment "Def(En): KF Number
Def(Th):",
	purno     	string       comment "Def(En): Schdule#
Def(Th):",
	clientcode	string       comment "Def(En): Limit Number
Def(Th):",
	debtorcode	string       comment "Def(En): Customer Factor ID
Def(Th):",
	trnsdate  	date         comment "Def(En): Sehedule Date
Def(Th):",
	docdate   	date         comment "Def(En): Invoice Date
Def(Th):",
	currency  	string       comment "Def(En): Currency
refer to CurrencyCode
Def(Th):",
	facfeeamt 	decimal(17,2) comment "Def(En):
Def(Th): ค่าธรรมเนียม",
	facfeewht 	decimal(17,2) comment "Def(En):
Def(Th): ค่าธรรมเนียม WHT",
	classlevel	smallint     comment "Def(En):
Def(Th): Class level รับมาจาก LPM",
	load_tms  	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_dgtl_fctrng/dgtl_fctrng_v_purref' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);