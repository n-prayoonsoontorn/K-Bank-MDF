-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_kplus_view_balancealertreglog_log.sql
# Area: kplus
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_KPLUS.KPLUS_VIEW_BALANCEALERTREGLOG_LOG
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_kplus.kplus_view_balancealertreglog_log (
	pos_dt             	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	id                 	string       comment "Def(En): Transaction ID
Def(Th): รหัสการทำรายการ",
	actiondatetime     	timestamp    comment "Def(En): Transaction date and time
Def(Th): วันที่การทำรายการ",
	mobileoperator     	string       comment "Def(En): Mobile operator
Def(Th): เครือข่ายโทรศัพท์",
	accountno          	string       comment "Def(En): Account number
Def(Th): หมายเลขบัญชี",
	registrationchannel	string       comment "Def(En):
Def(Th): ช่องทางการทำรายการ",
	alertchannel       	string       comment "Def(En):
Def(Th): ช่องทางการแจ้งเตือนไปยังลูกค้า",
	trantype           	string       comment "Def(En): Transaction type
Def(Th): ประเภทการทำรายการ",
	username           	string       comment "Def(En):
Def(Th): Username ของผู้ทำรายการหรือหมายเลขตู้ ATM",
	changedvalues      	string       comment "Def(En):
Def(Th): ข้อมูลที่มีการแก้ไข (ปัจจุบันไม่ได้ใช้งาน)",
	defaultvalues      	string       comment "Def(En):
Def(Th): XML แสดงรายละเอียดข้อมูลทำรายการ",
	status             	string       comment "Def(En): Status
Def(Th): สถานะการทำงาน",
	remark             	string       comment "Def(En): Remark
Def(Th): รายละเอียดเพิ่มเติมอื่นๆ",
	reason             	string       comment "Def(En): Reason
Def(Th): รายละเอียดเพิ่มเติมอื่นๆ",
	refid              	string       comment "Def(En): Reference ID
Def(Th): รหัสอ้างอิงสำหรับติดต่อ Back-end",
	email              	string       comment "Def(En): Email
Def(Th):",
	mobilephone        	string       comment "Def(En): Mobile number
Def(Th): หมายเลขโทรศัพท์",
	isfirsttime        	string       comment "Def(En): 
Def(Th): ทำการแก้ไขครั้งแรกหรือไม่ (ปัจจุบันไม่ได้ใช้งาน)",
	packageno          	string       comment "Def(Th): Package การใช้งาน
1: Balance change alert
3: Transaction alert",
	location           	string       comment "Def(En): Service branch / ATM ID
Def(Th): รหัสสาขาสำหรับกรณีทำรายการผ่านสาขา หรือรหัสตู้ ATM",
	load_tms           	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id         	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy           	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm             	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd             	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_kplus/kplus_view_balancealertreglog_log' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);