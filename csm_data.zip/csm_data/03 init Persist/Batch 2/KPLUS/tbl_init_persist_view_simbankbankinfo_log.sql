-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_view_simbankbankinfo_log.sql
# Area: kplus
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_KPLUS.VIEW_SIMBANKBANKINFO_LOG
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_kplus.view_simbankbankinfo_log (
	pos_dt          	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt      	timestamp    comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	bnk_id          	string       comment "Def(En): 
Def(Th): รหัสธนาคาร",
	th_bnk_nm       	string       comment "Def(En): 
Def(Th): ชื่อธนาคารภาษาไทย",
	en_bnk_nm       	string       comment "Def(En): 
Def(Th): ชื่อธนาคารภาษาอังกฤษ",
	th_bnk_shrt_nm  	string       comment "Def(En): 
Def(Th): ชื่อย่อธนาคารภาษาไทย",
	en_bnk_shrt_nm  	string       comment "Def(En): 
Def(Th): ชื่อย่อธนาคารภาษาอังกฤษ",
	tfr_tp_cd       	string       comment "Def(En): 
Def(Th): ประเภทการทำรายการ",
	orft_bnk_cd     	string       comment "Def(En): 
Def(Th): รหัสธนาคารต่างธนาคาร",
	orft_bnk_abr_nm 	string       comment "Def(En): 
Def(Th): ชือย่อธนาคารต่างธนาคาร",
	atm_sim_actv_f  	string       comment "Def(En): 
Def(Th): สถานะ (ใช้ สำหรับ ATM SIM)",
	th_bnk_long_nm  	string       comment "Def(En): 
Def(Th): ชื่อเต็มธนาคารภาษาอังกฤษ",
	en_bnk_long_nm  	string       comment "Def(En): 
Def(Th): ชื่อเต็มธนาคารภาษาไทย",
	sort_th_id      	string       comment "Def(En):
Def(Th):",
	sort_en_id      	string       comment "Def(En):
Def(Th):",
	th_bnk_full_nm  	string       comment "Def(En): 
Def(Th): ชื่อเต็มธนาคารภาษาไทย",
	en_bnk_full_nm  	string       comment "Def(En): 
Def(Th): ชื่อเต็มธนาคารภาษาอังกฤษ",
	mb_plus_actv_f  	string       comment "Def(En): 
Def(Th): สถานะแสดงการจ่ายเงินผ่านระบบ K-Mobile Banking PLUS",
	ppn_tms         	timestamp    comment "Def(En):The timestamp on which the instance of the entity was last updated.
Def(Th):วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_stm_id      	smallint     comment "Def(En): Source System Code
Def(Th):เลขที่แสดงระบบงาน",
	load_tms        	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id      	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy        	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm          	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd          	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_kplus/view_simbankbankinfo_log' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);