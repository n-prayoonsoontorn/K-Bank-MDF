-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_lpm_as400_lpm_x_ip_rel.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-04    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_LPM_AS400.LPM_AS400_LPM_X_IP_REL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_lpm_as400.lpm_as400_lpm_x_ip_rel (
	pos_dt       	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	lpm_id       	decimal(10,0) comment "Def(En): The number represents customer in LPM system. 
Def(Th): เลขที่ลูกหนี้ในระบบ LPM",
	vld_fm_dt    	timestamp    comment "Def(En): Version valid until
Def(Th): วันที่ระบบเปลี่ยนแปลงข้อมูล",
	ip_id        	bigint       comment "Def(En): Id of involved party
Def(Th): เลขที่ลูกค้า",
	ar_own_tp_cd 	bigint       comment "Def(En): Type Code of ownership account. 
Def(Th): รหัสระบุชนิดของบัญชี",
	crt_by       	string       comment "Def(En): The user that create record in the system.
Def(Th): User Login ที่บันทึกข้อมูล",
	crt_dt       	date         comment "Def(En): The timestamp that create information.
Def(Th): วันที่และเวลาที่บันทึกข้อมูล",
	upd_by       	string       comment "Def(En): The user that update record in the system.
Def(Th): User Login ที่แก้ไขข้อมูลล่าสุด",
	upd_dt       	date         comment "Def(En): The timestamp that update information.
Def(Th): วันที่และเวลาที่อัพเดตข้อมูล",
	ip_perf_st_cd	string       comment "Def(En): Code of involved party performance status that identify customer is good customer or bad customer
Def(Th): เป็นลูกค้าไม่ดีหรือไม่",
	prty_ip_id   	bigint       comment "Def(En): Priority id of involved party
Def(Th): เลขที่ลูกค้าในระบบ CIS ที่ผู้ใช้ข้อมูลให้ความสำคัญในกรณีกู้ร่วม",
	last_vrsn_f  	integer      comment "Def(En): Flag to inidcate latest version
Def(Th): Flag แสดง record ล่าสุดในระบบ",
	vld_to_dt    	timestamp    comment "Def(En): Version valid until
Def(Th): วันที่สุดท้ายที่ระบบเปลี่ยนแปลงข้อมูล",
	load_tms     	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id   	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy     	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm       	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd       	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน",
	upd_tms      	timestamp    comment "Def(En): Partition field - Record update timestamp"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_lpm_as400/lpm_as400_lpm_x_ip_rel' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);