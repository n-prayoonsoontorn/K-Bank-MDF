-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_gts_dbttnrel.sql
# Area: gts
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_GTS.GTS_DBTTNREL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_gts.gts_dbttnrel (
	pos_dt       	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	ref1st       	string       comment "Def(En): New Reference No of TradeNa
Def(Th): เลขที่ตั๋วใหม่",
	ref2nd       	string       comment "Def(En): Old Reference No of TradeNa 
Def(Th): เลขที่ตั๋วเก่า",
	limit_id_l2l3	string       comment "Def(En): Limit ID at Level 2 or 3 (ถ้าไม่มีวงเงินของ Level 2 ให้ส่ง Level 3)
Def(Th):",
	limit_id_l6  	string       comment "Def(En): Limit ID at Level 6
Def(Th):",
	load_tms     	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id   	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy     	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm       	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd       	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_gts/gts_dbttnrel' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);