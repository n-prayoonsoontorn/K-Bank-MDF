-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_targettablename.sql
# Area: gts
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_GTS.TARGETTABLENAME
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_gts.targettablename (
	pos_dt         	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	cis_id         	string       comment "Def(En): CIS Number
Def(Th):",
	limit_no_l4    	string       comment "Def(En):
Def(Th):Bank Trade Limit No at Level 3
จะมีค่าต่อเมื่อวงเงิน Trade Na ถูก migrate ไปที่ Bank Trade เท่านั้น",
	limit_no_l6    	string       comment "Def(En): 
Def(Th): Bank Trade Limit No at Level 4
จะมีค่าต่อเมื่อวงเงิน Trade Na ถูก migrate ไปที่ Bank Trade เท่านั้น",
	limit_l4_status	string       comment "Def(En):
Def(Th):",
	limit_l6_status	string       comment "Def(En):
Def(Th):",
	load_tms       	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id     	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy       	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm         	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd         	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_gts/targettablename' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);