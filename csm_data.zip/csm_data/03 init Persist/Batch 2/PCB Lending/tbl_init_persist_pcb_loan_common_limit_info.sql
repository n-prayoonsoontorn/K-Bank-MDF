-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_pcb_loan_common_limit_info.sql
# Area: pcb_loan
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_PCB_LOAN.PCB_LOAN_COMMON_LIMIT_INFO
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_pcb_loan.pcb_loan_common_limit_info (
	pos_dt             	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	lmt_ac_ar_id       	string       comment "Def(En): Limit Account Number (Limit Level)
Def(Th):",
	prfl_ac_ar_id      	string       comment "Def(En): Profile Account Number
Def(Th):",
	root_ac_ar_id      	string       comment "Def(En): Root Commitment Account ID
Def(Th):",
	ar_nm_th           	string       comment "Def(En): Limit Thai Name
Def(Th):",
	ar_nm_eng          	string       comment "Def(En): Limit Eng Name
Def(Th):",
	cst_typ_id         	string       comment "Def(En): Customer Type ID
Def(Th):",
	bsn_code_id        	string       comment "Def(En): Kbank Business code
Def(Th):",
	loan_pps_typ_id    	string       comment "Def(En): Loan purpose type ID
Def(Th):",
	ctr_dt             	date         comment "Def(En): Account Limit Contract date 
Def(Th):",
	eff_dt             	date         comment "Def(En): Effective Date (EffDt**)
Def(Th):",
	lmt_end_dt         	date         comment "Def(En): Limit Maturity Date
Def(Th):",
	ac_sts_id          	string       comment "Def(En): Account status ID
Def(Th):",
	cls_dt             	date         comment "Def(En): Close Date 
Def(Th):",
	lmt_lvl            	smallint     comment "Def(En):
Def(Th): ระดับวงเงิน
1: Commitment level
2: Sub Commitment 
level
3: Account Level",
	ctr_lmt_amt        	decimal(18,2) comment "Def(En): Contract Limit Amount
Def(Th):",
	setup_lmt_amt      	decimal(18,2) comment "Def(En): Setup Limit Amount
Def(Th):",
	lmt_typ_id         	smallint     comment "Def(En): Finance Service Limit Type Id
Def(Th):",
	lmt_typ            	smallint     comment "Def(En): Limit Type
Def(Th):",
	aprv_id            	string       comment "Def(En): Approver ID
Def(Th):",
	dcn_typ            	smallint     comment "Def(En): Discount Type
Def(Th):",
	br_nbr             	string       comment "Def(En): Branch Number of Account Arrangement (DomicileBranchId**)
Def(Th):",
	pd_grp             	string       comment "Def(En): Profile Product Group
Def(Th):",
	pd_typ             	string       comment "Def(En): Profile Product Type
Def(Th):",
	sub_typ            	string       comment "Def(En): Profile Product Sub Type
Def(Th):",
	mkt_code           	string       comment "Def(En): Profile Market Code
Def(Th):",
	kbank_pd_code      	string       comment "Def(En): Kbank Product Code
Def(Th):",
	coa_pd_ftr_code_pnp	string       comment "Def(En): Chart of Account (Product Feature Code)
Def(Th):",
	used_lmt           	decimal(18,2) comment "Def(En):
Def(Th): วงเงินที่ใช้ไป",
	esr                	decimal(18,2) comment "Def(En):
Def(Th): ยอดความเสี่ยงที่ธนาคารต้องแบกรับภาระ   (ยอดวงเงินที่ยังไม่เบิกใช้ +  ยอดเงินต้นคงค้าง)",
	unused_lmt         	decimal(18,2) comment "Def(En):
Def(Th): วงเงินที่ยังไม่ได้ใช้",
	avl_lmt            	decimal(18,2) comment "Def(En):
Def(Th): วงเงินคงเหลือที่สามารถใช้ได้",
	hold_amt           	decimal(18,2) comment "Def(En):
Def(Th): จำนวนเงินที่ถูก Hold",
	li_idv_flg         	smallint     comment "Def(En):
Def(Th): Flag ที่บอกว่าเป็น LI เฉพาะราย",
	cis_id             	bigint       comment "Def(En):
Def(Th): เลขที่ลูกค้า",
	tot_li_amt         	decimal(18,2) comment "Def(En):
Def(Th): ยอดรวมภาระ L/I",
	tot_dr_amt         	decimal(18,2) comment "Def(En):
Def(Th): ยอดรวมภาระที่ใช้ไป",
	eff_int_rate_typ_id	string       comment "Def(En): Effective Interest rate type ID
Def(Th):",
	eff_sprd_int_sign  	string       comment "Def(En): Effective Spread Interest Sign
Def(Th):",
	eff_sprd_int_rate  	decimal(9,5) comment "Def(En): Effective Spread Interest Rate
Def(Th):",
	max_days           	smallint     comment "Def(En): Max Days
Def(Th):",
	refr_ddcn_ac       	string       comment "Def(En): Reference Deduction Account Number
Def(Th):",
	rel_ac_ar_id       	string       comment "Def(En): Related Deposit Account
Def(Th):",
	rel_ac_ar_id_sub   	string       comment "Def(En): Related Deposit Sub Sequence
Def(Th):",
	rel_ac_sign_sprd   	decimal(9,5) comment "Def(En): Fixed Interest Rate Differential
Def(Th):",
	cr_prog            	string       comment "Def(En): Credit Program
Def(Th):",
	kcps_app_id        	string       comment "Def(En): Credit Application ID
Def(Th):",
	committed_type     	string       comment "Def(En): Committed Type
Def(Th):",
	filler             	string       comment "Def(En): Filler
Def(Th):",
	load_tms           	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id         	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy           	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm             	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd             	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_pcb_loan/pcb_loan_common_limit_info' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);