-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_scf_trading.sql
# Area: scf
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_SCF.SCF_TRADING
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_scf.scf_trading (
	pos_dt              	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	strsponsorid        	string       comment "Def(En): Sponsor Customer ID
Def(Th):",
	strbuysellid        	string       comment "Def(En): Buyer/Seller Customer ID
Def(Th):",
	strprodtype         	string       comment "Def(En): Product Type
Def(Th):",
	inttradingno        	bigint       comment "Def(En): Trading No
Def(Th):",
	declimitamt         	decimal(17,2) comment "Def(En): Limit Amount
Def(Th):",
	decoutlimitamt      	decimal(17,2) comment "Def(En): Outstanding Limit Amount
Def(Th):",
	decpenddirectdramt  	decimal(17,2) comment "Def(En): Pending Direct Debit Amount
Def(Th):",
	decpenddrawdwamt    	decimal(17,2) comment "Def(En): Pending Drawdown Amount
Def(Th):",
	decavltopupamt      	decimal(17,2) comment "Def(En): Available Top up Amount
Def(Th):",
	decremainlimitamt   	decimal(17,2) comment "Def(En): Remaining Limit Amount
Def(Th):",
	strsendremainchgflag	string       comment "Def(En):
Def(Th):",
	strremainupdatedflag	string       comment "Def(En):
Def(Th):",
	strapprdate         	date         comment "Def(En):
Def(Th):",
	strefftdate         	date         comment "Def(En): Effective Date
Def(Th):",
	strduedate          	date         comment "Def(En): Due Date
Def(Th):",
	strreviewdate       	date         comment "Def(En):
Def(Th):",
	strdesc             	string       comment "Def(En):
Def(Th):",
	strchargeintfor     	string       comment "Def(En): Charge Interest For
Def(Th):",
	strpayinttype       	string       comment "Def(En): Payment Interest Type
Def(Th):",
	strintflag          	string       comment "Def(En): Interest Flag
Def(Th):",
	strintcode          	string       comment "Def(En): Interest Code
Def(Th):",
	decintbasis         	decimal(11,8) comment "Def(En): Interest Basis
Def(Th):",
	decintspread        	decimal(11,8) comment "Def(En): Interest Basis
Def(Th):",
	decallinrate        	decimal(11,8) comment "Def(En): All In Rate
Def(Th):",
	decprepayperc       	decimal(11,8) comment "Def(En): Pre Payment Percentage
Def(Th):",
	inttenor            	smallint     comment "Def(En): Tenor Days
Def(Th):",
	strchargefeefor     	string       comment "Def(En): Charge Fee For (SP = Sponsor, BS = Buyer / Seller)
Def(Th):",
	strchargefeetype    	string       comment "Def(En): OD= On due, MN = Monthly, TD = Transaction Date
Def(Th):",
	strchargedcfeefor   	string       comment "Def(En): Charge DC Fee For (SP = Sponsor, BS = Buyer / Seller)
Def(Th):",
	strchargedcfeetype  	string       comment "Def(En):
Def(Th):",
	strcrtype           	string       comment "Def(En):
Def(Th):",
	strcrmethod         	string       comment "Def(En):
Def(Th):",
	decfeeamt           	decimal(15,2) comment "Def(En):
Def(Th):",
	decbalfeeamt        	decimal(15,2) comment "Def(En):
Def(Th):",
	decdcfeeamt         	decimal(15,2) comment "Def(En): DC FEE Amount
Def(Th):",
	strlastfeedate      	date         comment "Def(En):
Def(Th):",
	stractiveflag       	string       comment "Def(En): Active Flag
Def(Th):",
	strprocessflag      	string       comment "Def(En): Process Flag
Def(Th):",
	strverifyflag       	string       comment "Def(En): Verify Flag
Def(Th):",
	strverifyby         	string       comment "Def(En): Verify By
Def(Th):",
	strverifydate       	date         comment "Def(En): Verify Date
Def(Th):",
	strreturnflag       	string       comment "Def(En):
Def(Th):",
	strreturnrem        	string       comment "Def(En): Return Remark
Def(Th):",
	strdelverifyflag    	string       comment "Def(En): Delete Verify Flag
Def(Th):",
	strdelverifyby      	string       comment "Def(En): Delete Verify By
Def(Th):",
	strdelverifydate    	date         comment "Def(En): Delete Verify Date
Def(Th):",
	strsdintflag        	string       comment "Def(En): Special Direct Debit Interest Flag (1 = Fix, 2 = Float)
Def(Th):",
	decsdintrate        	decimal(11,8) comment "Def(En): Interest Rate
Def(Th):",
	strsdintcode        	string       comment "Def(En): Special Direct Debit Interest Code
Def(Th):",
	decsdintspread      	decimal(11,8) comment "Def(En): Special Direct Debit Interest Spread
Def(Th):",
	decsdintbasis       	decimal(11,8) comment "Def(En): Special Direct Debit Interest Basis
Def(Th):",
	decsdallinrate      	decimal(11,8) comment "Def(En): Special Direct Debit All in Rate
Def(Th):",
	stramendby          	string       comment "Def(En): Amend By
Def(Th):",
	stramenddate        	date         comment "Def(En): Amend Date
Def(Th):",
	stramendverifyby    	string       comment "Def(En): Amend Verify By
Def(Th):",
	stramendverifydate  	date         comment "Def(En): Amend Verify Date
Def(Th):",
	stramendverifyflag  	string       comment "Def(En): Amend Verify Flag
Def(Th):",
	decintrate          	decimal(11,8) comment "Def(En):
Def(Th):",
	strcreateuser       	string       comment "Def(En): Create User
Def(Th):",
	dtecreatedate       	timestamp    comment "Def(En): Create Date
Def(Th):",
	strupduser          	string       comment "Def(En): Update User
Def(Th):",
	dteupddate          	timestamp    comment "Def(En): Update Date
Def(Th):",
	stronlineflag       	string       comment "Def(En): Online Flag
Def(Th):",
	strshareflag        	string       comment "Def(En): Share Flag Y=share,N=No Share
Def(Th):",
	strsharegrp         	string       comment "Def(En): Share Group
Def(Th):",
	strchgshare         	string       comment "Def(En):
Def(Th):",
	load_tms            	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id          	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy            	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm              	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd              	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_scf/scf_trading' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);