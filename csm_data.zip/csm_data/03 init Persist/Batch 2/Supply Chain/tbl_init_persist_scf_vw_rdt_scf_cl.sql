-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_scf_vw_rdt_scf_cl.sql
# Area: scf
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_SCF.SCF_VW_RDT_SCF_CL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_scf.scf_vw_rdt_scf_cl (
	pos_dt                    	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	data_date                 	date         comment "Def(En): Data date is the ending date of income data
Def(Th):",
	credit_line_id            	string       comment "Def(En):
Def(Th): รหัสวงเงินหรือเลขที่อ้างอิงวงเงินของสถาบันการเงิน",
	entity_id                 	string       comment "Def(En):  CIS ID
Def(Th):",
	credit_line_approve_date  	date         comment "Def(En):
Def(Th): วันที่อนุมัติวงเงิน",
	credit_line_effective_date	date         comment "Def(En):
Def(Th): วันที่วงเงินมีผลบังคับใช้",
	maturitity_date           	date         comment "Def(En):
Def(Th): วันสิ้นสุดสัญญา",
	currency                  	string       comment "Def(En):
Def(Th): สกุลเงินของวงเงิน",
	setup_limit_amount        	decimal(15,2) comment "Def(En): First set up amount or Credit Line Amount in Original Currency
Def(Th):",
	available_limit_amount    	decimal(15,2) comment "Def(En):
Def(Th): วงเงินคงเหลือ ที่สามารถใช้ได้",
	utilize_limit_amount      	decimal(15,2) comment "Def(En):
Def(Th): วงเงินที่มีการใช้ไป",
	load_tms                  	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_scf/scf_vw_rdt_scf_cl' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);