-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_ud_vw_flt_div_pmt_inc.sql
# Area: ud
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_UD.UD_VW_FLT_DIV_PMT_INC
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_ud.ud_vw_flt_div_pmt_inc (
	pos_dt             	date          comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt         	date          comment "Def(En): Application Date
Def(Th):",
	ar_id              	string        comment "Def(En): Unit Holder Account Number
Def(Th):",
	fnd_id             	string        comment "Def(En): Fund ID
Def(Th):",
	snd_ar_id          	bigint        comment "Def(En): Sender's bank account number
Def(Th):",
	rcvr_ar_id         	string        comment "Def(En): Receiver's Deposit account number
Def(Th):",
	dvdn_pymt_id       	string        comment "Def(En): Dividend Payment Number
Def(Th):",
	eff_dt             	date          comment "Def(En): Dividend Payment date
Def(Th):",
	extr_dt            	timestamp     comment "Def(En): FCIS extraction DB server Date
Def(Th):",
	extr_tm            	timestamp     comment "Def(En): FCIS extraction DB server Timestmp
Def(Th):",
	mcl_refr_no        	string        comment "Def(En): Media Clearing Reference Number for dividend payment to non-KBank account-holders 
Def(Th):",
	mcl_tfr_amt        	decimal(10,0) comment "Def(En): Media Clearing Transfer Amount (net_dividend_amount)
Def(Th):",
	misc_cd            	string        comment "Def(En): MiscCode at Sub account level
Def(Th):",
	rcvr_nm            	string        comment "Def(En): Investor Full Name 
Def(Th):",
	dvdn_py_f          	string        comment "Def(En): In case of dividend pay to pledger or pledgee
0: Pledger
1: Pledgee
This field will be derived based on MISC code mapping maintenance

Def(Th):",
	pymt_mode          	string        comment "Def(En): Payment mode
Def(Th):",
	non_kbnk_rcvr_ar_id	bigint        comment "Def(En): Bank account number (Non K-Bank)
Def(Th):",
	rcvr_bnk_cd        	string        comment "Def(En): Receiver's Bank code
Def(Th):",
	rcvr_br_no         	string        comment "Def(En): Receiver's Branch code 
Def(Th):",
	setl_amt           	decimal(14,2) comment "Def(En): Transfer amount
Def(Th):",
	snd_bnk_cd         	string        comment "Def(En): Sender's bank code (4 = KBank)
Def(Th):",
	snd_br_no          	string        comment "Def(En): Sender's branch code
Def(Th):",
	pymt_dt            	date          comment "Def(En): Payment Date for dividend
Def(Th):",
	pymt_dd            	smallint      comment "Def(En): Trans DD
Def(Th):",
	pymt_mm            	smallint      comment "Def(En): Trans MM
Def(Th):",
	pymt_yy            	smallint      comment "Def(En): Trans  YY
Def(Th):",
	sub_ar_id          	string        comment "Def(En): Unit Holder Sub Account Number
Def(Th):",
	dvdn_per_unit      	decimal(20,12) comment "Def(En): Dividend per unit
Def(Th):",
	agnc_id            	string        comment "Def(En): Agency ID
Def(Th):",
	cnsnt_f            	string        comment "Def(En): Consent Flag
Def(Th):",
	kcyber_f           	string        comment "Def(En): Apply Kcyber Invest Flag
Def(Th):",
	grs_dvdn_amt       	decimal(30,12) comment "Def(En): Dividend amount Payment Amount (including Tax)
Def(Th):",
	whld_tax           	decimal(30,12) comment "Def(En): Withholding tax amount
Def(Th):",
	load_tms           	timestamp     comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id         	string        comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy           	string        comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm             	string        comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd             	string        comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_ud/ud_vw_flt_div_pmt_inc' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);