-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_ud_vw_flt_dp_div_cert_inc.sql
# Area: ud
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_UD.UD_VW_FLT_DP_DIV_CERT_INC
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_ud.ud_vw_flt_dp_div_cert_inc (
	pos_dt                    	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	bank_account_number       	string       comment "Def (En): Sender's bank account number
Def (Th): เลขที่บัญชีผู้จ่ายเงิน",
	deposit_acct_no           	string       comment "Def (En): Receiver's Deposit account number
Def (Th): เลขที่บัญชีผู้รับ",
	dividend_payment_no       	string       comment "Def (En): Reference key for Dividend Payment and Dividend Declaration 
Def (Th): Key ที่บอกว่าเป็นการจ่ายเงินรอบที่เท่าไหร่",
	effective_date_of_transfer	date         comment "Def (En): Redemption/Dividend payment date
Def (Th): วันที่จ่ายเงินปันผล",
	extraction_date           	date         comment "Def (En): UD FCIS Extraction Date
Def (Th): วันที่ทำการ extraction ข้อมูลในระบบ UD",
	extraction_time           	timestamp    comment "Def (En): DTE Extaction Date timestamp
Def (Th): วันที่ทำการ extraction ข้อมูลในระบบ UD แต่ตรงเวลาจะมีความละเอียดมากกว่า EXTR_DT",
	fund_id                   	string       comment "Def (En): Fund Code
Def(Th):",
	name                      	string       comment "Def (En): Title+' '+FirstName+' '+LastName -Thai
Def (Th): ชื่อลูกค้าที่รับเงิน",
	payment_mode              	string       comment "Def (En): Payment mode
Def(Th):",
	receiving_bank_code       	string       comment "Def (En): Receiver's Bank Code
Def (Th): รหัสธนาคารที่รับเงิน",
	receiving_branch_code     	string       comment "Def (En): Receiver's Bank Branch Code
Def (Th): รหัสสาขาที่รับเงิน",
	sb_transfer_amount        	decimal(15,2) comment "Def (En): Payment Amount net of Tax
(Net Amount)
Def(Th):",
	sending_bank_code         	string       comment "Def (En): Sender's bank code (4 = KBank)
Def(Th):",
	sending_branch_code       	string       comment "Def (En): Sender's branch code
Def(Th):",
	unitholder_acc_no         	string       comment "Def (En): Investor Account Number 
(Unitholder account)
Def (Th): บัญชีกองทุนที่ได้รับเงินปันผล",
	uh_sub_account            	string       comment "Def (En): Investor Sub Account Number
(Sub Account)
Def(Th):",
	dividend_per_unit         	decimal(20,2) comment "Def (En): Dividend rate per unit
Def (Th): เงินปันผล/หน่วยลงทุน",
	gross_dividend_amount     	decimal(15,2) comment "Def (En): Payment Amount (including Tax)
Def(Th):",
	wh_tax                    	decimal(15,2) comment "Def (En): Tax Amount
Def(Th):",
	dividend_processing_date  	date         comment "Def (En): Dividend Processing Date
Def (Th): เป็นวันที่เดียวกัน  Extraction date",
	type_of_transactions      	string       comment "Def (En): Type of Transaction
Def (Th): ประเภทของธุรกรรม",
	bookclosingdate           	date         comment "Def (En): Book Closing date (XD Date)
Def(Th):",
	confirm_unit_balance      	decimal(15,4) comment "Def (En): Confirm Unit for dividend
Def(Th):",
	load_tms                  	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_ud/ud_vw_flt_dp_div_cert_inc' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);