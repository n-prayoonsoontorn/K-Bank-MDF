-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_ud_vw_std_ins_eod_inc.sql
# Area: ud
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_UD.UD_VW_STD_INS_EOD_INC
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_ud.ud_vw_std_ins_eod_inc (
	pos_dt                        	date          comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	si_save_datetime              	timestamp     comment "Def(En): Saving Plan Create/Modify Date AND Time(English)
Def(Th):",
	application_status            	smallint      comment "Def(En): APPLICATION_STATUS possible values are 1 , 2 and 3
1. New Registration (If new SI record created, i.e. no record in SI history) 
2. Change/Modification (IF Add or delete new fund or Direct Debit payment fail cases also will be considered as modification of SI  
3. Cancel (SI Status- C) (Cancel both Invesment Plan(Fund Level and Saving Plan(Plan Level))
Def(Th):",
	si_level                      	string        comment "Def(En): SI level
Def(Th):",
	apply_kinvest_date            	timestamp     comment "Def(En): Apply K-Cyber Invest Date(English)
Def(Th):",
	uh_bank_code                  	string        comment "Def(En): UH Bank Code
Def(Th):",
	uh_bank_name                  	string        comment "Def(En): UH Bank Name Thai @ UH  Cr/Dr
Def(Th):",
	uh_bank_acc_number            	string        comment "Def(En): UH Bank Account Number
Def(Th):",
	uh_bank_acc_name              	string        comment "Def(En): UH Bank Account Name (Refer to CR)
Def(Th):",
	uh_bank_acc_type              	string        comment "Def(En): UH Bank Account Type
Def(Th):",
	communication_mode            	string        comment "Def(En): Communication Mode
Refer parameterisation
Def(Th):",
	uh_acc_number                 	string        comment "Def(En): Unitholder ID
Def(Th):",
	uh_title_thai                 	string        comment "Def(En): UH Title
(Refer Additional CR Lot 2 for Title)
From UH Maint Main screen
Def(Th):",
	uh_firstname_thai             	string        comment "Def(En): UH First name
From UH Maint Main screen
Def(Th):",
	uh_lastname_thai              	string        comment "Def(En): UH Last name
From UH Maint Main screen
Def(Th):",
	uh_fullname_thai              	string        comment "Def(En): Unitholder Name  @ Passbook (to be referred to Passbook UH Full Name and UH Screen Redesign
Def(Th):",
	uh_sub_acc_number             	string        comment "Def(En): UH Sub Account Number Destination, 
Def(Th):",
	fund_id                       	string        comment "Def(En): FUND ID
Def(Th):",
	fund_short_name               	string        comment "Def(En): Fund Short Name
Def(Th):",
	si_number                     	decimal(20,0) comment "Def(En): SI Number
Def(Th):",
	si_amount                     	decimal(17,8) comment "Def(En): SI Amount
Def(Th):",
	si_start_date                 	timestamp     comment "Def(En): Saving Plan Start Date (English)
Def(Th):",
	si_end_date                   	timestamp     comment "Def(En): Saving Plan End Date (English)
Def(Th):",
	payment_mode                  	string        comment "Def(En): Payment mode
Def(Th):",
	fund_name_thai                	string        comment "Def(En): FUND NAME Thai
Def(Th):",
	si_priority                   	smallint      comment "Def(En): Priority of the SI in case SI Level is Plan
Def(Th):",
	si_day                        	smallint      comment "Def(En): SI Day 1-31
Def(Th):",
	si_frequency                  	string        comment "Def(En): Frequency of Automatic Payment
Def(Th):",
	si_jan                        	string        comment "Def(En): Check Box Month of Jan
Def(Th):",
	si_feb                        	string        comment "Def(En): Check Box Month of Feb
Def(Th):",
	si_mar                        	string        comment "Def(En): Check Box Month of Mar
Def(Th):",
	si_apr                        	string        comment "Def(En): Check Box Month of Apr
Def(Th):",
	si_may                        	string        comment "Def(En): Check Box Month of May
Def(Th):",
	si_jun                        	string        comment "Def(En): Check Box Month of Jun
Def(Th):",
	si_jul                        	string        comment "Def(En): Check Box Month of Jul
Def(Th):",
	si_aug                        	string        comment "Def(En): Check Box Month of Aug
Def(Th):",
	si_sep                        	string        comment "Def(En): Check Box Month of Sep
Def(Th):",
	si_oct                        	string        comment "Def(En): Check Box Month of Oct
Def(Th):",
	si_nov                        	string        comment "Def(En): Check Box Month of Nov
Def(Th):",
	si_dec                        	string        comment "Def(En): Check Box Month of Dec
Def(Th):",
	transaction_mode              	string        comment "Def(En): Transaction mode
A, U,P

Def(Th):",
	si_unit                       	decimal(27,12) comment "Def(En): SI Unit
Def(Th):",
	transaction_type              	string        comment "Def(En): Transaction Type Code
Refer parameterisation also
Def(Th):",
	mobile_no                     	string        comment "Def(En): Customer’s mobile phone
UH Contact Address cellphone
Def(Th):",
	consecutive_direct_debit_fail 	smallint      comment "Def(En): Consecutive number of direct debit failure at Unitholder , Fund level
Def(Th):",
	src_pos_dt                    	date          comment "Def(En): FCIS Application Date
Def(Th):",
	extraction_date_time          	timestamp     comment "Def(En): FCIS extraction DB server Date Time
Def(Th):",
	keystring                     	string        comment "Def(En): Unique Key for each extraction
Def(Th):",
	agency_branch_id              	string        comment "Def(En): This field will store the value of Intermediary 
Agency Branch ID.
Def(Th):",
	agency_id                     	string        comment "Def(En): This field will store the value of Intermediary Agency ID.
Def(Th):",
	ao_id                         	string        comment "Def(En): This field will store the value of Intermediary Account Officer ID.
Def(Th):",
	consent_fund_risk_rating      	string        comment "Def(En): This field will extract the Consent given during Standing Instruction capture for each fund
Def(Th):",
	con_planfund_forn_exc_raterisk	string        comment "Def(En): This field will extract the Consent for Foreign Exchange Rate given during Standing Instruction capture for each fund 
Possible values are;
Y-Yes
N-No
Def(Th):",
	first_generation_date         	date          comment "Def(En): This field will extract the value of First Generation Date as parameterized in Standing Instruction level
Def(Th):",
	holiday_rule                  	string        comment "Def(En): Holiday rule will be extracted as part of this field
Def(Th):",
	last_processed_date           	date          comment "Def(En): This field will extract the value of Last processed Date (i.e., Very recently Date of transaction  generation
Def(Th):",
	maker_id                      	string        comment "Def(En): This field will store the value of creator ID
Def(Th):",
	no_of_si_transactions         	smallint      comment "Def(En): This will generate the number of SI transactions generated so far as tracked in Standing Instruction level.
Def(Th):",
	planfund_foreign_exc_raterisk 	smallint      comment "Def(En): This field will extract the Fund Foreign risk rating from Fund 
Def(Th):",
	planfund_risk_rating          	smallint      comment "Def(En): This field will extract the Fund risk rating from Fund Level 
Def(Th):",
	plan_code                     	string        comment "Def(En): This field will store the value of Plan Code. If SI Level is plan.
Def(Th):",
	plan_description              	string        comment "Def(En): Description of Plan from Plan Maintenance level
Def(Th):",
	reason_for_cancel             	string        comment "Def(En): This field will store the value of REASON FOR CANCEL. .Extract only in case of SI status is canceled.
Def(Th):",
	reminder_before_action        	smallint      comment "Def(En): This field will extract the value of Reminder as captured during Standing Instruction capture
Def(Th):",
	si_cancel_date                	date          comment "Def(En): This field will store the value of SI cancel date in 
Def(Th):",
	si_status                     	string        comment "Def(En): This field will extract the value of SI status. 
Def(Th):",
	si_status_fund                	string        comment "Def(En): SI status at fund level 
Def(Th):",
	uh_risk_rating                	smallint      comment "Def(En): This field will store the value of UH Risk rating captured at Standing Instruction level
Def(Th):",
	stream_no                     	bigint        comment "Def(En): Streaming No always 1
Def(Th):",
	load_tms                      	timestamp     comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                    	string        comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                      	string        comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                        	string        comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                        	string        comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_ud/ud_vw_std_ins_eod_inc' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);