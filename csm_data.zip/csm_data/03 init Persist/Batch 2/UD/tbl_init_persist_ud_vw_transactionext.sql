-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_ud_vw_transactionext.sql
# Area: ud
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-29    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_UD.UD_VW_TRANSACTIONEXT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_ud.ud_vw_transactionext (
	pos_dt                        	date          comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt                    	date          comment "Def(En): FCIS Application Date
Def(Th):",
	keystring                     	string        comment "Def(En): Unique Key for each extraction
Def(Th):",
	extraction_date_time          	timestamp     comment "Def(En): FCIS extraction DB server Date Time
Def(Th):",
	year                          	string        comment "Def(En): Transaction of year YYYY (Thai)
Def(Th):",
	certification_no              	bigint        comment "Def(En): Document Number/Certification Number
(RMF/LTF fund only)
Def(Th):",
	transaction_ref_no            	string        comment "Def(En): Transaction Reference Number
Def(Th):",
	transaction_no                	string        comment "Def(En): Transaction Number
Def(Th):",
	uh_acc_number                 	string        comment "Def(En): Unitholder ID
Def(Th):",
	uh_sub_acc_number             	string        comment "Def(En): UH Sub Account Number Destination, 
Def(Th):",
	transaction_type              	string        comment "Def(En): Transaction Type Code
Parameterisation ,Please refer Transaction_Type tab
Def(Th):",
	transaction_ref_type          	string        comment "Def(En): Transaction REF Type Code
Parameterisation ,Please refer Transaction_Type tab
Def(Th):",
	transaction_sub_type          	string        comment "Def(En): Transaction SUB TYPE Code
Parameterisation ,Please refer Transaction_Type tab
Def(Th):",
	transaction_date              	date          comment "Def(En): FCIS Transaction Date
Def(Th):",
	settlement_date               	date          comment "Def(En): SETTLEMENT DATE of TRANSACTION
Def(Th):",
	allocation_date               	date          comment "Def(En): FCIS Allocation Date
Def(Th):",
	alloted_price                 	decimal(17,8) comment "Def(En): Alloted Price per Unit
Def(Th):",
	price_date                    	date          comment "Def(En): Price Date
(English year)
Def(Th):",
	apply_kinvest_flag            	string        comment "Def(En): Apply K-Cyber Invest flag
Def(Th):",
	clearing_status               	string        comment "Def(En): Clearing Status
Y : Cleared
N : Not Clear
R : Reject
Def(Th):",
	communication_mode            	string        comment "Def(En): Communication Mode
Refer parameterisation
Def(Th):",
	transaction_mode              	string        comment "Def(En): Transaction mode
A, U,P
Def(Th):",
	grossornet_flag               	string        comment "Def(En): Gross or Net based transaction
Def(Th):",
	maker_id                      	string        comment "Def(En): Maker ID (User ID)
Def(Th):",
	transaction_save_datetime     	timestamp     comment "Def(En): Flexcube Transaction Create Date AND Time(English)
Def(Th):",
	switchin_date                 	date          comment "Def(En): In case of Switch out transaction, Switch-In leg TRANSACTION DATE, based on the SWITCHING TABLE CR.
Def(Th):",
	exit_fee_amount               	decimal(17,8) comment "Def(En): Exit Fee Amount
Def(Th):",
	frontend_fee_amount           	decimal(17,8) comment "Def(En): Front Fee Amount
Def(Th):",
	txn_dep_acc_number            	string        comment "Def(En): Payment Deposit Account Number, 
@ Txn level , Cr/Dr depend on Redemption/Subscription(in case of payment mode is Transfer or Direct Debit )
Def(Th):",
	txn_dep_acc_name              	string        comment "Def(En): Payment Deposit Account name , @ Txn level , Cr/Dr depend on Redemption/Subscription(in case of payment mode is Transfer or Direct Debit) (Refer to CR UH Account Name for print Passbook)
(Refer Additional CR Lot1 for TITLE)
Def(Th):",
	txn_dep_bank_code             	string        comment "Def(En): Payment Deposit Bank Code
@ Txn level , Cr/Dr depend on Redemption/Subscription (in case of payment mode is Transfer or Direct Debit or Cheque)
If Payment by cheque then Issue cheque bank code)
Def(Th):",
	txn_dep_bank_name             	string        comment "Def(En): Deposit Bank Name @ Txn level , Cr/Dr depend on Redemption/Subscription (in case of payment mode is Transfer or Direct Debit or Cheque)
If Payment by cheque then Issue cheque bank name)
Def(Th):",
	txn_dep_branch_code           	string        comment "Def(En): Payment Deposit Branch number 
@ Txn level , Cr/Dr depend on Redemption/Subscription (in case of payment mode is Transfer or Direct Debit or Cheque)
If Payment by cheque then Issue cheque branch code)
Def(Th):",
	txn_dep_branch_name           	string        comment "Def(En): Payment Deposit Branch Name 
@ Txn level , Cr/Dr depend on Redemption/Subscription (in case of payment mode is Transfer or Direct Debit or Cheque)
If Payment by cheque then Issue cheque branch name)
Def(Th):",
	cheque_number                 	string        comment "Def(En): Cheque Number  (@ Txn)
Def(Th):",
	payin_bank_code               	string        comment "Def(En): Payin Bank Code (@ Txn)

in case of IPO/subscription 
Def(Th):",
	payin_bank_name               	string        comment "Def(En): PAYIN Bank Branch Name (@ Txn)
in case of IPO/subscription 
Def(Th):",
	credit_card_number            	string        comment "Def(En): Credit Card Number (@ Txn)
Def(Th):",
	payment_mode                  	string        comment "Def(En): Payment mode
Def(Th):",
	sub_payment_mode              	string        comment "Def(En): Sub Payment mode
Def(Th):",
	payment_mode_name             	string        comment "Def(En): Payment mode
Def(Th):",
	payment_term_vedc             	string        comment "Def(En): Payment term VEDC
(Refer Fund Add Info)
Def(Th):",
	payment_date                  	date          comment "Def(En): Payment Date (Same as Settlement date)
Def(Th):",
	nav_per_unit                  	decimal(17,8) comment "Def(En): Nav Per Unit
Def(Th):",
	alloted_unit                  	decimal(27,12) comment "Def(En): Allotted Transaction Unit
Def(Th):",
	bid                           	decimal(17,8) comment "Def(En): Bid Price
(Based on Maximum Slab value)
Def(Th):",
	offer                         	decimal(17,8) comment "Def(En): Offer Price
Based on Maximum slab value
Def(Th):",
	transaction_unit              	decimal(27,12) comment "Def(En): BUY/SELL Unit
(Transaction units applied)
If Transaction_Mode is U or P
Def(Th):",
	transaction_amount            	decimal(30,12) comment "Def(En): BUY/SELL AMOUNT
(Transaction AMOUNT )
If Transaction_Mode is A
Def(Th):",
	net_transaction_amount        	decimal(30,12) comment "Def(En): Net Transaction Amount (not include fee and tax)

Below are current KBank scenario. Do not hardcode logic.

Will have value when 

Subscription/inflow
1) Transaction_Mode = A  and GROSSORNET_FLAG = G and ALLOCATION_FLAG = Y

Redemption/Outflow:
1) Transaction_Mode = A  and GROSSORNET_FLAG = N
2) Transaction_Mode = U  and GROSSORNET_FLAG = G
and ALLOCATION_FLAG = Y

Def(Th):",
	gross_transaction_amount      	decimal(30,12) comment "Def(En): Transaction Gross Amount (include fee and tax)

Below are current KBank scenario. Do not hardcode logic.

Will have value when 

Subscription/inflow:
1) Transaction_Mode = A  and GROSSORNET_FLAG = G

Redemption/Outflow:
1) Transaction_Mode = A  and GROSSORNET_FLAG = N and ALLOCATION_FLAG = Y
2) Transaction_Mode = U  and GROSSORNET_FLAG = G and ALLOCATION_FLAG = Y
Def(Th):",
	confirm_unit_balance          	decimal(27,12) comment "Def(En): Confirm Unit of UH in Fund 
Def(Th):",
	all_unit_balance              	decimal(27,12) comment "Def(En): Confirm and Provisional Unit of UH in Fund 
Def(Th):",
	vat_rate                      	decimal(17,8) comment "Def(En): Vat Rate %
Def(Th):",
	vat                           	decimal(17,8) comment "Def(En): VAT Amount of EntryFee/Exit Fee
(all LTP loads inclusive of VAT)
Def(Th):",
	capital_gains_tax_amount      	decimal(30,12) comment "Def(En): Withholding Tax Amount(SELL transactions only)
RMF/LTF redemptions
Def(Th):",
	capital_gains_tax_rate        	decimal(17,8) comment "Def(En): Withholding Tax Rate(SELL transactions only) %
Def(Th):",
	cost_amount                   	decimal(30,12) comment "Def(En): Cost Amount
Def(Th):",
	benefit_amount                	decimal(30,12) comment "Def(En): Benefit Amount in case of RMF and LTF redemptions.
Def(Th):",
	mobile_vedc                   	string        comment "Def(En): Mobile NO in VEDC
(Refer Txn Add Info)
Def(Th):",
	mail_flag                     	smallint      comment "Def(En): MAIL FLAG
0
Def(Th):",
	consent_flag                  	string        comment "Def(En): CONSENT FLAG for publish customer's  information
Def(Th):",
	pending_flag                  	string        comment "Def(En): Pending Flag
(For RMF only)
Def(Th):",
	allocation_flag               	string        comment "Def(En): Allocation Flag
Def(Th):",
	reverse_flag                  	string        comment "Def(En): Reverse Flag
Def(Th):",
	confirm_allocation_flag       	string        comment "Def(En): Allocation Flag
(Provisional or Confirmed )
Def(Th):",
	tax_id                        	string        comment "Def(En): UH Tax ID
UTANAME TAX ID, Customer TAX ID
Def(Th):",
	consent_fx_risk_accept_flag   	string        comment "Def(En):
Def(Th):",
	remark                        	string        comment "Def(En): Remark of transaction
Def(Th):",
	module_id                     	string        comment "Def(En): Module ID 
Def(Th):",
	pay_redemp_to                 	string        comment "Def(En): Pay Redemption to pledger or pledgee in case of pledge account auto redemption
PL: Pledger
PD: Pledgee
also Refer to Additional CR lot1
Def(Th):",
	cif_number                    	string        comment "Def(En): CIF NUMBER
In case of joint account, FCIS will provide only Unitholder’s CIF not joint CIF
Def(Th):",
	customer_fullname_thai        	string        comment "Def(En): Customer full name in Thai, CIF Name 
(Refer Additional CR Lot1 for TITLE)
Def(Th):",
	cust_type                     	string        comment "Def(En): Customer Type, Investor Type
Def(Th):",
	uh_title_thai                 	string        comment "Def(En): UH Title
(Refer Additional CR Lot 2 for Title)
From UH Maint Main screen
Def(Th):",
	uh_firstname_thai             	string        comment "Def(En): UH First name
From UH Maint Main screen
Def(Th):",
	uh_lastname_thai              	string        comment "Def(En): UH Last name
From UH Maint Main screen
Def(Th):",
	uh_fullname_thai              	string        comment "Def(En): Unitholder Name  @ Passbook (to be referred to Passbook UH Full Name and UH Screen Redesign
Def(Th):",
	uh_agency_id                  	string        comment "Def(En): UH Intermediary Agent Code
AGENCY ID Broker Code/ Counter Party Code , Domicile Agency ID of UH
Def(Th):",
	uh_agency_name                	string        comment "Def(En): UH Agent Name , Domicile Agency Name of UH
UH Intermediary Agent 
(Main screen not alternate)
Def(Th):",
	uh_agency_branch_code         	string        comment "Def(En): UH Agency Branch number Intermediary Branch (UHlevel)
Def(Th):",
	uh_agency_branch_name         	string        comment "Def(En): UH Agency Branch Name  (UH Intermediary/Domicile Agency Branch)
(Main screen not alternate)
Def(Th):",
	uh_acc_officer_id             	string        comment "Def(En): UH Account Officer Id, Sale ID (UH Level AO)
Def(Th):",
	uh_acc_officer_name           	string        comment "Def(En): UH Account Officer Name (UH Intermediary Account Officer Name)
(Main screen not alternate)
Def(Th):",
	uh_sub_acc_agency_id          	string        comment "Def(En): UH Sub Account  Intermediary Agent Code
AGENCY ID Broker Code/ Counter Party Code , Domicile Agency ID of UH Sub Acc
Def(Th):",
	uh_sub_acc_agency_name        	string        comment "Def(En): UH Sub Account Agent Name , Domicile Agency Name of UH Sub Acc Intermediary Agent 
(Main screen not alternate)
Def(Th):",
	uh_sub_acc_agency_branch_code 	string        comment "Def(En): UH Sub Account  Agency Branch number Intermediary Branch (UH Sub level)
Def(Th):",
	uh_sub_acc_agency_branch_name 	string        comment "Def(En): UH Sub Account  Agency Branch Name  (UH Sub Intermediary/Domicile Agency Branch)
(Main screen not alternate)
Def(Th):",
	uh_sub_acc_officer_id         	string        comment "Def(En): UH Sub Account  Account Officer Id, Sale ID (UH Sub Level AO)
Def(Th):",
	uh_sub_acc_officer_name       	string        comment "Def(En): UH Sub Account Officer Name 
(Main screen not alternate)
Def(Th):",
	mobile_sms_alert              	string        comment "Def(En): UH Contact address Mobile Number for sms alert
Def(Th):",
	contact_address1              	string        comment "Def(En): UH Contact Address - Addressline 1
Def(Th):",
	contact_address2              	string        comment "Def(En): UH Contact Address - Addressline 2 
Def(Th):",
	contact_tambon                	string        comment "Def(En): UH Contact Address - Tambon (DISTRICT)
Def(Th):",
	contact_amphur                	string        comment "Def(En): UH Contact Address -  Amphur (CITY)
Def(Th):",
	contact_province              	string        comment "Def(En): UH Contact Address - Province (STATE)
Def(Th):",
	contact_zipcode               	string        comment "Def(En): UH Contact Address - Zip code
Def(Th):",
	contact_tel_no_home           	string        comment "Def(En): UTANAME HOME TEL, UH Contact Telephone Number Home
Contac address Telephone 1
Def(Th):",
	contact_mobile_number         	string        comment "Def(En): UH Contact Address - Mobile NO
Def(Th):",
	country_code                  	string        comment "Def(En): Contact Address - Country Code
Def(Th):",
	passbook_no                   	string        comment "Def(En): Passbook Number
Def(Th):",
	uh_sub_acc_status             	string        comment "Def(En): Unit Holder Sub Account Status, Miscellaneous Code
(Refer additional CR Lot1)
Def(Th):",
	email                         	string        comment "Def(En): UH Email
Def(Th):",
	card_no                       	string        comment "Def(En): Identification Card Number
Def(Th):",
	card_type                     	string        comment "Def(En): Identification Card Type
Refer parameterisation
Def(Th):",
	card_type_name                	string        comment "Def(En): Identification Card Type Name
Def(Th):",
	uh_acc_number_destination     	string        comment "Def(En): UH Account Number Destination, case switching, To Unit holder ID
Def(Th):",
	uh_domicile_branch_code_dest  	string        comment "Def(En): Switch case - Agency Branch (UH Intermediary Branch)
Def(Th):",
	uh_title_thai_destination     	string        comment "Def(En): UH Title
(Refer Additional CR Lot 2 for Title)
case Switch/Transfer, 
Def(Th):",
	uh_firstname_thai_destination 	string        comment "Def(En): UH First name
case Switch/Transfer, 
Def(Th):",
	uh_lastname_thai_destination  	string        comment "Def(En): UH Last name
case Switch/Transfer, 
Def(Th):",
	uh_fullname_thai_destination  	string        comment "Def(En): case Switch/Transfer, (--Unitholder Name  @ Passbook (to be referred to Passbook UH Full Name and UH Screen Redesign
)  (Refer to CR UH Account Name for print Passbook)
Def(Th):",
	uh_sub_acc_number_destination 	string        comment "Def(En): Sub account number Destination , Switch case
Def(Th):",
	uh_sub_domicile_branchcodedest	string        comment "Def(En): UH  Sub Domicile Branch Code Destination (Intermediary branch)
Def(Th):",
	uh_risk_level                 	smallint      comment "Def(En): UH Risk Level
@ Fetch From Txn level
Def(Th):",
	uh_fx_risk_accept_flag        	string        comment "Def(En): UH Foreign Exchange Rate Risk Acceptance
(Refer Additional CR Lot 1) @ Fetch From Txn level
Def(Th):",
	uh_risk_date                  	date          comment "Def(En): UH Risk Date
Currently NOT CR
Def(Th):",
	uh_risk_exp_date              	date          comment "Def(En): UH Risk Expire Date
Currently NOT CR
Def(Th):",
	default_dep_acc_number        	string        comment "Def(En): Default Deposit Account number, Bank Account Number (@ UH Cr/Dr
Def(Th):",
	default_dep_bank_code         	string        comment "Def(En): Default Deposit  Bank Code.
 (@ UH  Cr/Dr
Def(Th):",
	default_dep_bank_name         	string        comment "Def(En): Default Deposit Bank Name Thai @ UH  Cr/Dr
Def(Th):",
	default_dep_branch_code       	string        comment "Def(En): Default Deposit  Branch number 
@ UH  Cr/Dr
Def(Th):",
	service_agency_id             	string        comment "Def(En): Transaction Agency ID, Intermediary Agency
Def(Th):",
	service_agency_name           	string        comment "Def(En): Transaction agency name
(Main screen not alternate)
Def(Th):",
	service_branch_code           	string        comment "Def(En): Service Branch number Intermediary Branch (Txn level)
Def(Th):",
	service_branch_name           	string        comment "Def(En): Service Branch Name (Txn Intermediary Agency Branch Name)
(Main screen not alternate)
Def(Th):",
	service_acc_officer_id        	string        comment "Def(En): Account Officer Id, Sale ID (Txn Level AO)
Def(Th):",
	service_acc_officer_name      	string        comment "Def(En): Account Officer Name (Txn Intermediary Account Officer Name)
(Main screen not alternate)
Def(Th):",
	si_number                     	decimal(20,0) comment "Def(En): SI Number
Def(Th):",
	si_type                       	string        comment "Def(En): Saving Plan/Investment Plan
Def(Th):",
	si_priority                   	smallint      comment "Def(En): Priority of the SI in case SI Level is Plan
Def(Th):",
	amc_code                      	string        comment "Def(En): AMC code
Def(Th):",
	amc_name                      	string        comment "Def(En): AMC Name 
Def(Th):",
	amc_address1                  	string        comment "Def(En): AMC Contact Address
Addressline 1
Def(Th):",
	amc_address2                  	string        comment "Def(En): AMC Contact  Address
Addressline 2
Def(Th):",
	amc_amphur                    	string        comment "Def(En): AMC Contact Address Amphur (CITY)
Def(Th):",
	amc_province                  	string        comment "Def(En): AMC Contact Address Province
Def(Th):",
	amc_zipcode                   	bigint        comment "Def(En): AMC Contact Address Zip Code
Def(Th):",
	other_amc_code_destination    	string        comment "Def(En): Other AMC Cod destination (For RMF/LTF Switching From/To Other AMC
Def(Th):",
	other_amc_code_fund_dest      	string        comment "Def(En): Other AMC Code(2) and Fund Code(4) destination (For RMF/LTF Switching From/To Other AMC, New Parameter Code = 'OTHERAMCADDINFO', This will be map in Transaction Add Info)
Def(Th):",
	other_amc_name_fund_dest      	string        comment "Def(En): Other AMC Name and Fund Name destination (For RMF/LTF Switching From/To Other AMC, New Parameter Code = 'OTHERAMCADDINFO', This will be map in Transaction Add Info)
Def(Th):",
	fund_dep_acc_number           	string        comment "Def(En): Pay-in Bank Account Number of Fund  Cr/Dr
Def(Th):",
	fund_type_code                	smallint      comment "Def(En): Fund Type Code
Def(Th):",
	fund_id                       	string        comment "Def(En): FUND ID
Def(Th):",
	fund_short_name               	string        comment "Def(En): fund short name
Def(Th):",
	fund_name_eng                 	string        comment "Def(En): FUND NAME eng
Def(Th):",
	fund_name_thai                	string        comment "Def(En): FUND NAME Thai
Def(Th):",
	fund_tax_id                   	string        comment "Def(En): Fund Tax ID
Def(Th):",
	fund_id_destination           	string        comment "Def(En): In case of switching , To Fund ID (For Switching Internal)
Def(Th):",
	fund_short_name_destination   	string        comment "Def(En): In case of switching , To Fund Short Name (For Switching Internal)
Def(Th):",
	fund_name_eng_destination     	string        comment "Def(En): FUND NAME eng Destination (For Switching Internal)
Def(Th):",
	fund_tax_id_destination       	string        comment "Def(En): case switching, Tax ID of destination fund
Def(Th):",
	fund_dep_acc_number_dest      	string        comment "Def(En): Pay-in Bank Account Number of destination fund for case switching. Fund  Cr/Dr
Def(Th):",
	fund_risk_level               	smallint      comment "Def(En): Fund Risk Level
(Refer Additional CR Lot 1) @Fund Level
Def(Th):",
	fund_fx_risk_accept_flag      	string        comment "Def(En): Fund Foreign Exchange Rate  risk acceptance 
(Refer Additional CR Lot 1) @Fund Level
Def(Th):",
	consent_fund_risk_flag        	string        comment "Def(En):
Def(Th):",
	fund_outstanding_amount       	decimal(31,12) comment "Def(En): Unitholder Sub Account Outstanding Amount
Unitholder Sub Account Confirmed Unit Balance * Latest Publish NAV
Def(Th):",
	trustee_name                  	string        comment "Def(En): Fund Trustee Name.
Def(Th):",
	trustee_address1              	string        comment "Def(En): Trustee Contact Address Addressline 1
Def(Th):",
	trustee_address2              	string        comment "Def(En): Trustee Contact Address Addressline 2
Def(Th):",
	trustee_amphur                	string        comment "Def(En): Trustee Contact Address AMPHUR (CITY)
Def(Th):",
	trustee_province              	string        comment "Def(En): Trustee Contact Address Province
Def(Th):",
	trustee_zipcode               	bigint        comment "Def(En): Trustee Contact Address Zip Code
Def(Th):",
	fund_name_thai_destination    	string        comment "Def(En): FUND NAME Thai Destination (For Switching Internal)
Def(Th):",
	settled_flag                  	string        comment "Def(En): Transaction Settled Flag
Settled from Transaction -> Settlement Details Screen
Def(Th):",
	campaign_code                 	string        comment "Def(En): Currently this field will be extracted as blank. This feature is not used currently
Def(Th):",
	reversal_code                 	string        comment "Def(En): In case of Transaction Reversal, the selected reversal code will be extracted as part of this field.
The codes are maintained as parameters. Paramcode ='REVERSALCODE'
Def(Th):",
	referal1                      	string        comment "Def(En): Transaction Screens -> Add Info3
Def(Th):",
	referal2                      	string        comment "Def(En): Transaction Screens -> Add Info4
Def(Th):",
	referal3                      	string        comment "Def(En): Transaction Screens -> Add Info5
Def(Th):",
	stocktofund_txn               	string        comment "Def(En): Transaction Screens -> Add Info 7
Def(Th):",
	bank_chequebank               	string        comment "Def(En): Bank Code of the transaction - Data available for payment mode 'Cheque' or 'Direct Debit'
Def(Th):",
	branch_chequebranch           	string        comment "Def(En): Bank Branch Code  - Data available for payment mode 'Cheque' or 'Direct Debit'
Def(Th):",
	cheque_date                   	date          comment "Def(En): Cheque Date - Data available only for payment mode 'Cheque' 
Def(Th):",
	uhbc_redeemable               	decimal(27,12) comment "Def(En): Latest Redeemable unit balance for the UH and Fund combination from Investor Fund Balance Summary Screen. Excluding the provisional balance
** Always send NULL for LTF/RMF Fund **
Def(Th):",
	average_cost                  	decimal(27,12) comment "Def(En): Latest FCIS Average Cost for the Unit holder fund combination
Def(Th):",
	provisional_unit              	decimal(27,12) comment "Def(En): Latest Provisional Unit balance for UH and Fund combination
Def(Th):",
	uhbc_holding                  	decimal(30,12) comment "Def(En): Total Amount Balance for UH and Fund combination from Investor Fund Balance Summary Screen.
This is calculated as Total Unit Balance * Latest Publish NAV
Def(Th):",
	non_taxable_units             	decimal(27,12) comment "Def(En): Non Taxable Unit Balance.
** Always send NULL for all Fund **
Def(Th):",
	non_taxable_amount            	decimal(30,12) comment "Def(En): Non Taxable Amount Balance.
** Always send NULL for all Fund **
Def(Th):",
	fee_pay_to_agent              	decimal(30,12) comment "Def(En): Load Amount UH to Agent (Based on Fund Load) for the transaction
Assumption is, in Fund Load only one load will be mapped in case of period based load.
Def(Th):",
	fee_pay_to_fund               	decimal(30,12) comment "Def(En): Load Amount UH to Fund (Based on Fund Load) for the transaction
Assumption is, in Fund Load only one load will be mapped in case of period based load.
Def(Th):",
	fee_pay_to_amc                	decimal(30,12) comment "Def(En): Load Amount UH to AMC(Based on Fund Load) for the transaction
Note: Assumption is, in Fund Load only one load will be mapped in case of period based load.
Def(Th):",
	initial_transaction_date      	date          comment "Def(En): Initial transaction date captured for Switching from other AMC transactions  Data available only for RMF/LTF Transaction 
Def(Th):",
	no_changeof_bene_ownership    	string        comment "Def(En): In Case of transfer transactions, this flag will be available at transaction level 
1 for yes
0 for no
Def(Th):",
	effective_date                	date          comment "Def(En): Effective Date used for the adjustment transactions. This data will be available only for adjustment transactions
Def(Th):",
	dest_uh_sub_acc_agency_id     	string        comment "Def(En): Switch In/To UH Sub Account  Intermediary Agent Code
AGENCY ID Broker Code/ Counter Party Code , Domicile Agency ID of UH Sub Acc
Refer Parameterization
Entity ID from UnitholderUnit holder Sub Account Details Screens
Def(Th):",
	dest_uh_sub_acc_agency_name   	string        comment "Def(En): Switch In/To UH Sub Account Agent Name, Domicile Agency Name of UH Sub Acc Intermediary Agent 
(Main screen not alternate)
Entity Name from UnitholderUnit holder Sub Account Details Screens
Def(Th):",
	dest_uh_sub_acc_agybranchcode 	string        comment "Def(En): Switch In/To UH Sub Account  Agency Branch number Intermediary Branch (UH Sub level)
Refer Parameterization
Entity ID from UnitholderUnit holder Sub Account Details Screens
Def(Th):",
	dest_uh_sub_acc_agybranchname 	string        comment "Def(En): Switch In/To UH Sub Account  Agency Branch Name  (UH Sub Intermediary/Domicile Agency Branch)
(Main screen not alternate)
Entity Name from UnitholderUnit holder Sub Account Details Screens
Def(Th):",
	dest_uh_sub_acc_officer_id    	string        comment "Def(En): Switch In/To UH Sub Account  Account Officer Id, Sale ID (UH Sub Level AO)
Refer Parameterization
Entity ID from UnitholderUnit holder Sub Account Details Screens
Def(Th):",
	dest_uh_sub_acc_officer_name  	string        comment "Def(En): Switch In/To UH Sub Account Officer Name 
(Main screen not alternate)
Entity Name from UnitholderUnit holder Sub Account Details Screens
Def(Th):",
	miscode                       	string        comment "Def(En): Misc Code mapped to UH and sub account level for the transaction
i.e. ∫{UH level Misc codes (~)} ||;|| ∫{UH sub Misc code (~)}
Def(Th):",
	tax_invoice_no                	decimal(15,0) comment "Def(En): Tax Invoice Number
Def(Th):",
	cgt_wht_year_sequence         	bigint        comment "Def(En): Capital gain tax sequence 
Def(Th):",
	cgt_wht_month_sequence        	bigint        comment "Def(En): CGT WHT Month Sequence no
Def(Th):",
	fee_applicable_offer          	decimal(17,8) comment "Def(En): Fee pay to offer
Def(Th):",
	fee_applicable_bid            	decimal(17,8) comment "Def(En): Fee pay to Bid
Def(Th):",
	fee_applicable_txn_unit       	decimal(27,12) comment "Def(En): Fee pay to transaction unit
Def(Th):",
	fee_applicable_net_txn_amount 	decimal(30,12) comment "Def(En): Fee pay to net transaction amount
Def(Th):",
	stream_no                     	bigint        comment "Def(En):
Def(Th):",
	vat_code                      	string        comment "Def(En): Vat Code
Def(Th):",
	checker_id                    	string        comment "Def(En): Checker  ID (User ID)
User ID who authorized the Transaction
Def(Th):",
	reversal_maker_id             	string        comment "Def(En): Maker ID (User ID) who reverses the transaction.
Def(Th):",
	reversal_checker_id           	string        comment "Def(En): Checker  ID (User ID)
who authorized the reversal transaction
Def(Th):",
	reversal_dt_stamp             	date          comment "Def(En): Reversal Date with Time 
Def(Th):",
	load_tms                      	timestamp     comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                    	string        comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                      	string        comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                        	string        comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                        	string        comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_ud/ud_vw_transactionext' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);