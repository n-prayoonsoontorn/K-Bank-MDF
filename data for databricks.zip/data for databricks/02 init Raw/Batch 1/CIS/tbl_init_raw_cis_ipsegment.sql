-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_cis_ipsegment.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-19    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CIS.CIS_IPSEGMENT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cis.cis_ipsegment (
	pos_dt        	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	method        	string        comment "Description (Eng): Ingestion Method
Description (Thai): วิธีการนำเข้า",
	ipsegm_ip_id  	integer       comment "Description (Eng): Customer id
Description (Thai): เลขที่ลูกค้า",
	ipsegm_tp     	string        comment "Description (Eng): Segment type
Description (Thai): รหัสประเภท segment",
	ipsegm_cd     	string        comment "Description (Eng): Segment code
Description (Thai): รหัส segment ของลูกค้า",
	ipsegm_dt     	date          comment "Description (Eng): Segment update date
Description (Thai): วันที่เปลี่ยนแปลง segment",
	ipsegm_user_id	string        comment "Description (Eng): User id
Description (Thai): รหัสผู้ทำรายการ",
	ipsegm_upd_dt 	timestamp     comment "Description (Eng): Update date time
Description (Thai): วันและเวลาที่ทำรายการ",
	load_tms      	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id    	string        comment "Source system ID",
	ptn_yyyy      	string        comment "Partition field - year",
	ptn_mm        	string        comment "Partition field - month",
	ptn_dd        	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cis/cis_ipsegment' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);