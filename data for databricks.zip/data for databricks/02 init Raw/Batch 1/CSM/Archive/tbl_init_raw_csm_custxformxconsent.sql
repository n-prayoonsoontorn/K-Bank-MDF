-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_csm_custxformxconsent.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CSM.CSM_CUSTXFORMXCONSENT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_csm.csm_custxformxconsent (
	pos_dt                  	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	custfc_cust_id          	bigint(10)   comment "Description (Eng): Cust ID (CIS ID)
Description (Thai): เลขที่ลูกค้า (CIS ID)",
	custfc_form_id          	bigint(10)   comment "Description (Eng): Form ID
Description (Thai): เลขที่ฟอร์มสำหรับกรอก consent",
	custfc_consent_eff_date 	timestamp    comment "Description (Eng):Effective date
Description (Thai):วันที่ให้ consent",
	custfc_consent_exp_date 	timestamp    comment "Description (Eng):Expire date
Description (Thai):วันที่สิ้นสุดค่า consent",
	custfc_re_consent_date  	date         comment "Description (Eng):Reconsent date
Description (Thai):วันที่ต้องถาม consent ใหม่",
	custfc_channel_cd       	string       comment "Description (Eng):Channel code
Description (Thai):ช่องทางที่ให้ consent",
	custfc_originate_product	string       comment "Description (Eng):Originate product
Description (Thai):product ที่ทำรายการที่ให้ consent",
	custfc_evidence_url     	string       comment "Description (Eng):Evidence URL
Description (Thai):URL รูปภาพหลักฐานการให้ consent",
	custfc_consent_flag     	string       comment "Description (Eng):Consent flag
Description (Thai):ค่า consent ที่ลูกค้าให้",
	custfc_upd_user         	string       comment "Description (Eng):Update by UserID
Description (Thai):user ที่แก้ไขข้อมูล",
	custfc_upd_user_name    	string       comment "Description (Eng):Update by User name
Description (Thai):ชื่อ-นามสกุล ของ user
(No value in phase1)",
	custfc_upd_user_deptcd  	string       comment "Description (Eng):Department code of user
Description (Thai):รหัสหน่วยงานหรือสาขาของ user ที่ทำรายการ",
	custfc_upd_user_deptnm  	string       comment "Description (Eng):Department name of user
Description (Thai):ชื่อหน่วยงานของ user ที่ทำรายการ
(No value in phase1)",
	custfc_upd_dt           	timestamp    comment "Description (Eng):Update date
Description (Thai):วันที่อัพเดทข้อมูล",
	load_tms                	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id              	string       comment "Source system ID",
	ptn_yyyy                	string       comment "Partition field - year",
	ptn_mm                  	string       comment "Partition field - month",
	ptn_dd                  	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_csm/csm_custxformxconsent' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);