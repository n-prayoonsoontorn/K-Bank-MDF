-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_csm_downstreamconfig.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CSM.CSM_DOWNSTREAMCONFIG
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_csm.csm_downstreamconfig (
	pos_dt      	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	dsc_form_id 	int(4)       comment "Def(En): Form Id
Def(Th): รหัส Form",
	dsc_rule_id 	smallint(2)  comment "Def(En):Rule Id
Def(Th):รหัส Rule",
	dsc_upd_user	string       comment "Def(En):Update by UserID
Def(Th):User ที่แก้ไขข้อมูล",
	dsc_upd_dt  	timestamp    comment "Def(En):Update date
Def(Th):วันที่อัพเดทข้อมูล",
	load_tms    	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id  	string       comment "Source system ID",
	ptn_yyyy    	string       comment "Partition field - year",
	ptn_mm      	string       comment "Partition field - month",
	ptn_dd      	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_csm/csm_downstreamconfig' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);