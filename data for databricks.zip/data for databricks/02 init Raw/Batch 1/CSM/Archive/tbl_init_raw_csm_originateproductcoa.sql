-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_csm_originateproductcoa.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CSM.CSM_ORIGINATEPRODUCTCOA
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_csm.csm_originateproductcoa (
	pos_dt             	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	oriprodcoa_cd      	string       comment "Description (Eng): COA product code
Description (Thai): รหัส product แบบ COA",
	oriprodcoa_th_desc 	string       comment "Description (Eng):COA product Thai description
Description (Thai):รายละเอียดภาษาไทย",
	oriprodcoa_en_desc 	string       comment "Description (Eng):COA product English description
Description (Thai):รายละเอียดภาษาอังกฤษ",
	oriprodcoa_status  	string       comment "Description (Eng):COA product status
Description (Thai):สถานะของ COA product",
	oriprodcoa_upd_user	string       comment "Description (Eng):Update by UserID
Description (Thai):User ที่แก้ไขข้อมูล",
	oriprodcoa_upd_dt  	timestamp    comment "Description (Eng):Update date
Description (Thai):วันที่อัพเดทข้อมูล",
	load_tms           	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id         	string       comment "Source system ID",
	ptn_yyyy           	string       comment "Partition field - year",
	ptn_mm             	string       comment "Partition field - month",
	ptn_dd             	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_csm/csm_originateproductcoa' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);