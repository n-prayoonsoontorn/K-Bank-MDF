-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_csm_receivertype.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CSM.CSM_RECEIVERTYPE
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_csm.csm_receivertype (
	pos_dt         	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	recvtp_cd      	smallint(5)  comment "Def(En): Receiver type code
Def(Th): รหัสประเภทของ receiver",
	recvtp_th_desc 	string       comment "Def(En):Receiver Thai description
Def(Th):รายละเอียดภาษาไทย",
	recvtp_en_desc 	string       comment "Def(En):Receiver English description
Def(Th):รายละเอียดภาษาอังกฤษ",
	recvtp_status  	string       comment "Def(En):Receiver type status
Def(Th):สถานะของ Receiver type",
	recvtp_upd_user	string       comment "Def(En):Update by UserID
Def(Th):user ที่แก้ไขข้อมูล",
	recvtp_upd_dt  	timestamp    comment "Def(En):Update date
Def(Th):วันที่อัพเดทข้อมูล",
	load_tms       	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id     	string       comment "Source system ID",
	ptn_yyyy       	string       comment "Partition field - year",
	ptn_mm         	string       comment "Partition field - month",
	ptn_dd         	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_csm/csm_receivertype' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);