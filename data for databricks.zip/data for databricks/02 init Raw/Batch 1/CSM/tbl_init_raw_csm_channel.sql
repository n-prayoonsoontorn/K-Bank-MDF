-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_csm_channel.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-19    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CSM.CSM_CHANNEL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_csm.csm_channel (
	pos_dt          	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	channel_cd      	string        comment "Description (Eng): Channel Code
Description (Thai): รหัสของ Channel ที่ทำรายการ",
	channel_desc    	string        comment "Description (Eng):Channel description
Description (Thai):รายละเอียดภาษาไทยของ channel ที่ทำรายการ",
	channel_upd_user	string        comment "Description (Eng):Update by UserID
Description (Thai):user ที่แก้ไขข้อมูล",
	channel_upd_dt  	timestamp     comment "Description (Eng):Update date
Description (Thai):วันที่อัพเดทข้อมูล",
	load_tms        	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id      	string        comment "Source system ID",
	ptn_yyyy        	string        comment "Partition field - year",
	ptn_mm          	string        comment "Partition field - month",
	ptn_dd          	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_csm/csm_channel' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);