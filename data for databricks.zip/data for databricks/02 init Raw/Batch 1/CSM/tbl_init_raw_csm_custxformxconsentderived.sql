-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_csm_custxformxconsentderived.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-19    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CSM.CSM_CUSTXFORMXCONSENTDERIVED
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_csm.csm_custxformxconsentderived (
	pos_dt               	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	custfcdr_cust_id     	smallint      comment "Description (Eng): Cust ID (CIS ID)
Description (Thai): เลขที่ลูกค้า (CIS ID)",
	custfcdr_formappr_cd 	string        comment "Description (Eng): Form APPR ID
Description (Thai): รหัสของวัตถุประสงค์ของฟอร์มสำหรับใส่ระดับ derived",
	custfcdr_consent_flag	string        comment "Description (Eng):Consent flag
Description (Thai):ค่า consent ที่ลูกค้าให้",
	custfcdr_upd_user    	string        comment "Description (Eng):Update by UserID
Description (Thai):User ที่แก้ไขข้อมูล

",
	custfcdr_upd_dt      	timestamp     comment "Description (Eng):Update date
Description (Thai):วันที่อัพเดทข้อมูล",
	load_tms             	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id           	string        comment "Source system ID",
	ptn_yyyy             	string        comment "Partition field - year",
	ptn_mm               	string        comment "Partition field - month",
	ptn_dd               	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_csm/csm_custxformxconsentderived' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);