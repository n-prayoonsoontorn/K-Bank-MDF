-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_csm_formxappr.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-19    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CSM.CSM_FORMXAPPR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_csm.csm_formxappr (
	pos_dt             	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	formappr_cd        	integer       comment "Description (Eng): Form APPR ID
Description (Thai): รหัสของวัตถุประสงค์ของฟอร์มสำหรับใส่ระดับ derived",
	formappr_form_id   	integer       comment "Description (Eng):Form ID
Description (Thai):เลขที่ของ Form",
	formappr_apprgrp_cd	smallint      comment "Description (Eng):APPR group code
Description (Thai):รหัสกลุ่มของวัตถุประสงค์",
	formappr_action_cd 	smallint      comment "Description (Eng):Action code
Description (Thai):เลขที่ action",
	formappr_purpose_cd	smallint      comment "Description (Eng):Purpose code
Description (Thai):เลขที่ purpose",
	formappr_prod_cd   	smallint      comment "Description (Eng):Product code
Description (Thai):เลขที่ product",
	formappr_recvtp_cd 	smallint      comment "Description (Eng):Receiver type code
Description (Thai):เลขที่ receiver type",
	formappr_company_cd	smallint      comment "Description (Eng):Company code
Description (Thai):เลขที่ company (receiver)",
	formappr_upd_user  	string        comment "Description (Eng):Update by UserID
Description (Thai):user ที่แก้ไขข้อมูล",
	formappr_upd_dt    	timestamp     comment "Description (Eng):Update date
Description (Thai):วันที่อัพเดทข้อมูล",
	load_tms           	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id         	string        comment "Source system ID",
	ptn_yyyy           	string        comment "Partition field - year",
	ptn_mm             	string        comment "Partition field - month",
	ptn_dd             	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_csm/csm_formxappr' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);