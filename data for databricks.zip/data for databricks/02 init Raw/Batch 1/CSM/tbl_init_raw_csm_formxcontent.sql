-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_csm_formxcontent.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-19    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CSM.CSM_FORMXCONTENT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_csm.csm_formxcontent (
	pos_dt            	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	formct_form_id    	integer       comment "Def(En): Form ID
Def(Th): เลขที่ฟอร์ม",
	formct_language_cd	string        comment "Def(En):Language code
Def(Th):รหัสภาษา",
	formct_short      	string        comment "Def(En):Short content
Def(Th):ข้อความขอ consent แบบสั้น",
	formct_long       	string        comment "Def(En):Long content
Def(Th):ข้อความขอ consent แบบยาว",
	formct_detail     	string        comment "Def(En):Detail content
Def(Th):ข้อความขอ consent แบบละเอียด",
	formct_upd_user   	string        comment "Def(En):Update by UserID
Def(Th):user ที่แก้ไขข้อมูล",
	formct_upd_dt     	timestamp     comment "Def(En):Update date
Def(Th):วันที่อัพเดทข้อมูล",
	load_tms          	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id        	string        comment "Source system ID",
	ptn_yyyy          	string        comment "Partition field - year",
	ptn_mm            	string        comment "Partition field - month",
	ptn_dd            	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_csm/csm_formxcontent' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);