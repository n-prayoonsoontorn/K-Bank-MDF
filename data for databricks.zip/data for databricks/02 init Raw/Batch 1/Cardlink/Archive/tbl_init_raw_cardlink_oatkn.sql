-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_cardlink_oatkn.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-12    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK.CARDLINK_OATKN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink.cardlink_oatkn (
	pos_dt                    	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	oatkn_org                 	string       comment "Organization",
	oatkn_type                	string       comment "Type",
	oatkn_acct                	string       comment "Account number",
	oatkn_token_number        	string       comment "Token number",
	oatkn_assurance_lvl       	string       comment "Token Assurance Level",
	oatkn_requestor_id        	string       comment "Token Requestor ID",
	oatkn_status              	string       comment "Token Status",
	oatkn_action_date         	date         comment "Token Action Date",
	oatkn_date_change         	date         comment "The Last Date Change",
	oatkn_time_change         	string       comment "The Last Time Change",
	oatkn_acct_exp_date       	string       comment "Card expiry date",
	oatkn_visa_token_type     	string       comment "Visa Token Type",
	oatkn_visa_device_id      	string       comment "Visa Device ID",
	oatkn_visa_device_nbr     	string       comment "Visa Device Number",
	oatkn_visa_device_loc     	string       comment "Visa Device Locate",
	oatkn_visa_wallet_acct_id 	string       comment "Visa Wallet Account ID",
	oatkn_visa_wallet_email   	string       comment "Visa Wallet Email Account",
	oatkn_visa_wallet_rsn_code	string       comment "Visa Wallet Reason Code",
	filler                    	string       ,
	oatkn_pymt_acct_ref       	string       comment "Payment Account Reference Data",
	load_tms                  	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id                	string       comment "Source system ID",
	ptn_yyyy                  	string       comment "Partition field - year",
	ptn_mm                    	string       comment "Partition field - month",
	ptn_dd                    	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink/cardlink_oatkn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);