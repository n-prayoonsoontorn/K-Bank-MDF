-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_ks_custprofile.sql
# Area: ks
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_KS.KS_CUSTPROFILE
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_ks.ks_custprofile (
	pos_dt         	date         comment "Business Date or Batch date From Control-M",
	as_of_date     	date         comment "Date of data generated (วันที่ข้อมูล)",
	card_id        	string       comment "Customer identification number (เลขบัตรประชาชน/หนังสือเดินทาง)",
	cust_cd        	string       comment "Customer reference number (รหัสลูกค้าตามประเภทการเปิดบัญชี)",
	cust_since_date	date         comment "Account approve date (วันที่ลูกค้าเปิดบัญชีประเภทต่างๆตาม)",
	document_type  	string       comment "Document type (ประเภทเอกสารยืนยันตัวตน)",
	birthday       	date         comment "Dath of birth วันเกิด",
	cust_type      	string       comment "ชนิดของลูกค้า
1 - ลูกค้าทั่วไป (Regular Customer)
2 - ลูกค้าต่างประเทศ (Foreign Customer)
3 - Sub-Broker หรือ Broker (เช่นกรณีซื้อขาย OTC)
4 - ลูกค้าที่เป็นกองทุน (Fund)
5 - Port ของบริษัท (Company Portfolio)",
	person_cd      	string       comment "เลขอ้างอิงประเภทบุคคล
personCode = 1 (บุคคลธรรมดา ในประเทศ)
personCode = 3 (บุคคลธรรมดา นอกประเทศ)
personCode = 0 (นิติบุคคล ในประเทศ)
personCode = 2 (นิติบุคคล ต่างประเทศ)",
	gndr           	string       comment "Gender เพศ (M,F,O)",
	marital        	string       comment "0 โสด
1 สมรส(จดทะเบียน)
2 หม้าย
3 หย่าร้าง
4 สมรส(ไม่จดทะเบียน)",
	income         	decimal(24,6)comment "Income รายได้(ตามลูกค้ากรอก)",
	load_tms       	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id     	string       comment "Source system ID",
	ptn_yyyy       	string       comment "Partition field - year",
	ptn_mm         	string       comment "Partition field - month",
	ptn_dd         	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_ks/ks_custprofile' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);