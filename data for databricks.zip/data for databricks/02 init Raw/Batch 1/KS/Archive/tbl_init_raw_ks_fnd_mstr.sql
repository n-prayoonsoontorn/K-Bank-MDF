-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_ks_fnd_mstr.sql
# Area: ks
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-12    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_KS.KS_FND_MSTR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_ks.ks_fnd_mstr (
	pos_dt          	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	as_of_date      	date         comment "Date of data generated (วันที่ข้อมูล)",
	fundid          	integer      comment "Fund ID (รหัสกองทุนที่ Ksec สร้างเอง)",
	fundcode        	string       comment "Fund code (ชื่อย่อกองทุน)",
	amcid           	integer      comment "AMC ID (รหัสบริษัทหลัก)",
	thaifundunitname	string       comment "Fund name thai (ชื่อกองทุนภาษาไทย)",
	engfundunitname 	string       comment "Fund name eng (ชื่อกองทุนภาษาอังกฤษ)",
	fundtype        	string       comment "Fund type (ประเภทกองทุน)",
	nametype        	string       comment "Name type (ชื่อประเภทกองทุนภาษาไทย)",
	risklevel       	string       comment "Risk level (ระดับความเสี่ยง)",
	nav             	decimal(24,6)comment "NAV (ราคาตลาดต่อหน่วย)",
	navdate         	date         comment "NAV date วันที่ออก NAV ล่าสุด",
	load_tms        	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id      	string       comment "Source system ID",
	ptn_yyyy        	string       comment "Partition field - year",
	ptn_mm          	string       comment "Partition field - month",
	ptn_dd          	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_ks/ks_fnd_mstr' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);