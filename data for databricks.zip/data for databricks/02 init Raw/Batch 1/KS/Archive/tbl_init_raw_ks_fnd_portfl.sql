-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_ks_fnd_portfl.sql
# Area: ks
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-12    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_KS.KS_FND_PORTFL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_ks.ks_fnd_portfl (
	pos_dt       	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	as_of_date   	date         comment "Date of data generated (วันที่ข้อมูล)",
	card_id      	string       comment "Customer identification number (เลขบัตรประชาชน/หนังสือเดินทาง)",
	cust_cd      	string       comment "Customer reference number (รหัสลูกค้าตามประเภทการเปิดบัญชี)",
	acct         	string       comment "Account number (หมายเลขบัญชีหลักทรัพย์)",
	product_type 	string       comment "Product Type (ประเภทของผลิตภัณฑ์)",
	product_name 	string       comment "Product Name (ชื่อของผลิตภัณฑ์)",
	fundid       	integer      comment "Fund ID (รหัสกองทุนที่ Ksec สร้างเอง)",
	fundcode     	string       comment "Fund code (ชื่อย่อกองทุน)",
	fundname     	string       comment "Fund name (ชื่อกองทุนภาษาอังกฤษ)",
	vol          	decimal(24,6)comment "Volume (ปริมาณหน่วยลงทุนคงเหลือ)",
	price_cost   	decimal(24,6)comment "AVG Price cost (ราคาต้นทุนต่อหน่วย(เฉลี่ย))",
	cost_amt     	decimal(24,6)comment "Cost amount (มูลค่าต้นทุน)",
	price_mkt    	decimal(24,6)comment "Market price (ราคาตลาดต่อหน่วย[NAV])",
	mkt_value    	decimal(38,6)comment "Market value (มูลค่าตลาด)",
	unrealize    	decimal(38,6)comment "Unrealize (มูลค่ากำไร(ขาดทุน)ทางบัญชี)",
	unrealize_pct	decimal(38,6)comment "Percent unrealize (%มูลค่ากำไร(ขาดทุน)ทางบัญชี)",
	amc_id       	integer      comment "Agent Identifier number",
	amc_name     	string       comment "Agent Name (ชื่อบล.กองทุน ภาษาอังกฤษ)",
	unitholder_id	string       comment "Unit holder ID (เลขที่บัญชีกองทุนที่ใช้ติดต่อบล.)",
	fund_type    	string       comment "Fund type (ประเภทของกองทุน)",
	price_mkt_dt 	date         comment "NAV Date (วันที่ของข้อมูลราคาตลาดต่อหน่วย)",
	load_tms     	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id   	string       comment "Source system ID",
	ptn_yyyy     	string       comment "Partition field - year",
	ptn_mm       	string       comment "Partition field - month",
	ptn_dd       	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_ks/ks_fnd_portfl' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);