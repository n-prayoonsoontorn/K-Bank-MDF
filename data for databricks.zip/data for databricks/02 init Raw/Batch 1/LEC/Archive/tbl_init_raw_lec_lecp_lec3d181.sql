-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_lec_lecp_lec3d18.sql
# Area: lec
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LEC.LEC_LECP_LEC3D18
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lec.lec_lecp_lec3d18 (
	pos_dt             	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	lec3d18_cust_no    	integer      comment "เลขที่ลูกหนี้",
	lec3d18_legal_sub  	integer      comment "ประเภทคดี",
	lec3d18_legal_dept 	integer      comment "คดีลำดับที่",
	lec3d18_acct_no    	string       comment "เลขที่บัญชี",
	lec3d18_acct_type  	integer      comment "ประเภทบัญชี",
	lec3d18_enter_date 	date         comment "วันที่บันทึก",
	lec3d18_acquit_flag	integer      comment "สถานะการฟ้องของบัญชี",
	filler             	string       ,
	load_tms           	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id         	string       comment "Source system ID",
	ptn_yyyy           	string       comment "Partition field - year",
	ptn_mm             	string       comment "Partition field - month",
	ptn_dd             	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lec/lec_lecp_lec3d18' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);