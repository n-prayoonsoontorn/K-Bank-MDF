-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_lpm_as400_ar_clss_qly.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-12    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_AR_CLSS_QLY
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_ar_clss_qly (
	pos_dt    	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	acctno    	string       comment "วันที่การจัดชั้นคุณภาพ",
	clsdate   	integer(8)   comment "ระดับการจัดชั้นคุณภาพ
1- ปกติ 2-กล่าวถึง3-ต่ำกว่ามาตราฐาน4-สงสัย 
5-สงสัยจะสูญ 6-สูญ",
	clslevel  	integer(1)   comment "ฝ่ายงานที่จัดชั้นคุณภาพ",
	clsby     	integer(2)   comment "จัดชั้นคุณภาพจาก",
	clsfrom   	integer(1)   comment "1-สอบทาน 2- ปรับโครงสร้าง 3-สอบทาน&ปรับโครงสร้าง",
	clsreason 	integer(3)   comment "เหตุผลการจัดชั้น",
	clsdetail1	string       comment "รายละเอียด",
	clsdetail2	string       comment "รายละเอียด",
	clstrdate 	integer(8)   comment "วันที่ทำรายการ",
	entryflag 	integer(1)   comment "0=CONVERT BEFORE ENTRYFLAG   
1=UPDATE โดย PGM L01B034     
2=UPDATE โดย PGM L01B037     
3=UPDATE โดย PGM L01B787     
5=UPDATE โดย PGM DRB00901",
	entdate   	integer(8)   ,
	entuser   	string       ,
	upddate   	integer(8)   ,
	upduser   	string       ,
	daydiff   	integer(5)   comment "วันค้างชำระที่นับโดย manual",
	daydiff1  	integer(5)   ,
	load_tms  	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id	string       comment "Source system ID",
	ptn_yyyy  	string       comment "Partition field - year",
	ptn_mm    	string       comment "Partition field - month",
	ptn_dd    	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_ar_clss_qly' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);