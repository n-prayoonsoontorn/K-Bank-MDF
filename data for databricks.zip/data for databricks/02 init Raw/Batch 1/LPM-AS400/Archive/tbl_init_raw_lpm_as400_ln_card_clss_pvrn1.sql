-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_lpm_as400_ln_card_clss_pvrn.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_LN_CARD_CLSS_PVRN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_ln_card_clss_pvrn (
	pos_dt         	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	cusno          	integer      comment "เลขที่ลูกหนี้",
	title          	string       comment "คำนำหน้า",
	name           	string       comment "ชื่อลูกหนี้ *** 2 field นี้เอามาใส่ไว้ทุกบัญชี",
	accttype       	integer      comment "ประเภทบัญชี",
	acctno         	string       comment "เลขที่บ/ช",
	crtype         	integer      comment "ประเภทเครดิต",
	ficstype       	integer      comment "รหัสหัวบัญชี fics",
	buscod         	integer      comment "รหัสธุรกิจ",
	busbot         	integer      comment "รหัสธุรกิจธปท.",
	busgrp         	integer      comment "รหัสกลุ่มธุรกิจ",
	busgrpseq      	integer      comment "ลำดับรหัสกลุ่มธุรกิจ",
	brno           	integer      comment "สาชา",
	deptno         	integer      comment "สังกัด",
	prvintfg       	integer      comment "รหัสพักด/บ 0-ไม่พัก 1-พักด/บ",
	prvstop        	integer      comment "วันที่พักด/บ",
	acctgrp        	integer      comment "ระดับตามวันค้างจากระบบ",
	prvdiff        	integer      comment "วันค้างชำระถูกต้อง",
	clslevel       	integer      comment "ระดับจากการปรับฯหรือ สอบทาน",
	acctresgrp     	integer      comment "ระดับตามการปรับฯ หากไม่ปรับจะเท่ากับระดับตามวันค้างระบบ",
	sprvouts       	string       comment "เครื่องหมาย +/-",
	prvouts        	decimal(13,2)comment "ยอดคงค้างเงินต้นหลังตัดสูญ",
	sprvaccr       	string       comment "เครื่องหมาย +/-",
	prvaccr        	decimal(13,2)comment "ยอดด/บคงค้างหลังตัดสูญ",
	limit          	decimal(13,2)comment "วงเงิน",
	prvpay         	decimal(13,2)comment "ยอดชำระ",
	acctnplgrp     	integer      comment "ระดับ NPL",
	clsfrom        	integer      comment "ปรับระดับการจัดชั้นจาก 1-สอบทาน 2- ปรับฯ 0-ไม่ทำ",
	clsreason      	integer      comment "เหตุผลการปรับระดับการจัดชั้น",
	group2         	integer      comment "ระดับการจัดชั้นรายลูกหนี้",
	grno           	integer      comment "เลขที่กลุ่มล/น",
	sbefouts       	string       comment "เครื่องหมาย +/-",
	befouts        	decimal(13,2)comment "ยอดคงค้างเงินต้นก่อนตัดสูญ",
	sbefaccr       	string       comment "เครื่องหมาย +/-",
	befaccr        	decimal(13,2)comment "ยอดด/บคงค้างก่อนตัดสูญ",
	custtdrfg      	integer      comment "ผลการปรับฯ จากระดับล/น 0-ไม่ปรับ1-ไม่ได้2-รอ3ได้ 4 ได้ทันที
มาจาก L12W909 ระดับลูกหนี้",
	oldgroup2      	integer      comment "ระดับการจัดชั้นรายลูกหนี้เดือนก่อนหน้า
เช่น control 254510 ต้องการเดือนก่อนหน้า
มาจาก L01D042 CUST-NO + YYYYMM -control read greater",
	f1             	string       comment "เครื่องหมาย+/-",
	pay            	decimal(13,2)comment "ยอดชำระรวม",
	f2             	string       comment "เครื่องหมาย+/-",
	payprin        	decimal(13,2)comment "ชำระเงินต้น",
	f3             	string       comment "เครื่องหมาย+/-",
	payint         	decimal(13,2)comment "ชำระดอกในการ์ด",
	f4             	string       comment "เครื่องหมาย+/-",
	paymemo        	decimal(13,2)comment "ชำระส่วนด/บนอกการ์ด",
	f5             	string       comment "เครื่องหมาย+/-",
	paymisc        	decimal(13,2)comment "ชำระอื่นๆ",
	sintrec        	string       comment "เครื่องหมาย+/-",
	intrec         	decimal(13,2)comment "รายได้ดอกเบี้ยรับ",
	oldnpl         	integer      comment "ระดับ NPLเดือนที่แล้ว(นำบ/ชและปีเดือนที่แล้วไปหา L01D041)
กรณีเป็นบ/ชใหม่(อ่านไม่พบ) มีค่าเท่ากับ 0",
	acctofctdr     	integer      comment "สังกัดผู้ดูแล",
	center         	integer      comment "สังกัดผู้ดูแล 10 หลัก",
	acctofcgb      	integer      comment "รหัสผู้ดูแลกรณี AO 944/957 จะเก็บรหัส good bank จาก L12W909",
	botacctgrp     	integer      comment "ระดับการจัดชั้นรายบัญชี",
	resouts        	decimal(13,2)comment "ยอดสำรองรายบัญชี",
	nplprin        	decimal(13,2)comment "ยอดเงินต้น  npl รายบ/ช",
	firstdrdt      	integer      comment "วันที่ลงนามแรกจากการปรับฯ drd07200 แรก",
	lastdrdt       	integer      comment "วันที่ลงนามหลังสุดจากการปรับฯ drd07200 ล่าสุด",
	tdrseq         	integer      comment "ลำดับการปรับฯ ล่าสุด",
	tdrmethod      	string       comment "วิธีการปรับของการปรับฯล่าสุด",
	tdrremark      	string       comment "หมายเหตุวิธีการปรับของการปรับฯล่าสุด",
	drdaydiff      	integer      comment "วันที่จากการปรับฯ (จากคล)",
	tdrrescodn     	integer      comment "เงื่อนไขปลดปกติ
0-ไม่มีการปรับฯ 1-ปรับแบบปลดปกติคุ้มด/บ 2-ปรับแบบไม่คุ้มด/บ",
	pclsreason     	integer      comment "รหัสเหตุผลการปรับก่อนหน้า
หาก class-date/class-level/class-reason <> 0 
นำ acct-no + class-date  ไปอ่าน L01D027key-desc 
หา record ถัดมาที่บ/ชเดียวกันแต่ class-date จะน้อยกว่า
หากพบข้อมูลดังกล่าวให้move class-reason มาใส่",
	acctofcpro     	integer      comment "รหัสสินทรัพย์ระดับบ/ช",
	blockw         	integer      comment "1-เป็นบัตรเครดิตติด block W 0-ไม่ใช้",
	collres        	decimal(13,2)comment "ยอดหลักประกันที่นำมาคำนวณสำรอง",
	sex            	string       comment "เพศ
'M' = MALE  
'F' = FEMALE",
	birthdate      	integer      comment "วันเกิด",
	occup          	string       comment "อาชีพ",
	altcusno       	string       comment "เลขที่บัตรเสริม",
	acctcenter     	string       comment "รหัสสังกัด (ที่ลงบัญชี)",
	sysdaydiff     	integer      comment "วันค้าง (จากระบบ)",
	crlineamt      	decimal(13,2)comment "วงเงินระดับลูกค้า",
	sbefprin       	string       comment "เครื่องหมาย+/-",
	befprin        	decimal(13,2)comment "เงินต้นก่อนตัดสูญ",
	smemoaccru     	string       comment "เครื่องหมาย+/-",
	memoaccru      	decimal(13,2)comment "ยอดดอกเบี้ยนอกการ์ด",
	srevaccru      	string       comment "เครื่องหมาย+/-",
	revaccru       	decimal(13,2)comment "ยอดดอกเบี้ย Reverse",
	ovrdueamt      	decimal(13,2)comment "ยอดค้างชำระ",
	ovrlimamt      	decimal(13,2)comment "ยอดที่เกินวงเงิน",
	ovrlimperc     	integer      comment "เปอร์เซ็นของวงเงินที่เกิน",
	minpay         	decimal(13,2)comment "ยอดขั้นต่ำที่ต้องชำระ (เฉพาะ Card)",
	blockcode      	string       comment "Block Code (เฉพาะ Card)",
	cycle          	integer      comment "Cycle (เฉพาะ Card)",
	usercode3      	string       comment "รหัส User Code 3 (เฉพาะ Card)",
	lstpaydate     	integer      comment "วันจ่ายชำระครั้งสุดท้าย (เฉพาะ Card)",
	duedate        	integer      comment "วันครบกำหนดชำระ",
	subprod        	integer      comment "ประเภทผลิตภัณฑ์ย่อย",
	opendate       	integer      comment "วันเปิดบัญชี",
	intrate        	string       comment "ประเภทอัตราดอกเบี้ย",
	sstmtbal       	string       comment "เครื่องหมาย+/-",
	stmtbal        	decimal(12,2)comment "จำนวนเงินที่ส่ง statement ไปเรียกเก็บลูกค้า",
	scashbal       	string       comment "เครื่องหมาย+/-",
	cashbal        	decimal(12,2)comment "จำนวนเงินที่ถอนเงินสด",
	sretailbal     	string       comment "เครื่องหมาย+/-",
	retailbal      	decimal(12,2)comment "จำนวนเงินใช้ซื้อสินค้าและบริการ",
	fpdfg          	string       comment "Flag ว่าเป็นการผิดนัดชำระครั้งแรกหรือไม่",
	lecsts         	decimal(4)   comment "สถานะ LEC ของลูกหนี้",
	sextpay        	string       comment "เครื่องหมาย+/-",
	extpay         	decimal(13,2)comment "ส่วนลดรับคงเหลือ",
	sacctresout5   	string       comment "เครื่องหมาย+/-",
	acct-res-outs-5	decimal(13,2)comment "ยอดสำรองเพิ่มตามเกณฑ์ ธปท.",
	ao-in-date     	integer      ,
	issue-date     	integer      ,
	block-date     	integer      ,
	tdrltgflag     	string       comment "Flag TDR/LTG  โดย T= TDR L=LTG",
	idno           	string       ,
	legentity      	integer      comment "รหัสบริษัท",
	respcntr       	integer      comment "รหัสสังกัด",
	glaccount      	integer      comment "รหัสบัญชีประเภทเครดิต",
	function       	integer      comment "รหัสฟังก์ชันงาน",
	linebus        	integer      comment "รหัสประเภทธุรกิจ",
	glprodcd       	integer      comment "รหัสผลิตภัณฑ์สำหรับการบันทึกบัญชี",
	intercom       	integer      comment "รหัสบริษัทในการหักค่าใช้จ่ายระหว่างบริษัทในเครือ",
	intracom       	integer      comment "รหัสบริษัทในการหักค่าใช้จ่ายระหว่างฝ่ายงาน",
	project        	integer      comment "รหัสโครงการ",
	glfiller1      	integer      comment "สำหรับใช้ในอนาคต",
	glfiller2      	integer      comment "สำหรับใช้ในอนาคต",
	prodcd         	integer      comment "รหัสผลิตภัณฑ์",
	load_tms       	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id     	string       comment "Source system ID",
	ptn_yyyy       	string       comment "Partition field - year",
	ptn_mm         	string       comment "Partition field - month",
	ptn_dd         	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_ln_card_clss_pvrn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);