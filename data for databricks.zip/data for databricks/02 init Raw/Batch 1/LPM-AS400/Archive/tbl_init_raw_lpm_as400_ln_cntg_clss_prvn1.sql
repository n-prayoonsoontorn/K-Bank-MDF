-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_lpm_as400_ln_cntg_clss_prvn.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_LN_CNTG_CLSS_PRVN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_ln_cntg_clss_prvn (
	pos_dt    	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	cusno     	integer      comment "เลขที่ลูกหนี้",
	accttype  	integer      comment "ประเภทบัญชี
01  =  LOAN
02  =  OD            
03  =  CARD PACK  
04  =  BILL DOMESTIC
05  =  TRADE        
06  =  บง   
07  =  ธล      
08  =  BIBF   
09  =  สต     
10  =  ADVANCE  
11  =  เงินสดและการชำระเงิน
12  =  เงินให้กู้ยืมแก่ผู้เช่าซื้อ
14  =  หนังสือค้ำประกันและภาระผูกพัน
99  =   อื่นๆ",
	acctno    	string       comment "เลขที่บัญชี",
	crtype    	integer      comment "ประเภทเครดิต",
	ficstype  	integer      comment "ประเภทหัวบัญชี",
	acctcust  	integer      comment "ประเภทลูกค้า ( ระดับบัญชี )",
	staffflag 	integer      comment "FLAG พนักงาน",
	closedate 	integer      comment "ปีเดือนวันที่ปิดบัญชี",
	npldate   	integer      comment "ปีเดือนวันที่เป็น NPL",
	buscod    	integer      comment "รหัสธุรกิจ 9 หลัก ( กสิกร )",
	busbot    	integer      comment "รหัสธุรกิจ ธปท.",
	busgrp    	integer      comment "ลำดับกลุ่มธุรกิจ",
	busgrpseq 	integer      comment "ลำดับกลุ่มธุรกิจย่อย",
	brno      	integer      comment "รหัสสาขา",
	deptno    	integer      comment "รหัสสังกัด",
	prvintfg  	integer      comment "FLAG การคิดดอกเบี้ยเดือนที่แล้ว
0=คิดดอกเบี้ยปกติ ,1= พัก/งดคิดดอกเบี้ย",
	prvstop   	integer      comment "ปีเดือนวันที่พักดอกเบี้ยเดือนที่แล้ว",
	acctgrp   	integer      comment "การจัดชั้นระดับบัญชีเชิงปริมาณ",
	prvdiff   	integer      comment "จำนวนวันค้างชำระสิ้นเดือน(จากระบบ)",
	clslevel  	integer      comment "ระดับการจัดชั้น
1- ปกติ 2-กล่าวถึง3-ต่ำกว่ามาตราฐาน4-สงสัย 
5-สงสัยจะสูญ 6-สูญ  9-ยกเลิกการสอบทาน/ปรับโครงสร้าง",
	clsfrom   	integer      comment "จัดชั้นคุณภาพจาก 1-สอบทาน ,2- ปรับโครงสร้าง",
	clsreason 	integer      comment "เหตุผลการจัดชั้น",
	acctresgrp	integer      comment "การจัดชั้นระดับบัญชีเชิงคุณภาพ",
	accnplgrp 	integer      comment "ระดับ NPL",
	prvoutreal	decimal(13,2)comment "ยอดจากระบบ",
	prvouts   	decimal(13,2)comment "ยอดคงค้างสิ้นเดือน(หลังตัดสูญทางบัญชี)",
	prvaccr   	decimal(13,2)comment "ยอดดอกเบี้ยค้างรับสิ้นเดือน(หลังตัดสูญทางบัญชี)",
	limit     	decimal(13,2)comment "วงเงิน",
	nplouts   	decimal(13,2)comment "ยอดคงค้าง NPL",
	nplaccr   	decimal(13,2)comment "ดอกเบี้ยค้างรับ NPL",
	prvpay    	decimal(13,2)comment "ยอดชำระเดือนที่แล้ว",
	prvextpay 	decimal(13,2)comment "ยอดชำระนอกการ์ดเดือนที่แล้ว",
	entdate   	integer      comment "ปีเดือนวันที่เข้ามาในระบบ",
	crbot     	integer      comment "ประเภทสินทรัพย์ธปท.",
	srcbr     	integer      comment "รหัสสาขาที่รายงานธปท.",
	srcbrseq  	integer      comment "ลำดับที่สาขาที่รายงานธปท.",
	area      	integer      comment "รหัสพื้นที่",
	dept      	integer      comment "รหัสสังกัด",
	reg       	integer      comment "รหัสภาค",
	zone      	integer      comment "รหัสเขต",
	div       	integer      comment "รหัสสาขา",
	sect      	integer      comment "รหัสส่วนงาน",
	acresgrpo 	integer      comment "ระดับจากวันค้างชำระระบบหรือปรับหรือสอบ (ไม่รวมสอบทานบางประเภท)",
	centerbr  	integer      comment "รหัสศูนยธุรกิจกรณีหนี้ exim bill / รหัส in-out out-out BIBF
BIBF = (ACCT TYPE = 8, 001 = IN-OUT, 002 = OUT-OUT)",
	currency  	integer      comment "รหัสสกุล",
	befouts   	decimal(13,2)comment "ยอดหนี้ก่อนตัดสูญ",
	befaccr   	decimal(13,2)comment "ยอดด/บค้างรับก่อนตัดสูญ",
	wrtbotflag	integer      comment "flag writeoff Bot
0=No write-off
1=Write-off",
	wrttfbflag	integer      comment "flag writeoff Tfb
0=No write-off
1=Write-off",
	recflag   	integer      comment "flag receive",
	prvrevflag	integer      comment "flag reverse accruยกเลิกการรับรู้รายได้
0 ไม่พักดอกเบี้ย = คิดดอกเบี้ย รับรู้เป็นรายได้ 
1  ระงับรับรู้รายได้    พักดอกเบี้ยตั้งแต่  1 มค 2543  โดยระบบต้นทาง 
2 ระงับรับรู้รายได้    พักดอกเบี้ยตั้งแต่  1 มค 2543  โดยระบบ LPM เมื่อ บัญชีมีสถานะคิดดอกเบี้ย แต่ มีการจัดชั้นระดับบัญชี ตั้งแต่ 4  ขึ้นไป 
3 ระงับรับรู้รายได้    พักดอกเบี้ยก่อน 1 มค 2543    แต่ต้องการให้ระบบคำนวนดอกเบี้ยนอกการ์ด
4 ดอกเบี้ยนอกการ์ด",
	prvrevdate	integer      comment "วันที่ยกเลิกการรับรู้รายได้",
	prvrevaccr	decimal(13,2)comment "ยอดด/บที่ยกเลิกรับรู้รายได้",
	prvmemaccr	decimal(13,2)comment "ยอดดอกเบี้ยนอกการ์ดเมื่อมีการยกเลิกการรับรู้รายได้",
	clsdate   	integer      comment "วันที่จัดชั้นจากการปรับโครงสร้าง/สอบทาน",
	drmemoflag	integer      comment "0 = บ/ช ปกติ, 1 = บ/ช ที่แปลงหนี้มาจากด/บ, 2 = Kbank priviledge
4= Home-Equity",
	clsdaydiff	integer      comment "จำนวนวันค้างชำระที่นับหลังปรํบโครงสร้างกรณี902 ปฏิบัติไม่ได้ /601ปฏิบัติได้ไม่ได้ล้างlate แล้วมาเสีย",
	npldaydiff	integer      comment "วันค้าง NPL",
	botacctgrp	integer      comment "จัดชั้นระดับบัญชีตามธปท.",
	collres   	decimal(13,2)comment "หลักประกันที่นำมาสำรองรายบัญชี",
	resouts   	decimal(13,2)comment "ยอดสำรองรายบัญชี",
	bcollres  	decimal(13,2)comment "หลักประกันที่นำมาสำรองรายบัญชีก่อนตัดสูญ",
	bresouts  	decimal(13,2)comment "ยอดสำรองรายบัญชีก่อนตัดสูญ",
	rectype   	integer      comment "ประเภทของ Record 
 1 = สินเชื่อ, 2 = Credit card block W, 3 = Trade contingent , 4 = LI , 5 = Aval  , 6 = Acceptance , 7 = ADL , 8 = ADI
 9 = Ploy, 0 = Dummy trade",
	resouts5  	decimal(13,2)comment "สำรองเพิ่มเติมตามเกณฑ์ ธปท.ระดับบัญชี",
	npvprov   	decimal(13,2)comment "สำรองส่วนสูญเสียจากการปรับโครงสร้างหนี้",
	cushion   	decimal(13,2)comment "สำรองส่วนเกินระดับบัญชี",
	befrevaccr	decimal(13,2)comment "ยอด REVERSE ที่พักดอกเบี้ยก่อนตัดสูญ",
	befmemaccr	decimal(13,2)comment "ยอดดอกเบี้ยนอกการ์ดเมื่อมีการยกเลิกการรับรู้รายได้ก่อนตัดสูญ",
	collreskb 	decimal(13,2)comment "หลักประกันที่นำมาสำรองรายบัญชีก่อนตัดสูญของ Kbank",
	resoutskb 	decimal(13,2)comment "ยอดสำรองรายบัญชีก่อนตัดสูญของ Kbank",
	resouts5kb	decimal(13,2)comment "สำรองเพิ่มเติมตามเกณฑ์ ธปท.ระดับบัญชีของ Kbank",
	npvprovkb 	decimal(13,2)comment "สำรองส่วนสูญเสียจากการปรับโครงสร้างหนี้ของ Kbank",
	provbasel 	decimal(13,2)comment "สำรองสำหรับ Basel II",
	legentity 	integer      comment "รหัสบริษัท",
	respcntr  	integer      comment "รหัสสังกัด",
	glaccount 	integer      comment "รหัสบัญชีประเภทเครดิต",
	function  	integer      comment "รหัสฟังก์ชันงาน",
	linebus   	integer      comment "รหัสประเภทธุรกิจ",
	glprodcd  	integer      comment "รหัสผลิตภัณฑ์สำหรับการบันทึกบัญชี",
	intercom  	integer      comment "รหัสบริษัทในการหักค่าใช้จ่ายระหว่างบริษัทในเครือ",
	intracom  	integer      comment "รหัสบริษัทในการหักค่าใช้จ่ายระหว่างฝ่ายงาน",
	project   	integer      comment "รหัสโครงการ",
	glfiller1 	integer      comment "สำหรับใช้ในอนาคต",
	glfiller2 	integer      comment "สำหรับใช้ในอนาคต",
	prodcd    	integer      comment "รหัสผลิตภัณฑ์",
	filler    	string       ,
	load_tms  	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id	string       comment "Source system ID",
	ptn_yyyy  	string       comment "Partition field - year",
	ptn_mm    	string       comment "Partition field - month",
	ptn_dd    	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_ln_cntg_clss_prvn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);