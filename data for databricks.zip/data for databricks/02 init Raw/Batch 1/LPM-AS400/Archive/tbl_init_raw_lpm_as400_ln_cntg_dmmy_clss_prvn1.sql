-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_lpm_as400_ln_cntg_dmmy_clss_prvn.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_LN_CNTG_DMMY_CLSS_PRVN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_ln_cntg_dmmy_clss_prvn (
	pos_dt    	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	tmid      	integer      comment "เดือนที่ประมวลผล",
	acctno    	string       comment "เลขที่บัญชี",
	accttype  	integer      comment "ประเภทบัญชี",
	crtype    	integer      comment "ประเภทเครดิต",
	cusno     	integer      comment "เลขที่ลูกหนี้",
	title     	string       comment "คำนำหน้า",
	name      	string       comment "ชื่อลูกหนี้",
	brno      	integer      comment "รหัสสาขา",
	deptno    	integer      comment "รหัสสังกัด",
	acctbuscod	integer      comment "รหัสประเภทธุรกิจ ระดับบัญชี",
	custbuscod	integer      comment "รหัสประเภทธุรกิจ ระดับลูกหนี้",
	ficstype  	integer      comment "ประเภทหัวบัญชี",
	prvdiff   	integer      comment "จำนวนวันขาดผ่อน",
	sprvouts  	string       comment "เครื่องหมาย PRVOUTS",
	prvouts   	decimal(13,2)comment "ยอดหนี้รวมดอกเบี้ย",
	sprvaccr  	string       comment "เครื่องหมาย PRVACCR",
	prvaccr   	decimal(13,2)comment "ยอดดอกเบี้ยค้างรับ",
	prvintfg  	integer      comment "Flag ดอกเบี้ย, 0-คิดดอกเบี้ย, 1-งดคิดดอกเบี้ย",
	acctcust  	integer      comment "ประเภทลูกค้า (ระดับบัญชี)",
	limit     	decimal(13,2)comment "วงเงิน ระดับบัญชี",
	deptcode  	integer      comment "รหัสสังกัด",
	bibfinout 	integer      comment "Flag BIBF, 1 - OUT-IN, 2 - OUT-OUT, 3 - PERSONAL OD",
	contdate  	integer      comment "วันที่ทำสัญญา",
	ratetype  	integer      comment "ประเภทอัตราดอกเบี้ย",
	sign      	integer      comment "0 =  + ,  1 =  - ",
	spread    	decimal(6,4) comment "ผลต่างของดอกเบี้ย",
	centerbr  	integer      comment "ศูนย์ธุรกิจต่างประเทศ",
	acctofctdr	integer      comment "สังกัดผู้ดูแล",
	duedate   	integer      comment "วันครบกำหนด",
	sbefouts  	string       comment "เครื่องหมาย BEFOUTS",
	befouts   	decimal(13,2)comment "ยอดหนี้ก่อนตัดสูญ",
	sbefaccr  	string       comment "เครื่องหมาย BEFACCR",
	befaccr   	decimal(13,2)comment "ยอดดอกเบี้ยคงค้างก่อนตัดสูญ",
	group2    	integer      comment "จัดชั้นกลุ่ม 2",
	assetfg   	integer      comment "FLAG สินทรัพย์",
	sprvextpay	string       comment "เครื่องหมาย PRVEXTPAY",
	prvextpay 	decimal(13,2)comment "ยอดส่วนลดรับ",
	custtype  	integer      comment "ประเภทลูกค้า (ระดับลูกหนี้)",
	botacctgrp	integer      comment "หนี้จัดชั้นตามธนาคารแห่งประเทศไทย",
	clsfrom   	integer      comment "รหัสการปรับโครงสร้างหนี้ 0, 1, 2, 3",
	clsdate   	integer      comment "ปีเดือนวันที่ปรับโครงสร้างหนี้",
	clsreason 	integer      comment "รหัสเหตุผลการปรับ เช่น 601, 901, 902",
	assetgp   	integer      comment "01-CG, 02-RT, 03-DR, 04-RN, 05-OTHERS (ฝ่าย นค)",
	proname   	integer      comment "ชื่อผลิตภัณฑ์ของธนาคาร (ฝ่าย นค)",
	segment   	integer      comment "กลุ่มผู้เป็นเจ้าของสินทรัพย์ หรือผู้ดูแล (ฝ่าย นค)",
	segmgeo   	integer      comment "กลุ่มผู้เป็นเจ้าของสินทรัพย์ หรือผู้ดูแล (ฝ่าย นค)",
	indus97   	string       comment "อุตสาหกรรม 97 อุตฯ  และผลิตภัณฑ์ (ฝ่าย นค)",
	indus100  	string       comment "อุตสาหกรรม 100 อุตฯ  และผลิตภัณฑ์ (ฝ่าย นค)",
	loaging   	integer      comment "จำแนกกลุ่มตามช่วงของวันค้าง แบบที่ 1",
	loaging2  	integer      comment "จำแนกกลุ่มตามช่วงของวันค้าง แบบที่ 2",
	incon97   	string       comment "การจำแนกอุตสาหกรรม 97 อย่างมีเงื่อนไข",
	incon100  	string       comment "การจำแนกอุตสาหกรรม 100 อย่างมีเงื่อนไข",
	rskind97  	integer      comment "อัตราดอกเบี้ย ตามความเสี่ยงของอุตสาหกรรม 97",
	rskind97cn	integer      comment "อัตราดอกเบี้ย ตามความเสี่ยงของอุตสาหกรรม 97",
	limitsub  	decimal(13,2)comment "ยอด Principal ลดลง หรือ Account หายไป)",
	duedate1  	integer      comment "วันครบกำหนด",
	contdate1 	integer      comment "วันทำสัญญา",
	cancelfg  	string       comment "Flag การยกเลิกของ Credit card",
	blockcd   	string       comment "Block code ของ Credit card",
	realrcfg  	string       ,
	assettype 	string       comment "ประเภทสินทรัพย์",
	lecsts    	decimal(4,2) comment "รหัสการดำเนินการในการดำเนินคดีLEC",
	colllim   	decimal(15,2)comment "วงเงินหลักประกัน",
	collval   	decimal(15,2)comment "ราคาประเมินที่กระจายแล้ว",
	acctofcfg 	integer      comment "Flag A/O รายบัญชี",
	lopurpose 	string       comment "จุดประสงค์การกู้เงิน",
	payfg     	string       comment "Flag การจ่ายเงิน",
	badcenter 	string       comment "Bad Center",
	resouts   	decimal(13,2)comment "ยอดหนี้สำรองระดับบัญชี",
	nplouts   	decimal(13,2)comment "ยอดเงินต้น+ดอกเบี้ยค้างรับที่เป็น NPL",
	nplaccr   	decimal(13,2)comment "ยอดดอกเบี้ยค้างรับที่เป็น NPL",
	sintrec   	string       comment "เครื่องหมาย INTREC",
	intrec    	decimal(13,2)comment "รายได้ดอกเบี้ย(เดือน)รายบัญชีที่ธนาคารรับรู้รายได้แล้ว",
	plstatu   	integer      comment "0=PL, 1=PRL
IF ACCT NPL GRP = 1,2 CLASS_FROM = 0,1  = PL
IF ACCT NPL GRP = 1,2 CLASS_FROM = 2  = PRL",
	acctofcrev	integer      comment "ผู้ดูแลลูกค้าก่อนหน้า (ผู้ดูแลลูกค้าเดิม)",
	effdate   	integer      comment "ปีเดือนวันที่เงื่อนไขการผ่อนชำระมีผลครั้งแรก",
	payyear   	integer      comment "ระยะเวลาที่ต้องผ่อนชำระ (เดือน)",
	nplyyyymm 	integer      comment "วันที่เริ่มเป็น NPL ล่าสุด",
	paymatu   	integer      ,
	fgdrawdown	integer      comment "0 = ใช้วงเงินไม่หมด
1 = ใช้วงเงินหมด",
	custrsts  	integer      comment "สถานะการเป็นลูกค้า Trade",
	sactpslimp	string       comment "เครื่องหมาย ACTPSLIMP",
	actpslimp 	decimal(15,2)comment "วงเงินอนุมัติ (ระดับ ACCT-TYPE-SUB)
ที่หักยอดที่ซ้ำออกแล้ว
สามารถนำมารวมได้เป็นวงเงินภาระผูกพันทั้ง Port ของธนาคาร",
	sexposamt 	string       comment "เครื่องหมาย EXPOSAMT",
	exposamt  	decimal(13,2)comment "ยอด Exposure",
	assetown  	string       ,
	loansize  	string       comment "จัดขนาดกลุ่มตามช่วงของ exposure",
	signprin  	string       comment "เครื่องหมาย PRINCIPAL",
	principal 	decimal(13,2)comment "ยอดเงินต้น",
	segmentgp 	string       comment "ประเภทกลุ่มผู้เป็นเจ้าของสินทรัพย์ หรือผู้ดูแล (ฝ่าย นค)",
	assetowngp	string       ,
	legentity 	integer      comment "รหัสบริษัท",
	respcntr  	integer      comment "รหัสสังกัด",
	glaccount 	integer      comment "รหัสบัญชีประเภทเครดิต",
	function  	integer      comment "รหัสฟังก์ชันงาน",
	linebus   	integer      comment "รหัสประเภทธุรกิจ",
	glprodcd  	integer      comment "รหัสผลิตภัณฑ์สำหรับการบันทึกบัญชี",
	intercom  	integer      comment "รหัสบริษัทในการหักค่าใช้จ่ายระหว่างบริษัทในเครือ",
	intracom  	integer      comment "รหัสบริษัทในการหักค่าใช้จ่ายระหว่างฝ่ายงาน",
	project   	integer      comment "รหัสโครงการ",
	glfiller1 	integer      comment "สำหรับใช้ในอนาคต",
	glfiller2 	integer      comment "สำหรับใช้ในอนาคต",
	prodcd    	integer      comment "รหัสผลิตภัณฑ์",
	load_tms  	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id	string       comment "Source system ID",
	ptn_yyyy  	string       comment "Partition field - year",
	ptn_mm    	string       comment "Partition field - month",
	ptn_dd    	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_ln_cntg_dmmy_clss_prvn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);