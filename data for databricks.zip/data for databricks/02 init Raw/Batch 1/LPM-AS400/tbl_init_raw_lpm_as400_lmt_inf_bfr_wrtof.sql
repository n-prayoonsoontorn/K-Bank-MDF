-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_lpm_as400_lmt_inf_bfr_wrtof.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-20    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_LMT_INF_BFR_WRTOF
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_lmt_inf_bfr_wrtof (
	pos_dt                       	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	lmd23500_cust_no             	integer       comment "เลขที่ลูกหนี้ LPM",
	lmd23500_acct_type           	integer       comment "ประเภทเครดิต",
	lmd23500_acct_type_sub       	string        comment "ประเภท Product ระดับ SUB หรือ เลขที่บัญชีระดับ SUB",
	lmd23500_prod_mode           	integer       comment "หมวดของ Product
01=สินเชื่อ         
02=ภาระผูกพัน
03=สินทรัพย์         
04=เงินลงทุน (ในระบบ LPM)
05=เงินลงทุน (นอกระบบ LPM)
99=อื่นๆ",
	lmd23500_br_no               	integer       comment "สาขา",
	lmd23500_acct_tp_sub_lim     	decimal       comment "วงเงินอนุมัติ (ระดับ ACCT-TYPE-SUB)",
	lmd23500_acct_tp_sub_lim_port	decimal       comment "วงเงินอนุมัติ (ระดับ ACCT-TYPE-SUB)
ที่หักยอดที่ซ้ำออกแล้ว
สามารถนำมารวมได้เป็นวงเงินภาระผูกพันทั้ง Port ของธนาคาร",
	lmd23500_acct_tp_sub_prin    	decimal       comment "เงินต้น (ระดับ ACCT-TYPE-SUB)",
	lmd23500_acct_tp_sub_accr    	decimal       comment "ดอกเบี้ย  (ระดับ ACCT-TYPE-SUB)",
	lmd23500_acct_tp_sub_con_dte1	integer       comment "วันที่เริ่มสัญญา 1",
	lmd23500_acct_tp_sub_due_dte1	integer       comment "วันที่ครบกำหนดสัญญา 1",
	lmd23500_acct_tp_sub_con_dte2	integer       comment "วันที่เริ่มสัญญา 2",
	lmd23500_acct_tp_sub_due_dte2	integer       comment "วันที่ครบกำหนดสัญญา 2",
	lmd23500_acct_tp_sub_con_dte3	integer       comment "วันที่เริ่มสัญญา 3",
	lmd23500_acct_tp_sub_due_dte3	integer       comment "วันที่ครบกำหนดสัญญา 3",
	lmd23500_acct_tp_sub_con_dte4	integer       comment "วันที่เริ่มสัญญา 4",
	lmd23500_acct_tp_sub_due_dte4	integer       comment "วันที่ครบกำหนดสัญญา 4",
	lmd23500_acct_tp_sub_con_dte5	integer       comment "วันที่เริ่มสัญญา 5",
	lmd23500_acct_tp_sub_due_dte5	integer       comment "วันที่ครบกำหนดสัญญา 5",
	lmd23500_acct_tp_sub_con_dte6	integer       comment "วันที่เริ่มสัญญา 6",
	lmd23500_acct_tp_sub_due_dte6	integer       comment "วันที่ครบกำหนดสัญญา 6",
	lmd23500_acct_tp_sub_con_dte7	integer       comment "วันที่เริ่มสัญญา 7",
	lmd23500_acct_tp_sub_due_dte7	integer       comment "วันที่ครบกำหนดสัญญา 7",
	lmd23500_fg_draw_down        	integer       comment "Flag การใช้วงเงินของเงินกู้
0 = ยังใช้วงเงินไม่หมด
1 = ใช้วงเงินหมดแล้ว",
	lmd23500_fg_pod              	string        comment "Flag POD เพื่อใช้แยกกรณีมี Acct-type = 2
0 = ไม่เป็น POD
1 = เป็น POD",
	lmd23500_cust_trade_status   	integer       comment "สถานะการใช้วงเงินของลูกค้า Trade",
	lmd23500_fg_in_active        	integer       comment "Flag Inactive
1 = ACTIVE  
0 = INACTIVE",
	lmd23500_limit_used          	integer       comment "Flag ของ Aval/Acceptance",
	lmd23500_debit_amt           	decimal       comment "ยอดที่เบิกใช้ เฉพาะ Loan",
	lmd23500_exposure_amt        	decimal       comment "ยอดที่ใช้",
	lmd23500_unuse_limit         	decimal       comment "วงเงินที่ใช้คำนวณวงเงินคงเหลือ Unuse Limit (ระดับ ACCT-TYPE-SUB)",
	lmd23500_group_cust_no       	integer       comment "เลขที่กลุ่มลูกค้า LPM",
	lmd23500_group_limit         	decimal       comment "วงเงินระดับกลุ่มลูกค้า ที่ได้รับอนุมัติ",
	load_tms                     	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id                   	string        comment "Source system ID",
	ptn_yyyy                     	string        comment "Partition field - year",
	ptn_mm                       	string        comment "Partition field - month",
	ptn_dd                       	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_lmt_inf_bfr_wrtof' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);