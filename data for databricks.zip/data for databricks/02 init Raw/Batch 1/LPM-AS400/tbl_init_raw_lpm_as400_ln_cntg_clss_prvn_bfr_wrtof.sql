-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_lpm_as400_ln_cntg_clss_prvn_bfr_wrtof.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-20    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_LN_CNTG_CLSS_PRVN_BFR_WRTOF
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_ln_cntg_clss_prvn_bfr_wrtof (
	pos_dt                    	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	l01w910_cust_no           	integer       ,
	l01w910_acct_type         	integer       ,
	l01w910_acct_no           	string        ,
	l01w910_cr_type           	integer       ,
	l01w910_fics_type         	integer       ,
	l01w910_acct_cust_type    	integer       ,
	l01w910_staff_flag        	integer       ,
	l01w910_close_date        	integer       ,
	l01w910_npl_date          	integer       ,
	l01w910_bus_code          	integer       ,
	l01w910_bus_bot           	integer       ,
	l01w910_bus_group         	integer       ,
	l01w910_bus_grp_seq       	integer       ,
	l01w910_branch_no         	integer       ,
	l01w910_dept_no           	integer       ,
	l01w910_prv_int_fg        	integer       ,
	l01w910_prv_stop_date     	integer       ,
	l01w910_acct_group        	integer       ,
	l01w910_prv_day_diff      	integer       ,
	l01w910_class_level       	integer       ,
	l01w910_class_from        	integer       ,
	l01w910_class_reason      	integer       ,
	l01w910_acct_res_group    	integer       ,
	l01w910_acct_npl_group    	integer       ,
	l01w910_r_prv_outs        	decimal(11,2) ,
	l01w910_prv_outs          	decimal(11,2) ,
	l01w910_prv_accru         	decimal(11,2) ,
	l01w910_limit             	decimal(11,2) ,
	l01w910_npl_outs          	decimal(11,2) ,
	l01w910_npl_accru         	decimal(11,2) ,
	l01w910_prv_pay           	decimal(11,2) ,
	l01w910_prv_ext_pay       	decimal(11,2) ,
	l01w910_enter_date        	integer       ,
	l01w910_cr_bot            	integer       ,
	l01w910_src_br            	integer       ,
	l01w910_src_br_seq        	integer       ,
	l01w910_area_code         	integer       ,
	l01w910_reg_code          	integer       ,
	l01w910_zone_code         	integer       ,
	l01w910_div_code          	integer       ,
	l01w910_acct_res_group_old	integer       ,
	l01w910_center_branch     	integer       ,
	l01w910_currency          	integer       ,
	l01w910_bef_outs          	decimal(11,2) ,
	l01w910_bef_accru         	decimal(11,2) ,
	l01w910_wrt_bot_flag      	integer       ,
	l01w910_wrt_tfb_flag      	integer       ,
	l01w910_rec_flag          	integer       ,
	l01w910_prv_reverse_flag  	integer       ,
	l01w910_prv_reverse_date  	integer       ,
	l01w910_prv_reverse_accru 	decimal(11,2) ,
	l01w910_prv_memo_accru    	decimal(11,2) ,
	l01w910_class_date        	integer       ,
	l01w910_dr_memo_flag      	integer       ,
	l01w910_cls_day_diff      	integer       ,
	l01w910_npl_day_diff      	integer       ,
	l01w910_bot_acct_group    	integer       ,
	l01w910_acct_coll_res     	decimal(11,2) ,
	l01w910_acct_res_outs     	decimal(11,2) ,
	l01w910_acct_b_coll_res   	decimal(11,2) ,
	l01w910_acct_b_res_outs   	decimal(11,2) ,
	l01w910_rec_type          	integer       ,
	l01w910_acct_res_outs_5   	decimal(11,2) ,
	l01w910_acct_npv_prov     	decimal(11,2) ,
	l01w910_acct_cushion      	decimal(11,2) ,
	l01w910_bef_reverse_accru 	decimal(11,2) ,
	l01w910_bef_memo_accru    	decimal(11,2) ,
	l01w910_acct_coll_res_kb  	decimal(11,2) ,
	l01w910_acct_res_outs_kb  	decimal(11,2) ,
	l01w910_acct_res_outs_5_kb	decimal(11,2) ,
	l01w910_acct_npv_prov_kb  	decimal(11,2) ,
	l01w910_provision_basel   	decimal(11,2) ,
	l01w910_legal_entity      	integer       ,
	l01w910_resp_center       	integer       ,
	l01w910_gl_account        	integer       ,
	l01w910_function          	integer       ,
	l01w910_line_business     	integer       ,
	l01w910_gl_product_code   	integer       ,
	l01w910_inter_company     	integer       ,
	l01w910_intra_company     	integer       ,
	l01w910_project           	integer       ,
	l01w910_gl_filler1        	integer       ,
	l01w910_gl_filler2        	integer       ,
	l01w910_product_code      	integer       ,
	l01w910_filler            	string        ,
	load_tms                  	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id                	string        comment "Source system ID",
	ptn_yyyy                  	string        comment "Partition field - year",
	ptn_mm                    	string        comment "Partition field - month",
	ptn_dd                    	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_ln_cntg_clss_prvn_bfr_wrtof' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);