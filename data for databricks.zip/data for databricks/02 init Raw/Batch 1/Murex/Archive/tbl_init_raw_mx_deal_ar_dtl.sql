-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_mx_deal_ar_dtl.sql
# Area: mx
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-12    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_MX.MX_DEAL_AR_DTL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_mx.mx_deal_ar_dtl (
	pos_dt         	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	haeder3        	integer(8)   ,
	dealref        	string       ,
	package_id     	string       ,
	contract       	decimal(10,0),
	nb             	decimal(10,0),
	trn_fmly       	string       ,
	trn_grp        	string       ,
	trn_type       	string       ,
	trn_typology   	string       ,
	portfolio      	string       ,
	cisid          	string       ,
	ctpy_short_name	string       ,
	prinamt        	decimal(19,2),
	princcy        	string       ,
	tradedate      	integer(8)   ,
	valuedate      	integer(8)   ,
	matdate        	integer(8)   ,
	sbtthb         	decimal(19,2),
	intrate        	decimal(19,6),
	intbasis       	string       ,
	ai_tdy_day     	decimal(5,0) ,
	ai_tdy_amt     	decimal(16,2),
	ai_mat_day     	decimal(5,0) ,
	ai_mat_amt     	decimal(16,2),
	intamt_ytd     	decimal(19,2),
	intamt_mtd     	decimal(19,2),
	si_method      	string       ,
	trader         	string       ,
	dealstatus     	string       ,
	dealtype       	string       ,
	buysell        	string       ,
	prem_disc      	decimal(19,2),
	ogl_acc        	string       ,
	interest_index 	string       ,
	spread         	decimal(24,11),
	notional       	decimal(25,8),
	int_pay_freq   	string       ,
	notional_move  	decimal(25,0),
	interest_move  	decimal(25,0),
	mop_status     	string       ,
	related_deal   	bigint(10)   ,
	load_tms       	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id     	string       comment "Source system ID",
	ptn_yyyy       	string       comment "Partition field - year",
	ptn_mm         	string       comment "Partition field - month",
	ptn_dd         	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_mx/mx_deal_ar_dtl' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);