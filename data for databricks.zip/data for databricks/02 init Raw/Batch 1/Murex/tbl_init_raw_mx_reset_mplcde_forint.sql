-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_mx_reset_mplcde_forint.sql
# Area: mx
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-20    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_MX.MX_RESET_MPLCDE_FORINT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_mx.mx_reset_mplcde_forint (
	pos_dt                              	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	record type                         	smallint     ,
	key                                 	string       comment "Description (Eng):Original customer ID
Description (Thai):เลขที่บัญชี",
	fullname                            	string       comment "Description (Eng):Original customer name
Description (Thai):ชื่อเต็มของบัญชี",
	parent                              	string       comment "Description (Eng):Parent original customer ID for check share limit 
Description (Thai):เลขที่บัญชีของ Parent สำหรับตรวจสอบการใช้วงเงินร่วมกัน",
	ib_corp                             	string       comment "Description (Eng):Customer type code
Description (Thai):บอกประเภทว่าเป็น Corporate หรือ InterBank",
	cis_id                              	string       comment "Description (Eng):Id of involved party
Description (Thai):เลขที่ลูกค้า CIS",
	counterparty_staus                  	string       comment "Description (Eng):Contract status
Description (Thai):สถานะของสัญญา",
	bad_bank                            	string       comment "Description (Eng):To identify bad customer 
Description (Thai):เป็น field ที่บอกว่าเป็นลูกค้า BadBank หรือไม่",
	csa_active                          	string       comment "Description (Eng):CSA Active flag
Description (Thai):สถานะของ CSA",
	mlc_ratingfitch                     	string       comment "Description (Eng):Counterparty rating from Fitch
Description (Thai): การจัดอันดับของสัญญาจาก Fitch",
	mlc_ratingmoodys                    	string       comment "Description (Eng):Counterparty rating from Moody's
Description (Thai):การจัดอันดับของสัญญาจาก Moody's",
	mlc_ratingstandardpoors             	string       comment "Description (Eng):Counterparty rating from Standard & Poor's
Description (Thai):การจัดอันดับของสัญญาจาก Standard & Poor's",
	kbankrating                         	string       comment "Description (Eng):Counterparty rating from Kbank
Description (Thai):การจัดอันดับของสัญญาจาก Kbank",
	group                               	string       comment "Description (Eng):Product group code
Description (Thai):ประเภทผลิตภัณฑ์",
	pillar                              	string       comment "Description (Eng):Pillar
Description (Thai):ระยะเวลาธุรกรรม",
	limit_parameter                     	string       comment "Description (Eng):Limit Parameter
Description (Thai):พารามิเตอร์ที่แสดงว่าอนุมัติวงเงินหรือไม่",
	limit_currency                      	string       comment "Description (Eng):Limit currency code
Description (Thai):สกุลของวงเงินที่อนุมัติ",
	limit_amount                        	decimal(24,2) comment "Description (Eng):Limit Amount
Description (Thai):วงเงิน",
	utilization_pfe                     	decimal(24,2) comment "Description (Eng):PFE utilization amount
Description (Thai):ยอดใช้วงเงิน PFE",
	utilization_net_mtm_non_csa         	decimal(24,2) comment "Description (Eng):Current exposure of all transaction not covered with CSA amount
Description (Thai):ภาระเครดิตปัจจุบันทั้งหมดที่ไม่รวม CSA",
	utilization_net_mtm_csa             	decimal(24,2) comment "Description (Eng):Current exposure of all transaction covered with CSA amount
Description (Thai):ภาระเครดิตปัจจุบันทั้งหมดที่รวม CSA",
	utilization_csa_margin              	decimal(24,2) comment "Description (Eng):CSA margin amount in limit currency amount
Description (Thai):ยอดรวม CSA margin ใน limit currency",
	utilization_net_mtm_after_collateral	decimal(24,2) comment "Description (Eng):Current exposure of all transaction covered with CSA after reduction by CSA margin amount
Description (Thai):ภาระเครดิตปัจจุบันทั้งหมดที่รวม CSA หลังจากหักลดด้วย CSA margin",
	utilization_net_mtm_bond_trade      	decimal(24,2) comment "Description (Eng):Current exposure of all bond trades amount
Description (Thai):ภาระเครดิตปัจจุบันของ bond trades",
	utilization_net_hair_cut_repo       	decimal(24,2) comment "Description (Eng):Current exposure of all repo transactions amount
Description (Thai):ภาระเครดิตปัจจุบันของ Repo transactions",
	utilization_total                   	decimal(24,2) comment "Description (Eng):Principal Amount
Description (Thai):ยอดค้าง",
	available                           	decimal(29,2) comment "Description (Eng):Available limit amount or over limit amount
Description (Thai):วงเงินที่คงเหลือ",
	utilization_pfe_                    	string       comment "Description (Eng):Percentage of counterparty PFE
Description (Thai): เปอร์เซ็นต์ที่ใช้วงเงิน PFE",
	utilization_total_                  	string       comment "Description (Eng):Percentage of counterparty PSE
Description (Thai):เปอร์เซ็นต์ที่ใช้วงเงิน PSE",
	maxcomment                          	string       comment "Description (Eng):Comment field
Description (Thai):Remark field ที่เก็บข้อมูลผสม",
	enginedate                          	date         comment "Description (Eng):Source system  date
Description (Thai):วันที่ของระบบ source",
	load_tms                            	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id                          	string       comment "Source system ID",
	ptn_yyyy                            	string       comment "Partition field - year",
	ptn_mm                              	string       comment "Partition field - month",
	ptn_dd                              	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_mx/mx_reset_mplcde_forint' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);