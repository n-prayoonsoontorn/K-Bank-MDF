-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_pcb_dep_extrate1.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_PCB_DEP.PCB_DEP_EXTRATE1
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_pcb_dep.pcb_dep_extrate1 (
	pos_dt    	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	sch       	string       comment "Rate Schedule Name",
	efd       	date         comment "Effective date",
	term      	integer      comment "Term of Certificate in Days (Term Increment)",
	mbalterm  	decimal(10,2)comment "Minimum Balance within Term",
	ratexbal  	decimal(3,5) comment "Rate associated with minimum balance",
	load_tms  	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id	string       comment "Source system ID",
	ptn_yyyy  	string       comment "Partition field - year",
	ptn_mm    	string       comment "Partition field - month",
	ptn_dd    	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_pcb_dep/pcb_dep_extrate1' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);