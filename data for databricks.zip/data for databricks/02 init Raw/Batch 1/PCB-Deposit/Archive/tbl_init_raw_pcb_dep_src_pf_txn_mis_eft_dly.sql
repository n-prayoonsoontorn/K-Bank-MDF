-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_pcb_dep_src_pf_txn_mis_eft_dly.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_PCB_DEP.PCB_DEP_SRC_PF_TXN_MIS_EFT_DLY
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_pcb_dep.pcb_dep_src_pf_txn_mis_eft_dly (
	pos_dt          	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	orig_txn_id     	string       comment "Def(En): Profile unique running number
Def(Th):",
	txn_dt          	timestamp    comment "Def(En): Transaction Date
Def(Th): วันที่ทำรายการ",
	txn_val_dt      	timestamp    comment "Def(En): The date that the transaction takes effect. For example, for check deposits, this will differ from the book date by the time it takes to clear the check; for Trades, this will be the settled date; etc.
Def(Th): วันที่รายการมีผล",
	txn_cd          	string       comment "Def(En): Transaction Code
Def(Th): รหัสการทำรายการ 4 หลัก (ความหมายเหมือนกับระบบ SAFE)",
	txn_tm          	string       comment "Def(En): Time of entry of the trasaction.This is the time assocoated with the Entry Date
Def(Th): เวลาที่ทำรายการ",
	txn_tms         	timestamp    comment "Def(En): Transaction Timestamp
Def(Th): วันเวลาที่ทำรายการ",
	cnl_id          	string       comment "Def(En): Channel identifies the different delivery and communications mechanisms through which products and services are made available to a customer and by which the Financial Institution and customers communicate with each other. Application Id
Def(Th): ระบบที่ทำรายการ",
	fm_ar_id        	string       comment "Def(En): From Arrangement Id
Def(Th): บัญชีของผู้ทำรายการ",
	to_ar_id        	string       comment "Def(En): To Arrangement Id
Def(Th): บัญชีผู้รับ",
	intr_zon_id     	string       comment "Def(En): Inter Zone Id
Def(Th): รหัสบ่งบอกการข้ามเขตสำนักหักบัญชี",
	txn_amt         	decimal(18,2)comment "Def(En): Transaction Amount
Def(Th): จำนวนเงินที่ทำรายการ",
	cmsn_amt        	decimal(18,2)comment "Def(En): Commission Amount
Def(Th): ค่าธรรมเนียมโอน",
	tel_amt         	decimal(18,2)comment "Def(En): Telephone Fee Amount
Def(Th): ค่าคู่สายโทรศัพท์",
	act_amt         	decimal(18,2)comment "Def(En): Actual amount 
Def(Th): จำนวนเงินที่จ่ายจริงในการทำรายการ

ACT_TXN_AMT = (TXN_AMT - CMSN_TXN_AMT + WV_FEE_AMT)
Example: โอน 10,000 บาท Commission 30 บาท Waive 10 บาท Field นี้จะมีค่าเป็น 9980 บาท (case หักจากปลายทาง)",
	wv_fee_amt      	decimal(18,2)comment "Def(En): Waive Fee 
Def(Th): จำนวนเงินลดหย่อน",
	fm_svc_br_no    	string       comment "Def(En): Service Branch Number
Def(Th): สาขาที่ทำรายการ",
	to_domc_br_no   	string       comment "Def(En): Domicile branch Number of The receiver 
Def(Th): สาขาบัญชีผู้รับ",
	fm_domc_br_no   	string       comment "Def(En): From arrangement branch number of the owner 
Def(Th): สาขาบัญชีของผู้ทำรายการ",
	fm_ar_pd_tp_cd  	string       comment "Def(En): Product type id  of the From arrangement
Def(Th): รหัสผลิตภัณฑ์ของผู้ทำรายการ",
	to_ar_pd_tp_cd  	string       comment "Def(En): Product type id  of the To arrangement
Def(Th): รหัสผลิตภัณฑ์ของผู้รับ",
	fm_coa_pd_ftr_cd	string       comment "Def(En): Product Feature code of the From arrangement
Def(Th): รหัสผลิตภัณฑ์ตามระบบบํญชีใหม่ของธนาคาร (KBANK New Chart of Accounts) ของผู้ทำรายการ",
	to_coa_pd_ftr_cd	string       comment "Def(En): Product Feature code of the To arrangement
Def(Th): รหัสผลิตภัณฑ์ตามระบบบํญชีใหม่ของธนาคาร (KBANK New Chart of Accounts) ของผู้รับ",
	usr_id          	string       comment "Def(En): User ID
Def(Th): ผู้ทำรายการที่สาขานั้น",
	txn_tp_cd       	string       comment "Def(En): Type of Operation
Def(Th): ประเภทของรายการ",
	chq_no          	string       comment "Def(En): Cheque Number
Def(Th): เลขที่เช็ค",
	chq_bnk_cd      	string       comment "Def(En): Cheque Bank ID
Def(Th): แบงก์ผู้ออกเช็ค",
	ppn_tms         	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	load_tms        	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id      	string       comment "Source system ID",
	ptn_yyyy        	string       comment "Partition field - year",
	ptn_mm          	string       comment "Partition field - month",
	ptn_dd          	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_pcb_dep/pcb_dep_src_pf_txn_mis_eft_dly' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);