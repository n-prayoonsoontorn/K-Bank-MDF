-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_rdm_card_tp_cd.sql
# Area: rdm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_RDM.RDM_CARD_TP_CD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_rdm.rdm_card_tp_cd (
	pos_dt         	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	name           	string       comment "Def(En):Card Name
Def(Th): Product name ของผลิตภัณฑ์บัตรเครดิต",
	code           	string       comment "Def(En):Unique key 
Def(Th):key ที่ใช้ในการ Mapping เพื่อให้ได้ card description detail",
	card_tp_cd     	string       comment "Def(En):Card Type Code
Def(Th): Card type ของระบบ CardLink",
	afinty_cd      	string       comment "Def(En):Affinity Code
Def(Th): รหัสสำหรับ Partner ที่ออกบัตรร่วมกับธนาคาร",
	plstic_cd      	string       comment "Def(En):Plastic Code
Def(Th): Plastic code ของแต่ละบัตร",
	card_nm_th     	string       comment "Def(En):Card Name Thai
Def(Th):",
	card_nm_shrt_en	string       comment "Def(En):Card Short Name English
Def(Th):",
	card_nm_shrt_th	string       comment "Def(En):Card Short Name Thai
Def(Th):",
	plstic_dsc     	string       comment "Def(En):Plastic Description - Card Name 2 (Plastic code level)
Def(Th):Product name ของผลิตภัณฑ์บัตรเครดิต แต่แยกย่อยหากมีหลายหน้าบัตรใน card type เดียวกัน",
	card_grp       	string       comment "Def(En):Card Group
Def(Th): กลุ่มของผลิตภัณฑ์แยกตามธุรกิจบัตร",
	card_issur     	string       comment "Def(En):Card Issuer
Def(Th): Issuer partner ของธนาคาร",
	kbnk_card_lvl  	string       comment "Def(En):Kbank Card Level
Def(Th): สีบัตร ตาม Definition ของ KBank",
	issur_card_lvl 	string       comment "Def(En):Issuer Card Level
Def(Th): สีบัตร ตาม Definition ของ Card Issuer",
	bin_no         	string       comment "Def(En):BIN No.
Def(Th): หมายเลขบัตร 8 หลักแรก",
	afinty_dsc     	string       comment "Def(En):Affinity Description
Def(Th): Partner name ที่ออกบัตรร่วมกับธนาคาร
              กรณี Affinity = 00 จะใช้ Description สำหรับการแยก CASH CARD, FLEET CARD, FLEET CARD RELOADED, THAI BEV CARD",
	pnt_cnsl_f_code	string       comment "Def(En): Point Consolidation Flag Code
Def(Th): รหัสตัวบ่งชี้ว่าเก็บคะแนนแบบรวมหรืแยก",
	pnt_cnsl_f_name	string       comment "Def(En): Point Consolidation Flag Name
Def(Th): คำอธิบายรหัสตัวบ่งชี้ว่าเก็บคะแนนแบบรวมหรืแยก",
	actv_f_code    	string       comment "Def(En):Active Flag
Def(Th):สถานะของข้อมูล (ใช้งาน/ยกเลิกการใช้งาน)",
	actv_f_name    	string       comment "Def(En):Active Flag Name
Def(Th):",
	rmrk           	string       comment "Def(En):Remark
Def(Th):หมายเหตุ",
	url            	string       comment "Def(En):URL Picture
Def(Th):",
	enterdatetime  	timestamp    comment "Def(En)Enter Date time
Def(Th):วันที่ใส่ข้อมูล",
	enterusername  	string       comment "Def(En):Enter User Name
Def(Th):ผู้ใส่ข้อมูล",
	lastchgdatetime	timestamp    comment "Def(En):Update Date
Def(Th):วันที่อัพเดทข้อมูล",
	lastchgusername	string       comment "Def(En):Update User Name
Def(Th):ผู้อัพเดทข้อมูล",
	load_tms       	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id     	string       comment "Source system ID",
	ptn_yyyy       	string       comment "Partition field - year",
	ptn_mm         	string       comment "Partition field - month",
	ptn_dd         	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_rdm/rdm_card_tp_cd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);