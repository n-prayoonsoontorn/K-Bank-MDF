-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_rdm_cst_ip_lgl_stc_tp_cd.sql
# Area: rdm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_RDM.RDM_CST_IP_LGL_STC_TP_CD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_rdm.rdm_cst_ip_lgl_stc_tp_cd (
	pos_dt          	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	ip_lgl_stc_tp_cd	string       comment "Description (Eng):Code that refer to involved party legal structure type
Description (Thai):รหัสบุคคล/นิติบุคคล",
	ip_tp_cd_code   	string       comment "Description (Eng):Code of involved party type  Code
Description (Thai):รหัสประเภทลูกค้า",
	ip_tp_cd_name   	string       comment "Description (Eng):Code of involved party type Name
Description (Thai):คำอธิบายรหัสประเภทลูกค้า",
	dsc_th          	string       comment "Description (Eng): Description in Thai
Description (Thai): คำอธิบายรหัสบุคคล/นิติบุคคลภาษาไทย",
	dsc_en          	string       comment "Description (Eng): Description in English
Description (Thai): คำอธิบายรหัสบุคคล/นิติบุคคลภาษาอังกฤษ",
	enterdatetime   	timestamp    comment "Description (Eng)Enter Date time
Description (Thai):วันที่ใส่ข้อมูล",
	enterusername   	string       comment "Description (Eng):Enter User Name
Description (Thai):ผู้ใส่ข้อมูล",
	lastchgdatetime 	timestamp    comment "Description (Eng):Update Date
Description (Thai):วันที่อัพเดทข้อมูล",
	lastchgusername 	string       comment "Description (Eng):Update User Name
Description (Thai):ผู้อัพเดทข้อมูล",
	load_tms        	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id      	string       comment "Source system ID",
	ptn_yyyy        	string       comment "Partition field - year",
	ptn_mm          	string       comment "Partition field - month",
	ptn_dd          	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_rdm/rdm_cst_ip_lgl_stc_tp_cd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);