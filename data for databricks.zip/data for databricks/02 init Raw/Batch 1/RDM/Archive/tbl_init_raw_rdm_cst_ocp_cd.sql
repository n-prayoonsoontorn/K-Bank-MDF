-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_rdm_cst_ocp_cd.sql
# Area: rdm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_RDM.RDM_CST_OCP_CD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_rdm.rdm_cst_ocp_cd (
	pos_dt               	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	name                 	string       comment "Description (Eng):Description in Thai
Description (Thai):คำอธิบายอาชีพภาษาไทย",
	code                 	string       comment "Description (Eng):Code of occupation
Description (Thai):รหัสอาชีพ",
	dsc_en               	string       comment "Description (Eng):Description in English
Description (Thai):คำอธิบายอาชีพภาษาอังกฤษ",
	actv_f_code          	string       comment "Description (Eng):Active Flag
Description (Thai):",
	actv_f_name          	string       comment "Description (Eng):Active Flag Name
Description (Thai):",
	dspl_seq             	decimal(38,0)comment "Description (Eng): Display Sequence
Description (Thai):",
	bot_emp_char_cd_code 	string       comment "Description (Eng): BOT Employment Characteristic Code
Description (Thai):  รหัสของลักษณะการจ้างงานของคู่สัญญาหรือบุคคลที่มีงานทำ",
	bot_emp_char_cd_name 	string       comment "Description (Eng): BOT Employment Characteristic Nane
Description (Thai):  คำอธิบายรหัสของลักษณะการจ้างงานของคู่สัญญาหรือบุคคลที่มีงานทำ",
	bot_emp_st_cd_code   	string       comment "Description (Eng): BOT Employment Status Code
Description (Thai): รหัสสถานะการทำงานของคู่สัญญาหรือบุคคล",
	bot_emp_st_cd_name   	string       comment "Description (Eng): BOT Employment Status Name
Description (Thai): คำอธิบายรหัสสถานะการทำงานของคู่สัญญาหรือบุคคล",
	ocp_grp_cd_code      	string       comment "Description (Eng): Occupation Group Code
Description (Thai): รหัสกลุ่มอาชีพ",
	ocp_grp_cd_name      	string       comment "Description (Eng): Occupation Group Name
Description (Thai): คำอธิบายรหัสกลุ่มอาชีพ",
	wrk_nm_rqe_f_code    	string       comment "Description (Eng): Work Name Require Flag Code
Description (Thai): รหัสสตัวบางชี้ว่าต้องการชื่อสถานที่ทำงานหรือไม่",
	wrk_nm_rqe_f_name    	string       comment "Description (Eng): Work Name Require Flag Name
Description (Thai): คำอธิบายรหัสสตัวบางชี้ว่าต้องการชื่อสถานที่ทำงานหรือไม่",
	wrk_adr_rqe_f_code   	string       comment "Description (Eng): Work Address Require Flag Code
Description (Thai): รหัสสตัวบางชี้ว่าต้องการที่อยู่สถานที่ทำงานหรือไม่",
	wrk_adr_rqe_f_name   	string       comment "Description (Eng): Work Address Require Flag Name
Description (Thai): คำอธิบายรหัสสตัวบางชี้ว่าต้องการที่อยู่สถานที่ทำงานหรือไม่",
	th_ip_lgl_stc_tp_cd  	string       comment "Description (Eng): Thai Involved Party Legal Structure Type Code
Description (Thai): รหัสประเภทบุคคล/นิติบุคคลสำหรับคนไทย",
	frng_ip_lgl_stc_tp_cd	string       comment "Description (Eng): Foreign Involved Party Legal Structure Type Code
Description (Thai): รหัสประเภทบุคคล/นิติบุคคลสำหรับคนต่างชาติ",
	enterdatetime        	timestamp    comment "Description (Eng)Enter Date time
Description (Thai):วันที่ใส่ข้อมูล",
	enterusername        	string       comment "Description (Eng):Enter User Name
Description (Thai):ผู้ใส่ข้อมูล",
	lastchgdatetime      	timestamp    comment "Description (Eng):Update Date
Description (Thai):วันที่อัพเดทข้อมูล",
	lastchgusername      	string       comment "Description (Eng):Update User Name
Description (Thai):ผู้อัพเดทข้อมูล",
	load_tms             	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id           	string       comment "Source system ID",
	ptn_yyyy             	string       comment "Partition field - year",
	ptn_mm               	string       comment "Partition field - month",
	ptn_dd               	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_rdm/rdm_cst_ocp_cd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);