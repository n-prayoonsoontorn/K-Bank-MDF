-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_rdm_cst_seg_cd.sql
# Area: rdm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_RDM.RDM_CST_SEG_CD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_rdm.rdm_cst_seg_cd (
	pos_dt         	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	code           	string       comment "Def(En): Code of segment which is a group of customer
Def(Th): รหัสกลุ่มลูกค้า",
	seg_cgy_cd_code	string       comment "Def(En): Segment Category Code
Def(Th): รหัสประเภท segment",
	seg_cgy_cd_name	string       comment "Def(En): Segment Category Name
Def(Th): คำอธิบายรหัสประเภท segment",
	dsc_th         	string       comment "Def(En): Description in Thai
Def(Th): คำอธิบายภาษาไทย",
	dsc_en         	string       comment "Def(En): Description in English
Def(Th): คำอธิบายภาษาอังกฤษ",
	grp            	string       comment "Def(En): Description of group
Def(Th): รายละเอียดกลุ่ม",
	sub_grp        	string       comment "Def(En): Description of sub group
Def(Th): คำอธิบายรายละเอียดกลุ่มย่อย",
	map_cd         	string       comment "Def(En): Customer segment mapped code for sending to SmartQ
Def(Th):",
	cst_seg_f_code 	string       comment "Def(En): Flag to indicate Customer Segment Code
Def(Th): รหัสตัวบ่งชี้แสดงสถานะของรหัสลูกค้าที่คำนวณตาม Wealth ของลูกค้าหรือไม่",
	cst_seg_f_name 	string       comment "Def(En): Flag to indicate Customer Segment Name
Def(Th):คำอธิบายรหัส ตัวบ่งชี้แสดงสถานะของรหัสลูกค้าที่คำนวณตาม Wealth ของลูกค้าหรือไม่",
	rm_seg_f_code  	string       comment "Def(En): Flag to indicate RM Segment Code
Def(Th): รหัสตัวบ่งชี้แสดงสถานะของรหัสSegment ว่าเป็นรหัสของผู้ดูแลหรือไม่",
	rm_seg_f_name  	string       comment "Def(En): Flag to indicate RM Segment Name
Def(Th): คำอธิบายตัวบ่งชี้แสดงสถานะของรหัสSegment ว่าเป็นรหัสของผู้ดูแลหรือไม่",
	actv_f_code    	string       comment "Def(En):Active Flag Code
Def(Th):รหัสบ่งชี้สถานะ",
	actv_f_name    	string       comment "Def(En):Active Flag Name
Def(Th):",
	enterdatetime  	timestamp    comment "Def(En)Enter Date time
Def(Th):วันที่ใส่ข้อมูล",
	enterusername  	string       comment "Def(En):Enter User Name
Def(Th):ผู้ใส่ข้อมูล",
	lastchgdatetime	timestamp    comment "Def(En):Update Date
Def(Th):วันที่อัพเดทข้อมูล",
	lastchgusername	string       comment "Def(En):Update User Name
Def(Th):ผู้อัพเดทข้อมูล",
	load_tms       	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id     	string       comment "Source system ID",
	ptn_yyyy       	string       comment "Partition field - year",
	ptn_mm         	string       comment "Partition field - month",
	ptn_dd         	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_rdm/rdm_cst_seg_cd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);