-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_rdm_cst_mar_st_cd.sql
# Area: rdm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-16    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_RDM.RDM_CST_MAR_ST_CD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_rdm.rdm_cst_mar_st_cd (
	pos_dt         	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	code           	string        comment "Def(En): Code of marital status
Def(Th): รหัสสถานภาพ",
	dsc_th         	string        comment "Def(En): Description in Thai
Def(Th): คำอธิบายสถานภาพภาษาไทย",
	dsc_en         	string        comment "Def(En): Description in English
Def(Th): คำอธิบายสถานภาพภาษาอังกฤษ",
	enterdatetime  	timestamp     comment "Def(En): Enter Date time
Def(Th): วันที่ใส่ข้อมูล",
	enterusername  	string        comment "Def(En): Enter User Name
Def(Th): ผู้ใส่ข้อมูล",
	lastchgdatetime	timestamp     comment "Def(En): Update Date
Def(Th): วันที่อัพเดทข้อมูล",
	lastchgusername	string        comment "Def(En): Update User Name
Def(Th): ผู้อัพเดทข้อมูล",
	load_tms       	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id     	string        comment "Source system ID",
	ptn_yyyy       	string        comment "Partition field - year",
	ptn_mm         	string        comment "Partition field - month",
	ptn_dd         	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_rdm/rdm_cst_mar_st_cd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);