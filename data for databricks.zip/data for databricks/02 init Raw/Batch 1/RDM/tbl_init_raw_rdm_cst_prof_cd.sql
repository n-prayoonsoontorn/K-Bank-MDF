-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_rdm_cst_prof_cd.sql
# Area: rdm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-16    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_RDM.RDM_CST_PROF_CD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_rdm.rdm_cst_prof_cd (
	pos_dt         	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	name           	string        comment "Description (Eng):Description in Thai
Description (Thai):คำอธิบายภาษาไทย",
	code           	string        comment "Description (Eng):Code of profession
Description (Thai):รหัสสาขาอาชีพ",
	dsc_en         	string        comment "Description (Eng):Description in English
Description (Thai):คำอธิบายภาษาอังกฤษ",
	rsk_f          	string        comment "Description (Eng):Flag that use to identify risk on the profession in term of bank's credit policy
Description (Thai):มีความเสี่ยงในเชิงนโยบายเครดิตหรือไม่",
	actv_f_code    	string        comment "Description (Eng):Active Flag Code
Description (Thai):รหัสบ่งชี้สถานะ",
	actv_f_name    	string        comment "Description (Eng):Active Flag Name",
	dspl_seq       	decimal(38,0) comment "Description (Eng): Display Sequence",
	enterdatetime  	timestamp     comment "Description (Eng)Enter Date time
Description (Thai):วันที่ใส่ข้อมูล",
	enterusername  	string        comment "Description (Eng):Enter User Name
Description (Thai):ผู้ใส่ข้อมูล",
	lastchgdatetime	timestamp     comment "Description (Eng):Update Date
Description (Thai):วันที่อัพเดทข้อมูล",
	lastchgusername	string        comment "Description (Eng):Update User Name
Description (Thai):ผู้อัพเดทข้อมูล",
	load_tms       	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id     	string        comment "Source system ID",
	ptn_yyyy       	string        comment "Partition field - year",
	ptn_mm         	string        comment "Partition field - month",
	ptn_dd         	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_rdm/rdm_cst_prof_cd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);