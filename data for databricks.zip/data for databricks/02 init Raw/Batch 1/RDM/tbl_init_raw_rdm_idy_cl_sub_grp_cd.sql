-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_rdm_idy_cl_sub_grp_cd.sql
# Area: rdm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-16    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_RDM.RDM_IDY_CL_SUB_GRP_CD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_rdm.rdm_idy_cl_sub_grp_cd (
	pos_dt             	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	name               	string        comment "Def(En):Description in Thai
Def(Th):คำอธิบายประเภทธุรกิจภาษาไทย",
	code               	string        comment "Def(En):Industry Classification Sub Group Code
Def(Th):รหัสกลุ่มอุตสาหกรรมระดับย่อย",
	dsc_en_std         	string        comment "Def(En):Description in English
Def(Th):คำอธิบายประเภทธุรกิจภาษาอังกฤษ",
	idy_cl_grp_cd_name 	string        comment "Def(En):Industry Classification Group Code
Def(Th):คำอธิบายรหัสกลุ่มอุตสาหกรรมระดับใหญ่",
	idy_cl_grp_cd_std  	string        comment "Def(En):Industry Classification Group Code
Def(Th):รหัสกลุ่มอุตสาหกรรมระดับใหญ่",
	ebitda_mrgn_pct_std	decimal(38,2) comment "Def(En): EBITDA Margin Percentage for segment Small / Formula lending (Pending for Approval)
(Earnings before interest, tax, depreciation and amortization as a percentage of total revenue)
Def(Th): อัตราส่วนกำไรก่อนค่าใช้จ่ายทางการเงิน ค่าใช้จ่ายภาษีเงินได้ ค่าเสื่อมราคาและค่าตัดจำหน่าย และการด้อยค่าของสินทรัพย์ ต่อรายได้รวม คำนวณสำหรับ segment Small / Formula lending",
	cash_ptn_std       	decimal(38,2) comment "Def(En): Cash Portion Percentage
Def(Th): อัตราส่วนรายรับจากเงินสด ต่อรายได้รวมของธุรกิจ",
	actv_f_name        	string        comment "Def(En):Active Flag
Def(Th):คำอธิบายรหัสบ่งชี้สถานะ",
	actv_f_std         	string        comment "Def(En):Active Flag
Def(Th):รหัสบ่งชี้สถานะ",
	load_tms           	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id         	string        comment "Source system ID",
	ptn_yyyy           	string        comment "Partition field - year",
	ptn_mm             	string        comment "Partition field - month",
	ptn_dd             	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_rdm/rdm_idy_cl_sub_grp_cd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);