-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_cis_ipxcontact.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-15    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CIS.CIS_IPXCONTACT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cis.cis_ipxcontact (
	pos_dt        	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	method        	string        comment "Description (Eng): Ingestion Method
Description (Thai): วิธีการนำเข้า",
	ipcont_ip_id  	integer       comment "Description (Eng): Customer id
Description (Thai): เลขที่ลูกค้า",
	ipcont_cont_id	bigint        comment "Description (Eng): Contact id
Description (Thai): เลขที่ Contact",
	ipcont_rel_tp 	string        comment "Description (Eng): Customer and Contact Relationship Type
Description (Thai): รหัสประเภทความสัมพันธ์ของลูกค้ากับ Contact",
	ipcont_stat   	string        comment "Description (Eng): Customer and Contact Relationship Status code
Description (Thai): รหัสสถานะความสัมพันธ์ของลูกค้ากับ Contact",
	ipcont_eft_dt 	date          comment "Description (Eng): Customer and Contact Relationship Effective date
Description (Thai): วันที่ผูกความสัมพันธ์",
	ipcont_exp_dt 	date          comment "Description (Eng): Customer and Contact Relationship Expire date
Description (Thai): วันที่ยกเลิกความสัมพันธ์",
	ipcont_user_id	string        comment "Description (Eng): User id
Description (Thai): รหัสผู้ทำรายการ",
	ipcont_upd_dt 	timestamp     comment "Description (Eng): Update date time
Description (Thai): วันและเวลาที่ทำรายการ",
	load_tms      	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id    	string        comment "Source system ID",
	ptn_yyyy      	string        comment "Partition field - year",
	ptn_mm        	string        comment "Partition field - month",
	ptn_dd        	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cis/cis_ipxcontact' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);