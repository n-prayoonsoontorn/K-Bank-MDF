-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_cis_conttp.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-20    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CIS.CIS_CONTTP
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cis.cis_conttp (
	pos_dt           	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	conttp_cd        	string        comment "Def(En): Contact Type code
Def(Th): รหัสประเภท Contact",
	conttp_local_desc	string        comment "Def(En): Contact Type description in Local language
Def(Th): คำอธิบายประเภท Contact ภาษาท้องถิ่น",
	conttp_en_desc   	string        comment "Def(En): Contact Type description in English
Def(Th): คำอธิบายประเภท Contact ภาษาอังกฤษ",
	conttp_user_id   	string        comment "Def(En): User id
Def(Th): รหัสผู้ทำรายการ",
	conttp_upd_dt    	timestamp     comment "Def(En): Update date time
Def(Th): วันและเวลาที่ทำรายการ",
	load_tms         	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id       	string        comment "Source system ID",
	ptn_yyyy         	string        comment "Partition field - year",
	ptn_mm           	string        comment "Partition field - month",
	ptn_dd           	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cis/cis_conttp' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);