-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_csm_product.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CSM.CSM_PRODUCT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_csm.csm_product (
	pos_dt       	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	prod_cd      	smallint(2)  comment "Description (Eng): Product Level Consent
Description (Thai): ความยินยอมระดับผลิตภัณฑ์",
	prod_th_desc 	string       comment "Description (Eng):Product Level Consent Thai description
Description (Thai):รายละเอียดภาษาไทย",
	prod_en_desc 	string       comment "Description (Eng):Product Level Consent English description
Description (Thai):รายละเอียดภาษาอังกฤษ",
	prod_status  	string       comment "Description (Eng):Product Level Consent status
Description (Thai):สถานะของ Product Level Consent",
	prod_upd_user	string       comment "Description (Eng):Update by UserID
Description (Thai):User ที่แก้ไขข้อมูล",
	prod_upd_dt  	timestamp    comment "Description (Eng):Update date
Description (Thai):วันที่อัพเดทข้อมูล",
	load_tms     	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id   	string       comment "Source system ID",
	ptn_yyyy     	string       comment "Partition field - year",
	ptn_mm       	string       comment "Partition field - month",
	ptn_dd       	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_csm/csm_product' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);