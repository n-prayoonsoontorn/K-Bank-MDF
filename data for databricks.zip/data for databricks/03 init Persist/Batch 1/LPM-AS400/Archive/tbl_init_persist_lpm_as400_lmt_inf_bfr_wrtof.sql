-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_lpm_as400_lmt_inf_bfr_wrtof.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-12    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_LPM_AS400.LPM_AS400_LMT_INF_BFR_WRTOF
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_lpm_as400.lpm_as400_lmt_inf_bfr_wrtof (
	pos_dt    	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	cusno     	integer(10)  comment "เลขที่ลูกหนี้ LPM",
	accttype  	integer(2)   comment "ประเภทเครดิต",
	accttypesb	string       comment "ประเภท Product ระดับ SUB หรือ เลขที่บัญชีระดับ SUB",
	prodmode  	integer(2)   comment "หมวดของ Product
01=สินเชื่อ         
02=ภาระผูกพัน
03=สินทรัพย์         
04=เงินลงทุน (ในระบบ LPM)
05=เงินลงทุน (นอกระบบ LPM)
99=อื่นๆ",
	brno      	integer(4)   comment "สาขา",
	actpslim  	decimal(15,2)comment "วงเงินอนุมัติ (ระดับ ACCT-TYPE-SUB)",
	actpslimp 	decimal(15,2)comment "วงเงินอนุมัติ (ระดับ ACCT-TYPE-SUB)
ที่หักยอดที่ซ้ำออกแล้ว
สามารถนำมารวมได้เป็นวงเงินภาระผูกพันทั้ง Port ของธนาคาร",
	actpsprin 	decimal(15,2)comment "เงินต้น (ระดับ ACCT-TYPE-SUB)",
	actpsaccr 	decimal(15,2)comment "ดอกเบี้ย  (ระดับ ACCT-TYPE-SUB)",
	actpscond1	integer(8)   comment "วันที่เริ่มสัญญา 1",
	actpsdued1	integer(8)   comment "วันที่ครบกำหนดสัญญา 1",
	actpscond2	integer(8)   comment "วันที่เริ่มสัญญา 2",
	actpsdued2	integer(8)   comment "วันที่ครบกำหนดสัญญา 2",
	actpscond3	integer(8)   comment "วันที่เริ่มสัญญา 3",
	actpsdued3	integer(8)   comment "วันที่ครบกำหนดสัญญา 3",
	actpscond4	integer(8)   comment "วันที่เริ่มสัญญา 4",
	actpsdued4	integer(8)   comment "วันที่ครบกำหนดสัญญา 4",
	actpscond5	integer(8)   comment "วันที่เริ่มสัญญา 5",
	actpsdued5	integer(8)   comment "วันที่ครบกำหนดสัญญา 5",
	actpscond6	integer(8)   comment "วันที่เริ่มสัญญา 6",
	actpsdued6	integer(8)   comment "วันที่ครบกำหนดสัญญา 6",
	actpscond7	integer(8)   comment "วันที่เริ่มสัญญา 7",
	actpsdued7	integer(8)   comment "วันที่ครบกำหนดสัญญา 7",
	fgdrawdown	integer(1)   comment "Flag การใช้วงเงินของเงินกู้
0 = ยังใช้วงเงินไม่หมด
1 = ใช้วงเงินหมดแล้ว",
	fgpod     	string       comment "Flag POD เพื่อใช้แยกกรณีมี Acct-type = 2
0 = ไม่เป็น POD
1 = เป็น POD",
	custrsts  	integer(1)   comment "สถานะการใช้วงเงินของลูกค้า Trade",
	fginactive	integer(1)   comment "Flag Inactive
1 = ACTIVE  
0 = INACTIVE",
	limitused 	integer(1)   comment "Flag ของ Aval/Acceptance",
	debtamt   	decimal(15,2)comment "ยอดที่เบิกใช้ เฉพาะ Loan",
	expos     	decimal(15,2)comment "ยอดที่ใช้",
	unuselmit 	decimal(17,2)comment "วงเงินที่ใช้คำนวณวงเงินคงเหลือ Unuse Limit (ระดับ ACCT-TYPE-SUB)",
	grpcusno  	integer(10)  comment "เลขที่กลุ่มลูกค้า LPM",
	grplimit  	decimal(17,2)comment "วงเงินระดับกลุ่มลูกค้า ที่ได้รับอนุมัติ",
	load_tms  	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id	string       comment "Source system ID",
	ptn_yyyy  	string       comment "Partition field - year",
	ptn_mm    	string       comment "Partition field - month",
	ptn_dd    	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_lpm_as400/lpm_as400_lmt_inf_bfr_wrtof' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);