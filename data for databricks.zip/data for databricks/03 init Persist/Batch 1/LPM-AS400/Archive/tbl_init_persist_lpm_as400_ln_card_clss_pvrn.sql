-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_lpm_as400_ln_card_clss_pvrn.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-12    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_LPM_AS400.LPM_AS400_LN_CARD_CLSS_PVRN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_lpm_as400.lpm_as400_ln_card_clss_pvrn (
	pos_dt         	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	cusno          	integer(10)  comment "เลขที่ลูกหนี้",
	title          	string       comment "คำนำหน้า",
	name           	string       comment "ชื่อลูกหนี้ *** 2 field นี้เอามาใส่ไว้ทุกบัญชี",
	accttype       	integer(2)   comment "ประเภทบัญชี",
	acctno         	string       comment "เลขที่บ/ช",
	crtype         	integer(3)   comment "ประเภทเครดิต",
	ficstype       	integer(7)   comment "รหัสหัวบัญชี fics",
	buscod         	integer(9)   comment "รหัสธุรกิจ",
	busbot         	integer(5)   comment "รหัสธุรกิจธปท.",
	busgrp         	integer(2)   comment "รหัสกลุ่มธุรกิจ",
	busgrpseq      	integer(1)   comment "ลำดับรหัสกลุ่มธุรกิจ",
	brno           	integer(3)   comment "สาชา",
	deptno         	integer(2)   comment "สังกัด",
	prvintfg       	integer(1)   comment "รหัสพักด/บ 0-ไม่พัก 1-พักด/บ",
	prvstop        	integer(8)   comment "วันที่พักด/บ",
	acctgrp        	integer(1)   comment "ระดับตามวันค้างจากระบบ",
	prvdiff        	integer(5)   comment "วันค้างชำระถูกต้อง",
	clslevel       	integer(1)   comment "ระดับจากการปรับฯหรือ สอบทาน",
	acctresgrp     	integer(1)   comment "ระดับตามการปรับฯ หากไม่ปรับจะเท่ากับระดับตามวันค้างระบบ",
	sprvouts       	string       comment "เครื่องหมาย +/-",
	prvouts        	decimal(13,2)comment "ยอดคงค้างเงินต้นหลังตัดสูญ",
	sprvaccr       	string       comment "เครื่องหมาย +/-",
	prvaccr        	decimal(13,2)comment "ยอดด/บคงค้างหลังตัดสูญ",
	limit          	decimal(13,2)comment "วงเงิน",
	prvpay         	decimal(13,2)comment "ยอดชำระ",
	acctnplgrp     	integer(1)   comment "ระดับ NPL",
	clsfrom        	integer(1)   comment "ปรับระดับการจัดชั้นจาก 1-สอบทาน 2- ปรับฯ 0-ไม่ทำ",
	clsreason      	integer(3)   comment "เหตุผลการปรับระดับการจัดชั้น",
	group2         	integer(1)   comment "ระดับการจัดชั้นรายลูกหนี้",
	grno           	integer(7)   comment "เลขที่กลุ่มล/น",
	sbefouts       	string       comment "เครื่องหมาย +/-",
	befouts        	decimal(13,2)comment "ยอดคงค้างเงินต้นก่อนตัดสูญ",
	sbefaccr       	string       comment "เครื่องหมาย +/-",
	befaccr        	decimal(13,2)comment "ยอดด/บคงค้างก่อนตัดสูญ",
	custtdrfg      	integer(1)   comment "ผลการปรับฯ จากระดับล/น 0-ไม่ปรับ1-ไม่ได้2-รอ3ได้ 4 ได้ทันที
มาจาก L12W909 ระดับลูกหนี้",
	oldgroup2      	integer(1)   comment "ระดับการจัดชั้นรายลูกหนี้เดือนก่อนหน้า
เช่น control 254510 ต้องการเดือนก่อนหน้า
มาจาก L01D042 CUST-NO + YYYYMM -control read greater",
	f1             	string       comment "เครื่องหมาย+/-",
	pay            	decimal(13,2)comment "ยอดชำระรวม",
	f2             	string       comment "เครื่องหมาย+/-",
	payprin        	decimal(13,2)comment "ชำระเงินต้น",
	f3             	string       comment "เครื่องหมาย+/-",
	payint         	decimal(13,2)comment "ชำระดอกในการ์ด",
	f4             	string       comment "เครื่องหมาย+/-",
	paymemo        	decimal(13,2)comment "ชำระส่วนด/บนอกการ์ด",
	f5             	string       comment "เครื่องหมาย+/-",
	paymisc        	decimal(13,2)comment "ชำระอื่นๆ",
	sintrec        	string       comment "เครื่องหมาย+/-",
	intrec         	decimal(13,2)comment "รายได้ดอกเบี้ยรับ",
	oldnpl         	integer(1)   comment "ระดับ NPLเดือนที่แล้ว(นำบ/ชและปีเดือนที่แล้วไปหา L01D041)
กรณีเป็นบ/ชใหม่(อ่านไม่พบ) มีค่าเท่ากับ 0",
	acctofctdr     	integer(3)   comment "สังกัดผู้ดูแล",
	center         	integer(10)  comment "สังกัดผู้ดูแล 10 หลัก",
	acctofcgb      	integer(3)   comment "รหัสผู้ดูแลกรณี AO 944/957 จะเก็บรหัส good bank จาก L12W909",
	botacctgrp     	integer(1)   comment "ระดับการจัดชั้นรายบัญชี",
	resouts        	decimal(13,2)comment "ยอดสำรองรายบัญชี",
	nplprin        	decimal(13,2)comment "ยอดเงินต้น  npl รายบ/ช",
	firstdrdt      	integer(8)   comment "วันที่ลงนามแรกจากการปรับฯ drd07200 แรก",
	lastdrdt       	integer(8)   comment "วันที่ลงนามหลังสุดจากการปรับฯ drd07200 ล่าสุด",
	tdrseq         	integer(3)   comment "ลำดับการปรับฯ ล่าสุด",
	tdrmethod      	string       comment "วิธีการปรับของการปรับฯล่าสุด",
	tdrremark      	string       comment "หมายเหตุวิธีการปรับของการปรับฯล่าสุด",
	drdaydiff      	integer(5)   comment "วันที่จากการปรับฯ (จากคล)",
	tdrrescodn     	integer(1)   comment "เงื่อนไขปลดปกติ
0-ไม่มีการปรับฯ 1-ปรับแบบปลดปกติคุ้มด/บ 2-ปรับแบบไม่คุ้มด/บ",
	pclsreason     	integer(3)   comment "รหัสเหตุผลการปรับก่อนหน้า
หาก class-date/class-level/class-reason <> 0 
นำ acct-no + class-date  ไปอ่าน L01D027key-desc 
หา record ถัดมาที่บ/ชเดียวกันแต่ class-date จะน้อยกว่า
หากพบข้อมูลดังกล่าวให้move class-reason มาใส่",
	acctofcpro     	integer(2)   comment "รหัสสินทรัพย์ระดับบ/ช",
	blockw         	integer(1)   comment "1-เป็นบัตรเครดิตติด block W 0-ไม่ใช้",
	collres        	decimal(13,2)comment "ยอดหลักประกันที่นำมาคำนวณสำรอง",
	sex            	string       comment "เพศ
'M' = MALE  
'F' = FEMALE",
	birthdate      	integer(8)   comment "วันเกิด",
	occup          	string       comment "อาชีพ",
	altcusno       	string       comment "เลขที่บัตรเสริม",
	acctcenter     	string       comment "รหัสสังกัด (ที่ลงบัญชี)",
	sysdaydiff     	integer(5)   comment "วันค้าง (จากระบบ)",
	crlineamt      	decimal(13,2)comment "วงเงินระดับลูกค้า",
	sbefprin       	string       comment "เครื่องหมาย+/-",
	befprin        	decimal(13,2)comment "เงินต้นก่อนตัดสูญ",
	smemoaccru     	string       comment "เครื่องหมาย+/-",
	memoaccru      	decimal(13,2)comment "ยอดดอกเบี้ยนอกการ์ด",
	srevaccru      	string       comment "เครื่องหมาย+/-",
	revaccru       	decimal(13,2)comment "ยอดดอกเบี้ย Reverse",
	ovrdueamt      	decimal(13,2)comment "ยอดค้างชำระ",
	ovrlimamt      	decimal(13,2)comment "ยอดที่เกินวงเงิน",
	ovrlimperc     	integer(5)   comment "เปอร์เซ็นของวงเงินที่เกิน",
	minpay         	decimal(13,2)comment "ยอดขั้นต่ำที่ต้องชำระ (เฉพาะ Card)",
	blockcode      	string       comment "Block Code (เฉพาะ Card)",
	cycle          	integer(2)   comment "Cycle (เฉพาะ Card)",
	usercode3      	string       comment "รหัส User Code 3 (เฉพาะ Card)",
	lstpaydate     	integer(8)   comment "วันจ่ายชำระครั้งสุดท้าย (เฉพาะ Card)",
	duedate        	integer(8)   comment "วันครบกำหนดชำระ",
	subprod        	integer(7)   comment "ประเภทผลิตภัณฑ์ย่อย",
	opendate       	integer(8)   comment "วันเปิดบัญชี",
	intrate        	string       comment "ประเภทอัตราดอกเบี้ย",
	sstmtbal       	string       comment "เครื่องหมาย+/-",
	stmtbal        	decimal(12,2)comment "จำนวนเงินที่ส่ง statement ไปเรียกเก็บลูกค้า",
	scashbal       	string       comment "เครื่องหมาย+/-",
	cashbal        	decimal(12,2)comment "จำนวนเงินที่ถอนเงินสด",
	sretailbal     	string       comment "เครื่องหมาย+/-",
	retailbal      	decimal(12,2)comment "จำนวนเงินใช้ซื้อสินค้าและบริการ",
	fpdfg          	string       comment "Flag ว่าเป็นการผิดนัดชำระครั้งแรกหรือไม่",
	lecsts         	decimal(4)   comment "สถานะ LEC ของลูกหนี้",
	sextpay        	string       comment "เครื่องหมาย+/-",
	extpay         	decimal(13,2)comment "ส่วนลดรับคงเหลือ",
	sacctresout5   	string       comment "เครื่องหมาย+/-",
	acct-res-outs-5	decimal(13,2)comment "ยอดสำรองเพิ่มตามเกณฑ์ ธปท.",
	ao-in-date     	integer(8)   ,
	issue-date     	integer(8)   ,
	block-date     	integer(8)   ,
	tdrltgflag     	string       comment "Flag TDR/LTG  โดย T= TDR L=LTG",
	idno           	string       ,
	legentity      	integer(3)   comment "รหัสบริษัท",
	respcntr       	integer(5)   comment "รหัสสังกัด",
	glaccount      	integer(7)   comment "รหัสบัญชีประเภทเครดิต",
	function       	integer(1)   comment "รหัสฟังก์ชันงาน",
	linebus        	integer(3)   comment "รหัสประเภทธุรกิจ",
	glprodcd       	integer(6)   comment "รหัสผลิตภัณฑ์สำหรับการบันทึกบัญชี",
	intercom       	integer(3)   comment "รหัสบริษัทในการหักค่าใช้จ่ายระหว่างบริษัทในเครือ",
	intracom       	integer(5)   comment "รหัสบริษัทในการหักค่าใช้จ่ายระหว่างฝ่ายงาน",
	project        	integer(4)   comment "รหัสโครงการ",
	glfiller1      	integer(7)   comment "สำหรับใช้ในอนาคต",
	glfiller2      	integer(4)   comment "สำหรับใช้ในอนาคต",
	prodcd         	integer(9)   comment "รหัสผลิตภัณฑ์",
	load_tms       	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id     	string       comment "Source system ID",
	ptn_yyyy       	string       comment "Partition field - year",
	ptn_mm         	string       comment "Partition field - month",
	ptn_dd         	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_lpm_as400/lpm_as400_ln_card_clss_pvrn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);