-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_lpm_as400_ln_cntg_clss_prvn_bfr_wrtof.sql
# Area: lpm-as/400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-12    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_LPM-AS/400.LPM_AS400_LN_CNTG_CLSS_PRVN_BFR_WRTOF
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_lpm-as/400.lpm_as400_ln_cntg_clss_prvn_bfr_wrtof (
	pos_dt    	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	cusno     	integer(10)  ,
	accttype  	integer(2)   ,
	acctno    	x(19)(19)    ,
	crtype    	integer(3)   ,
	ficstype  	integer(7)   ,
	acctcust  	integer(4)   ,
	staffflag 	integer(1)   ,
	closedate 	integer(8)   ,
	npldate   	integer(8)   ,
	buscod    	integer(9)   ,
	busbot    	integer(5)   ,
	busgrp    	integer(2)   ,
	busgrpseq 	integer(1)   ,
	brno      	integer(4)   ,
	deptno    	integer(2)   ,
	prvintfg  	integer(1)   ,
	prvstop   	integer(8)   ,
	acctgrp   	integer(1)   ,
	prvdiff   	integer(5)   ,
	clslevel  	integer(1)   ,
	clsfrom   	integer(1)   ,
	clsreason 	integer(3)   ,
	acctresgrp	integer(1)   ,
	acctnplgrp	integer(1)   ,
	prvoutreal	decimal(13,2),
	prvouts   	decimal(13,2),
	prvaccr   	decimal(13,2),
	limit     	decimal(13,2),
	nplouts   	decimal(13,2),
	nplaccr   	decimal(13,2),
	prvpay    	decimal(13,2),
	prvextpay 	decimal(13,2),
	entdate   	integer(8)   ,
	crbot     	integer(4)   ,
	srcbr     	integer(3)   ,
	srcbrseq  	integer(2)   ,
	area      	integer(1)   ,
	reg       	integer(2)   ,
	zone      	integer(2)   ,
	div       	integer(4)   ,
	acresgrpo 	integer(1)   ,
	centerbr  	integer(3)   ,
	currency  	integer(3)   ,
	befouts   	decimal(13,2),
	befaccr   	decimal(13,2),
	wrtbotflag	integer(1)   ,
	wrttfbflag	integer(1)   ,
	recflag   	integer(1)   ,
	prvrevflag	integer(1)   ,
	prvrevdate	integer(8)   ,
	prvrevaccr	decimal(13,2),
	prvmemaccr	decimal(13,2),
	clsdate   	integer(8)   ,
	drmemoflag	integer(1)   ,
	clsdaydiff	integer(5)   ,
	npldaydiff	integer(5)   ,
	botacctgrp	integer(1)   ,
	collres   	decimal(13,2),
	resouts   	decimal(13,2),
	bcollres  	decimal(13,2),
	bresouts  	decimal(13,2),
	rectype   	integer(1)   ,
	resouts5  	decimal(13,2),
	npvprov   	decimal(13,2),
	cushion   	decimal(13,2),
	befrevaccr	decimal(13,2),
	befmemaccr	decimal(13,2),
	collreskb 	decimal(13,2),
	resoutskb 	decimal(13,2),
	resouts5kb	decimal(13,2),
	npvprovkb 	decimal(13,2),
	provbasel 	decimal(13,2),
	legentity 	integer(3)   ,
	respcntr  	integer(5)   ,
	glaccount 	integer(7)   ,
	"function"	integer(1)   ,
	linebus   	integer(3)   ,
	glprodcd  	integer(6)   ,
	intercom  	integer(3)   ,
	intracom  	integer(5)   ,
	project   	integer(4)   ,
	glfiller1 	integer(7)   ,
	glfiller2 	integer(4)   ,
	prodcd    	integer(9)   ,
	filler    	string       ,
	load_tms  	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id	string       comment "Source system ID",
	ptn_yyyy  	string       comment "Partition field - year",
	ptn_mm    	string       comment "Partition field - month",
	ptn_dd    	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_lpm-as/400/lpm_as400_ln_cntg_clss_prvn_bfr_wrtof' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);