-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_lpm_as400_ln_cntg_clss_prvn_bfr_wrtof.sql
# Area: lpm-as/400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-14    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_LPM-AS/400.LPM_AS400_LN_CNTG_CLSS_PRVN_BFR_WRTOF
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_lpm-as/400.lpm_as400_ln_cntg_clss_prvn_bfr_wrtof (
	pos_dt    	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	cusno     	integer      ,
	accttype  	integer      ,
	acctno    	x(19)        ,
	crtype    	integer      ,
	ficstype  	integer      ,
	acctcust  	integer      ,
	staffflag 	integer      ,
	closedate 	integer      ,
	npldate   	integer      ,
	buscod    	integer      ,
	busbot    	integer      ,
	busgrp    	integer      ,
	busgrpseq 	integer      ,
	brno      	integer      ,
	deptno    	integer      ,
	prvintfg  	integer      ,
	prvstop   	integer      ,
	acctgrp   	integer      ,
	prvdiff   	integer      ,
	clslevel  	integer      ,
	clsfrom   	integer      ,
	clsreason 	integer      ,
	acctresgrp	integer      ,
	acctnplgrp	integer      ,
	prvoutreal	decimal(13,2),
	prvouts   	decimal(13,2),
	prvaccr   	decimal(13,2),
	limit     	decimal(13,2),
	nplouts   	decimal(13,2),
	nplaccr   	decimal(13,2),
	prvpay    	decimal(13,2),
	prvextpay 	decimal(13,2),
	entdate   	integer      ,
	crbot     	integer      ,
	srcbr     	integer      ,
	srcbrseq  	integer      ,
	area      	integer      ,
	reg       	integer      ,
	zone      	integer      ,
	div       	integer      ,
	acresgrpo 	integer      ,
	centerbr  	integer      ,
	currency  	integer      ,
	befouts   	decimal(13,2),
	befaccr   	decimal(13,2),
	wrtbotflag	integer      ,
	wrttfbflag	integer      ,
	recflag   	integer      ,
	prvrevflag	integer      ,
	prvrevdate	integer      ,
	prvrevaccr	decimal(13,2),
	prvmemaccr	decimal(13,2),
	clsdate   	integer      ,
	drmemoflag	integer      ,
	clsdaydiff	integer      ,
	npldaydiff	integer      ,
	botacctgrp	integer      ,
	collres   	decimal(13,2),
	resouts   	decimal(13,2),
	bcollres  	decimal(13,2),
	bresouts  	decimal(13,2),
	rectype   	integer      ,
	resouts5  	decimal(13,2),
	npvprov   	decimal(13,2),
	cushion   	decimal(13,2),
	befrevaccr	decimal(13,2),
	befmemaccr	decimal(13,2),
	collreskb 	decimal(13,2),
	resoutskb 	decimal(13,2),
	resouts5kb	decimal(13,2),
	npvprovkb 	decimal(13,2),
	provbasel 	decimal(13,2),
	legentity 	integer      ,
	respcntr  	integer      ,
	glaccount 	integer      ,
	"function"	integer      ,
	linebus   	integer      ,
	glprodcd  	integer      ,
	intercom  	integer      ,
	intracom  	integer      ,
	project   	integer      ,
	glfiller1 	integer      ,
	glfiller2 	integer      ,
	prodcd    	integer      ,
	filler    	string       ,
	load_tms  	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id	string       comment "Source system ID",
	ptn_yyyy  	string       comment "Partition field - year",
	ptn_mm    	string       comment "Partition field - month",
	ptn_dd    	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_lpm-as/400/lpm_as400_ln_cntg_clss_prvn_bfr_wrtof' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);