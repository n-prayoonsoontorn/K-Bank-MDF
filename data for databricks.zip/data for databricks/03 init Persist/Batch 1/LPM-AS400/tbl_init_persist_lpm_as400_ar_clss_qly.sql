-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_lpm_as400_ar_clss_qly.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-20    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_LPM_AS400.LPM_AS400_AR_CLSS_QLY
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_lpm_as400.lpm_as400_ar_clss_qly (
	pos_dt               	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	l01d027_acct_no      	string       comment "เลขที่บัญชี",
	l01d027_class_date   	integer      comment "วันที่การจัดชั้นคุณภาพ",
	l01d027_class_level  	integer      comment "ระดับการจัดชั้นคุณภาพ
1- ปกติ 2-กล่าวถึง3-ต่ำกว่ามาตราฐาน4-สงสัย 
5-สงสัยจะสูญ 6-สูญ",
	l01d027_class_by     	integer      comment "ฝ่ายงานที่จัดชั้นคุณภาพ",
	l01d027_class_from   	integer      comment "จัดชั้นคุณภาพจาก 
1-สอบทาน 2- ปรับโครงสร้าง 3-สอบทาน&ปรับโครงสร้าง",
	l01d027_class_reason 	integer      comment "เหตุผลการจัดชั้น",
	l01d027_class_detail1	string       comment "รายละเอียด",
	l01d027_class_detail2	string       comment "รายละเอียด",
	l01d027_class_tr_date	integer      comment "วันที่ทำรายการ",
	l01d027_entry_flag   	integer      comment "0=CONVERT BEFORE ENTRYFLAG  
1=UPDATE โดย PGM L01B034     
2=UPDATE โดย PGM L01B037     
3=UPDATE โดย PGM L01B787     
5=UPDATE โดย PGM DRB00901",
	l01d027_enter_date   	integer      ,
	l01d027_enter_user   	string       ,
	l01d027_update_date  	integer      ,
	l01d027_update_user  	string       ,
	l01d027_day_diff     	integer      comment "วันค้างชำระที่นับโดย manual",
	l01d027_day_diff1    	integer      ,
	load_tms             	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id           	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy             	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm               	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd               	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_lpm_as400/lpm_as400_ar_clss_qly' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);