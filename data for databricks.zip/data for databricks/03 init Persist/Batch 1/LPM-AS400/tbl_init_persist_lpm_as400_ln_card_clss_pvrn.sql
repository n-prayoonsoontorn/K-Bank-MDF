-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_lpm_as400_ln_card_clss_pvrn.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-20    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_LPM_AS400.LPM_AS400_LN_CARD_CLSS_PVRN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_lpm_as400.lpm_as400_ln_card_clss_pvrn (
	pos_dt                     	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	l01w181_cust_no            	bigint        comment "เลขที่ลูกหนี้",
	l01w181_cust_title         	string        comment "คำนำหน้า",
	l01w181_cust_name          	string        comment "ชื่อลูกหนี้ *** 2 field นี้เอามาใส่ไว้ทุกบัญชี",
	l01w181_acct_type          	smallint      comment "ประเภทบัญชี",
	l01w181_acct_no            	string        comment "เลขที่บ/ช",
	l01w181_cr_type            	smallint      comment "ประเภทเครดิต",
	l01w181_fics_type          	integer       comment "รหัสหัวบัญชี fics",
	l01w181_bus_code           	integer       comment "รหัสธุรกิจ",
	l01w181_bus_bot            	smallint      comment "รหัสธุรกิจธปท.",
	l01w181_bus_group          	smallint      comment "รหัสกลุ่มธุรกิจ",
	l01w181_bus_grp_seq        	smallint      comment "ลำดับรหัสกลุ่มธุรกิจ",
	l01w181_branch_no          	smallint      comment "สาชา",
	l01w181_dept_no            	smallint      comment "สังกัด",
	l01w181_prv_int_fg         	smallint      comment "รหัสพักด/บ 0-ไม่พัก 1-พักด/บ",
	l01w181_prv_stop_date      	integer       comment "วันที่พักด/บ",
	l01w181_acct_group         	smallint      comment "ระดับตามวันค้างจากระบบ",
	l01w181_prv_day_diff       	smallint      comment "วันค้างชำระถูกต้อง",
	l01w181_class_level        	smallint      comment "ระดับจากการปรับฯหรือ สอบทาน",
	l01w181_acct_res_group     	smallint      comment "ระดับตามการปรับฯ หากไม่ปรับจะเท่ากับระดับตามวันค้างระบบ",
	l01w181_prv_outs           	decimal(11,2) comment "ยอดคงค้างเงินต้นหลังตัดสูญ",
	l01w181_prv_accru          	decimal(11,2) comment "ยอดด/บคงค้างหลังตัดสูญ",
	l01w181_limit              	decimal(11,2) comment "วงเงิน",
	l01w181_prv_pay            	decimal(11,2) comment "ยอดชำระ",
	l01w181_acct_npl_group     	smallint      comment "ระดับ NPL",
	l01w181_class_from         	smallint      comment "ปรับระดับการจัดชั้นจาก 1-สอบทาน 2- ปรับฯ 0-ไม่ทำ",
	l01w181_class_reason       	smallint      comment "เหตุผลการปรับระดับการจัดชั้น",
	l01w181_group2             	smallint      comment "ระดับการจัดชั้นรายลูกหนี้",
	l01w181_gr_no              	integer       comment "เลขที่กลุ่มล/น",
	l01w181_sign_bef_outs      	string        comment "เครื่องหมาย +/-",
	l01w181_bef_outs           	decimal(11,2) comment "ยอดคงค้างเงินต้นก่อนตัดสูญ",
	l01w181_sign_bef_accru     	string        comment "เครื่องหมาย +/-",
	l01w181_bef_accru          	decimal(11,2) comment "ยอดด/บคงค้างก่อนตัดสูญ",
	l01w181_cust_tdr_flag      	smallint      comment "ผลการปรับฯ จากระดับล/น 0-ไม่ปรับ1-ไม่ได้2-รอ3ได้ 4 ได้ทันที
มาจาก L12W909 ระดับลูกหนี้",
	l01w181_old_group2         	smallint      comment "ระดับการจัดชั้นรายลูกหนี้เดือนก่อนหน้า
เช่น control 254510 ต้องการเดือนก่อนหน้า
มาจาก L01D042 CUST-NO + YYYYMM -control read greater",
	l01w181_f1                 	string        comment "เครื่องหมาย+/-",
	l01w181_pay                	decimal(11,2) comment "ยอดชำระรวม",
	l01w181_f2                 	string        comment "เครื่องหมาย+/-",
	l01w181_pay_principal      	decimal(11,2) comment "ชำระเงินต้น",
	l01w181_f3                 	string        comment "เครื่องหมาย+/-",
	l01w181_pay_int            	decimal(11,2) comment "ชำระดอกในการ์ด",
	l01w181_f4                 	string        comment "เครื่องหมาย+/-",
	l01w181_pay_memo           	decimal(11,2) comment "ชำระส่วนด/บนอกการ์ด",
	l01w181_f5                 	string        comment "เครื่องหมาย+/-",
	l01w181_pay_misc           	decimal(11,2) comment "ชำระอื่นๆ",
	l01w181_sign_receive       	string        ,
	l01w181_int_receive        	decimal(11,2) comment "รายได้ดอกเบี้ยรับ",
	l01w181_old_npl            	smallint      comment "ระดับ NPLเดือนที่แล้ว(นำบ/ชและปีเดือนที่แล้วไปหา L01D041)
กรณีเป็นบ/ชใหม่(อ่านไม่พบ) มีค่าเท่ากับ 0",
	l01w181_acct_ofc_tdr       	smallint      comment "สังกัดผู้ดูแล",
	l01w181_center             	bigint        comment "สังกัดผู้ดูแล 10 หลัก",
	l01w181_acct_ofc_gb        	smallint      comment "รหัสผู้ดูแลกรณี AO 944/957 จะเก็บรหัส good bank จาก L12W909",
	l01w181_bot_acct_group     	smallint      comment "ระดับการจัดชั้นรายบัญชี",
	l01w181_acct_res_outs      	decimal(11,2) comment "ยอดสำรองรายบัญชี",
	l01w181_npl_prin           	decimal(11,2) comment "ยอดเงินต้น  npl รายบ/ช",
	l01w181_first_tdr_date     	integer       comment "วันที่ลงนามแรกจากการปรับฯ drd07200 แรก",
	l01w181_last_tdr_date      	integer       comment "วันที่ลงนามหลังสุดจากการปรับฯ drd07200 ล่าสุด",
	l01w181_tdr_seq            	smallint      comment "ลำดับการปรับฯ ล่าสุด",
	l01w181_tdr_method         	string        comment "วิธีการปรับของการปรับฯล่าสุด",
	l01w181_tdr_remark         	string        comment "หมายเหตุวิธีการปรับของการปรับฯล่าสุด",
	l01w181_dr_day_diff        	smallint      comment "วันที่จากการปรับฯ (จากคล)",
	l01w181_tdr_res_cond       	smallint      comment "เงื่อนไขปลดปกติ
0-ไม่มีการปรับฯ 1-ปรับแบบปลดปกติคุ้มด/บ 2-ปรับแบบไม่คุ้มด/บ",
	l01w181_prv_class_reason   	smallint      comment "รหัสเหตุผลการปรับก่อนหน้า
หาก class-date/class-level/class-reason <> 0 
นำ acct-no + class-date  ไปอ่าน L01D027key-desc 
หา record ถัดมาที่บ/ชเดียวกันแต่ class-date จะน้อยกว่า
หากพบข้อมูลดังกล่าวให้move class-reason มาใส่",
	l01w181_acct_ofc_prod_fg   	smallint      comment "รหัสสินทรัพย์ระดับบ/ช",
	l01w181_block_w            	smallint      comment "1-เป็นบัตรเครดิตติด block W 0-ไม่ใช้",
	l01w181_acct_coll_res      	decimal(11,2) comment "ยอดหลักประกันที่นำมาคำนวณสำรอง",
	l01w181_sex                	string        comment "เพศ
'M' = MALE  
'F' = FEMALE",
	l01w181_birth_date         	integer       comment "วันเกิด",
	l01w181_occupation         	string        comment "อาชีพ",
	l01w181_alt_cust_no        	string        comment "เลขที่บัตรเสริม",
	l01w181_acct_center        	string        comment "รหัสสังกัด (ที่ลงบัญชี)",
	l01w181_sys_day_diff       	smallint      comment "วันค้าง (จากระบบ)",
	l01w181_cr_line_amt        	decimal(11,2) comment "วงเงินระดับลูกค้า",
	l01w181_sign_bef_prin      	string        comment "เครื่องหมาย+/-",
	l01w181_bef_prin           	decimal(11,2) comment "เงินต้นก่อนตัดสูญ",
	l01w181_sign_memo_accru    	string        comment "เครื่องหมาย+/-",
	l01w181_memo_accru         	decimal(11,2) comment "ยอดดอกเบี้ยนอกการ์ด",
	l01w181_sign_reverse_accru 	string        comment "เครื่องหมาย+/-",
	l01w181_reverse_accru      	decimal(11,2) comment "ยอดดอกเบี้ย Reverse",
	l01w181_overdue_amt        	decimal(11,2) comment "ยอดค้างชำระ",
	l01w181_overlimit_amt      	decimal(11,2) comment "ยอดที่เกินวงเงิน",
	l01w181_overlimit_percent  	smallint      comment "เปอร์เซ็นของวงเงินที่เกิน",
	l01w181_minimum_payment    	decimal(11,2) comment "ยอดขั้นต่ำที่ต้องชำระ (เฉพาะ Card)",
	l01w181_block_code         	string        comment "Block Code (เฉพาะ Card)",
	l01w181_cycle              	smallint      comment "Cycle (เฉพาะ Card)",
	l01w181_user_code3         	string        comment "รหัส User Code 3 (เฉพาะ Card)",
	l01w181_last_pay_date      	integer       comment "วันจ่ายชำระครั้งสุดท้าย (เฉพาะ Card)",
	l01w181_due_date           	integer       comment "วันครบกำหนดชำระ",
	l01w181_sub_prod_type_code 	integer       comment "ประเภทผลิตภัณฑ์ย่อย",
	l01w181_open_date          	integer       comment "วันเปิดบัญชี",
	l01w181_int_rate           	string        comment "ประเภทอัตราดอกเบี้ย",
	l01w181_sign_stmt_balance  	string        comment "เครื่องหมาย+/-",
	l01w181_stmt_balance       	decimal(10,2) comment "จำนวนเงินที่ส่ง statement ไปเรียกเก็บลูกค้า",
	l01w181_sign_cash_balance  	string        ,
	l01w181_cash_balance       	decimal(10,2) comment "จำนวนเงินที่ถอนเงินสด",
	l01w181_sign_retail_balance	string        comment "เครื่องหมาย+/-",
	l01w181_retail_balance     	decimal(10,2) comment "จำนวนเงินใช้ซื้อสินค้าและบริการ",
	l01w181_fpd_flag           	string        comment "Flag ว่าเป็นการผิดนัดชำระครั้งแรกหรือไม่",
	l01w181_lec_status         	decimal(2,2)  comment "สถานะ LEC ของลูกหนี้",
	l01w181_sign_ext_pay       	string        comment "เครื่องหมาย+/-",
	l01w181_ext_pay            	decimal(11,2) comment "ส่วนลดรับคงเหลือ",
	l01w181_sign_res_outs_5    	string        comment "เครื่องหมาย+/-",
	l01w181_acct_res_outs_5    	decimal(11,2) comment "ยอดสำรองเพิ่มตามเกณฑ์ ธปท.",
	l01w181_ao_in_date         	integer       ,
	l01w181_issue_date         	integer       ,
	l01w181_block_date         	integer       ,
	l01w181_tdr_ltg_flag       	string        comment "Flag TDR/LTG  โดย T= TDR L=LTG",
	l01w181_id_no              	string        ,
	l01w181_id_no              	string        ,
	l01w181_legal_entity       	smallint      comment "รหัสบริษัท",
	l01w181_resp_center        	smallint      comment "รหัสสังกัด",
	l01w181_gl_account         	integer       comment "รหัสบัญชีประเภทเครดิต",
	l01w181_function           	smallint      comment "รหัสฟังก์ชันงาน",
	l01w181_line_business      	smallint      comment "รหัสประเภทธุรกิจ",
	l01w181_gl_product_code    	integer       comment "รหัสผลิตภัณฑ์สำหรับการบันทึกบัญชี",
	l01w181_inter_company      	smallint      comment "รหัสบริษัทในการหักค่าใช้จ่ายระหว่างบริษัทในเครือ",
	l01w181_intra_company      	smallint      comment "รหัสบริษัทในการหักค่าใช้จ่ายระหว่างฝ่ายงาน",
	l01w181_project            	smallint      comment "รหัสโครงการ",
	l01w181_gl_filler1         	integer       comment "สำหรับใช้ในอนาคต",
	l01w181_gl_filler2         	smallint      comment "สำหรับใช้ในอนาคต",
	l01w181_product_code       	integer       comment "รหัสผลิตภัณฑ์",
	l01w181_provision_id       	bigint        ,
	load_tms                   	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id                 	string        comment "Source system ID",
	ptn_yyyy                   	string        comment "Partition field - year",
	ptn_mm                     	string        comment "Partition field - month",
	ptn_dd                     	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_lpm_as400/lpm_as400_ln_card_clss_pvrn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);