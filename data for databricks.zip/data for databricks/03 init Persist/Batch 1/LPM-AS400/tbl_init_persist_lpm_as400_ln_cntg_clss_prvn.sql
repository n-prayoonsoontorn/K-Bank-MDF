-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_lpm_as400_ln_cntg_clss_prvn.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-20    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_LPM_AS400.LPM_AS400_LN_CNTG_CLSS_PRVN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_lpm_as400.lpm_as400_ln_cntg_clss_prvn (
	pos_dt                    	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	l01w909_cust_no           	bigint        comment "เลขที่ลูกหนี้",
	l01w909_acct_type         	smallint      comment "ประเภทบัญชี
01  =  LOAN02  =  OD
03  =  CARD PACK  
04  =  BILL DOMESTIC05  =  TRADE        
06  =  บง   
07  =  ธล       
08  =  BIBF   
09  =  สต     
10  =  ADVANCE  
11  =  เงินสดและการชำระเงิน
12  =  เงินให้กู้ยืมแก่ผู้เช่าซื้อ
14  =  หนังสือค้ำประกันและภาระผูกพัน
99  =   อื่นๆ",
	l01w909_acct_no           	string        comment "เลขที่บัญชี",
	l01w909_cr_type           	smallint      comment "ประเภทเครดิต",
	l01w909_fics_type         	integer       comment "ประเภทหัวบัญชี",
	l01w909_acct_cust_type    	smallint      comment "ประเภทลูกค้า ( ระดับบัญชี )",
	l01w909_staff_flag        	smallint      comment "FLAG พนักงาน",
	l01w909_close_date        	integer       comment "ปีเดือนวันที่ปิดบัญชี",
	l01w909_npl_date          	integer       comment "ปีเดือนวันที่เป็น NPL",
	l01w909_bus_code          	integer       comment "รหัสธุรกิจ 9 หลัก ( กสิกร )",
	l01w909_bus_bot           	smallint      comment "รหัสธุรกิจ ธปท.",
	l01w909_bus_group         	smallint      comment "ลำดับกลุ่มธุรกิจ",
	l01w909_bus_grp_seq       	smallint      comment "ลำดับกลุ่มธุรกิจย่อย",
	l01w909_branch_no         	smallint      comment "รหัสสาขา",
	l01w909_dept_no           	smallint      comment "รหัสสังกัด",
	l01w909_prv_int_fg        	smallint      comment "FLAG การคิดดอกเบี้ยเดือนที่แล้ว 
0=คิดดอกเบี้ยปกติ ,1= พัก/งดคิดดอกเบี้ย",
	l01w909_prv_stop_date     	integer       comment "ปีเดือนวันที่พักดอกเบี้ยเดือนที่แล้ว",
	l01w909_acct_group        	smallint      comment "การจัดชั้นระดับบัญชีเชิงปริมาณ",
	l01w909_prv_day_diff      	smallint      comment "จำนวนวันค้างชำระสิ้นเดือน(จากระบบ)",
	l01w909_class_level       	smallint      comment "ระดับการจัดชั้น
1- ปกติ 2-กล่าวถึง3-ต่ำกว่ามาตราฐาน4-สงสัย 
5-สงสัยจะสูญ 6-สูญ  9-ยกเลิกการสอบทาน/ปรับโครงสร้าง",
	l01w909_class_from        	smallint      comment "จัดชั้นคุณภาพจาก 1-สอบทาน ,2- ปรับโครงสร้าง",
	l01w909_class_reason      	smallint      comment "เหตุผลการจัดชั้น",
	l01w909_acct_res_group    	smallint      comment "การจัดชั้นระดับบัญชีเชิงคุณภาพ",
	l01w909_acct_npl_group    	smallint      comment "ระดับ NPL",
	l01w909_r_prv_outs        	decimal(11,2) comment "ยอดจากระบบ",
	l01w909_prv_outs          	decimal(11,2) comment "ยอดคงค้างสิ้นเดือน(หลังตัดสูญทางบัญชี)",
	l01w909_prv_accru         	decimal(11,2) comment "ยอดดอกเบี้ยค้างรับสิ้นเดือน(หลังตัดสูญทางบัญชี)",
	l01w909_limit             	decimal(11,2) comment "วงเงิน",
	l01w909_npl_outs          	decimal(11,2) comment "ยอดคงค้าง NPL",
	l01w909_npl_accru         	decimal(11,2) comment "ดอกเบี้ยค้างรับ NPL",
	l01w909_prv_pay           	decimal(11,2) comment "ยอดชำระเดือนที่แล้ว",
	l01w909_prv_ext_pay       	decimal(11,2) comment "ยอดชำระนอกการ์ดเดือนที่แล้ว",
	l01w909_enter_date        	integer       comment "ปีเดือนวันที่เข้ามาในระบบ",
	l01w909_cr_bot            	smallint      comment "ประเภทสินทรัพย์ธปท.",
	l01w909_src_br            	smallint      comment "รหัสสาขาที่รายงานธปท.",
	l01w909_src_br_seq        	smallint      comment "ลำดับที่สาขาที่รายงานธปท.",
	l01w909_area_code         	smallint      comment "รหัสพื้นที่",
	l01w909_reg_code          	smallint      comment "รหัสภาค",
	l01w909_zone_code         	smallint      comment "รหัสเขต",
	l01w909_div_code          	smallint      comment "รหัสสาขา",
	l01w909_acct_res_group_old	smallint      ,
	l01w909_center_branch     	smallint      comment "รหัสศูนยธุรกิจกรณีหนี้ exim bill / รหัส in-out out-out BIBF
BIBF = (ACCT TYPE = 8, 001 = IN-OUT, 002 = OUT-OUT)",
	l01w909_currency          	smallint      comment "รหัสสกุล",
	l01w909_bef_outs          	decimal(11,2) comment "ยอดหนี้ก่อนตัดสูญ",
	l01w909_bef_accru         	decimal(11,2) comment "ยอดด/บค้างรับก่อนตัดสูญ",
	l01w909_wrt_bot_flag      	smallint      comment "flag writeoff Bot
0=No write-off
1=Write-off",
	l01w909_wrt_tfb_flag      	smallint      comment "flag writeoff Tfb
0=No write-off
1=Write-off",
	l01w909_rec_flag          	smallint      comment "flag receive",
	l01w909_prv_reverse_flag  	smallint      comment "flag reverse accruยกเลิกการรับรู้รายได้
0 ไม่พักดอกเบี้ย = คิดดอกเบี้ย รับรู้เป็นรายได้ 
1  ระงับรับรู้รายได้    พักดอกเบี้ยตั้งแต่  1 มค 2543  โดยระบบต้นทาง 
2 ระงับรับรู้รายได้    พักดอกเบี้ยตั้งแต่  1 มค 2543  โดยระบบ LPM เมื่อ บัญชีมีสถานะคิดดอกเบี้ย แต่ มีการจัดชั้นระดับบัญชี ตั้งแต่ 4  ขึ้นไป 
3 ระงับรับรู้รายได้    พักดอกเบี้ยก่อน 1 มค 2543    แต่ต้องการให้ระบบคำนวนดอกเบี้ยนอกการ์ด
4 ดอกเบี้ยนอกการ์ด",
	l01w909_prv_reverse_date  	integer       comment "วันที่ยกเลิกการรับรู้รายได้",
	l01w909_prv_reverse_accru 	decimal(11,2) comment "ยอดด/บที่ยกเลิกรับรู้รายได้",
	l01w909_prv_memo_accru    	decimal(11,2) comment "ยอดดอกเบี้ยนอกการ์ดเมื่อมีการยกเลิกการรับรู้รายได้",
	l01w909_class_date        	integer       comment "วันที่จัดชั้นจากการปรับโครงสร้าง/สอบทาน",
	l01w909_dr_memo_flag      	smallint      comment "0 = บ/ช ปกติ, 1 = บ/ช ที่แปลงหนี้มาจากด/บ, 2 = Kbank priviledge
4= Home-Equity",
	l01w909_cls_day_diff      	smallint      comment "จำนวนวันค้างชำระที่นับหลังปรํบโครงสร้างกรณี",
	l01w909_npl_day_diff      	smallint      comment "วันค้าง NPL",
	l01w909_bot_acct_group    	smallint      comment "จัดชั้นระดับบัญชีตามธปท.",
	l01w909_acct_coll_res     	decimal(11,2) comment "หลักประกันที่นำมาสำรองรายบัญชี",
	l01w909_acct_res_outs     	decimal(11,2) comment "ยอดสำรองรายบัญชี",
	l01w909_acct_b_coll_res   	decimal(11,2) comment "หลักประกันที่นำมาสำรองรายบัญชีก่อนตัดสูญ",
	l01w909_acct_b_res_outs   	decimal(11,2) comment "ยอดสำรองรายบัญชีก่อนตัดสูญ",
	l01w909_rec_type          	smallint      comment "ประเภทของ Record 
 1 = สินเชื่อ, 2 = Credit card block W, 3 = Trade contingent , 4 = LI , 5 = Aval  , 6 = Acceptance , 7 = ADL , 8 = ADI
 9 = Ploy, 0 = Dummy trade",
	l01w909_acct_res_outs_5   	decimal(11,2) ,
	l01w909_acct_npv_prov     	decimal(11,2) ,
	l01w909_acct_cushion      	decimal(11,2) ,
	l01w909_bef_reverse_accru 	decimal(11,2) ,
	l01w909_bef_memo_accru    	decimal(11,2) ,
	l01w909_acct_coll_res_kb  	decimal(11,2) ,
	l01w909_acct_res_outs_kb  	decimal(11,2) ,
	l01w909_acct_res_outs_5_kb	decimal(11,2) ,
	l01w909_acct_npv_prov_kb  	decimal(11,2) ,
	l01w909_provision_basel   	decimal(11,2) ,
	l01w909_legal_entity      	smallint      ,
	l01w909_resp_center       	smallint      ,
	l01w909_gl_account        	integer       ,
	l01w909_function          	smallint      ,
	l01w909_line_business     	smallint      ,
	l01w909_gl_product_code   	integer       ,
	l01w909_inter_company     	smallint      ,
	l01w909_intra_company     	smallint      ,
	l01w909_project           	smallint      ,
	l01w909_gl_filler1        	integer       ,
	l01w909_gl_filler2        	smallint      ,
	l01w909_product_code      	integer       ,
	l01w909_filler            	string        ,
	load_tms                  	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id                	string        comment "Source system ID",
	ptn_yyyy                  	string        comment "Partition field - year",
	ptn_mm                    	string        comment "Partition field - month",
	ptn_dd                    	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_lpm_as400/lpm_as400_ln_cntg_clss_prvn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);