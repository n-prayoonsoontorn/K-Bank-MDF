-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_mx_limiteffective.sql
# Area: mx
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-20    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_MX.MX_LIMITEFFECTIVE
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_mx.mx_limiteffective (
	pos_dt        	date        comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	record type   	smallint    ,
	report_date   	date        comment "Report Date",
	cis_id        	string      comment "CIS ID",
	ctp_short_name	string      comment "MX counterparty short name",
	limit_group   	string      comment "Limit group",
	effective_date	date        comment "Limit effective date",
	load_tms      	timestamp   comment "Ingestion job date and timestamp",
	src_sys_id    	string      comment "Source system ID",
	ptn_yyyy      	string      comment "Partition field - year",
	ptn_mm        	string      comment "Partition field - month",
	ptn_dd        	string      comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_mx/mx_limiteffective' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);