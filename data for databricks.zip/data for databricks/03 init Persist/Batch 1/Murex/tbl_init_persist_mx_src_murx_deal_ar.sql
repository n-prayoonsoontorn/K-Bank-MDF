-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_mx_src_murx_deal_ar.sql
# Area: mx
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-20    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_MX.MX_SRC_MURX_DEAL_AR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_mx.mx_src_murx_deal_ar (
	pos_dt         	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	rec_type       	smallint      ,
	header3        	integer       ,
	dealref        	string        ,
	package_id     	string        ,
	contract       	decimal       ,
	nb             	decimal       ,
	trn_fmly       	string        ,
	trn_grp        	string        ,
	trn_type       	string        ,
	trn_typology   	string        ,
	portfolio      	string        ,
	cisid          	string        ,
	ctpy_short_name	string        ,
	prinamt        	decimal       ,
	princcy        	string        ,
	tradedate      	integer       ,
	valuedate      	integer       ,
	matdate        	integer       ,
	sbtthb         	decimal       ,
	intrate        	decimal       ,
	intbasis       	string        ,
	ai_tdy_day     	decimal       ,
	ai_tdy_amt     	decimal       ,
	ai_mat_day     	decimal       ,
	ai_mat_amt     	decimal       ,
	intamt_ytd     	decimal       ,
	intamt_mtd     	decimal       ,
	si_method      	string        ,
	trader         	string        ,
	dealstatus     	string        ,
	dealtype       	string        ,
	buysell        	string        ,
	prem_disc      	decimal       ,
	ogl_acc        	string        ,
	interest_index 	string        ,
	spread         	decimal       ,
	notional       	decimal       ,
	int_pay_freq   	string        ,
	notional_move  	decimal       ,
	interest_move  	decimal       ,
	mop_status     	string        ,
	related_deal   	bigint        ,
	load_tms       	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id     	string        comment "Source system ID",
	ptn_yyyy       	string        comment "Partition field - year",
	ptn_mm         	string        comment "Partition field - month",
	ptn_dd         	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_mx/mx_src_murx_deal_ar' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);