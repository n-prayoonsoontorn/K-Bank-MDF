-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_pcb_dep_ar_mstr.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-13    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_PCB_DEP.PCB_DEP_AR_MSTR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_pcb_dep.pcb_dep_ar_mstr (
	pos_dt             	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	header3            	string       ,
	accountnumber      	string       ,
	reverseflag        	string       ,
	reversedate        	timestamp    ,
	delinquencyday     	string       ,
	delinquencydate    	timestamp    ,
	penaltyrttype      	string       ,
	penaltyrtsign      	string       ,
	penaltyrtspread    	string       ,
	maxrttype          	string       ,
	maxrtsign          	string       ,
	maxrtspread        	string       ,
	actualintamtinmonth	string       ,
	clearingamt        	string       ,
	legalentity        	string       ,
	responsibilitycode 	string       ,
	function           	string       ,
	linebusiness       	string       ,
	intercompany       	string       ,
	intracompany       	string       ,
	project            	string       ,
	load_tms           	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id         	string       comment "Source system ID",
	ptn_yyyy           	string       comment "Partition field - year",
	ptn_mm             	string       comment "Partition field - month",
	ptn_dd             	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_pcb_dep/pcb_dep_ar_mstr' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);