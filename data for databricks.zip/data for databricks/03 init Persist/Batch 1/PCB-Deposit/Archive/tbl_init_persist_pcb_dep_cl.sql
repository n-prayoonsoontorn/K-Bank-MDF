-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_pcb_dep_cl.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-13    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_PCB_DEP.PCB_DEP_CL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_pcb_dep.pcb_dep_cl (
	pos_dt      	date         comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	cl_scm_tp_id	string       comment "Def(En):Classification Scheme Type Id
Def(En):",
	cl_scm_id   	string       comment "Def(En):Classification Scheme Id
Def(En):",
	cl_id       	string       comment "Def(En):Classification Id
Def(En):",
	eff_dt      	date         comment "Def(En):Effective Date
Def(En):",
	prn_cl_id   	string       comment "Def(En):Parent Classification Id
Def(En):",
	cl_nm_eng   	string       comment "Def(En):English Classification Name
Def(En):",
	cl_nm_th    	string       comment "Def(En):Thai Classification Name
Def(En):",
	cl_nm_used  	string       comment "Def(En):Name used for Classification
Def(En):",
	sort_seq    	string       comment "Def(En):Sort Sequence
Def(En):",
	arthm_opr   	string       comment "Def(En):Arithmetic Operator
Def(En):",
	own         	string       comment "Def(En):Owner
Def(En):",
	end_dt      	date         comment "Def(En):End Date
Def(En):",
	mn_rng      	string       comment "Def(En):Minimum Range
Def(En):",
	mx_rng      	string       comment "Def(En):Maximum Range
Def(En):",
	load_tms    	timestamp    comment "Ingestion job date and timestamp",
	src_sys_id  	string       comment "Source system ID",
	ptn_yyyy    	string       comment "Partition field - year",
	ptn_mm      	string       comment "Partition field - month",
	ptn_dd      	string       comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_pcb_dep/pcb_dep_cl' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);