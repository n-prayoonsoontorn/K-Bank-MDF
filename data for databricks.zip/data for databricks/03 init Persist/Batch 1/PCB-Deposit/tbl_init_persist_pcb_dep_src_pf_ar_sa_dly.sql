-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_pcb_dep_src_pf_ar_sa_dly.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-20    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_PCB_DEP.PCB_DEP_SRC_PF_AR_SA_DLY
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_pcb_dep.pcb_dep_src_pf_ar_sa_dly (
	pos_dt              	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	rec_type            	string        comment "Record Type - This is to indicate the body record type (Detail record)",
	ar_id               	string        comment "Def(En): Arrangement Id is KBANK original account number. This account number must be unique
Def(Th): เลขที่บํญชี (Account number)",
	src_pos_dt          	date          comment "Position Date (Source) - This is the position date for daily and monthly which is the Calendar Month-end date of data.",
	ar_nm_th            	string        comment "Def(En): Arrangment Thai Name
Def(Th) : ชื่อบัญชีภาษาไทย",
	ar_nm_eng           	string        comment "Def(En): Arrangment English Name
Def(Th) : ชื่อบัญชีภาษาอังกฤษ",
	opn_dt              	date          comment "Def(En): Account open date
Def(Th): วันที่เปิดบัญชี",
	cls_dt              	date          comment "Def(En): Closed Date
Def(Th): วันที่ปิดบัญชี",
	ar_lcs_tp_id        	string        comment "Def(En): Arrangement life cycle status type ID
Def(Th): สถานะของบัญชี",
	cst_tp_id           	string        comment "Def(En): Customer type classified align with KBANK standard customer type
Def(Th): รหัสประเภทลูกค้าตามมาตรฐานการจัดประเภทลูกค้าของธนาคาร",
	bsn_code_id         	string        comment "Def(En):  Business code id is the business sector in which the arrangement/customer is belonged to. It should be align with KBANK stardard business code.
Def(Th): รหัสประเภทธุรกิจของลูกค้าหรือบัญชีของลูกค้า ตาม KBANK stardard business code",
	br_nbr              	string        comment "Def(En):  Branch Number, Code to represent KBank Branch, Domicile Branch
Def(Th): รหัสสาขาเจ้าของบัญชี",
	ccy_id              	string        comment "Def(En): This is the original currency of which the account is belonged to. The code for this field is character code e.g. THB, USD, EUR etc
Def(Th): รหัสสกุลเงินตาม ISO ตัวอย่างเช่น 'THB', 'USD'",
	otsnd_bal_amt       	decimal(18,2) comment "Def(En): Outstanding balance amount
Def(Th): จำนวนเงินของหนี้คงค้างรวมดอกเบี้ย, ยอดเงินคงเหลือ",
	opn_bal_amt         	decimal(18,2) comment "Def(En): This is the opening Balance of the account. 
Def(Th): จำนวนเงินที่เปิดบัญชี",
	cls_bal_amt         	decimal(18,2) comment "Def(En): Amount of deposits account  that have already been closed in last period (Principal + Interest)
Def(Th): ยอดเงินสุดท้ายก่อนการปิดบัญชี",
	last_cst_avy_dt     	date          comment "Def(En): The most recent date on which any Customer initiated activity related to the Arrangement took place.
Def(Th): วันที่ลูกค้ามาทำรายการวันล่าสุด",
	drmt_dys            	smallint      comment "Def(En): Dormant Days (The total number of days that customer didn't have any transaction with Kbank since his last contact date)
Def(Th): จำนวนวันที่ลูกค้าไม่ได้มีการติดต่อกับธนาคาร (นับตั้งแต่วันที่มีการติดต่อครั้งสุดท้าย)",
	psbk_no             	string        comment "Def(En): Passbook Number
Def(Th): เลขที่สมุดบัญชี",
	acr_bss_code        	string        comment "Def(En): Accrual Basis Code is the basis on which the interest accrual on an account is calculated. The accrual basis code should be set according to account’s original currency. The code is expected to be used instead of actual description. 
Def(Th): วิธีการคำนวณดอกเบี้ย โดยพิจารณาจาก จำนวนวันที่คำนวณดอกเบี้ยต่อเดือน/จำนวนวันที่คำนวณดอกเบี้ยต่อปี
ตัวอย่างเช่น 
ปล่อยสินเชื่อ 90 วัน ระบบคิดอัตราดอกเบี้ย  = จำนวนเงินต้น * อัตราดอกเบี้ย / 365 
โดยจำนวนวันที่ระบบจะทำการคิดดอกเบี้ยตามจำนวนวันจริง ณ สิ้นเดือน อย่างเช่น เดือนมกราคม เป็น 31 วัน.,เดือนกุมภาพันธ์ เป็น 29 วัน 
และ จำนวนวันที่ระบบจะทำการคิดดอกเบี้ยต่อปีเป็น 360  วัน
ดังนั้น accrual basis cd =  6 (Actual/ 365)
หมายเหตุ   actual เป็นจำนวนวันจริงที่คำนวณดอกเบี้ยต่อเดือน/ปีตามปฎิทิน",
	int_pymt_frq        	smallint      comment "Def(En): 
For lending, Interest Payment Frequency is the frequency in which the customer pays their interest. 
For deposit, Interest Payment Frequency is the frequency in which the bank pays interest to the customer.

Def(Th): 
กรณีเงินให้สินเชื่อ คือ ความถี่ในการจ่ายดอกเบี้ยของลูกค้าตามสัญญา 
กรณีเงินฝาก คือ ความถี่ในการจ่ายดอกเบี้ยของธนาคารให้กับลูกค้า",
	int_pymt_frq_unit   	string        comment "Def(En): 
For lending, it is Unit of measurement of Interest Payment Frequency when customer pays their interest.
For deposit, it is Unit of measurement of Interest Payment Frequency when the bank pays interest to the customer.
Def(Th): 
กรณีเงินให้สินเชื่อ คือ หน่วยของความถี่ของการจ่ายดอกเบี้ยของลูกค้า
กรณีเงินฝาก คือ หน่วยของความถี่ของการจ่ายดอกเบี้ยของธนาคาร",
	last_int_pymt_dt    	date          comment "Def(En): 
For lending, Last Interest Payment Date is the date in which the interest payment is last scheduled before position date.
For deposit, Last Interest Payment Date is the latest date in which the bank pays interest to the customer.
Def(Th): 
กรณีเงินให้สินเชื่อ คือ วันที่ลูกค้าชำระดอกเบี้ยครั้งล่าสุดก่อนวันที่ส่งข้อมูล
กรณีเงินฝาก คือ วันที่ธนาคารจ่ายดอกเบี้ยให้กับลูกค้าครั้งล่าสุด",
	nxt_int_pymt_dt     	date          comment "Def(En): 
For lending, Next Interest Payment Date is the date in which the interest payment is next scheduled nearest to position date.
For deposit, Next Interest Payment Date is the bank will pay interest next time.
Def(Th): 
กรณีเงินให้สินเชื่อ คือ วันที่ลูกค้าจะชำระดอกเบี้ยครั้งถัดไป 
กรณีเงินฝาก คือ วันที่ธนาคารจะชำระดอกเบี้ยครั้งถัดไป",
	cmpd_frq            	smallint      comment "Def(En): Frequency by which interest is compounded in which the customer has to pay the bank
Def(Th): ความถี่ของดอกเบี้ยที่ทบรวมเงินต้น ที่ทางลูกค้าจะต้องจ่ายให้กับทางแบงค์",
	cmpd_frq_unit       	string        comment "Def(En): Unit of measurement of Compound Frequency in which the customer has to pay the bank
Def(Th): หน่วยของความถี่ของดอกเบี้ยที่ทบรวมเงินต้น ที่ทางลูกค้าจะต้องจ่ายให้กับทางแบงค์",
	int_ctn_clc_bss_id  	string        comment "Def(En): Interest computation calculation basis ID
Def(Th): รหัสวิธีการคำนวณดอกเบี้ย",
	int_ctn_clc_prd_id  	string        comment "Def(En): Interest computation calculation period ID
Def(Th): รหัสช่วงเวลาที่ใช้ในการคำนวนดอกเบี้ย",
	eff_int_rate        	decimal(9,5)  comment "Def(En): Effective interest rate is the current interest rate give to customer.
Def(Th): อัตราดอกเบี้ยที่แท้จริงที่ใช้ในการคำนวณดอกเบี้ย ณ ปัจจุบัน
Include spread rate",
	int_eff_dt          	date          comment "Def(En): Interest Rate Effective Date
Def(Th): วันที่อัตราดอกเบี้ยที่แท้จริงที่ใช้ในการคำนวณดอกเบี้ยเริ่มมีผล",
	int_end_dt          	date          comment "Def(En): Interest Rate End Date
Def(Th): วันที่อัตราดอกเบี้ยที่แท้จริงที่ใช้ในการคำนวณดอกเบี้ยสิ้นสุด",
	eff_int_rate_tp_id  	string        comment "Def(En): Effective Interest Rate Type Id
Def(Th): ประเภทของดอกเบี้ย",
	int_rate_ind        	string        comment "Def(En): Interest Rate Indicator
Def(Th): รหัสประเภทของดอกเบี้ย (ปกติ, พิเศษ)",
	eff_sprd_int_rate   	decimal(9,5)  comment "Def(En): Effective Spread Interest Rate
Def(Th): สเปรด เรท",
	acr_int_pbl_amt     	decimal(18,2) comment "Def(En):  Accrued Interest Payable Amount
Def(Th): ดอกเบี้ยสะสม",
	int_paid_amt        	decimal(18,2) comment "Def(En): Interest amount that already paid to customer on that business day. If no interest payment then 0.
Def(Th): ดอกเบี้ยที่จ่ายจริงให้กับลูกค้าในวันนั้น ถ้าในวันนั้นไม่มีการจ่ายดอกเบี้ยจะมีค่าเป็น 0",
	int_cal_st_id       	string        comment "Def(En):  Interest Calculation Status
Def(Th): รหัสประเภทการคิดดอกเบี้ย เช่น 9 หยุดคิดดอกเบี้ย",
	coa_ac              	string        comment "Def(En): Chart of Accounts account code is KBANK New GL-account number in which the account is belonged to
The 1st Digit = nature of accounts, 
A leading 1 indicates Asset
A leading 2 indicates Liabilities
A leading 3 indicates Shareholder's equity
A leading 4 indicates Revenues
A leading 5 indicates Interest expenses
A leading 6 indicates Non interest expenses
A leading 7 indicates Off balance sheet items
A leading 8 indicates Memo accounts
The 2nd & 3rd Digit = group of nature of accounts
A “01” indicates Cash
A “02” indicates ….
The 4th Digit = sub-group of nature of accounts
5th - 7th digit = Block Range of Account Codes
Def(Th): รหัสบัญชีแยกประเภทตามผังการลงบัญชีใหม่ของธนาคาร (KBANK New GL-account number)",
	coa_pd              	string        comment "Def(En): Chart of Accounts product code is KBANK New GL-product number 
1st - 2nd digits = Product Group
3rd - 4th digits = Product Sub-Group 
5th - 6th digits = Product (or service)
7th - 9th digits = Product Feature (not in the new GL system)
Def(Th): รหัสผลิตภัณฑ์ตามระบบบํญชีใหม่ของธนาคาร (KBANK New Chart of Accounts)",
	coa_pd_ftr_code     	string        comment "Def(En): Chart of Accounts product feature code  is KBANK New GL-product number 
1st - 2nd digits = Product Group
3rd - 4th digits = Product Sub-Group 
5th - 6th digits = Product (or service)
7th - 9th digits = Product Feature (not in the new GL system)
Def(Th): รหัสผลิตภัณฑ์ตามระบบบํญชีใหม่ของธนาคาร (KBANK New Chart of Accounts)",
	hld_bal_amt         	decimal(18,2) comment "Def(En) : Hold Balance Amount
Def(Th): จำนวนเงินที่ห้ามถอน ตัวอย่างเช่นเพื่อกันไว้เป็นหลักประกัน",
	cnvr_esvg_dt        	date          comment "Def(En): Effective Date when the arrangement change to e-saving (Nobook)
Def(Th): วันที่เปลี่ยนบัญชีเป็น e-saving",
	cnvr_esvg_tm        	string        comment "Def(En): Time when the arrangement change to e-saving (Nobook)
Def(Th): เวลาที่เปลี่ยนบัญชีเป็น e-saving",
	cnvr_esvg_dvc_id    	string        comment "Def(En): Device Id where the arrangement change to e-saving (Nobook)
Def(Th): เครื่องที่ทำรายการเปลี่ยนบัญชีเป็น e-saving",
	cnvr_esvg_svc_br_nbr	string        comment "Def(En): Service branch where the arrangement change to e-saving (Nobook)
Def(Th): สาขาที่ทำรายการเปลี่ยนบัญชีเป็น e-saving",
	cnvr_esvg_f         	string        comment "Def(En): Flag if the arrangement is E-Saving account
Def(Th): รหัสบ่งชี้ว่าบัญชีเป็น e-saving",
	pcb_int_idnx        	string        ,
	int_paid_life       	decimal(15,2) ,
	int_paid_pr_year    	decimal(15,2) ,
	int_ytd             	decimal(15,2) ,
	back_wht_flg        	string        ,
	back_wht_pr_year    	decimal(20,2) ,
	back_wht_ytd        	decimal(20,2) ,
	tax_owner           	string        ,
	intwcalc            	string        ,
	tax_key             	string        ,
	srty_ar_f           	string        ,
	block_ind           	string        ,
	allow_flag          	string        ,
	tax_id              	string        ,
	citizen_id          	string        ,
	load_tms            	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id          	string        comment "Source system ID",
	ptn_yyyy            	string        comment "Partition field - year",
	ptn_mm              	string        comment "Partition field - month",
	ptn_dd              	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_pcb_dep/pcb_dep_src_pf_ar_sa_dly' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);