-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cis_ipxcontact.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-13    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CIS.CIS_IPXCONTACT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cis.cis_ipxcontact (
	pos_dt        	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	method        	string       comment "Def(En): Ingestion Method
Def(Th): วิธีการนำเข้า",
	ipcont_ip_id  	string       comment "Def(En): Customer id
Def(Th): เลขที่ลูกค้า",
	ipcont_cont_id	string       comment "Def(En): Contact id
Def(Th): เลขที่ Contact",
	ipcont_rel_tp 	string       comment "Def(En): Customer and Contact Relationship Type
Def(Th): รหัสประเภทความสัมพันธ์ของลูกค้ากับ Contact",
	ipcont_stat   	string       comment "Def(En): Customer and Contact Relationship Status code
Def(Th): รหัสสถานะความสัมพันธ์ของลูกค้ากับ Contact",
	ipcont_eft_dt 	string       comment "Def(En): Customer and Contact Relationship Effective date
Def(Th): วันที่ผูกความสัมพันธ์",
	ipcont_exp_dt 	string       comment "Def(En): Customer and Contact Relationship Expire date
Def(Th): วันที่ยกเลิกความสัมพันธ์",
	ipcont_user_id	string       comment "Def(En): User id
Def(Th): รหัสผู้ทำรายการ",
	ipcont_upd_dt 	string       comment "Def(En): Update date time
Def(Th): วันและเวลาที่ทำรายการ",
	load_tms      	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id    	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy      	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm        	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd        	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cis/cis_ipxcontact' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);