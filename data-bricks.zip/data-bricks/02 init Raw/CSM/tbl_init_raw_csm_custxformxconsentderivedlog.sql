-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_csm_custxformxconsentderivedlog.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-13    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CSM.CSM_CUSTXFORMXCONSENTDERIVEDLOG
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_csm.csm_custxformxconsentderivedlog (
	pos_dt                	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	lcustfcdr_cust_id     	string       comment "Def(En): Cust ID (CIS ID)
Def(Th): เลขที่ลูกค้า (CIS ID)",
	lcustfcdr_formappr_cd 	string       comment "Def(En): Form APPR ID
Def(Th): รหัสของวัตถุประสงค์ของฟอร์มสำหรับใส่ระดับ derived",
	lcustfcdr_consent_flag	string       comment "Def(En):Consent flag
Def(Th):ค่า consent ที่ลูกค้าให้",
	lcustfcdr_upd_user    	string       comment "Def(En):Update by UserID
Def(Th):User ที่แก้ไขข้อมูล",
	lcustfcdr_upd_dt      	string       comment "Def(En):Update date
Def(Th):วันที่อัพเดทข้อมูล",
	lcustfcdr_upd_dt_group	string       comment "Def(En):Update date group
Def(Th):วันที่ใช้สำหรับ group ข้อมูลที่ update เป็นชุดเดียวกัน",
	lcustfcdr_upd_user_l  	string       comment "Def(En):Update by UserID
Def(Th):User ที่แก้ไขข้อมูล",
	lcustfcdr_upd_dt_l    	string       comment "Def(En):Update log date
Def(Th):วันที่ log ข้อมูล",
	load_tms              	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id            	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy              	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน",
	upd_tms               	string       comment "Def(En): Partition field - Record update timestamp
Def(Th):"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_csm/csm_custxformxconsentderivedlog' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);