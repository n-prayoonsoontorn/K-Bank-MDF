-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cardlink_acq_ci1d1167_cardtype.sql
# Area: cardlink_acq
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-11    Panita T.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK_ACQ.CARDLINK_ACQ_CI1D1167_CARDTYPE
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink_acq.cardlink_acq_ci1d1167_cardtype (
	pos_dt    	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	cardtype  	string       comment "Def(En): Card Type
Def(Th):",
	cardprefix	string       comment "Def(En): Card Prefix
Def(Th):",
	carddesc  	string       comment "Def(En): Card Description
Def(Th):",
	filler    	string       comment "Def(En): Padding for fixed length file formats
Def(Th):",
	load_tms  	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink_acq/cardlink_acq_ci1d1167_cardtype' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);