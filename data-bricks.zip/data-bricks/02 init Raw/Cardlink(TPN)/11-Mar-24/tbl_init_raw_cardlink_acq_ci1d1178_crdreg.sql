-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cardlink_acq_ci1d1178_crdreg.sql
# Area: cardlink_acq
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-12    Panita T.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK_ACQ.CARDLINK_ACQ_CI1D1178_CRDREG
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink_acq.cardlink_acq_ci1d1178_crdreg (
	pos_dt              	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	issuekey            	string       comment "Def(En): issueKey
Def(Th):",
	transactiondate     	string       comment "Def(En): Transaction Date(YYYYMMDD)
Def(Th):",
	transactiontime     	string       comment "Def(En): Transaction time(HHMNSS)
Def(Th):",
	userid              	string       comment "Def(En): User number
Def(Th):",
	authuserid          	string       comment "Def(En): User authorization
Def(Th):",
	savingaccount       	string       comment "Def(En): Savings account
Def(Th):",
	savingaccountbranch 	string       comment "Def(En): Branch of savings account
Def(Th):",
	currentaccount      	string       comment "Def(En): Current account
Def(Th):",
	currentaccountbranch	string       comment "Def(En): Branch of current account
Def(Th):",
	entrydate           	string       comment "Def(En): Entry date
Def(Th):",
	purposeflag         	string       comment "Def(En): Issuing purpose
Def(Th):",
	cardtype            	string       comment "Def(En): Card type 
Def(Th):",
	cardhavephoto       	string       comment "Def(En): Have photo flag
Def(Th):",
	cardtitlename       	string       comment "Def(En): Title
Def(Th):",
	cardsex             	string       comment "Def(En): Sex
Def(Th):",
	cardthainame        	string       comment "Def(En): Name
Def(Th):",
	cardthaisurname     	string       comment "Def(En): Surname
Def(Th):",
	cardengfullname     	string       comment "Def(En): English Name
Def(Th):",
	cardbirthday        	string       comment "Def(En): Birth date 
Def(Th):",
	carddoctype         	string       comment "Def(En): Document type
Def(Th):",
	carddocnumber       	string       comment "Def(En): Document number
Def(Th):",
	cardaddress1        	string       comment "Def(En): Address1
Def(Th):",
	cardaddress2        	string       comment "Def(En): Address2
Def(Th):",
	cardamphur          	string       comment "Def(En): Amphur
Def(Th):",
	cardprovicde        	string       comment "Def(En): Province
Def(Th):",
	cardzipcode         	string       comment "Def(En): ZIP code
Def(Th):",
	cardhomephone       	string       comment "Def(En): Home telephone
Def(Th):",
	cardofficephone     	string       comment "Def(En): Office telephone
Def(Th):",
	cardmobilenumber    	string       comment "Def(En): Mobile
Def(Th):",
	cardpagernumber     	string       comment "Def(En): Pager
Def(Th):",
	cardemail           	string       comment "Def(En): Mail
Def(Th):",
	entryfee            	string       comment "Def(En):
Def(Th): ค่าแรกเข้าที่เก็บลูกค้า",
	yearlyfee           	string       comment "Def(En):
Def(Th): ค่าธรรมเนียมรายปีที่เก็บลูกค้า",
	destbranch          	string       comment "Def(En): Destination Branch
Def(Th):",
	cancelflag          	string       comment "Def(En): Cancel flag
Def(Th):",
	useridcancel        	string       comment "Def(En): User no cancel
Def(Th):",
	userauthcancel      	string       comment "Def(En): User authorization cancel
Def(Th):",
	cardcustid          	string       comment "Def(En): ID
Def(Th):",
	cardbarcode         	string       comment "Def(En): Barcode
Def(Th):",
	issuedate           	string       comment "Def(En): Issue date
Def(Th):",
	expireddate         	string       comment "Def(En): Expire date
Def(Th):",
	cardref1            	string       comment "Def(En): Reference text1
Def(Th):",
	cardref2            	string       comment "Def(En): Reference text2
Def(Th):",
	cardref3            	string       comment "Def(En): Reference text3
Def(Th):",
	cardfreeform        	string       comment "Def(En): Free form
Def(Th):",
	cardduedate         	string       comment "Def(En): Due date
Def(Th):",
	cardoldcard         	string       comment "Def(En): Replaced card
Def(Th):",
	cardmainflag        	string       comment "Def(En): Main card flag
Def(Th):",
	purchaselimit       	string       comment "Def(En): Purchase limit
Def(Th):",
	cardmasking         	string       comment "Def(En): Full PAN are masking (the first six and last four digits)
Def(Th):",
	initialentryfee     	string       comment "Def(En):
Def(Th): Entry fee ของ card type ก่อนมีการ waive fee",
	initialannualfee    	string       comment "Def(En): 
Def(Th): Annual fee ของ card type ก่อนมีการ waive fee",
	waivefeecode        	string       comment "Def(En): Waive fee code
Def(Th):",
	waivefeereason      	string       comment "Def(En): Waive fee reason
Def(Th):",
	deliveryfee         	string       comment "Def(En): 
Def(Th): Delivery fee ค่าส่งบัตร",
	cardrandom          	string       comment "Def(En): cardRandom
Def(Th):",
	cardencryptedpb     	string       comment "Def(En): 
Def(Th): เบอร์บัตรที่ทำการ encrypted ด้วย Random Key",
	eban_card_masking   	string       comment "Def(En):
Def(Th):",
	customernumber      	string       comment "Def(En): 
Def(Th): เลข Customer",
	load_tms            	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id          	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy            	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm              	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd              	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink_acq/cardlink_acq_ci1d1178_crdreg' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);