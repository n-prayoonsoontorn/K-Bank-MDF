-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cardlink_kb1dh006_kbbcus.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-11    Panita T.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK.CARDLINK_KB1DH006_KBBCUS
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink.cardlink_kb1dh006_kbbcus (
	pos_dt                   	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	1dh006_org               	string       comment "Def(En): Customer Org
Def(Th):",
	1dh006_cust_nbr          	string       comment "Def(En): Customer Number
Def(Th):",
	1dh006_fin_info          	string       comment "Def(En): Financial Information

Def(Th):",
	1dh006_gross_income      	string       comment "Def(En): Gross Income
Def(Th):",
	1dh006_tr_bill_time      	string       comment "Def(En): TREASURY BILL TIME TO MATURITY
Def(Th):",
	1dh006_curr_email        	string       comment "Def(En): Email Address
Def(Th):",
	1dh006_reg_address       	string       comment "Def(En): Register Address
Def(Th):",
	1dh006_fin_inst          	string       comment "Def(En): Current Savings Deposit Financial Institution / Current Fixed Deposit (held) Financial Institution/ Current Fixed Deposit (not held) Financial Institution
Def(Th):",
	1dh006_cust_perf_ind     	string       comment "Def(En): Customer Performance Indicator
Def(Th):",
	1dh006_cust_risk_grade   	string       comment "Def(En): Customer Risk Grade
Def(Th):",
	1dh006_perm_limit        	string       comment "Def(En): PERMANENT LIMIT OFFER
Def(Th): ข้อมูลบอกว่า สามารถเพิ่มวงเงิน ให้ลูกค้าได้เป็นเท่าไร",
	1dh006_shadow_limit_upp  	string       comment "Def(En): SHADOW-LIMIT-UPPER
Def(Th): รับค่าจาก file CC1D6303 ( PRFB-UPPER-SHADOW-LIMIT)",
	1dh006_shadow_limit_low  	string       comment "Def(En): SHADOW-LIMIT-LOWER
Def(Th): รับค่าจาก file CC1D6303 (PRFB-LOWER-SHADOW-LIMIT)",
	1dh006_deposit_amt       	string       comment "Def(En): Fixed Deposit (held)
Def(Th): ส่งค่าต่อไปยัง CC3D6303 (D6303-CENSUS-TRACT )",
	1dh006_pca_code          	string       comment "Def(En): 
Def(Th): รหัสที่มาของข้อมูล ส่งค่าต่อให้ file KB1D0200 , KB1D0253, KB1D0317",
	1dh006_bot_flag          	string       comment "Def(En): BOT Flag
Def(Th):",
	1dh006_bot_date          	string       comment "Def(En): BOT date
Def(Th):",
	1dh006_lifetime_fee_waive	string       comment "Def(En): FLAG WAIVE 
Def(Th):  ค่าธรรมเนียมรายปีตลอดชีพ ส่งค่าต่อให้ file KB1D0200, KB1D0253,KB1D0317,KB1D0485-PLATINUM-CARD",
	1dh006_consent_flag      	string       comment "Def(En): Consent Letter  transact
Def(Th): Flag มีค่าเป็น 'Y' 'N' เป็น field ที่รับค่ามาจาก",
	1dh006_consent_date      	string       comment "Def(En): Date of Concent Bureau
Def(Th): field ที่รับค่าจาก transact",
	1dh006_cust_since_dte    	string       comment "Def(En): Customer Open date
Def(Th):",
	1dh006_highest_flag      	string       comment "Def(En): CUSTOMER SCORE 
Def(Th): UPDATEด้วย KB1D0282-SCORE ส่งค่าต่อให้ KB1D0163,KB1D0200,KB1D0253,CC1D289,CC1D289G,(CPACP.KB1D0253.D%%TRANDATE)",
	1dh006_fleet_flag        	string       comment "Def(En): FLEET FLAG 
Def(Th): มีค่าเป็น 0 กับ 1 ส่งค่าต่อให้ file KB1D0317(CPACP.KB1D0317.D%%DATENEXT1)",
	1dh006_discount_flag     	string       comment "Def(En): DISCOUNT-FLAG ส่งต่อที่ file (CPACP.KB1D0317.D%%DATENEXT1)
Def(Th):",
	1dh006_sme_income        	string       comment "Def(En): SME Income
Def(Th): กรณีเป็นCustomer-SME ใช้ฟิลด์นี้สำหรับแสดง Income ของCustomer-บุคคลธรรมดา หารด้วย 1000 เพื่อให้ฝ่าย บผ.ใช้พิจารณาอนุมัติวงเงิน",
	1dh006_sme_crline        	string       comment "Def(En): SME Credit Line
Def(Th):",
	1dh006_cash_limit_per    	string       comment "Def(En): CASH LIMIT PERCENT
Def(Th):",
	filler                   	string       comment "Def(En): 
Def(Th):",
	load_tms                 	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id               	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                 	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                   	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                   	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink/cardlink_kb1dh006_kbbcus' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);