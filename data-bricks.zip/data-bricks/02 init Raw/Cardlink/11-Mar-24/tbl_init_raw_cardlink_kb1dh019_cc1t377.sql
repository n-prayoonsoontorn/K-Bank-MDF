-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cardlink_kb1dh019_cc1t377.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-11    Panita T.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK.CARDLINK_KB1DH019_CC1T377
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink.cardlink_kb1dh019_cc1t377 (
	pos_dt                            	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh019_t377_proc_dte               	string       comment "Def(En): Post Date
Def(Th): วันที่ Post ข้อมูล",
	dh019_t377_bt_rec_type            	string       comment "Def(En): Record type Issuer/ Acquire
Def(Th):",
	dh019_t377_bt_card_type           	string       comment "Def(En): Card Type Group4
Def(Th):",
	dh019_t377_bt_bank_code           	string       comment "Def(En): Bank Code
Def(Th):",
	dh019_t377_bt_type                	string       comment "Def(En): ประเภทบัตร
Def(Th):",
	dh019_t377_bt_trans_code          	string       comment "Def(En): Transaction Code

01 : SALE           คือ TC40
02 : SALE-REV   คือ TC41
03 : RET             คือ TC
04 : RET-REV     คือ TC
05 : CASH           คือ TC30
06 : CASH-REV   คือ TC31
Def(Th):",
	dh019_t377_bt_amount              	string       comment "Def(En): จำนวนเงิน
Def(Th):",
	dh019_t377_bt_rej                 	string       comment "Def(En): กรณีที่เป็นบัตร Kbank ถ้าบัตรนี้ติด Invalid Block Cod จะมีค่า เป็น 1
Def(Th):",
	dh019_t377_bt_card_no             	string       comment "Def(En): Card Number (Encrypt)
Def(Th):",
	dh019_t377_bt_reference           	string       comment "Def(En): Acquire Reference Number
รหัสอ้างอิงกับร้านค้าต่างธนาคาร
Def(Th):",
	dh019_t377_bt_merch_category      	string       comment "Def(En): ประเภทกลุ่มร้านค้า เช่นกลุ่มร้านอาหาร , กลุ่มปั้มน้ำมัน
Def(Th):",
	dh019_t377_bt_merch_acct          	string       comment "Def(En): รหัสร้านค้า
Def(Th):",
	dh019_t377_bt_merch_org           	string       comment "Def(En): Org ร้านค้า
Def(Th):",
	dh019_t377_bt_orig_curr_code      	string       comment "Def(En): Original Currency Code
Def(Th):",
	dh019_t377_bt_orig_curr_amt       	string       comment "Def(En): Original Currency Amount
Def(Th):",
	dh019_t377_bt_fpi                 	string       comment "Def(En): FPI  Flag 
(Fee Program Interchange Indicator)
เป็นรายการที่ทำจากร้านค้ากลุ่มพิเศษที่ได้รับค่าธรรมเนียมราคาพิเศษ (ได้รับส่วนลดค่าธรรมเนียม)
Def(Th):",
	dh019_t377_bt_ecomm_ind           	string       comment "Def(En): E-Commerce Flag
Def(Th):",
	dh019_t377_bt_orig_credit         	string       comment "Def(En): Original Credit Flag
รายการนี้เป็นรายการ Reverse หรือไม่

MOVE 0                      TO  TFB-BT-ORIG-CREDIT    
IF  W030-CPAC-TC-41                                   
    IF CXS120-BIS-FMT-CODE EQUAL TO  'CR'             
       MOVE 2                  TO  TFB-BT-ORIG-CREDIT 
    ELSE                                              
       MOVE 1                  TO  TFB-BT-ORIG-CREDIT 
    END-IF                                            
Def(Th):",
	dh019_t377_bt_bin_des             	string       comment "Def(En): BIN Description
Def(Th):",
	dh019_t377_bt_bin_detail          	string       comment "Def(En): BIN Detail
Def(Th):",
	dh019_t377_vs_arda_issuer_bin     	string       comment "Def(En): VISA Issuer BIN
Def(Th):",
	dh019_t377_vs_arda_card_type      	string       comment "Def(En): VISA Card Type Code
Def(Th):",
	dh019_t377_vs_arda_process_bin    	string       comment "Def(En): VISA Process BIN
Def(Th):",
	dh019_t377_vs_arda_domain         	string       comment "Def(En): VISA Domain Code
Def(Th):",
	dh019_t377_vs_arda_region         	string       comment "Def(En): VISA Region Code
Def(Th):",
	dh019_t377_vs_arda_country        	string       comment "Def(En): VISA Country Code
Def(Th):",
	dh019_t377_mc_mpaa_t40_mbr_id     	string       comment "Def(En): Mastercard Member ID
Def(Th):",
	dh019_t377_mc_mpaa_t40_prod_id    	string       comment "Def(En): Mastercard Product Code
Def(Th):",
	dh019_t377_mc_mpaa_t40_prod_type  	string       comment "Def(En): Mastercard Product Type Code
Def(Th):",
	dh019_t377_mc_mpaa_t40_cntry_cde_a	string       comment "Def(En): Mastercard Country Name
Def(Th):",
	dh019_t377_mc_mpaa_t40_cntry_cde_n	string       comment "Def(En): Mastercard Country Code
Def(Th):",
	dh019_t377_mc_mpaa_t40_region     	string       comment "Def(En): Mastercard Region Code
Def(Th):",
	dh019_t377_mc_mpaa_t40_prod_class 	string       comment "Def(En): Mastercard Product Class Code
Def(Th):",
	dh019_t377_vs_mc_type             	string       comment "Def(En): BIN Card Group Code
Def(Th):",
	dh019_t377_ardef_acct_funding_src 	string       comment "Def(En): Identifies the source of the funds associated with the primary account for the card. 
Def(Th):",
	load_tms                          	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                        	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                          	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                            	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                            	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink/cardlink_kb1dh019_cc1t377' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);