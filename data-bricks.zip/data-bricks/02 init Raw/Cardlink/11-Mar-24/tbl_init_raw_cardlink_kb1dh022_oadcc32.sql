-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cardlink_kb1dh022_oadcc32.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-11    Panita T.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK.CARDLINK_KB1DH022_OADCC32
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink.cardlink_kb1dh022_oadcc32 (
	pos_dt                     	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh022_oadcms_d_batch_no    	string       comment "Def(En): Batch no.
Def(Th):",
	dh022_oadcms_d_seq_no      	string       comment "Def(En): Seq no.
Def(Th):",
	dh022_oadcms_d_terminal_id 	string       comment "Def(En): Terminal ID
Def(Th):",
	dh022_oadcms_d_card        	string       comment "Def(En): Card no.
Def(Th):",
	dh022_oadcms_d_txn_date    	string       comment "Def(En):
Def(Th): วันที่ทำรายการ",
	dh022_oadcms_d_txn_time    	string       comment "Def(En):
Def(Th): เวลาที่ทำรายการ HHMMSS",
	dh022_oadcms_d_org_amt     	string       comment "Def(En): Original amount
Def(Th):",
	dh022_oadcms_d_redm_amt    	string       comment "Def(En): Redeemtion amount
Def(Th): Redeemtion amount
Ex. 1000 Point 100 บาท
ธนาคารตกลงกับร้าน 90% ดังนั้น ธนาคารจะจ่ายให้ร้านค้า 90 บาท แต่ลูกค้าได้ส่วนลดไป 100 บาท
Redeemtion amount  = 100",
	dh022_oadcms_d_net_sales   	string       comment "Def(En): Net sale
Def(Th):",
	dh022_oadcms_d_redm_pt     	string       comment "Def(En): Redeemtion point
Def(Th):",
	dh022_oadcms_d_redm_amt_mer	string       comment "Def(En): Redeemtion amount merchant
Def(Th): Redeemtion amount merchant
Ex. 1000 Point 100 บาท
ธนาคารตกลงกับร้าน 90% ดังนั้น ธนาคารจะจ่ายให้ร้านค้า 90 บาท แต่ลูกค้าได้ส่วนลดไป 100 บาท
Redeemtion amount merchant = 90",
	dh022_oadcms_d_merch_per   	string       comment "Def(En): Merchant percent
Def(Th):",
	dh022_oadcms_d_t_code      	string       comment "Def(En): Transaction code
Def(Th):",
	dh022_oadcms_d_auth_code   	string       comment "Def(En): Authorize code
Def(Th):",
	dh022_oadcms_d_t_trace     	string       comment "Def(En): Trace ID
Def(Th):",
	dh022_oadcms_d_merch_id    	string       comment "Def(En): Merchant ID
Def(Th):",
	dh022_oadcms_d_setl_date   	string       comment "Def(En): Settlement date
Def(Th):",
	dh022_oadcms_d_rem_typ     	string       comment "Def(En): Redeem Type 
Def(Th): ประเภทของการแลกส่วนลด
EC 
หมายถึง   E-Vouncher + Credit (เงินส่วนต่างที่ลูกค้าต้องเสียเพิ่ม) 
ตัวอย่าง   สินค้าราคา 1,000 บาท ลูกค้าใช้ Point Redeem 1,000 Points = 100 บาท และใช้ E-Vouncher ลดราคาสินค้า 200 บาท  ค่าของ Credit = 700 บาท 

E 
หมายถึง   E-Vouncher 
ตัวอย่าง   ลูกค้าใช้ Point 1,000 Points กับทางร้านค้าเพื่อแลกเป็น E-Vouncher โดยที่ลูกค้ายังไม่ซื้อสินค้า ซึ่งในกรณี E-Vouncher ขึ้นอยู่กับร้านค้าว่าจะให้เป็นอะไร 

PC 
หมายถึง   Product + Credit (เงินส่วนต่างที่ลูกค้าต้องเสียเพิ่ม) 
ตัวอย่าง   สินค้าราคา 1,000 บาท ลูกค้าใช้ Point Redeem 1,000 Points = 100 บาท และได้รับสินค้าของแถมเพิ่มเติม (Product) ค่าของ Credit = 900 

P 
หมายถึง   Product 
ตัวอย่าง   สินค้าราคา 1,000 บาท ลูกค้าใช้ Point เท่ากับราคาสินค้า 1,000 Points เพื่อแลกสินค้า (Product) โดยที่ลูกค้าไม่ต้องจ่ายเพิ่ม",
	dh022_oadcms_d_prod_cd     	string       comment "Def(En): Product code
Def(Th): รหัสสินค้า",
	dh022_oadcms_d_e_voucher   	string       comment "Def(En): E-Voucher
Def(Th): ประเภทของการแลกคะแนนสะสม
*------------------------------*
Product คือ สินค้า
PC - ใช้ส่วนลด แต่ต้องมีจ่ายเงินเป็นส่วนเพิ่ม
'P' - ได้รับสินค้าไปเลย ไม่มี Financial

Product คือ Voucher
EC - ใช้ส่วนลด แต่ต้องมีจ่ายเงินเป็นส่วนเพิ่ม
'E' - ได้รับสินค้าไปเลย ไม่มี Financial",
	dh022_oadcms_d_qty         	string       comment "Def(En): Quantity
Def(Th):",
	dh022_oadcms_d_bal_pt      	string       comment "Def(En): Balance point
Def(Th):",
	dh022_oadcms_d_point       	string       comment "Def(En): Point 
Def(Th): คะแนนที่ใช้ไป",
	dh022_oadcms_d_amount      	string       comment "Def(En):
Def(Th): จำนวนเงินสินค้า",
	dh022_oadcms_d_prod_name   	string       comment "Def(En): Product name
Def(Th):",
	dh022_oadcms_d_pos_em_pan  	string       comment "Def(En): Pos entry mode 
Def(Th): ประเภทรายการ
ถ้าเป็น Instant Redemption = 80",
	dh022_oadcms_d_invoice_nbr 	string       comment "Def(En): Invoice number
Def(Th):",
	dh022_oadcms_d_merch_br    	string       comment "Def(En): Merchant branch code 
Def(Th): บัญชี Merchant ผูกกับสาขาไหนของ KBank",
	dh022_oadcms_d_ui_batch    	string       comment "Def(En): UI Batch code (system)
Def(Th):",
	dh022_d_filler             	string       comment "Def(En): Space
Def(Th):",
	load_tms                   	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                 	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                   	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                     	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                     	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink/cardlink_kb1dh022_oadcc32' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);