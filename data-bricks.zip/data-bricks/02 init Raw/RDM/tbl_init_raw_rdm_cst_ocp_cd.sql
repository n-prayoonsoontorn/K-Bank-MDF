-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_rdm_cst_ocp_cd.sql
# Area: rdm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-13    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_RDM.RDM_CST_OCP_CD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_rdm.rdm_cst_ocp_cd (
	pos_dt               	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	name                 	string       comment "Def(En):Description in Thai
Def(Th):คำอธิบายอาชีพภาษาไทย",
	code                 	string       comment "Def(En):Code of occupation
Def(Th):รหัสอาชีพ",
	dsc_en               	string       comment "Def(En):Description in English
Def(Th):คำอธิบายอาชีพภาษาอังกฤษ",
	actv_f_code          	string       comment "Def(En):Active Flag
Def(Th):",
	actv_f_name          	string       comment "Def(En):Active Flag Name
Def(Th):",
	dspl_seq             	string       comment "Def(En): Display Sequence
Def(Th):",
	bot_emp_char_cd_code 	string       comment "Def(En): BOT Employment Characteristic Code
Def(Th):  รหัสของลักษณะการจ้างงานของคู่สัญญาหรือบุคคลที่มีงานทำ",
	bot_emp_char_cd_name 	string       comment "Def(En): BOT Employment Characteristic Nane
Def(Th):  คำอธิบายรหัสของลักษณะการจ้างงานของคู่สัญญาหรือบุคคลที่มีงานทำ",
	bot_emp_st_cd_code   	string       comment "Def(En): BOT Employment Status Code
Def(Th): รหัสสถานะการทำงานของคู่สัญญาหรือบุคคล",
	bot_emp_st_cd_name   	string       comment "Def(En): BOT Employment Status Name
Def(Th): คำอธิบายรหัสสถานะการทำงานของคู่สัญญาหรือบุคคล",
	ocp_grp_cd_code      	string       comment "Def(En): Occupation Group Code
Def(Th): รหัสกลุ่มอาชีพ",
	ocp_grp_cd_name      	string       comment "Def(En): Occupation Group Name
Def(Th): คำอธิบายรหัสกลุ่มอาชีพ",
	wrk_nm_rqe_f_code    	string       comment "Def(En): Work Name Require Flag Code
Def(Th): รหัสสตัวบ่งชี้ว่าต้องการชื่อสถานที่ทำงานหรือไม่",
	wrk_nm_rqe_f_name    	string       comment "Def(En): Work Name Require Flag Name
Def(Th): คำอธิบายรหัสสตัวบางชี้ว่าต้องการชื่อสถานที่ทำงานหรือไม่",
	wrk_adr_rqe_f_code   	string       comment "Def(En): Work Address Require Flag Code
Def(Th): รหัสสตัวบางชี้ว่าต้องการที่อยู่สถานที่ทำงานหรือไม่",
	wrk_adr_rqe_f_name   	string       comment "Def(En): Work Address Require Flag Name
Def(Th): คำอธิบายรหัสสตัวบางชี้ว่าต้องการที่อยู่สถานที่ทำงานหรือไม่",
	th_ip_lgl_stc_tp_cd  	string       comment "Def(En): Thai Involved Party Legal Structure Type Code
Def(Th): รหัสประเภทบุคคล/นิติบุคคลสำหรับคนไทย",
	frng_ip_lgl_stc_tp_cd	string       comment "Def(En): Foreign Involved Party Legal Structure Type Code
Def(Th): รหัสประเภทบุคคล/นิติบุคคลสำหรับคนต่างชาติ",
	enterdatetime        	string       comment "Def(En):Enter Date time
Def(Th):วันที่ใส่ข้อมูล",
	enterusername        	string       comment "Def(En):Enter User Name
Def(Th):ผู้ใส่ข้อมูล",
	lastchgdatetime      	string       comment "Def(En):Update Date
Def(Th):วันที่อัพเดทข้อมูล",
	lastchgusername      	string       comment "Def(En):Update User Name
Def(Th):ผู้อัพเดทข้อมูล",
	load_tms             	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id           	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy             	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm               	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd               	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_rdm/rdm_cst_ocp_cd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);