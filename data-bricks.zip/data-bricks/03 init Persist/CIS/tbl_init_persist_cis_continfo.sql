-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cis_continfo.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-13    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CIS.CIS_CONTINFO
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cis.cis_continfo (
	pos_dt           	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	method           	string       comment "Def(En): Ingestion Method
Def(Th): วิธีการนำเข้า",
	cont_id          	bigint       comment "Def(En): Contact id
Def(Th): เลขที่ Contact",
	cont_tp          	string       comment "Def(En): Contact Type
Def(Th): ประเภท Contact",
	cont_ip_id       	integer      comment "Def(En): Customer id
Def(Th): เลขที่ลูกค้า",
	cont_src_stm     	string       comment "Def(En): Contact Source system
Def(Th): ระบบที่สร้าง Contact",
	cont_info        	string       comment "Def(En): Contact infomation
Def(Th): ข้อมูล contact แต่ละประเภท เช่น เบอร์โทรศัพท์, เบอร์มือถือ, email address, URL, FB account",
	cont_phone_ext   	string       comment "Def(En): Phone Extension no.
Def(Th): เบอร์ต่อ",
	cont_phone_cntry 	string       comment "Def(En): Phone Country code
Def(Th): รหัสประเทศของเบอร์โทร",
	cont_phone_area  	string       comment "Def(En): Phone Area code
Def(Th): รหัสพื้นที่ของเบอร์โทรต่างประเทศ",
	cont_stat        	string       comment "Def(En): Contact Status code
Def(Th): รหัสสถานะของ Contact",
	cont_eft_dt      	date         comment "Def(En): Contact Effective date
Def(Th): วันที่สร้าง Contact",
	cont_exp_dt      	date         comment "Def(En): Contact Expire date
Def(Th): วันที่ยกเลิก Contact",
	cont_uncnt_flg   	string       comment "Def(En): Contact Uncontact Mark flag
Def(Th): ระบุสถานะ contact ที่ไม่สามารถติดต่อได้",
	cont_uncnt_dt    	date         comment "Def(En): Contact Uncontact Mark date
Def(Th): วันที่บันทึก Contact ที่ไม่สามารถติดต่อได้",
	cont_uncnt_user  	string       comment "Def(En): User id
Def(Th): รหัสผู้บันทึก Contact ที่ไม่สามารถติดต่อได้",
	cont_uncnt_cen_cd	string       comment "Def(En): User Center code
Def(Th): รหัสสังกัดของผู้บันทึก Contact ที่ไม่สามารถติดต่อได้",
	cont_uncnt_br_no 	string       comment "Def(En): User Branch no.
Def(Th): รหัสสาขาของผู้บันทึก Contact ที่ไม่สามารถติดต่อได้",
	cont_cre_user    	string       comment "Def(En): User id
Def(Th): รหัสผู้สร้าง Contact",
	cont_user_id     	string       comment "Def(En): User id
Def(Th): รหัสผู้ทำรายการ",
	cont_upd_dt      	timestamp    comment "Def(En): Update date time
Def(Th): วันและเวลาที่ทำรายการ",
	load_tms         	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id       	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy         	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm           	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd           	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cis/cis_continfo' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);