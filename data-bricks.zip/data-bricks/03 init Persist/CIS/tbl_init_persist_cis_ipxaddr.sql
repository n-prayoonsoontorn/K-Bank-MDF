-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cis_ipxaddr.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-13    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CIS.CIS_IPXADDR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cis.cis_ipxaddr (
	pos_dt        	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	method        	string       comment "Def(En): Ingestion Method
Def(Th): วิธีการนำเข้า",
	ipaddr_ip_id  	integer      comment "Def(En): Customer id
Def(Th): เลขที่ลูกค้า",
	ipaddr_addr_id	bigint       comment "Def(En): Address id
Def(Th): เลขที่ที่อยู่",
	ipaddr_tp     	string       comment "Def(En): Customer and Address Relationship Type
Def(Th): รหัสประเภทความสัมพันธ์ของลูกค้ากับที่อยู่",
	ipaddr_stat   	string       comment "Def(En): Customer and Address Relationship Status code
Def(Th): รหัสสถานะความสัมพันธ์ของลูกค้ากับที่อยู่",
	ipaddr_eft_dt 	date         comment "Def(En): Customer and Address Relationship Effective date
Def(Th): วันที่ผูกความสัมพันธ์",
	ipaddr_exp_dt 	date         comment "Def(En): Customer and Address Relationship Expire date
Def(Th): วันที่ยกเลิกความสัมพันธ์",
	ipaddr_user_id	string       comment "Def(En): User id
Def(Th): รหัสผู้ทำรายการ",
	ipaddr_upd_dt 	timestamp    comment "Def(En): Update date time
Def(Th): วันและเวลาที่ทำรายการ",
	load_tms      	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id    	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy      	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm        	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd        	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cis/cis_ipxaddr' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);