-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_kb1dh002_cpbcrd.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-11    Panita T.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_KB1DH002_CPBCRD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_kb1dh002_cpbcrd (
	pos_dt                        	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh002_org_nmbr                	smallint     comment "Def(En): ORG Number
Def(Th):",
	dh002_type                    	smallint     comment "Def(En): Type Number 
Def(Th):",
	dh002_card_nmbr               	bigint       comment "Def(En): Card Number
Def(Th):",
	dh002_short_name              	string       comment "Def(En): Short Name 
Def(Th):",
	dh002_alpha_key               	string       comment "Def(En): LPM Number
จากที่ทาง LPM AS/400 ทำการขยายความยาวของฟิลด์ Branch ที่ดูแล Account Officer จาก 3 หลัก เป็น 4 หลัก ดังนั้นจึงส่งผลให้ทาง CardLinK ต้อง Re-structure Format Alpha Key โดยทำการตัด Flag ตั้งฐานหนี้ (1 digit) ที่ตำแหน่งสุดท้าย (Position ที่ 16) ทิ้ง เพื่อใช้สำหรับการขยายความยาวของฟิลด์ Branch ที่ดูแล Account Officer (Not extension of field length , Data Content Change only)
From - LLLLLLLLLLGBBBDE
  To - LLLLLLLLLLGBBBBD
Def(Th):",
	dh002_customer_org            	smallint     comment "Def(En): Main Customer Org number

Def(Th):",
	dh002_customer_nmbr           	string       comment "Def(En): Main Customer ID Number
Def(Th):",
	dh002_alt_customer_org        	smallint     comment "Def(En): Sup Customer Org Number

Def(Th):",
	dh002_alt_customer_nmbr       	string       comment "Def(En): Sup Customer ID Number

Def(Th):",
	dh002_dup_stmt_org            	smallint     comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_dup_stmt_nbr            	bigint       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_instl_amort             	decimal(11,2) comment "Def(En): จำนวนเงินผ่อนชำระต่องวด
Def(Th):",
	dh002_filler1                 	string       comment "Def(En):
Def(Th):",
	dh002_cycle                   	smallint     comment "Def(En): BILLING CYCLE
Def(Th):",
	dh002_xfr_org_nmbr            	smallint     comment "Def(En): Details of new account after transfer 
Def(Th):",
	dh002_xfr_type_nmbr           	smallint     comment "Def(En): Details of new account after transfer
Def(Th):",
	dh002_xfr_acct_nmbr           	bigint       comment "Def(En): Details of new account after transfer
Credit Card No ใบใหม่ เช่น กรณีที่บัตรเก่าติด Block=L และถูก Transfer ไปยังบัตรใบใหม่
Def(Th):",
	dh002_officer                 	string       comment "Def(En):
Def(Th):",
	dh002_aff_br_code             	smallint     comment "Def(En):
Def(Th):",
	dh002_curr_collector          	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_perm_collector          	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_agent_bank_nmbr         	smallint     comment "Def(En): Agent bank number used as sort criteria for trial balance
Def(Th):",
	dh002_corp_acct_org           	smallint     comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_corp_acct_nmbr          	bigint       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_domicile_branch         	smallint     comment "Def(En): Branch to which the cardholder belongs
Def(Th):",
	dh002_collateral_code         	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_user_code               	string       comment "Def(En):
Def(Th):",
	dh002_stmt_flag_tfb           	string       comment "Def(En):
Def(Th):",
	dh002_prt_stmt_flag_tfb       	string       comment "Def(En):
Def(Th):",
	dh002_user_code_2             	string       comment "Def(En):
Def(Th):",
	dh002_staff_flag_tfb          	string       comment "Def(En): Staff KBank Flag
Def(Th):",
	dh002_card_return_flag_tfb    	string       comment "Def(En):
Def(Th):",
	dh002_user_code_3             	string       comment "Def(En):
Def(Th):",
	dh002_ins_code                	string       comment "Def(En): Insurance code—not used
Def(Th):",
	dh002_ownership_flag          	string       comment "Def(En): Identifies if the cardholder owns a business
Def(Th):",
	dh002_block_code              	string       comment "Def(En): Block Code   
Def(Th):",
	dh002_alt_block_code          	string       comment "Def(En): Last Block Code
Def(Th):",
	dh002_rpt_auth_flag           	smallint     comment "Def(En):
Def(Th):",
	dh002_status                  	string       comment "Def(En): สถานะของบัตร
Def(Th):",
	dh002_statement_flag          	smallint     comment "Def(En):
Def(Th):",
	dh002_stmt_freq               	smallint     comment "Def(En): A two-digit code identifying the monthly frequency of statement production. The maximum period allowable between statement production is 60 months.
Def(Th):",
	dh002_waive_late_chg          	smallint     comment "Def(En): 1 = Waive late charges
Def(Th):",
	dh002_waive_late_notice       	smallint     comment "Def(En): 1 = Waive late notices
Def(Th):",
	dh002_waive_annual_fee        	smallint     comment "Def(En): 0 = Charge Principal membership fee
1 = Waive membership fee
2 = Charge supplementary membership fee
Def(Th):",
	dh002_waive_over_limit        	smallint     comment "Def(En): 1 = Waive overlimit fees
Def(Th):",
	dh002_waive_svc_chrg          	smallint     comment "Def(En): 1 = Waive service charges
Def(Th):",
	dh002_coll_card_rqtd          	smallint     comment "Def(En): 1 = Collection card requested
Def(Th):",
	dh002_stat_chng_flag          	smallint     comment "Def(En): 1 = Status changed today
Def(Th):",
	dh002_request_display         	smallint     comment "Def(En): 1 = Display requested today
Def(Th):",
	dh002_region_codes            	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_exception_response_code 	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_chgoff_status_flag      	smallint     comment "Def(En): Charge off Status Flag 
Def(Th):",
	dh002_write_off_days          	smallint     comment "Def(En): No. of days account must remain in the write-off range before it is allowed to be written off
Def(Th):",
	dh002_cr_bal_refund_days      	smallint     comment "Def(En): No. of days the account must remain in the credit balance range before a credit balance can be refunded
Def(Th):",
	dh002_affinity_flag           	string       comment "Def(En): Y = Account has affinity records
N = Account does not have affinity records
Def(Th):",
	dh002_1098_flag               	smallint     comment "Def(En): 1098 Flag which defines whether the account is eligible for 1098 reporting
Def(Th):",
	dh002_ann_fee_disclosure_sw   	string       comment "Def(En): Indicates whether the membership fee has to be disclosed
Def(Th):",
	dh002_first_usg_flag          	string       comment "Def(En):
Def(Th):",
	dh002_cash_adv_flag           	string       comment "Def(En):
Def(Th):",
	dh002_dte_opened              	string       comment "Def(En):
Def(Th):",
	dh002_dte_lst_stat_chng       	string       comment "Def(En):
Def(Th):",
	dh002_dte_closed              	string       comment "Def(En):
Def(Th):",
	dh002_card_fee_dte            	string       comment "Def(En):
Def(Th):",
	dh002_dte_lst_purchase        	string       comment "Def(En):
Def(Th):",
	dh002_dte_lst_advance         	string       comment "Def(En):
Def(Th):",
	dh002_dte_lst_delq            	string       comment "Def(En):
Def(Th):",
	dh002_dte_prior_delq          	string       comment "Def(En):
Def(Th):",
	dh002_dte_lst_accr            	string       comment "Def(En):
Def(Th):",
	dh002_dte_accr_thru           	string       comment "Def(En):
Def(Th):",
	dh002_dte_lst_active          	string       comment "Def(En):
Def(Th):",
	dh002_dte_lst_cash_pymt       	string       comment "Def(En):
Def(Th):",
	dh002_dte_lst_rtl_pymt        	string       comment "Def(En):
Def(Th):",
	dh002_crlimit_dte             	string       comment "Def(En):
Def(Th):",
	dh002_lst_crlimit_dte         	string       comment "Def(En):
Def(Th):",
	dh002_ach_pymt_exp_dte        	string       comment "Def(En):
Def(Th):",
	dh002_dte_lst_stmt            	string       comment "Def(En):
Def(Th):",
	dh002_dte_nxt_stmt            	string       comment "Def(En):
Def(Th):",
	dh002_dte_pymt_due            	string       comment "Def(En):
Def(Th):",
	dh002_card_expir_dte          	smallint     comment "Def(En): Card Expire date
Def(Th):",
	dh002_card_create_dte         	string       comment "Def(En): Card Create date
Def(Th):",
	dh002_lst_expir_dte           	smallint     comment "Def(En): Card last expire date
Def(Th):",
	dh002_dte_hi_balance          	string       comment "Def(En): Date when account had its highest balance
Def(Th):",
	dh002_dte_lst_pymt            	string       comment "Def(En): last payment date
Def(Th):",
	dh002_dte_cr_balance          	string       comment "Def(En): Date balance went into credit
Def(Th):",
	dh002_dte_warning_bulletin    	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_dte_lst_rtn_check       	string       comment "Def(En): Date of last returned cheque
Def(Th):",
	dh002_dte_lst_debit           	string       comment "Def(En): last debit date
Def(Th):",
	dh002_dte_tbl_hi_balance      	string       comment "Def(En): last hi balance date
Def(Th):",
	dh002_dte_lst_maint           	string       comment "Def(En): last maintenance date
Def(Th):",
	dh002_dte_lst_rate_chg        	string       comment "Def(En): Date of last rate change
Def(Th):",
	dh002_dte_into_collection     	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_alt_cust_expir_dte      	string       comment "Def(En):
Def(Th):",
	dh002_dup_stmt_expir_dte      	string       comment "Def(En):
Def(Th):",
	dh002_pymt_table_dte          	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_user_dte_1              	string       comment "Def(En): User code-1 date
Def(Th):",
	dh002_user_dte_2              	string       comment "Def(En): user code-2 date
Def(Th):",
	dh002_dte_exception_purge     	smallint     comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_dte_xfer_effective      	string       comment "Def(En): วันที่ Transfer บัตร
Def(Th):",
	dh002_late_fee_date           	string       comment "Def(En): Late effective date
Def(Th):",
	dh002_p99                     	string       comment "Def(En):
Def(Th):",
	dh002_1st_late_notice_date    	string       comment "Def(En): First late notice date
Def(Th):",
	dh002_2nd_late_notice_date    	string       comment "Def(En): Second late notice date
Def(Th):",
	dh002_instl_amort_bnp         	decimal(13,2) comment "Def(En):
Def(Th):",
	dh002_filler2                 	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_dte_chgoff_stat_change  	string       comment "Def(En): Chagre off status change date
Def(Th):",
	dh002_dte_cr_bal_range        	string       comment "Def(En): Date on which the account balance fell into the credit balance refund range set on the type record
Def(Th):",
	dh002_dte_block_code          	string       comment "Def(En): Block code date
Def(Th):",
	dh002_dte_alt_block_code      	string       comment "Def(En): Alt block date
Def(Th):",
	dh002_instl_bal               	decimal(11,2) comment "Def(En): Instalment Balance
Def(Th):",
	dh002_amnt_outst_instl        	decimal(11,2) comment "Def(En): Amount outstanding installment
Def(Th):",
	dh002_cash_pymt_tfb           	decimal(11,2) comment "Def(En): Cash payment 
Def(Th):",
	dh002_othr_pymt_tfb           	decimal(11,2) comment "Def(En): Other payment
Def(Th):",
	dh002_crlimit                 	bigint       comment "Def(En): Credit Limit
Def(Th):",
	dh002_lst_crlimit             	bigint       comment "Def(En): Last Credit Limit
Def(Th):",
	dh002_hi_balance              	bigint       comment "Def(En): Highest balance since the account was opened
Def(Th):",
	dh002_pymt_table_hi_bal       	decimal(11,2) comment "Def(En): Highest balance used against the payment table if payment type is 3
Def(Th):",
	dh002_nmbr_rtn_checks         	smallint     comment "Def(En): Number return checks
Def(Th):",
	dh002_months_balance          	smallint     comment "Def(En): No. of months for which the account has had a positive balance
Def(Th):",
	dh002_months_purchase         	smallint     comment "Def(En): No. of purchases this month
Def(Th):",
	dh002_history                 	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_01            	string       comment "Def(En): Deliquence history
Def(Th):",
	dh002_balance_hist_01         	string       comment "Def(En): Balance deliquency
Def(Th):",
	dh002_delq_hist_02            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_02         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_03            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_03         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_04            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_04         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_05            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_05         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_06            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_06         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_07            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_07         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_08            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_08         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_09            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_09         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_10            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_10         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_11            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_11         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_12            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_12         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_13            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_13         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_14            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_14         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_15            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_15         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_16            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_16         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_17            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_17         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_18            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_18         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_19            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_19         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_20            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_20         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_21            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_21         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_22            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_22         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_23            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_23         	string       comment "Def(En):
Def(Th):",
	dh002_delq_hist_24            	string       comment "Def(En):
Def(Th):",
	dh002_balance_hist_24         	string       comment "Def(En):
Def(Th):",
	dh002_coll_history_flag       	string       comment "Def(En): Not use (Indicates if this account has ever been passed to collections)
Def(Th):",
	dh002_ol_flag                 	smallint     comment "Def(En): 1 = Account is overlimit
Def(Th):",
	dh002_olc_reason              	string       comment "Def(En): Reason account is in collections
ไม่ใช้ เพราะเป็นเรื่อง Collection
Def(Th):",
	dh002_ol_amt_due              	decimal(11,2) comment "Def(En): Overlimit amount added to amount due if the bill all overlimit flag is set on the type
Def(Th):",
	dh002_olc_restructure_bal     	decimal(11,2) comment "Def(En): Balance at which a restructure is allowed in CC 
ไม่ใช้ เพราะเป็นเรื่อง Collection
Def(Th):",
	dh002_chgoff_rsn_cd_1         	string       comment "Def(En): Reason for charge-off-1.

Def(Th):",
	dh002_chgoff_rsn_cd_2         	string       comment "Def(En): Reason for charge-off-2.

Def(Th):",
	dh002_embosser_name_1         	string       comment "Def(En): Embossing data for plastic card production
Def(Th):",
	dh002_emb_1_card_data         	string       comment "Def(En): Card Data Line-1
Def(Th):",
	dh002_embosser_name_2         	string       comment "Def(En): Emoboss name -2 
Def(Th):",
	dh002_emb_2_card_data         	string       comment "Def(En): Card Data Line-2
Def(Th):",
	dh002_embosser_name_3         	string       comment "Def(En): Emoboss name -3 
Def(Th):",
	dh002_cash_3mos_intr_free     	decimal(13,4) comment "Def(En): Kbank not use
เป็น field ที่ใช้สำหรับเก็บ accru Interest ว่ามีค่าเท่าไร 
จะมีค่าในกรณีที่ Project code = 6004 - 6013

เนื่องจาก project code 6004-6013 เราจะไม่เรียกเก็บดอกเบี้ยจากผู้ถือบัตร แต่จะนำมาแสดงไว้ที่ field นี้เพื่อบอกว่าดอกเบี้ยเป็นเท่าใด
Def(Th):",
	dh002_emb_3_card_data         	string       comment "Def(En): Card Data Line-3
Def(Th):",
	dh002_embosser_name_4         	string       comment "Def(En): Emoboss name -4
Def(Th):",
	dh002_emb_4_card_data         	string       comment "Def(En): Card Data Line-4
Def(Th):",
	dh002_embosser_name_01        	string       comment "Def(En): Emoboss name  
Def(Th):",
	dh002_card_action_01          	smallint     comment "Def(En): Action Card code
Def(Th):",
	dh002_nmbr_requested_01       	smallint     comment "Def(En):
Def(Th):",
	dh002_card_type_01            	smallint     comment "Def(En):
Def(Th):",
	dh002_nmbr_cards_01           	smallint     comment "Def(En):
Def(Th):",
	dh002_nmbr_cards_ret_01       	smallint     comment "Def(En):
Def(Th):",
	dh002_req_card_type_01        	smallint     comment "Def(En):
Def(Th):",
	dh002_card_prev_action_01     	smallint     comment "Def(En):
Def(Th):",
	dh002_embosser_name_02        	string       comment "Def(En):
Def(Th):",
	dh002_card_action_02          	smallint     comment "Def(En):
Def(Th):",
	dh002_nmbr_requested_02       	smallint     comment "Def(En):
Def(Th):",
	dh002_card_type_02            	smallint     comment "Def(En):
Def(Th):",
	dh002_nmbr_cards_02           	smallint     comment "Def(En):
Def(Th):",
	dh002_nmbr_cards_ret_02       	smallint     comment "Def(En):
Def(Th):",
	dh002_req_card_type_02        	smallint     comment "Def(En):
Def(Th):",
	dh002_card_prev_action_02     	smallint     comment "Def(En):
Def(Th):",
	dh002_embosser_name_03        	string       comment "Def(En):
Def(Th):",
	dh002_card_action_03          	smallint     comment "Def(En):
Def(Th):",
	dh002_nmbr_requested_03       	smallint     comment "Def(En):
Def(Th):",
	dh002_card_type_03            	smallint     comment "Def(En):
Def(Th):",
	dh002_nmbr_cards_03           	smallint     comment "Def(En):
Def(Th):",
	dh002_nmbr_cards_ret_03       	smallint     comment "Def(En):
Def(Th):",
	dh002_req_card_type_03        	smallint     comment "Def(En):
Def(Th):",
	dh002_card_prev_action_03     	smallint     comment "Def(En):
Def(Th):",
	dh002_embosser_name_04        	string       comment "Def(En):
Def(Th):",
	dh002_card_action_04          	smallint     comment "Def(En):
Def(Th):",
	dh002_nmbr_requested_04       	smallint     comment "Def(En):
Def(Th):",
	dh002_card_type_04            	smallint     comment "Def(En):
Def(Th):",
	dh002_nmbr_cards_04           	smallint     comment "Def(En):
Def(Th):",
	dh002_nmbr_cards_ret_04       	smallint     comment "Def(En):
Def(Th):",
	dh002_req_card_type_04        	smallint     comment "Def(En):
Def(Th):",
	dh002_card_prev_action_04     	smallint     comment "Def(En):
Def(Th):",
	dh002_checking_acct           	bigint       comment "Def(En): Current Account for using ATM
Def(Th):",
	dh002_savings_acct            	bigint       comment "Def(En): Saving Account for using ATM
Def(Th):",
	dh002_user_acct               	bigint       comment "Def(En): ฟิลด์ User-Acct เก็บข้อมูล 2 ความหมาย
1.สำหรับบัตร Type 971,979  ฟิลด์ user-acct นี้เก็บข้อมูลบัตร Priority-Pass  ไว้ค่ะ ซึ่งบัตร Priority-Pass เป็นบัตรพิเศษอีกใบที่ธนาคารออกให้ลูกค้า
2.สำหรับบัตรประเภทอื่นๆ ฟิลด์ user-acct นี้ เก็บข้อมูลบัตรเบอร์เก่า ก่อนที่จะทำการ Upgrade เป็นบัตรประเภทใหม่ที่สูงกว่าเดิมค่ะ  (Project Convert บัตรค่ะ)
หมายเหตุ : สำหรับบัตร Type 971,979  ฟิลด์ user-acct จะเก็บหมายเลขบัตร Priority-Pass 16 หลักคะ  ซึ่งไม่ใช่หมายเลขบัตรเครดิต

Format ของหมายเลข Priority Pass ที่เก็บในฟิลด์ User Account 16 หลัก  แบ่งเป็น 2 Case ดังนี้

1.บัตร Priority Pass แบบเก่า  : มีเลข 12 หลัก โดยข้อมูลที่เก็บ ใน User account 16 หลัก คือ 0000XXXXXXXXXXXX 
ตำแหน่งที่ 1 -4 มีค่าเป็น 0000 , ตำแหน่งที่ 5 – 16 คือ หมายเลข Priority Pass)  
  
2.บัตรPriority Pass แบบใหม่ : มีเลข 14 โดยข้อมูลที่เก็บ ใน User account 16 หลัก คือ  = 99XXXXXXXXXXXXXX  
ตำแหน่งแรกของฟิลด์ User Account จะเก็บค่า Action บัตร (1-8)
ตำแหน่งที่ 2 ของฟิลด์ User Account จะเก็บค่า Previous-Action (1-8) ไว้ (ค่านี้จะถูก Move มาจากหลักแรก)
ตำแหน่งที่ 3 – 16 คือ หมายเลข Priority Pass)



Def(Th):",
	dh002_pin_offset              	integer      comment "Def(En):
Def(Th):",
	dh002_dte_lst_req             	string       comment "Def(En): Last request date
Def(Th):",
	dh002_card_usage_flag         	smallint     comment "Def(En):
Def(Th):",
	dh002_pre_reissue_action      	smallint     comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_reissue_action          	smallint     comment "Def(En):
Def(Th):",
	dh002_total_nmbr_cards        	smallint     comment "Def(En):
Def(Th):",
	dh002_pymt_skip_flag          	smallint     comment "Def(En):
Def(Th):",
	dh002_pymt_flag               	smallint     comment "Def(En): Paymenet 
Def(Th):",
	dh002_ach_flag                	smallint     comment "Def(En):
Def(Th):",
	dh002_fixed_pymt_amnt         	decimal(11,2) comment "Def(En): Fixed payment amount
Def(Th):",
	dh002_ach_rt_nmbr             	integer      comment "Def(En): Bank Sort Code
Def(Th):",
	dh002_ach_db_nmbr             	bigint       comment "Def(En): Auto payment Account number
Def(Th):",
	dh002_ep_nbr_pin_retries      	smallint     comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_ep_pin_retries_curr_code	smallint     comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_ep_pin_retries_date     	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_filler3                 	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_beg_cycle_due           	smallint     comment "Def(En): Begin Cycle Due
Def(Th):",
	dh002_cycle_due               	smallint     comment "Def(En): Cycle due
Def(Th):",
	dh002_amnt_prepaid            	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_total_amnt_due          	decimal(11,2) comment "Def(En): Total amount due
Def(Th):",
	dh002_reage_request           	string       comment "Def(En): Reage request flag
Def(Th):",
	dh002_dte_lst_reage           	string       comment "Def(En): Last reage request date
Def(Th):",
	dh002_curr_due                	decimal(11,2) comment "Def(En): Current Due amount
Def(Th):",
	dh002_past_due                	decimal(11,2) comment "Def(En): Pass due amount
Def(Th):",
	dh002_30days_delq             	decimal(11,2) comment "Def(En): 30 days deliquncy amount
Def(Th):",
	dh002_60days_delq             	decimal(11,2) comment "Def(En): 60 days deliquncy amount
Def(Th):",
	dh002_90days_delq             	decimal(11,2) comment "Def(En): 90 days deliquncy amount
Def(Th):",
	dh002_120days_delq            	decimal(11,2) comment "Def(En): 120 days deliquncy amount
Def(Th):",
	dh002_150days_delq            	decimal(11,2) comment "Def(En): 150 days deliquncy amount
Def(Th):",
	dh002_180days_delq            	decimal(11,2) comment "Def(En): 180 days deliquncy amount
Def(Th):",
	dh002_210days_delq            	decimal(11,2) comment "Def(En): 210 days deliquncy amount
Def(Th):",
	dh002_buckets_clear           	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_pymt_bucket_01          	decimal(11,2) comment "Def(En): PAYMENT-BUCKET
Def(Th):",
	dh002_pymt_bucket_02          	decimal(11,2) comment "Def(En):
Def(Th):",
	dh002_pymt_bucket_03          	decimal(11,2) comment "Def(En):
Def(Th):",
	dh002_pymt_bucket_04          	decimal(11,2) comment "Def(En):
Def(Th):",
	dh002_pymt_bucket_05          	decimal(11,2) comment "Def(En):
Def(Th):",
	dh002_pymt_bucket_06          	decimal(11,2) comment "Def(En):
Def(Th):",
	dh002_pymt_bucket_07          	decimal(11,2) comment "Def(En):
Def(Th):",
	dh002_pymt_bucket_08          	decimal(11,2) comment "Def(En):
Def(Th):",
	dh002_pymt_bucket_09          	decimal(11,2) comment "Def(En):
Def(Th):",
	dh002_delq_counter1           	smallint     comment "Def(En): Deliquence counter 
Def(Th):",
	dh002_delq_counter2           	smallint     comment "Def(En): Deliquence counter 
Def(Th):",
	dh002_delq_counter3           	smallint     comment "Def(En): Deliquence counter 
Def(Th):",
	dh002_delq_counter4           	smallint     comment "Def(En): Deliquence counter 
Def(Th):",
	dh002_delq_counter5           	smallint     comment "Def(En): Deliquence counter 
Def(Th):",
	dh002_delq_counter6           	smallint     comment "Def(En): Deliquence counter 
Def(Th):",
	dh002_delq_counter7           	smallint     comment "Def(En): Deliquence counter 
Def(Th):",
	dh002_delq_counter8           	smallint     comment "Def(En): Deliquence counter 
Def(Th):",
	dh002_waive_prepay            	smallint     comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_prepay_cycles_left      	smallint     comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_last_pymt_sw            	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_last_pymt_aged_count    	smallint     comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_last_pymt_change1       	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_last_pymt_change2       	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_last_pymt_change3       	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_last_pymt_change4       	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_last_pymt_change5       	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_last_pymt_change6       	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_last_pymt_change7       	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_last_pymt_change8       	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_last_pymt_change9       	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_last_pymt_prepay_change 	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_rtl_beg_balance         	decimal(11,2) comment "Def(En): Retail beginning balance
Def(Th):",
	dh002_rtl_amnt_db             	decimal(11,2) comment "Def(En): Retail debit amount
Def(Th):",
	dh002_rtl_amnt_cr             	decimal(11,2) comment "Def(En): retail credit amount
Def(Th):",
	dh002_rtl_balance             	decimal(11,2) comment "Def(En): Retail balance
Def(Th):",
	dh002_rtl_ibnp                	decimal(11,2) comment "Def(En): Retail interest bill not paid
Def(Th):",
	dh002_rtl_svc_bnp             	decimal(7,2) comment "Def(En): Retail service bill not paid
Def(Th):",
	dh002_rtl_misc_fees           	decimal(7,2) comment "Def(En): retail misicllinus bill not paid
Def(Th):",
	dh002_rtl_insur_bnp           	decimal(7,2) comment "Def(En): retail insurance bill not paid
Def(Th):",
	dh002_rtl_member_bnp          	decimal(7,2) comment "Def(En): retail member bill not paid
Def(Th):",
	dh002_rtl_misc_ctd            	decimal(9,2) comment "Def(En): retail misicllinus cycle to date
Def(Th):",
	dh002_rtl_disputed_bal        	decimal(11,2) comment "Def(En): retail deiputed balance
Def(Th):",
	dh002_rtl_curr_mon_bal        	decimal(11,2) comment "Def(En): retail current mon balance
Def(Th):",
	dh002_rtl_accrued_intr        	decimal(13,4) comment "Def(En): retail accure interest
Def(Th):",
	dh002_rtl_nmbr_db             	smallint     comment "Def(En): retail debit number
Def(Th):",
	dh002_rtl_nmbr_cr             	smallint     comment "Def(En): retail credit number
Def(Th):",
	dh002_rtl_pymt_ctd            	decimal(11,2) comment "Def(En): retail payment cycle to date
Def(Th):",
	dh002_rtl_ytd_intr_billed     	decimal(11,2) comment "Def(En): retail interest billed year to date
Def(Th):",
	dh002_rtl_ibnp_lst_stmt       	decimal(11,2) comment "Def(En): retail interest bill not paid last statement
Def(Th):",
	dh002_rtl_ytd_intr_paid       	decimal(11,2) comment "Def(En): Retail interest paid year to date
Def(Th):",
	dh002_rtl_lst_ytd_intr_paid   	decimal(11,2) comment "Def(En): Retail interest paid last year to date
Def(Th):",
	dh002_rtl_amnt_pymt_rev       	decimal(11,2) comment "Def(En): Retail payment amount reverse
Def(Th):",
	dh002_rtl_std_intr            	decimal(11,2) comment "Def(En): retail standard interest
Def(Th):",
	dh002_rtl_provis_bal          	decimal(11,2) comment "Def(En): retail provisional balance
Def(Th):",
	dh002_rtl_provis_intr         	decimal(13,4) comment "Def(En): retail provision interest 
Def(Th):",
	dh002_rtl_filler              	string       comment "Def(En):
Def(Th):",
	dh002_cash_beg_balance        	decimal(11,2) comment "Def(En): cash beginning balance
Def(Th):",
	dh002_cash_amnt_db            	decimal(11,2) comment "Def(En): cash  debit amount
Def(Th):",
	dh002_cash_amnt_cr            	decimal(11,2) comment "Def(En): cash  credit amount
Def(Th):",
	dh002_cash_balance            	decimal(11,2) comment "Def(En): cash balance
Def(Th):",
	dh002_cash_ibnp               	decimal(11,2) comment "Def(En): cash interest bill not paid
Def(Th):",
	dh002_cash_svc_bnp            	decimal(7,2) comment "Def(En): cash service bill not paid
Def(Th):",
	dh002_cash_disputed_bal       	decimal(11,2) comment "Def(En): cash deiputed balance
Def(Th):",
	dh002_cash_curr_mon_bal       	decimal(11,2) comment "Def(En): cash current mon balance
Def(Th):",
	dh002_cash_accrued_intr       	decimal(13,4) comment "Def(En): cash accure interest
Def(Th):",
	dh002_cash_nmbr_db            	smallint     comment "Def(En): cash  debit number
Def(Th):",
	dh002_cash_nmbr_cr            	smallint     comment "Def(En): Cash number credit
Def(Th):",
	dh002_cash_pymt_ctd           	decimal(11,2) comment "Def(En): cash payment cycle to date
Def(Th):",
	dh002_cash_ytd_intr_billed    	decimal(11,2) comment "Def(En): cash interest billed year to date
Def(Th):",
	dh002_cash_ibnp_lst_stmt      	decimal(11,2) comment "Def(En): Interest billed not paid at last statement
Def(Th):",
	dh002_cash_ytd_intr_paid      	decimal(11,2) comment "Def(En): cash  interest paid year to date
Def(Th):",
	dh002_cash_lst_ytd_intr_paid  	decimal(11,2) comment "Def(En): cash  interest paid last year to date
Def(Th):",
	dh002_cash_amnt_pymt_rev      	decimal(11,2) comment "Def(En): cash  payment amount reverse
Def(Th):",
	dh002_cash_std_intr           	decimal(11,2) comment "Def(En): Cash statement to date interest
ดอกเบี้ยที่เกิดจากทำรายการ Cash Advance นับตั้งแต่วัน Statement จนถึงวันนี้
Def(Th):",
	dh002_rtl_neg_provis_intr     	decimal(13,4) comment "Def(En):
Def(Th):",
	dh002_rtl_neg_antici_intr     	decimal(13,4) comment "Def(En):
Def(Th):",
	dh002_cash_filler             	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_curr_balance            	decimal(11,2) comment "Def(En): Current Balance
Def(Th):",
	dh002_amnt_lst_debit          	decimal(9,2) comment "Def(En): Last debit amount
Def(Th):",
	dh002_amnt_lst_purch          	decimal(9,2) comment "Def(En): Last purchase amount
Def(Th):",
	dh002_amnt_lst_adv            	decimal(9,2) comment "Def(En): Last cash advance amount
Def(Th):",
	dh002_amnt_outst_auth         	decimal(11,2) comment "Def(En): Amount of outstanding (unmatched) authorisations
Def(Th):",
	dh002_nmbr_outst_auth         	smallint     comment "Def(En): Outstanding authorize number
Def(Th):",
	dh002_avail_credit            	bigint       comment "Def(En): Available credit
Def(Th):",
	dh002_csh_adv_lim             	integer      comment "Def(En): Cash advance limit
Def(Th):",
	dh002_csh_adv_avail           	integer      comment "Def(En): Cash advace available
Def(Th):",
	dh002_grace_days              	smallint     comment "Def(En): Greace days period
Def(Th):",
	dh002_lst_ytd_intr_billed     	decimal(11,2) comment "Def(En): Last Interest bill year to date
Def(Th):",
	dh002_curr_ytd_svc_chrg       	decimal(11,2) comment "Def(En): Current Service charge Year to Date
Def(Th):",
	dh002_aggr_cash_balance       	decimal(13,2) comment "Def(En):
Def(Th):",
	dh002_aggr_rtl_balance        	decimal(13,2) comment "Def(En):
Def(Th):",
	dh002_nmbr_disputed_items     	smallint     comment "Def(En): Number of dispute item
Def(Th):",
	dh002_amnt_disputed_items     	decimal(11,2) comment "Def(En): amount of dispute item
Def(Th):",
	dh002_rtl_amnt_charge_off     	decimal(11,2) comment "Def(En): Retail charge off amount
Def(Th):",
	dh002_cash_amnt_charge_off    	decimal(11,2) comment "Def(En): Cash charge off amount
Def(Th):",
	dh002_lst_pymt_amnt           	decimal(9,2) comment "Def(En): Last payment amount
Def(Th):",
	dh002_aggr_cash_days          	smallint     comment "Def(En):
Def(Th):",
	dh002_aggr_rtl_days           	smallint     comment "Def(En):
Def(Th):",
	dh002_amnt_auth_tdy           	decimal(11,2) comment "Def(En): Amount of authorisations today
Def(Th):",
	dh002_nmbr_auth_tdy           	smallint     comment "Def(En): Number of authorisations today
Def(Th):",
	dh002_amnt_decl_tdy           	decimal(11,2) comment "Def(En): Amount of authorisation requests declined today
Def(Th):",
	dh002_nmbr_decl_tdy           	smallint     comment "Def(En): Number of authorisation requests declined today
Def(Th):",
	dh002_annual_fee              	decimal(7,2) comment "Def(En): Annual fee rate
Def(Th):",
	dh002_bb_beg_balance          	integer      comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_bb_used_ctd             	integer      comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_instl_limit             	bigint       comment "Def(En): Installment limit
Def(Th):",
	dh002_filler4                 	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_2nd_late_notice_counter 	smallint     comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_aggr_ytd_days           	smallint     comment "Def(En): Total no. of days in the year on which there has been a balance on the account
Def(Th):",
	dh002_aggr_ytd_balance        	decimal(13,2) comment "Def(En):
Def(Th):",
	dh002_aggr_lst_ytd_days       	smallint     comment "Def(En): No. of days on which there was a balance on the account last year
Def(Th):",
	dh002_aggr_lst_ytd_balance    	decimal(13,2) comment "Def(En):
Def(Th):",
	dh002_rtl_neg_antici_bal      	decimal(11,2) comment "Def(En):
Def(Th):",
	dh002_rtl_neg_provis_bal      	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_ci_option               	smallint     comment "Def(En): Cash Interest option
Def(Th):",
	dh002_ci_flag                 	smallint     comment "Def(En): cash Interest flag
Def(Th):",
	dh002_ci_change_flag          	smallint     comment "Def(En): 1 = Cash interest changed today
2 = Change cash interest today
Def(Th):",
	dh002_ci_limit_1              	bigint       comment "Def(En): Cash interest limit - 1
Def(Th):",
	dh002_ci_limit_2              	bigint       comment "Def(En): Cash interest limit - 2
Def(Th):",
	dh002_ci_rate_1               	decimal(8,7) comment "Def(En): Cash Interest rate - 1
Def(Th):",
	dh002_ci_adj_1                	decimal(8,7) comment "Def(En): Cash interest adjust - 1
Def(Th):",
	dh002_ci_rate_2               	decimal(8,7) comment "Def(En): Cash Interest rate - 2
Def(Th):",
	dh002_ci_adj_2                	decimal(8,7) comment "Def(En): Cash interest adjust - 2
Def(Th):",
	dh002_ci_rate_3               	decimal(8,7) comment "Def(En): Cash Interest rate - 3
Def(Th):",
	dh002_ci_adj_3                	decimal(8,7) comment "Def(En): Cash interest adjust - 3
Def(Th):",
	dh002_ri_option               	smallint     comment "Def(En): Wave retail interest flage
Def(Th):",
	dh002_ri_flag                 	smallint     comment "Def(En): retail Interest flag
Def(Th):",
	dh002_ri_change_flag          	smallint     comment "Def(En):
Def(Th):",
	dh002_ri_limit_1              	bigint       comment "Def(En): Retail interest limit - 1
Def(Th):",
	dh002_ri_limit_2              	bigint       comment "Def(En): Retail interest limit - 2
Def(Th):",
	dh002_ri_rate_1               	decimal(8,7) comment "Def(En): Retail Interest rate - 1
Def(Th):",
	dh002_ri_adj_1                	decimal(8,7) comment "Def(En): Retail interest adjust - 1
Def(Th):",
	dh002_ri_rate_2               	decimal(8,7) comment "Def(En): Retail Interest rate - 2
Def(Th):",
	dh002_ri_adj_2                	decimal(8,7) comment "Def(En): Retail interest adjust - 2
Def(Th):",
	dh002_ri_rate_3               	decimal(8,7) comment "Def(En): Retail Interest rate - 3
Def(Th):",
	dh002_ri_adj_3                	decimal(8,7) comment "Def(En): Retail interest adjust - 3
Def(Th):",
	dh002_intr_sw                 	smallint     comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_intr_per_diem           	decimal(9,4) comment "Def(En): Interest Per day
Def(Th):",
	dh002_pot_select_code         	smallint     comment "Def(En): Determines the P.O.T. to which account is assigned
Def(Th):",
	dh002_pot_exp_date            	smallint     comment "Def(En): POT Expire date
เก็บ Expire date (format MMYY) ของ Product Offering Table
Def(Th):",
	dh002_pend_pot_select_code    	smallint     comment "Def(En): Determines the P.O.T. to which the account will be assigned when the current assignment expires
Def(Th):",
	dh002_pend_pot_exp_date       	smallint     comment "Def(En): เก็บ Expire date (format MMYY) ของ Pending Product Offering Table
Def(Th):",
	dh002_prior_pot_select_code   	smallint     comment "Def(En): The P.O.T. to which the account was last assigned
Def(Th):",
	dh002_prior_pot_exp_date      	smallint     comment "Def(En): เก็บ Expire date (format MMYY) ของ Prior Product Offering Table
Def(Th):",
	dh002_cash_adv_per_fee_ctd    	decimal(7,2) comment "Def(En): Amount of cash advance fees accrued in this cycle
Def(Th):",
	dh002_intr_filler             	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_ie_accrued              	decimal(11,4) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_ie_aggr_bal             	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_ie_aggr_days            	smallint     comment "Def(En): Number of days with a credit balance on which interest is to be calculated
Def(Th):",
	dh002_ie_ytd                  	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_ie_prior_ytd            	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_ie_tax_ytd              	decimal(11,2) comment "Def(En): Amount of tax paid on earned interest in the current financial year
Def(Th):",
	dh002_ie_prior_tax_ytd        	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_tax_fisc_ytd            	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_tax_fisc_prior_ytd      	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_pymt_pending            	string       comment "Def(En): Determines if a payment is pending for this cardholder
Def(Th):",
	dh002_bdg_multiple            	decimal(3,1) comment "Def(En): The factor by which the fixed payment amount is multiplied to give the account credit limit
Def(Th):",
	dh002_ins_no_policies         	smallint     comment "Def(En): Number of insurance policies in force on the account
Def(Th):",
	dh002_dte_lst_cycle           	string       comment "Def(En):
Def(Th):",
	dh002_coll_block_code         	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_stop_int_income_date    	string       comment "Def(En): วันที่ติด NPL Flag
Def(Th):",
	dh002_stop_int_income_flag    	string       comment "Def(En): NPL Flag
Def(Th):",
	dh002_dte_user_code_3         	string       comment "Def(En): Date User Code-3
Def(Th):",
	dh002_fee_charge_pct_tfb      	smallint     comment "Def(En): ค่า Fee Charge ที่ Kbank กำหนด
Def(Th):",
	dh002_cycle_chg_tfb           	string       comment "Def(En):
Def(Th):",
	dh002_mc_ytd_ss               	smallint     comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_rtl_svc_ctd_tfb         	decimal(7,2) comment "Def(En): ยอดค่า Service ภายในรอบ Statement
Def(Th):",
	dh002_waive_repl_fee_tfb      	smallint     comment "Def(En): Flag Waive Replacement request fee
Def(Th):",
	dh002_waive_pinreq_fee_tfb    	smallint     comment "Def(En): Flag Waive PIN request fee
Def(Th):",
	dh002_pinreq_count_tfb        	smallint     comment "Def(En): จำนวนครั้งการขอ PIN 
Def(Th):",
	dh002_cycle_cash_limit_tfb    	bigint       comment "Def(En): วงเงิน การถอนเงิน ที่ใช้ได้ ในรอบบิล Cash advance limit in Cycle
Def(Th):",
	dh002_cycle_avail_cash_tfb    	bigint       comment "Def(En): วงเงิน การถอนเงิน ที่เหลืออยู่  Cash Advance available
Def(Th):",
	dh002_daily_avail_cash_tfb    	bigint       comment "Def(En): วงเงิน การถอนเงินสดที่ใช้ได้ต่อวัน Daily Cash advance 
Def(Th):",
	dh002_cash_outst_auth_tfb     	decimal(11,2) comment "Def(En):
Def(Th):",
	dh002_cash_outst_auth_tdy_tfb 	decimal(11,2) comment "Def(En):
Def(Th):",
	dh002_rtl_prev_mon_bal        	decimal(11,2) comment "Def(En):
Def(Th):",
	dh002_rtl_ib_ctd_tfb          	decimal(7,2) comment "Def(En):
Def(Th):",
	dh002_waive_joining_fee       	smallint     comment "Def(En):
Def(Th):",
	dh002_crlimit_perm            	bigint       comment "Def(En): Credit limit permanent
Def(Th):",
	dh002_crlimit_temp            	bigint       comment "Def(En): Credit limit temporary
Def(Th):",
	dh002_crlimit_temp_eff_dte    	string       comment "Def(En): Credit limit temporary start date
Def(Th):",
	dh002_crlimit_temp_exp_dte    	string       comment "Def(En): Credit limit temporary end date
Def(Th):",
	dh002_cash_limit              	bigint       comment "Def(En): Cash limit
Def(Th):",
	dh002_avail_cash              	bigint       comment "Def(En): Available cash
Def(Th):",
	dh002_cash_adv_os_auth        	bigint       comment "Def(En): Cash advance outstanding authorize
Def(Th):",
	dh002_dte_lst_cash_auth       	string       comment "Def(En): Last date cash authorization
Def(Th):",
	dh002_xfr_ind                 	smallint     comment "Def(En):
Def(Th):",
	dh002_posting_flag            	string       comment "Def(En):
Def(Th):",
	dh002_posting_acct_orgn       	smallint     comment "Def(En):
Def(Th):",
	dh002_posting_acct_type       	smallint     comment "Def(En):
Def(Th):",
	dh002_posting_acct_nmbr       	bigint       comment "Def(En):
Def(Th):",
	dh002_np_ctd_used_amnt        	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_np_ctd_used_cash        	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_filler_jcb              	string       comment "Def(En):
Def(Th):",
	dh002_cash_cr_adjust_bnp      	decimal(11,2) comment "Def(En):
Def(Th):",
	dh002_rtl_cr_adjust_bnp       	decimal(11,2) comment "Def(En):
Def(Th):",
	dh002_ol_cash_pymt            	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_ol_rtl_pymt             	decimal(11,2) comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_lst_dte_pymt_due        	string       comment "Def(En): Last Payment Due Date
Def(Th):",
	dh002_prev_cc_reason          	string       comment "Def(En): Not use in Kbank
Def(Th):",
	dh002_prev_pin_offset         	integer      comment "Def(En):
Def(Th):",
	dh002_dte_pin_maint           	string       comment "Def(En):
Def(Th):",
	dh002_avail_instl             	bigint       comment "Def(En): Installment Avialable
Def(Th):",
	dh002_qrtly_trx_flg           	string       comment "Def(En): Quarter transaction flag
Indicator ที่จะถูก update on first processing day of every querter
TRX-PROCESSED   VALUE 'Y'.
Def(Th):",
	dh002_filler5                 	string       comment "Def(En):
Def(Th):",
	dh002_offline_block           	string       comment "Def(En):
Def(Th):",
	dh002_rl_flag                 	string       comment "Def(En):
Def(Th):",
	dh002_rl_dte                  	string       comment "Def(En):
Def(Th):",
	dh002_ll_flag                 	string       comment "Def(En):
Def(Th):",
	dh002_ll_dte                  	string       comment "Def(En):
Def(Th):",
	dh002_prev_beg_bal_tfb        	decimal(11,2) comment "Def(En): Previous beginning balance (statement)
Def(Th):",
	dh002_cash_instl_amort        	decimal(11,2) comment "Def(En): จำนวนเงินผ่อนชำระต่องวด (รายการ Cash Advance Installment) 
Def(Th):",
	dh002_cash_instl_amort_bnp    	decimal(11,2) comment "Def(En): ยอดค้างชำระ (รายการ Cash Advance Installment)
Def(Th):",
	dh002_dte_activation          	string       comment "Def(En): Activation date for JCB card only
Def(Th):",
	filler                        	string       comment "Def(En):
Def(Th):",
	load_tms                      	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                    	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                      	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                        	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                        	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_kb1dh002_cpbcrd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);