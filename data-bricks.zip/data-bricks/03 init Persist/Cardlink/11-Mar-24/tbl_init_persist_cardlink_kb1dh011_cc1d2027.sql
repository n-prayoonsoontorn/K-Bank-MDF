-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_kb1dh011_cc1d2027.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-11    Panita T.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_KB1DH011_CC1D2027
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_kb1dh011_cc1d2027 (
	pos_dt                       	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh011_d_type                 	smallint     comment "Def(En): TYPE OF CARD
Def(Th):",
	dh011_d_card_nmbr            	bigint       comment "Def(En): CARD NUMBER
Def(Th):",
	dh011_d_stmt_date            	date         comment "Def(En): Statement Date
Def(Th):",
	dh011_d_file_date            	date         comment "Def(En):
Def(Th): File Date  = Extract date ตาม  batch date",
	dh011_d_curr_balance         	decimal(11,2) comment "Def(En):
Def(Th): Current Balance ยอดหนี้  จะมีค่าคงที่ตามรอบ statement  ล่าสุด",
	dh011_d_stop_int_income_flag 	string       comment "Def(En):
Def(Th): Flag to stop Calculate Interest เป็นหนี้เสียแล้วหรือยัง 
  spaces  คือ ลูกค้าปกติ (ชั้นดี)
   0             คือ ลูกค้าที่เคยเป็นหนี้เสีย และกลับมาเป็นลูกค้าชั้นดี (ปัจจุบันเป็น 0 คือ ลูกหนี้ดี)
   1            คือ NPL รุ่นอดีต (LPM จะมีสูตรการคำนวณรองรับ NPL รุ่นเก่า)                                                                          
   2.          คือ NPL ปัจจุบัน",
	dh011_d_cust_nmbr            	bigint       comment "Def(En):
Def(Th): Custommer Number เบอร์ลูกค้า Cardlink",
	dh011_d_alt_cust_nmbr        	bigint       comment "Def(En):
Def(Th): Supplement Customer number  บอกว่าเป็นลูกค้าหลัก หรือ ลูกค้าเสริม 
ถ้าเป็นลูกค้าหลัก = 0 แต่ถ้ามีหมายเลข  16  หลัก เป็นบัตรเสริม

 ถ้า DH002_ALT_CUSTOMER_NMBR  = 0  แสดงว่า เป็น บัตรหลักแต่ ถ้า > 0  แสดงว่าเป็นบัตรเสริม 
ตัวอย่าง นาย ก.  บัตรใบที่  1  เป็นบัตรหลัก 
 DH002_CUSTOMER_NMBR  = Internal customer no. #1 และ  DH002_ALT_CUSTOMER_NMBR  = 0 (16 ตัว) 

 นาย ข . เป็น บัตรเสริมของ นาย   ก.
 DH002_CUSTOMER_NMBR  = Internal customer no#1 DH002_ALT_CUSTOMER_NMBR  = Internal customer no#2",
	dh011_d_cycle                	smallint     comment "Def(En):
Def(Th): Cycle Due  รอบ  statement  ของบัตร",
	dh011_d_misc_late_not_paid   	decimal(11,2) comment "Def(En):
Def(Th): Miscellenous check   ค่าธรรมเนียมที่ยังไม่ได้จ่าย รวมDH011-D-MISC-CHEQUE-NOT-PAID (ค่าธรรมเนียมจ่ายล่าช้า)",
	dh011_d_misc_cheque_not_paid 	decimal(11,2) comment "Def(En):
Def(Th): Miscellenous check not paid  ค่าธรรมเนียมที่จ่ายด้วยเช็ค แล้วเช็คเด้ง",
	dh011_d_accum_int_income     	decimal(11,2) comment "Def(En):
Def(Th): Interest Income ดอกเบี้ยสะสมในการ์ด ถ้าเป็นลูกค้าดี ยอดคงค้างหนี้ <= 90 วัน  จะดูที่ค่านี้ จะลงค่านี้
การคิดดอกเบี้ย คิดทุกวัน  
DH011-D-ACCUM-STOP-INT-INCOME  = 50,000",
	dh011_d_accum_stop_int_income	decimal(11,2) comment "Def(En):
Def(Th): Stop interest Income ถ้า ลูกค้าเป็นหนี้ มากกว่า > 90 วัน จะถือว่าเป็นหนี้เสีย จะลงดอกเบี้ยที่ค่านี้ เป็นดอกเบี้ยนอกการ์ด  ตัวอย่างเช่น  ณ วันที่  91 DH011-D-ACCUM-INT-INCOME  = 0 
DH011-D-ACCUM-STOP-INT-INCOME = 50,001",
	dh011_d_cm_curr_balance      	decimal(11,2) comment "Def(En):
Def(Th): Current Balance  
ยอดหนี้คงค้างเดิม และ ยอดคงค้างล่าสุด
ยอดหนี้ ของ  card holder DH002  และ ยอดหนี้  ของ Statement  
 ยอดหนี้ outstanding",
	dh011_d_cm_cycle_due         	smallint     comment "Def(En):
Def(Th): Cycle Due  ลูกค้าเกินกำหนดชำระ หรือไม่ ตัวอย่าง 
0, 1, 2   ยังไม่มีค้างชำระ      เช่น  1 - 29   วัน
3             ค้างชำระ  30  วัน   เช่น  30 - 59   วัน
4              ค้างชำระ  60 วัน  เช่น   60 - 89   วัน 
5             ค้างชำระ  90 วัน
6              ค้างชำระ  120 วัน
7              ค้างชำระ  150 วัน
8              ค้างชำระ  180 วัน  เช่น  181 - 209  วัน
9              ค้างชำระ  210 วัน ขึ้นไป",
	dh011_d_cm_ibnp              	decimal(11,2) comment "Def(En):
Def(Th): CardLink interest Bill not paid    ดอกเบี้ยทั้งหมดที่เกิดขึ้น มีค่าเท่ากับ
DH011-D-ACCUM-INT-INCOME  +
DH011-D-ACCUM-STOP-INT-INCOME",
	dh011_d_cm_rtl_misc          	decimal(11,2) comment "Def(En):
Def(Th): CardLink Retial MIS  ค่าธรรมเนียมของบัตรเครดิต
 เช่น รูดซื้อสินค้า ( Unused field)  
 PIN Request fee, Service Charge, Miscellouse fee",
	dh011_d_cm_month_delq        	smallint     comment "Def(En):
Def(Th): Deliquency Months จำนวนเดือนที่ผิดชำระ  ( Unused field)",
	dh011_d_base_amt             	decimal(11,2) comment "Def(En):
Def(Th): Principle amount จำนวนเงินต้น",
	dh011_d_base_int             	decimal(11,2) comment "Def(En):
Def(Th): Interest Amount (Reverse Interest) ดอกเบี้ย  Accrure 
มีค่าเท่ากับ DH011-D-ACCUM-INT-INCOME 
สำหรับวันที่  0 - 90 
DH011-D-BASE-INT  = DH011-D-ACCUM-INT-INCOME   
ตัวอย่างเช่น วันที่  90  มีค่า = 50,000

วันที่  91  DH011-D-BASE-INT  = 50,000  ค่านี้จะคงที่  เรียกว่า  reverse",
	dh011_d_base_memo            	decimal(11,2) comment "Def(En):
Def(Th): Memo Amount   เป็นดอกเบี้ยนับ วันที่  91  
DH011-D-BASE-MEMO = 1",
	dh011_d_base_misc            	decimal(11,2) comment "Def(En):
Def(Th): Base MISC Amount  ค่าธรรมเนียมเรียกเก็บทั้งหมด",
	dh011_d_occpn_code           	string       comment "Def(En):
Def(Th): Occupation code ( Unused field )",
	dh011_d_block_code           	string       comment "Def(En):
Def(Th): Block code ควรไปดูที่ file 002 จะดีกว่า ( Unused field )",
	dh011_d_expire_dte           	smallint     comment "Def(En):
Def(Th): Expire Date วันหมดอายุของบัตร ( Unused field )",
	dh011_d_dte_lst_advance      	string       comment "Def(En):
Def(Th): Date last Advance วันล่าสุดที่มี  cash advance กดเงินจากบัตร ( Unused field )",
	dh011_d_flag                 	string       comment "Def(En):
Def(Th): Flag   ( Unused field )",
	dh011_d_rtl_cash_interest    	decimal(11,2) comment "Def(En):
Def(Th): Retail cash interest ดอกเบี้ยที่จากการกดเงิน ณ วัน statement  ( Unused field )",
	dh011_d_tax                  	decimal(11,2) comment "Def(En):
Def(Th): Tax Paid หนี้เสียมีการชำระเงินเข้ามา ต้องจ่าย TAX",
	filler                       	string       comment "Def(En): Filler
Def(Th):",
	load_tms                     	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                   	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                     	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                       	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                       	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_kb1dh011_cc1d2027' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);