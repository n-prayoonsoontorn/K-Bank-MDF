-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_kb1dh012_cpcah.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-11    Panita T.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_KB1DH012_CPCAH
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_kb1dh012_cpcah (
	pos_dt                        	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh012_acth_org_nmbr           	smallint     comment "Def(En): ORG Number
Def(Th):",
	dh012_acth_type               	smallint     comment "Def(En):
Def(Th): Type Number  คือ Type ของบัตรเครดิต",
	dh012_acth_card_nmbr          	bigint       comment "Def(En): Card Number
Def(Th):",
	dh012_acth_lst_maint          	date         comment "Def(En): Last Maintenance Date
Def(Th):",
	dh012_acth_ctd_tbl_entry      	smallint     comment "Def(En): Specify which Table Entry to point to for  THE CYCLE-TO-DATE VALUE                            
Def(Th):",
	dh012_acth_stmt_dte_1         	date         comment "Def(En): The Statement Date of January
Def(Th):",
	dh012_acth_stmt_dte_2         	date         comment "Def(En): The Statement Date of February
Def(Th):",
	dh012_acth_stmt_dte_3         	date         comment "Def(En): The Statement Date of March
Def(Th):",
	dh012_acth_stmt_dte_4         	date         comment "Def(En): The Statement Date of April
Def(Th):",
	dh012_acth_stmt_dte_5         	date         comment "Def(En): The Statement Date of May
Def(Th):",
	dh012_acth_stmt_dte_6         	date         comment "Def(En): The Statement Date of June
Def(Th):",
	dh012_acth_stmt_dte_7         	date         comment "Def(En): The Statement Date of July
Def(Th):",
	dh012_acth_stmt_dte_8         	date         comment "Def(En): The Statement Date of August
Def(Th):",
	dh012_acth_stmt_dte_9         	date         comment "Def(En): The Statement Date of September
Def(Th):",
	dh012_acth_stmt_dte_10        	date         comment "Def(En): The Statement Date of October
Def(Th):",
	dh012_acth_stmt_dte_11        	date         comment "Def(En): The Statement Date of November
Def(Th):",
	dh012_acth_stmt_dte_12        	date         comment "Def(En): The Statement Date of December
Def(Th):",
	dh012_acth_nmbr_retail_jan    	integer      comment "Def(En): Item Retail of January
Def(Th):",
	dh012_acth_amnt_retail_jan    	decimal(13,2) comment "Def(En): Amount Retail of January
Def(Th):",
	dh012_acth_nmbr_ca_atm_jan    	integer      comment "Def(En): Item Cash Advance AT Atm of January
Def(Th):",
	dh012_acth_amnt_ca_atm_jan    	decimal(13,2) comment "Def(En): Amount Cash Advance At Atm of January
Def(Th):",
	dh012_acth_nmbr_ca_man_jan    	integer      comment "Def(En): Item Cash Advance AT Counter of January
Def(Th):",
	dh012_acth_amnt_ca_man_jan    	decimal(13,2) comment "Def(En): Amount Cash Advance At Counter of January
Def(Th):",
	dh012_acthr_interest_jan      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of January",
	dh012_acthr_curr_base_rate_jan	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of January",
	dh012_acthr_limit_1_jan       	integer      comment "Def(En): Retail Limit1 of January
Def(Th):",
	dh012_acthr_limit_2_jan       	integer      comment "Def(En): Retail Limit2 of January
Def(Th):",
	dh012_acthr_rate_2_jan        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of January",
	dh012_acthr_rate_3_jan        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of January",
	dh012_acthr_limit_option_jan  	smallint     comment "Def(En): Retail Limit Option  of January
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_jan      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of January",
	dh012_acthc_curr_base_rate_jan	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of January",
	dh012_acthc_limit_1_jan       	integer      comment "Def(En): Cash Advance Limit1 of January
Def(Th):",
	dh012_acthc_limit_2_jan       	integer      comment "Def(En): Cash Advance Limit2 of January
Def(Th):",
	dh012_acthc_rate_2_jan        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of January",
	dh012_acthc_rate_3_jan        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of January",
	dh012_acthc_limit_option_jan  	smallint     comment "Def(En): Cash Advance Limit Option of January
Def(Th):",
	dh012_acth_nmbr_annual_fee_jan	integer      comment "Def(En): Item Annual Fee of January
Def(Th):",
	dh012_acth_amnt_annual_fee_jan	decimal(13,2) comment "Def(En): Amount Annual Fee of January
Def(Th):",
	dh012_acth_nmbr_late_chg_jan  	integer      comment "Def(En): Item Late Charge of January
Def(Th):",
	dh012_acth_amnt_late_chg_jan  	decimal(13,2) comment "Def(En): Amount Late Charge of January
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_jan 	integer      comment "Def(En): Item Over Limit Fee of January
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_jan 	decimal(13,2) comment "Def(En): Amount Over Limit Fee of January
Def(Th):",
	dh012_acth_nmbr_misc_chg_jan  	integer      comment "Def(En): Item Miscellaneous Charge Fee of January
Def(Th):",
	dh012_acth_amnt_misc_chg_jan  	decimal(13,2) comment "Def(En): Amount Miscellaneous Charge Fee of January
Def(Th):",
	dh012_acth_nmbr_svc_chg_jan   	integer      comment "Def(En): Item Service Charge Fee of January
Def(Th):",
	dh012_acth_amnt_svc_chg_jan   	decimal(13,2) comment "Def(En): Amount Service Charge Fee of January
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_jan	integer      comment "Def(En): Item Cash Advance Per Fee of January
Def(Th):",
	dh012_acth_amnt_ca_per_fee_jan	decimal(13,2) comment "Def(En): Amount Cash Advance Per Fee of January
Def(Th):",
	dh012_acth_amnt_payment_jan   	decimal(13,2) comment "Def(En): Amount Payment of January
Def(Th):",
	dh012_acth_amnt_curr_bal_jan  	decimal(13,2) comment "Def(En): Amount Current Balance as at statement of January
Def(Th):",
	dh012_acth_bb_beg_balance_jan 	integer      comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of January
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_jan  	integer      comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of January
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_jan    	integer      comment "Def(En):
Def(Th): Bonus Bucket Used ?? of January
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_jan   	integer      comment "Def(En): Credit Limit  as at statement of January
Def(Th):",
	dh012_acth_avail_credit_jan   	integer      comment "Def(En): Avail Credit  as at statement of January
Def(Th):",
	dh012_acth_cash_limit_jan     	integer      comment "Def(En): Cash Limit  as at statement of January
Def(Th):",
	dh012_acth_avail_cash_jan     	integer      comment "Def(En): Avail Cash  as at statement of January
Def(Th):",
	dh012_acth_nmbr_airline_jan   	integer      comment "Def(En): Item Airline of January
Def(Th):",
	dh012_acth_amnt_airline_jan   	decimal(13,2) comment "Def(En): Amount Airline of January
Def(Th):",
	dh012_acth_nmbr_hotel_jan     	integer      comment "Def(En): Item Hotel of January
Def(Th):",
	dh012_acth_amnt_hotel_jan     	decimal(13,2) comment "Def(En): Amount Hotel of January
Def(Th):",
	dh012_acth_nmbr_car_rental_jan	integer      comment "Def(En): Item Car Rental of January
Def(Th):",
	dh012_acth_amnt_car_rental_jan	decimal(13,2) comment "Def(En): Amount Car Rental of January
Def(Th):",
	dh012_acth_nmbr_restaurant_jan	integer      comment "Def(En): Item Restaurant of January
Def(Th):",
	dh012_acth_amnt_restaurant_jan	decimal(13,2) comment "Def(En): Amount Restaurant of January
Def(Th):",
	dh012_acth_nmbr_mail_order_jan	integer      comment "Def(En): Item Mail Order of January
Def(Th):",
	dh012_acth_amnt_mail_order_jan	decimal(13,2) comment "Def(En): Amount Mail Order of January
Def(Th):",
	dh012_acth_nmbr_atm_cash_jan  	integer      comment "Def(En): Item ATM Cash Advance of January
Def(Th):",
	dh012_acth_amnt_atm_cash_jan  	decimal(13,2) comment "Def(En): Amount ATM Cash Advance of January
Def(Th):",
	dh012_acth_nmbr_man_cash_jan  	integer      comment "Def(En): Item Manual Cash Advance At Counter Kbank of January
Def(Th):",
	dh012_acth_amnt_man_cash_jan  	decimal(13,2) comment "Def(En): Amount Manual Cash Advance At Counter Kbank of January
Def(Th):",
	dh012_acth_nmbr_quasi_cash_jan	integer      comment "Def(En): Item Quasi Cash Advance ?? of January
กลุ่ม MCC ร้านค้าเสมือนเงินสด
Def(Th):",
	dh012_acth_amnt_quasi_cash_jan	decimal(13,2) comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of January
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_jan   	integer      comment "Def(En): Item Other Merchant of January
Def(Th):",
	dh012_acth_amnt_oth_mer_jan   	decimal(13,2) comment "Def(En): Amount Other Merchant of January
Def(Th):",
	dh012_acth_nmbr_retail_feb    	integer      comment "Def(En): Item Retail of Febuary
Def(Th):",
	dh012_acth_amnt_retail_feb    	decimal(13,2) comment "Def(En): Amount Retail of Febuary
Def(Th):",
	dh012_acth_nmbr_ca_atm_feb    	integer      comment "Def(En): Item Cash Advance AT Atm of Febuary
Def(Th):",
	dh012_acth_amnt_ca_atm_feb    	decimal(13,2) comment "Def(En): Amount Cash Advance At Atm of Febuary
Def(Th):",
	dh012_acth_nmbr_ca_man_feb    	integer      comment "Def(En): Item Cash Advance AT Counter of Febuary
Def(Th):",
	dh012_acth_amnt_ca_man_feb    	decimal(13,2) comment "Def(En): Amount Cash Advance At Counter of Febuary
Def(Th):",
	dh012_acthr_interest_feb      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of Febuary",
	dh012_acthr_curr_base_rate_feb	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of Febuary",
	dh012_acthr_limit_1_feb       	integer      comment "Def(En): Retail Limit1 of Febuary
Def(Th):",
	dh012_acthr_limit_2_feb       	integer      comment "Def(En): Retail Limit2 of Febuary
Def(Th):",
	dh012_acthr_rate_2_feb        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of Febuary",
	dh012_acthr_rate_3_feb        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of Febuary",
	dh012_acthr_limit_option_feb  	smallint     comment "Def(En): Retail Limit Option  of Febuary
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_feb      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of Febuary",
	dh012_acthc_curr_base_rate_feb	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of Febuary",
	dh012_acthc_limit_1_feb       	integer      comment "Def(En): Cash Advance Limit1 of Febuary
Def(Th):",
	dh012_acthc_limit_2_feb       	integer      comment "Def(En): Cash Advance Limit2 of Febuary
Def(Th):",
	dh012_acthc_rate_2_feb        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of Febuary",
	dh012_acthc_rate_3_feb        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of Febuary",
	dh012_acthc_limit_option_feb  	smallint     comment "Def(En): Cash Advance Limit Option of Febuary
Def(Th):",
	dh012_acth_nmbr_annual_fee_feb	integer      comment "Def(En): Item Annual Fee of Febuary
Def(Th):",
	dh012_acth_amnt_annual_fee_feb	decimal(13,2) comment "Def(En): Amount Annual Fee of Febuary
Def(Th):",
	dh012_acth_nmbr_late_chg_feb  	integer      comment "Def(En): Item Late Charge of Febuary
Def(Th):",
	dh012_acth_amnt_late_chg_feb  	decimal(13,2) comment "Def(En): Amount Late Charge of Febuary
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_feb 	integer      comment "Def(En): Item Over Limit Fee of Febuary
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_feb 	decimal(13,2) comment "Def(En): Amount Over Limit Fee of Febuary
Def(Th):",
	dh012_acth_nmbr_misc_chg_feb  	integer      comment "Def(En): Item Miscellaneous Charge Fee of Febuary
Def(Th):",
	dh012_acth_amnt_misc_chg_feb  	decimal(13,2) comment "Def(En): Amount Miscellaneous Charge Fee of Febuary
Def(Th):",
	dh012_acth_nmbr_svc_chg_feb   	integer      comment "Def(En): Item Service Charge Fee of Febuary
Def(Th):",
	dh012_acth_amnt_svc_chg_feb   	decimal(13,2) comment "Def(En): Amount Service Charge Fee of Febuary
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_feb	integer      comment "Def(En): Item Cash Advance Per Fee of Febuary
Def(Th):",
	dh012_acth_amnt_ca_per_fee_feb	decimal(13,2) comment "Def(En): Amount Cash Advance Per Fee of Febuary
Def(Th):",
	dh012_acth_amnt_payment_feb   	decimal(13,2) comment "Def(En): Amount Payment of Febuary
Def(Th):",
	dh012_acth_amnt_curr_bal_feb  	decimal(13,2) comment "Def(En): Amount Current Balance as at statement of Febuary
Def(Th):",
	dh012_acth_bb_beg_balance_feb 	integer      comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of Febuary
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_feb  	integer      comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of Febuary
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_feb    	integer      comment "Def(En):
Def(Th): Bonus Bucket Used ?? of Febuary
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_feb   	integer      comment "Def(En): Credit Limit  as at statement of Febuary
Def(Th):",
	dh012_acth_avail_credit_feb   	integer      comment "Def(En): Avail Credit  as at statement of Febuary
Def(Th):",
	dh012_acth_cash_limit_feb     	integer      comment "Def(En): Cash Limit  as at statement of Febuary
Def(Th):",
	dh012_acth_avail_cash_feb     	integer      comment "Def(En): Avail Cash  as at statement of Febuary
Def(Th):",
	dh012_acth_nmbr_airline_feb   	integer      comment "Def(En): Item Airline of Febuary
Def(Th):",
	dh012_acth_amnt_airline_feb   	decimal(13,2) comment "Def(En): Amount Airline of Febuary
Def(Th):",
	dh012_acth_nmbr_hotel_feb     	integer      comment "Def(En): Item Hotel of Febuary
Def(Th):",
	dh012_acth_amnt_hotel_feb     	decimal(13,2) comment "Def(En): Amount Hotel of Febuary
Def(Th):",
	dh012_acth_nmbr_car_rental_feb	integer      comment "Def(En): Item Car Rental of Febuary
Def(Th):",
	dh012_acth_amnt_car_rental_feb	decimal(13,2) comment "Def(En): Amount Car Rental of Febuary
Def(Th):",
	dh012_acth_nmbr_restaurant_feb	integer      comment "Def(En): Item Restaurant of Febuary
Def(Th):",
	dh012_acth_amnt_restaurant_feb	decimal(13,2) comment "Def(En): Amount Restaurant of Febuary
Def(Th):",
	dh012_acth_nmbr_mail_order_feb	integer      comment "Def(En): Item Mail Order of Febuary
Def(Th):",
	dh012_acth_amnt_mail_order_feb	decimal(13,2) comment "Def(En): Amount Mail Order of Febuary
Def(Th):",
	dh012_acth_nmbr_atm_cash_feb  	integer      comment "Def(En): Item ATM Cash Advance of Febuary
Def(Th):",
	dh012_acth_amnt_atm_cash_feb  	decimal(13,2) comment "Def(En): Amount ATM Cash Advance of Febuary
Def(Th):",
	dh012_acth_nmbr_man_cash_feb  	integer      comment "Def(En): Item Manual Cash Advance At Counter Kbank of Febuary
Def(Th):",
	dh012_acth_amnt_man_cash_feb  	decimal(13,2) comment "Def(En): Amount Manual Cash Advance At Counter Kbank of Febuary
Def(Th):",
	dh012_acth_nmbr_quasi_cash_feb	integer      comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of Febuary
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_feb	decimal(13,2) comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of Febuary
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_feb   	integer      comment "Def(En): Item Other Merchant of Febuary
Def(Th):",
	dh012_acth_amnt_oth_mer_feb   	decimal(13,2) comment "Def(En): Amount Other Merchant of Febuary
Def(Th):",
	dh012_acth_nmbr_retail_mar    	integer      comment "Def(En): Item Retail of Mar
Def(Th):",
	dh012_acth_amnt_retail_mar    	decimal(13,2) comment "Def(En): Amount Retail of Mar
Def(Th):",
	dh012_acth_nmbr_ca_atm_mar    	integer      comment "Def(En): Item Cash Advance AT Atm of Mar
Def(Th):",
	dh012_acth_amnt_ca_atm_mar    	decimal(13,2) comment "Def(En): Amount Cash Advance At Atm of Mar
Def(Th):",
	dh012_acth_nmbr_ca_man_mar    	integer      comment "Def(En): Item Cash Advance AT Counter of Mar
Def(Th):",
	dh012_acth_amnt_ca_man_mar    	decimal(13,2) comment "Def(En): Amount Cash Advance At Counter of Mar
Def(Th):",
	dh012_acthr_interest_mar      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of Mar",
	dh012_acthr_curr_base_rate_mar	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of Mar",
	dh012_acthr_limit_1_mar       	integer      comment "Def(En): Retail Limit1 of Mar
Def(Th):",
	dh012_acthr_limit_2_mar       	integer      comment "Def(En): Retail Limit2 of Mar
Def(Th):",
	dh012_acthr_rate_2_mar        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of Mar",
	dh012_acthr_rate_3_mar        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of Mar",
	dh012_acthr_limit_option_mar  	smallint     comment "Def(En): Retail Limit Option  of Mar
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_mar      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of Mar",
	dh012_acthc_curr_base_rate_mar	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of Mar",
	dh012_acthc_limit_1_mar       	integer      comment "Def(En): Cash Advance Limit1 of Mar
Def(Th):",
	dh012_acthc_limit_2_mar       	integer      comment "Def(En): Cash Advance Limit2 of Mar
Def(Th):",
	dh012_acthc_rate_2_mar        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of Mar",
	dh012_acthc_rate_3_mar        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of Mar",
	dh012_acthc_limit_option_mar  	smallint     comment "Def(En): Cash Advance Limit Option of Mar
Def(Th):",
	dh012_acth_nmbr_annual_fee_mar	integer      comment "Def(En): Item Annual Fee of Mar
Def(Th):",
	dh012_acth_amnt_annual_fee_mar	decimal(13,2) comment "Def(En): Amount Annual Fee of Mar
Def(Th):",
	dh012_acth_nmbr_late_chg_mar  	integer      comment "Def(En): Item Late Charge of Mar
Def(Th):",
	dh012_acth_amnt_late_chg_mar  	decimal(13,2) comment "Def(En): Amount Late Charge of Mar
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_mar 	integer      comment "Def(En): Item Over Limit Fee of Mar
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_mar 	decimal(13,2) comment "Def(En): Amount Over Limit Fee of Mar
Def(Th):",
	dh012_acth_nmbr_misc_chg_mar  	integer      comment "Def(En): Item Miscellaneous Charge Fee of Mar
Def(Th):",
	dh012_acth_amnt_misc_chg_mar  	decimal(13,2) comment "Def(En): Amount Miscellaneous Charge Fee of Mar
Def(Th):",
	dh012_acth_nmbr_svc_chg_mar   	integer      comment "Def(En): Item Service Charge Fee of Mar
Def(Th):",
	dh012_acth_amnt_svc_chg_mar   	decimal(13,2) comment "Def(En): Amount Service Charge Fee of Mar
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_mar	integer      comment "Def(En): Item Cash Advance Per Fee of Mar
Def(Th):",
	dh012_acth_amnt_ca_per_fee_mar	decimal(13,2) comment "Def(En): Amount Cash Advance Per Fee of Mar
Def(Th):",
	dh012_acth_amnt_payment_mar   	decimal(13,2) comment "Def(En): Amount Payment of Mar
Def(Th):",
	dh012_acth_amnt_curr_bal_mar  	decimal(13,2) comment "Def(En): Amount Current Balance as at statement of Mar
Def(Th):",
	dh012_acth_bb_beg_balance_mar 	integer      comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of Mar
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_mar  	integer      comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of Mar
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_mar    	integer      comment "Def(En):
Def(Th): Bonus Bucket Used ?? of Mar
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_mar   	integer      comment "Def(En): Credit Limit  as at statement of Mar
Def(Th):",
	dh012_acth_avail_credit_mar   	integer      comment "Def(En): Avail Credit  as at statement of Mar
Def(Th):",
	dh012_acth_cash_limit_mar     	integer      comment "Def(En): Cash Limit  as at statement of Mar
Def(Th):",
	dh012_acth_avail_cash_mar     	integer      comment "Def(En): Avail Cash  as at statement of Mar
Def(Th):",
	dh012_acth_nmbr_airline_mar   	integer      comment "Def(En): Item Airline of Mar
Def(Th):",
	dh012_acth_amnt_airline_mar   	decimal(13,2) comment "Def(En): Amount Airline of Mar
Def(Th):",
	dh012_acth_nmbr_hotel_mar     	integer      comment "Def(En): Item Hotel of Mar
Def(Th):",
	dh012_acth_amnt_hotel_mar     	decimal(13,2) comment "Def(En): Amount Hotel of Mar
Def(Th):",
	dh012_acth_nmbr_car_rental_mar	integer      comment "Def(En): Item Car Rental of Mar
Def(Th):",
	dh012_acth_amnt_car_rental_mar	decimal(13,2) comment "Def(En): Amount Car Rental of Mar
Def(Th):",
	dh012_acth_nmbr_restaurant_mar	integer      comment "Def(En): Item Restaurant of Mar
Def(Th):",
	dh012_acth_amnt_restaurant_mar	decimal(13,2) comment "Def(En): Amount Restaurant of Mar
Def(Th):",
	dh012_acth_nmbr_mail_order_mar	integer      comment "Def(En): Item Mail Order of Mar
Def(Th):",
	dh012_acth_amnt_mail_order_mar	decimal(13,2) comment "Def(En): Amount Mail Order of Mar
Def(Th):",
	dh012_acth_nmbr_atm_cash_mar  	integer      comment "Def(En): Item ATM Cash Advance of Mar
Def(Th):",
	dh012_acth_amnt_atm_cash_mar  	decimal(13,2) comment "Def(En): Amount ATM Cash Advance of Mar
Def(Th):",
	dh012_acth_nmbr_man_cash_mar  	integer      comment "Def(En): Item Manual Cash Advance At Counter Kbank of Mar
Def(Th):",
	dh012_acth_amnt_man_cash_mar  	decimal(13,2) comment "Def(En): Amount Manual Cash Advance At Counter Kbank of Mar
Def(Th):",
	dh012_acth_nmbr_quasi_cash_mar	integer      comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of Mar
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_mar	decimal(13,2) comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of Mar
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_mar   	integer      comment "Def(En): Item Other Merchant of Mar
Def(Th):",
	dh012_acth_amnt_oth_mer_mar   	decimal(13,2) comment "Def(En): Amount Other Merchant of Mar
Def(Th):",
	dh012_acth_nmbr_retail_apr    	integer      comment "Def(En): Item Retail of April
Def(Th):",
	dh012_acth_amnt_retail_apr    	decimal(13,2) comment "Def(En): Amount Retail of April
Def(Th):",
	dh012_acth_nmbr_ca_atm_apr    	integer      comment "Def(En): Item Cash Advance AT Atm of April
Def(Th):",
	dh012_acth_amnt_ca_atm_apr    	decimal(13,2) comment "Def(En): Amount Cash Advance At Atm of April
Def(Th):",
	dh012_acth_nmbr_ca_man_apr    	integer      comment "Def(En): Item Cash Advance AT Counter of April
Def(Th):",
	dh012_acth_amnt_ca_man_apr    	decimal(13,2) comment "Def(En): Amount Cash Advance At Counter of April
Def(Th):",
	dh012_acthr_interest_apr      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of April",
	dh012_acthr_curr_base_rate_apr	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of April",
	dh012_acthr_limit_1_apr       	integer      comment "Def(En): Retail Limit1 of April
Def(Th):",
	dh012_acthr_limit_2_apr       	integer      comment "Def(En): Retail Limit2 of April
Def(Th):",
	dh012_acthr_rate_2_apr        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of April",
	dh012_acthr_rate_3_apr        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of April",
	dh012_acthr_limit_option_apr  	smallint     comment "Def(En): Retail Limit Option  of April
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_apr      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of April",
	dh012_acthc_curr_base_rate_apr	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of April",
	dh012_acthc_limit_1_apr       	integer      comment "Def(En): Cash Advance Limit1 of April
Def(Th):",
	dh012_acthc_limit_2_apr       	integer      comment "Def(En): Cash Advance Limit2 of April
Def(Th):",
	dh012_acthc_rate_2_apr        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of April",
	dh012_acthc_rate_3_apr        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of April",
	dh012_acthc_limit_option_apr  	smallint     comment "Def(En): Cash Advance Limit Option of April
Def(Th):",
	dh012_acth_nmbr_annual_fee_apr	integer      comment "Def(En): Item Annual Fee of April
Def(Th):",
	dh012_acth_amnt_annual_fee_apr	decimal(13,2) comment "Def(En): Amount Annual Fee of April
Def(Th):",
	dh012_acth_nmbr_late_chg_apr  	integer      comment "Def(En): Item Late Charge of April
Def(Th):",
	dh012_acth_amnt_late_chg_apr  	decimal(13,2) comment "Def(En): Amount Late Charge of April
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_apr 	integer      comment "Def(En): Item Over Limit Fee of April
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_apr 	decimal(13,2) comment "Def(En): Amount Over Limit Fee of April
Def(Th):",
	dh012_acth_nmbr_misc_chg_apr  	integer      comment "Def(En): Item Miscellaneous Charge Fee of April
Def(Th):",
	dh012_acth_amnt_misc_chg_apr  	decimal(13,2) comment "Def(En): Amount Miscellaneous Charge Fee of April
Def(Th):",
	dh012_acth_nmbr_svc_chg_apr   	integer      comment "Def(En): Item Service Charge Fee of April
Def(Th):",
	dh012_acth_amnt_svc_chg_apr   	decimal(13,2) comment "Def(En): Amount Service Charge Fee of April
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_apr	integer      comment "Def(En): Item Cash Advance Per Fee of April
Def(Th):",
	dh012_acth_amnt_ca_per_fee_apr	decimal(13,2) comment "Def(En): Amount Cash Advance Per Fee of April
Def(Th):",
	dh012_acth_amnt_payment_apr   	decimal(13,2) comment "Def(En): Amount Payment of April
Def(Th):",
	dh012_acth_amnt_curr_bal_apr  	decimal(13,2) comment "Def(En): Amount Current Balance as at statement of April
Def(Th):",
	dh012_acth_bb_beg_balance_apr 	integer      comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of April
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_apr  	integer      comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of April
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_apr    	integer      comment "Def(En):
Def(Th): Bonus Bucket Used ?? of April
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_apr   	integer      comment "Def(En): Credit Limit  as at statement of April
Def(Th):",
	dh012_acth_avail_credit_apr   	integer      comment "Def(En): Avail Credit  as at statement of April
Def(Th):",
	dh012_acth_cash_limit_apr     	integer      comment "Def(En): Cash Limit  as at statement of April
Def(Th):",
	dh012_acth_avail_cash_apr     	integer      comment "Def(En): Avail Cash  as at statement of April
Def(Th):",
	dh012_acth_nmbr_airline_apr   	integer      comment "Def(En): Item Airline of April
Def(Th):",
	dh012_acth_amnt_airline_apr   	decimal(13,2) comment "Def(En): Amount Airline of April
Def(Th):",
	dh012_acth_nmbr_hotel_apr     	integer      comment "Def(En): Item Hotel of April
Def(Th):",
	dh012_acth_amnt_hotel_apr     	decimal(13,2) comment "Def(En): Amount Hotel of April
Def(Th):",
	dh012_acth_nmbr_car_rental_apr	integer      comment "Def(En): Item Car Rental of April
Def(Th):",
	dh012_acth_amnt_car_rental_apr	decimal(13,2) comment "Def(En): Amount Car Rental of April
Def(Th):",
	dh012_acth_nmbr_restaurant_apr	integer      comment "Def(En): Item Restaurant of April
Def(Th):",
	dh012_acth_amnt_restaurant_apr	decimal(13,2) comment "Def(En): Amount Restaurant of April
Def(Th):",
	dh012_acth_nmbr_mail_order_apr	integer      comment "Def(En): Item Mail Order of April
Def(Th):",
	dh012_acth_amnt_mail_order_apr	decimal(13,2) comment "Def(En): Amount Mail Order of April
Def(Th):",
	dh012_acth_nmbr_atm_cash_apr  	integer      comment "Def(En): Item ATM Cash Advance of April
Def(Th):",
	dh012_acth_amnt_atm_cash_apr  	decimal(13,2) comment "Def(En): Amount ATM Cash Advance of April
Def(Th):",
	dh012_acth_nmbr_man_cash_apr  	integer      comment "Def(En): Item Manual Cash Advance At Counter Kbank of April
Def(Th):",
	dh012_acth_amnt_man_cash_apr  	decimal(13,2) comment "Def(En): Amount Manual Cash Advance At Counter Kbank of April
Def(Th):",
	dh012_acth_nmbr_quasi_cash_apr	integer      comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of April
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_apr	decimal(13,2) comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of April
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_apr   	integer      comment "Def(En): Item Other Merchant of April
Def(Th):",
	dh012_acth_amnt_oth_mer_apr   	decimal(13,2) comment "Def(En): Amount Other Merchant of April
Def(Th):",
	dh012_acth_nmbr_retail_may    	integer      comment "Def(En): Item Retail of May
Def(Th):",
	dh012_acth_amnt_retail_may    	decimal(13,2) comment "Def(En): Amount Retail of May
Def(Th):",
	dh012_acth_nmbr_ca_atm_may    	integer      comment "Def(En): Item Cash Advance AT Atm of May
Def(Th):",
	dh012_acth_amnt_ca_atm_may    	decimal(13,2) comment "Def(En): Amount Cash Advance At Atm of May
Def(Th):",
	dh012_acth_nmbr_ca_man_may    	integer      comment "Def(En): Item Cash Advance AT Counter of May
Def(Th):",
	dh012_acth_amnt_ca_man_may    	decimal(13,2) comment "Def(En): Amount Cash Advance At Counter of May
Def(Th):",
	dh012_acthr_interest_may      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of May",
	dh012_acthr_curr_base_rate_may	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of May",
	dh012_acthr_limit_1_may       	integer      comment "Def(En): Retail Limit1 of May
Def(Th):",
	dh012_acthr_limit_2_may       	integer      comment "Def(En): Retail Limit2 of May
Def(Th):",
	dh012_acthr_rate_2_may        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of May",
	dh012_acthr_rate_3_may        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of May",
	dh012_acthr_limit_option_may  	smallint     comment "Def(En): Retail Limit Option  of May
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_may      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of May",
	dh012_acthc_curr_base_rate_may	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of May",
	dh012_acthc_limit_1_may       	integer      comment "Def(En): Cash Advance Limit1 of May
Def(Th):",
	dh012_acthc_limit_2_may       	integer      comment "Def(En): Cash Advance Limit2 of May
Def(Th):",
	dh012_acthc_rate_2_may        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of May",
	dh012_acthc_rate_3_may        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of May",
	dh012_acthc_limit_option_may  	smallint     comment "Def(En): Cash Advance Limit Option of May
Def(Th):",
	dh012_acth_nmbr_annual_fee_may	integer      comment "Def(En): Item Annual Fee of May
Def(Th):",
	dh012_acth_amnt_annual_fee_may	decimal(13,2) comment "Def(En): Amount Annual Fee of May
Def(Th):",
	dh012_acth_nmbr_late_chg_may  	integer      comment "Def(En): Item Late Charge of May
Def(Th):",
	dh012_acth_amnt_late_chg_may  	decimal(13,2) comment "Def(En): Amount Late Charge of May
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_may 	integer      comment "Def(En): Item Over Limit Fee of May
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_may 	decimal(13,2) comment "Def(En): Amount Over Limit Fee of May
Def(Th):",
	dh012_acth_nmbr_misc_chg_may  	integer      comment "Def(En): Item Miscellaneous Charge Fee of May
Def(Th):",
	dh012_acth_amnt_misc_chg_may  	decimal(13,2) comment "Def(En): Amount Miscellaneous Charge Fee of May
Def(Th):",
	dh012_acth_nmbr_svc_chg_may   	integer      comment "Def(En): Item Service Charge Fee of May
Def(Th):",
	dh012_acth_amnt_svc_chg_may   	decimal(13,2) comment "Def(En): Amount Service Charge Fee of May
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_may	integer      comment "Def(En): Item Cash Advance Per Fee of May
Def(Th):",
	dh012_acth_amnt_ca_per_fee_may	decimal(13,2) comment "Def(En): Amount Cash Advance Per Fee of May
Def(Th):",
	dh012_acth_amnt_payment_may   	decimal(13,2) comment "Def(En): Amount Payment of May
Def(Th):",
	dh012_acth_amnt_curr_bal_may  	decimal(13,2) comment "Def(En): Amount Current Balance as at statement of May
Def(Th):",
	dh012_acth_bb_beg_balance_may 	integer      comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of May
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_may  	integer      comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of May
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_may    	integer      comment "Def(En):
Def(Th): Bonus Bucket Used ?? of May
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_may   	integer      comment "Def(En): Credit Limit  as at statement of May
Def(Th):",
	dh012_acth_avail_credit_may   	integer      comment "Def(En): Avail Credit  as at statement of May
Def(Th):",
	dh012_acth_cash_limit_may     	integer      comment "Def(En): Cash Limit  as at statement of May
Def(Th):",
	dh012_acth_avail_cash_may     	integer      comment "Def(En): Avail Cash  as at statement of May
Def(Th):",
	dh012_acth_nmbr_airline_may   	integer      comment "Def(En): Item Airline of May
Def(Th):",
	dh012_acth_amnt_airline_may   	decimal(13,2) comment "Def(En): Amount Airline of May
Def(Th):",
	dh012_acth_nmbr_hotel_may     	integer      comment "Def(En): Item Hotel of May
Def(Th):",
	dh012_acth_amnt_hotel_may     	decimal(13,2) comment "Def(En): Amount Hotel of May
Def(Th):",
	dh012_acth_nmbr_car_rental_may	integer      comment "Def(En): Item Car Rental of May
Def(Th):",
	dh012_acth_amnt_car_rental_may	decimal(13,2) comment "Def(En): Amount Car Rental of May
Def(Th):",
	dh012_acth_nmbr_restaurant_may	integer      comment "Def(En): Item Restaurant of May
Def(Th):",
	dh012_acth_amnt_restaurant_may	decimal(13,2) comment "Def(En): Amount Restaurant of May
Def(Th):",
	dh012_acth_nmbr_mail_order_may	integer      comment "Def(En): Item Mail Order of May
Def(Th):",
	dh012_acth_amnt_mail_order_may	decimal(13,2) comment "Def(En): Amount Mail Order of May
Def(Th):",
	dh012_acth_nmbr_atm_cash_may  	integer      comment "Def(En): Item ATM Cash Advance of May
Def(Th):",
	dh012_acth_amnt_atm_cash_may  	decimal(13,2) comment "Def(En): Amount ATM Cash Advance of May
Def(Th):",
	dh012_acth_nmbr_man_cash_may  	integer      comment "Def(En): Item Manual Cash Advance At Counter Kbank of May
Def(Th):",
	dh012_acth_amnt_man_cash_may  	decimal(13,2) comment "Def(En): Amount Manual Cash Advance At Counter Kbank of May
Def(Th):",
	dh012_acth_nmbr_quasi_cash_may	integer      comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of May
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_may	decimal(13,2) comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of May
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_may   	integer      comment "Def(En): Item Other Merchant of May
Def(Th):",
	dh012_acth_amnt_oth_mer_may   	decimal(13,2) comment "Def(En): Amount Other Merchant of May
Def(Th):",
	dh012_acth_nmbr_retail_jun    	integer      comment "Def(En): Item Retail of June
Def(Th):",
	dh012_acth_amnt_retail_jun    	decimal(13,2) comment "Def(En): Amount Retail of June
Def(Th):",
	dh012_acth_nmbr_ca_atm_jun    	integer      comment "Def(En): Item Cash Advance AT Atm of June
Def(Th):",
	dh012_acth_amnt_ca_atm_jun    	decimal(13,2) comment "Def(En): Amount Cash Advance At Atm of June
Def(Th):",
	dh012_acth_nmbr_ca_man_jun    	integer      comment "Def(En): Item Cash Advance AT Counter of June
Def(Th):",
	dh012_acth_amnt_ca_man_jun    	decimal(13,2) comment "Def(En): Amount Cash Advance At Counter of June
Def(Th):",
	dh012_acthr_interest_jun      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of June",
	dh012_acthr_curr_base_rate_jun	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of June",
	dh012_acthr_limit_1_jun       	integer      comment "Def(En): Retail Limit1 of June
Def(Th):",
	dh012_acthr_limit_2_jun       	integer      comment "Def(En): Retail Limit2 of June
Def(Th):",
	dh012_acthr_rate_2_jun        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of June",
	dh012_acthr_rate_3_jun        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of June",
	dh012_acthr_limit_option_jun  	smallint     comment "Def(En): Retail Limit Option  of June
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_jun      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of June",
	dh012_acthc_curr_base_rate_jun	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of June",
	dh012_acthc_limit_1_jun       	integer      comment "Def(En): Cash Advance Limit1 of June
Def(Th):",
	dh012_acthc_limit_2_jun       	integer      comment "Def(En): Cash Advance Limit2 of June
Def(Th):",
	dh012_acthc_rate_2_jun        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of June",
	dh012_acthc_rate_3_jun        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of June",
	dh012_acthc_limit_option_jun  	smallint     comment "Def(En): Cash Advance Limit Option of June
Def(Th):",
	dh012_acth_nmbr_annual_fee_jun	integer      comment "Def(En): Item Annual Fee of June
Def(Th):",
	dh012_acth_amnt_annual_fee_jun	decimal(13,2) comment "Def(En): Amount Annual Fee of June
Def(Th):",
	dh012_acth_nmbr_late_chg_jun  	integer      comment "Def(En): Item Late Charge of June
Def(Th):",
	dh012_acth_amnt_late_chg_jun  	decimal(13,2) comment "Def(En): Amount Late Charge of June
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_jun 	integer      comment "Def(En): Item Over Limit Fee of June
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_jun 	decimal(13,2) comment "Def(En): Amount Over Limit Fee of June
Def(Th):",
	dh012_acth_nmbr_misc_chg_jun  	integer      comment "Def(En): Item Miscellaneous Charge Fee of June
Def(Th):",
	dh012_acth_amnt_misc_chg_jun  	decimal(13,2) comment "Def(En): Amount Miscellaneous Charge Fee of June
Def(Th):",
	dh012_acth_nmbr_svc_chg_jun   	integer      comment "Def(En): Item Service Charge Fee of June
Def(Th):",
	dh012_acth_amnt_svc_chg_jun   	decimal(13,2) comment "Def(En): Amount Service Charge Fee of June
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_jun	integer      comment "Def(En): Item Cash Advance Per Fee of June
Def(Th):",
	dh012_acth_amnt_ca_per_fee_jun	decimal(13,2) comment "Def(En): Amount Cash Advance Per Fee of June
Def(Th):",
	dh012_acth_amnt_payment_jun   	decimal(13,2) comment "Def(En): Amount Payment of June
Def(Th):",
	dh012_acth_amnt_curr_bal_jun  	decimal(13,2) comment "Def(En): Amount Current Balance as at statement of June
Def(Th):",
	dh012_acth_bb_beg_balance_jun 	integer      comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of June
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_jun  	integer      comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of June
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_jun    	integer      comment "Def(En):
Def(Th): Bonus Bucket Used ?? of June
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_jun   	integer      comment "Def(En): Credit Limit  as at statement of June
Def(Th):",
	dh012_acth_avail_credit_jun   	integer      comment "Def(En): Avail Credit  as at statement of June
Def(Th):",
	dh012_acth_cash_limit_jun     	integer      comment "Def(En): Cash Limit  as at statement of June
Def(Th):",
	dh012_acth_avail_cash_jun     	integer      comment "Def(En): Avail Cash  as at statement of June
Def(Th):",
	dh012_acth_nmbr_airline_jun   	integer      comment "Def(En): Item Airline of June
Def(Th):",
	dh012_acth_amnt_airline_jun   	decimal(13,2) comment "Def(En): Amount Airline of June
Def(Th):",
	dh012_acth_nmbr_hotel_jun     	integer      comment "Def(En): Item Hotel of June
Def(Th):",
	dh012_acth_amnt_hotel_jun     	decimal(13,2) comment "Def(En): Amount Hotel of June
Def(Th):",
	dh012_acth_nmbr_car_rental_jun	integer      comment "Def(En): Item Car Rental of June
Def(Th):",
	dh012_acth_amnt_car_rental_jun	decimal(13,2) comment "Def(En): Amount Car Rental of June
Def(Th):",
	dh012_acth_nmbr_restaurant_jun	integer      comment "Def(En): Item Restaurant of June
Def(Th):",
	dh012_acth_amnt_restaurant_jun	decimal(13,2) comment "Def(En): Amount Restaurant of June
Def(Th):",
	dh012_acth_nmbr_mail_order_jun	integer      comment "Def(En): Item Mail Order of June
Def(Th):",
	dh012_acth_amnt_mail_order_jun	decimal(13,2) comment "Def(En): Amount Mail Order of June
Def(Th):",
	dh012_acth_nmbr_atm_cash_jun  	integer      comment "Def(En): Item ATM Cash Advance of June
Def(Th):",
	dh012_acth_amnt_atm_cash_jun  	decimal(13,2) comment "Def(En): Amount ATM Cash Advance of June
Def(Th):",
	dh012_acth_nmbr_man_cash_jun  	integer      comment "Def(En): Item Manual Cash Advance At Counter Kbank of June
Def(Th):",
	dh012_acth_amnt_man_cash_jun  	decimal(13,2) comment "Def(En): Amount Manual Cash Advance At Counter Kbank of June
Def(Th):",
	dh012_acth_nmbr_quasi_cash_jun	integer      comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of June
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_jun	decimal(13,2) comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of June
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_jun   	integer      comment "Def(En): Item Other Merchant of June
Def(Th):",
	dh012_acth_amnt_oth_mer_jun   	decimal(13,2) comment "Def(En): Amount Other Merchant of June
Def(Th):",
	dh012_acth_nmbr_retail_jul    	integer      comment "Def(En): Item Retail of July
Def(Th):",
	dh012_acth_amnt_retail_jul    	decimal(13,2) comment "Def(En): Amount Retail of July
Def(Th):",
	dh012_acth_nmbr_ca_atm_jul    	integer      comment "Def(En): Item Cash Advance AT Atm of July
Def(Th):",
	dh012_acth_amnt_ca_atm_jul    	decimal(13,2) comment "Def(En): Amount Cash Advance At Atm of July
Def(Th):",
	dh012_acth_nmbr_ca_man_jul    	integer      comment "Def(En): Item Cash Advance AT Counter of July
Def(Th):",
	dh012_acth_amnt_ca_man_jul    	decimal(13,2) comment "Def(En): Amount Cash Advance At Counter of July
Def(Th):",
	dh012_acthr_interest_jul      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of July",
	dh012_acthr_curr_base_rate_jul	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of July",
	dh012_acthr_limit_1_jul       	integer      comment "Def(En): Retail Limit1 of July
Def(Th):",
	dh012_acthr_limit_2_jul       	integer      comment "Def(En): Retail Limit2 of July
Def(Th):",
	dh012_acthr_rate_2_jul        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of July",
	dh012_acthr_rate_3_jul        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of July",
	dh012_acthr_limit_option_jul  	smallint     comment "Def(En): Retail Limit Option  of July
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_jul      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of July",
	dh012_acthc_curr_base_rate_jul	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of July",
	dh012_acthc_limit_1_jul       	integer      comment "Def(En): Cash Advance Limit1 of July
Def(Th):",
	dh012_acthc_limit_2_jul       	integer      comment "Def(En): Cash Advance Limit2 of July
Def(Th):",
	dh012_acthc_rate_2_jul        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of July",
	dh012_acthc_rate_3_jul        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of July",
	dh012_acthc_limit_option_jul  	smallint     comment "Def(En): Cash Advance Limit Option of July
Def(Th):",
	dh012_acth_nmbr_annual_fee_jul	integer      comment "Def(En): Item Annual Fee of July
Def(Th):",
	dh012_acth_amnt_annual_fee_jul	decimal(13,2) comment "Def(En): Amount Annual Fee of July
Def(Th):",
	dh012_acth_nmbr_late_chg_jul  	integer      comment "Def(En): Item Late Charge of July
Def(Th):",
	dh012_acth_amnt_late_chg_jul  	decimal(13,2) comment "Def(En): Amount Late Charge of July
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_jul 	integer      comment "Def(En): Item Over Limit Fee of July
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_jul 	decimal(13,2) comment "Def(En): Amount Over Limit Fee of July
Def(Th):",
	dh012_acth_nmbr_misc_chg_jul  	integer      comment "Def(En): Item Miscellaneous Charge Fee of July
Def(Th):",
	dh012_acth_amnt_misc_chg_jul  	decimal(13,2) comment "Def(En): Amount Miscellaneous Charge Fee of July
Def(Th):",
	dh012_acth_nmbr_svc_chg_jul   	integer      comment "Def(En): Item Service Charge Fee of July
Def(Th):",
	dh012_acth_amnt_svc_chg_jul   	decimal(13,2) comment "Def(En): Amount Service Charge Fee of July
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_jul	integer      comment "Def(En): Item Cash Advance Per Fee of July
Def(Th):",
	dh012_acth_amnt_ca_per_fee_jul	decimal(13,2) comment "Def(En): Amount Cash Advance Per Fee of July
Def(Th):",
	dh012_acth_amnt_payment_jul   	decimal(13,2) comment "Def(En): Amount Payment of July
Def(Th):",
	dh012_acth_amnt_curr_bal_jul  	decimal(13,2) comment "Def(En): Amount Current Balance as at statement of July
Def(Th):",
	dh012_acth_bb_beg_balance_jul 	integer      comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of July
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_jul  	integer      comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of July
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_jul    	integer      comment "Def(En):
Def(Th): Bonus Bucket Used ?? of July
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_jul   	integer      comment "Def(En): Credit Limit  as at statement of July
Def(Th):",
	dh012_acth_avail_credit_jul   	integer      comment "Def(En): Avail Credit  as at statement of July
Def(Th):",
	dh012_acth_cash_limit_jul     	integer      comment "Def(En): Cash Limit  as at statement of July
Def(Th):",
	dh012_acth_avail_cash_jul     	integer      comment "Def(En): Avail Cash  as at statement of July
Def(Th):",
	dh012_acth_nmbr_airline_jul   	integer      comment "Def(En): Item Airline of July
Def(Th):",
	dh012_acth_amnt_airline_jul   	decimal(13,2) comment "Def(En): Amount Airline of July
Def(Th):",
	dh012_acth_nmbr_hotel_jul     	integer      comment "Def(En): Item Hotel of July
Def(Th):",
	dh012_acth_amnt_hotel_jul     	decimal(13,2) comment "Def(En): Amount Hotel of July
Def(Th):",
	dh012_acth_nmbr_car_rental_jul	integer      comment "Def(En): Item Car Rental of July
Def(Th):",
	dh012_acth_amnt_car_rental_jul	decimal(13,2) comment "Def(En): Amount Car Rental of July
Def(Th):",
	dh012_acth_nmbr_restaurant_jul	integer      comment "Def(En): Item Restaurant of July
Def(Th):",
	dh012_acth_amnt_restaurant_jul	decimal(13,2) comment "Def(En): Amount Restaurant of July
Def(Th):",
	dh012_acth_nmbr_mail_order_jul	integer      comment "Def(En): Item Mail Order of July
Def(Th):",
	dh012_acth_amnt_mail_order_jul	decimal(13,2) comment "Def(En): Amount Mail Order of July
Def(Th):",
	dh012_acth_nmbr_atm_cash_jul  	integer      comment "Def(En): Item ATM Cash Advance of July
Def(Th):",
	dh012_acth_amnt_atm_cash_jul  	decimal(13,2) comment "Def(En): Amount ATM Cash Advance of July
Def(Th):",
	dh012_acth_nmbr_man_cash_jul  	integer      comment "Def(En): Item Manual Cash Advance At Counter Kbank of July
Def(Th):",
	dh012_acth_amnt_man_cash_jul  	decimal(13,2) comment "Def(En): Amount Manual Cash Advance At Counter Kbank of July
Def(Th):",
	dh012_acth_nmbr_quasi_cash_jul	integer      comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of July
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_jul	decimal(13,2) comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of July
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_jul   	integer      comment "Def(En): Item Other Merchant of July
Def(Th):",
	dh012_acth_amnt_oth_mer_jul   	decimal(13,2) comment "Def(En): Amount Other Merchant of July
Def(Th):",
	dh012_acth_nmbr_retail_aug    	integer      comment "Def(En): Item Retail of August
Def(Th):",
	dh012_acth_amnt_retail_aug    	decimal(13,2) comment "Def(En): Amount Retail of August
Def(Th):",
	dh012_acth_nmbr_ca_atm_aug    	integer      comment "Def(En): Item Cash Advance AT Atm of August
Def(Th):",
	dh012_acth_amnt_ca_atm_aug    	decimal(13,2) comment "Def(En): Amount Cash Advance At Atm of August
Def(Th):",
	dh012_acth_nmbr_ca_man_aug    	integer      comment "Def(En): Item Cash Advance AT Counter of August
Def(Th):",
	dh012_acth_amnt_ca_man_aug    	decimal(13,2) comment "Def(En): Amount Cash Advance At Counter of August
Def(Th):",
	dh012_acthr_interest_aug      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of August",
	dh012_acthr_curr_base_rate_aug	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of August",
	dh012_acthr_limit_1_aug       	integer      comment "Def(En): Retail Limit1 of August
Def(Th):",
	dh012_acthr_limit_2_aug       	integer      comment "Def(En): Retail Limit2 of August
Def(Th):",
	dh012_acthr_rate_2_aug        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of August",
	dh012_acthr_rate_3_aug        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of August",
	dh012_acthr_limit_option_aug  	smallint     comment "Def(En): Retail Limit Option  of August
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_aug      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of August",
	dh012_acthc_curr_base_rate_aug	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of August",
	dh012_acthc_limit_1_aug       	integer      comment "Def(En): Cash Advance Limit1 of August
Def(Th):",
	dh012_acthc_limit_2_aug       	integer      comment "Def(En): Cash Advance Limit2 of August
Def(Th):",
	dh012_acthc_rate_2_aug        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of August",
	dh012_acthc_rate_3_aug        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of August",
	dh012_acthc_limit_option_aug  	smallint     comment "Def(En): Cash Advance Limit Option of August
Def(Th):",
	dh012_acth_nmbr_annual_fee_aug	integer      comment "Def(En): Item Annual Fee of August
Def(Th):",
	dh012_acth_amnt_annual_fee_aug	decimal(13,2) comment "Def(En): Amount Annual Fee of August
Def(Th):",
	dh012_acth_nmbr_late_chg_aug  	integer      comment "Def(En): Item Late Charge of August
Def(Th):",
	dh012_acth_amnt_late_chg_aug  	decimal(13,2) comment "Def(En): Amount Late Charge of August
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_aug 	integer      comment "Def(En): Item Over Limit Fee of August
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_aug 	decimal(13,2) comment "Def(En): Amount Over Limit Fee of August
Def(Th):",
	dh012_acth_nmbr_misc_chg_aug  	integer      comment "Def(En): Item Miscellaneous Charge Fee of August
Def(Th):",
	dh012_acth_amnt_misc_chg_aug  	decimal(13,2) comment "Def(En): Amount Miscellaneous Charge Fee of August
Def(Th):",
	dh012_acth_nmbr_svc_chg_aug   	integer      comment "Def(En): Item Service Charge Fee of August
Def(Th):",
	dh012_acth_amnt_svc_chg_aug   	decimal(13,2) comment "Def(En): Amount Service Charge Fee of August
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_aug	integer      comment "Def(En): Item Cash Advance Per Fee of August
Def(Th):",
	dh012_acth_amnt_ca_per_fee_aug	decimal(13,2) comment "Def(En): Amount Cash Advance Per Fee of August
Def(Th):",
	dh012_acth_amnt_payment_aug   	decimal(13,2) comment "Def(En): Amount Payment of August
Def(Th):",
	dh012_acth_amnt_curr_bal_aug  	decimal(13,2) comment "Def(En): Amount Current Balance as at statement of August
Def(Th):",
	dh012_acth_bb_beg_balance_aug 	integer      comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of August
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_aug  	integer      comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of August
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_aug    	integer      comment "Def(En):
Def(Th): Bonus Bucket Used ?? of August
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_aug   	integer      comment "Def(En): Credit Limit  as at statement of August
Def(Th):",
	dh012_acth_avail_credit_aug   	integer      comment "Def(En): Avail Credit  as at statement of August
Def(Th):",
	dh012_acth_cash_limit_aug     	integer      comment "Def(En): Cash Limit  as at statement of August
Def(Th):",
	dh012_acth_avail_cash_aug     	integer      comment "Def(En): Avail Cash  as at statement of August
Def(Th):",
	dh012_acth_nmbr_airline_aug   	integer      comment "Def(En): Item Airline of August
Def(Th):",
	dh012_acth_amnt_airline_aug   	decimal(13,2) comment "Def(En): Amount Airline of August
Def(Th):",
	dh012_acth_nmbr_hotel_aug     	integer      comment "Def(En): Item Hotel of August
Def(Th):",
	dh012_acth_amnt_hotel_aug     	decimal(13,2) comment "Def(En): Amount Hotel of August
Def(Th):",
	dh012_acth_nmbr_car_rental_aug	integer      comment "Def(En): Item Car Rental of August
Def(Th):",
	dh012_acth_amnt_car_rental_aug	decimal(13,2) comment "Def(En): Amount Car Rental of August
Def(Th):",
	dh012_acth_nmbr_restaurant_aug	integer      comment "Def(En): Item Restaurant of August
Def(Th):",
	dh012_acth_amnt_restaurant_aug	decimal(13,2) comment "Def(En): Amount Restaurant of August
Def(Th):",
	dh012_acth_nmbr_mail_order_aug	integer      comment "Def(En): Item Mail Order of August
Def(Th):",
	dh012_acth_amnt_mail_order_aug	decimal(13,2) comment "Def(En): Amount Mail Order of August
Def(Th):",
	dh012_acth_nmbr_atm_cash_aug  	integer      comment "Def(En): Item ATM Cash Advance of August
Def(Th):",
	dh012_acth_amnt_atm_cash_aug  	decimal(13,2) comment "Def(En): Amount ATM Cash Advance of August
Def(Th):",
	dh012_acth_nmbr_man_cash_aug  	integer      comment "Def(En): Item Manual Cash Advance At Counter Kbank of August
Def(Th):",
	dh012_acth_amnt_man_cash_aug  	decimal(13,2) comment "Def(En): Amount Manual Cash Advance At Counter Kbank of August
Def(Th):",
	dh012_acth_nmbr_quasi_cash_aug	integer      comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of August
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_aug	decimal(13,2) comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of August
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_aug   	integer      comment "Def(En): Item Other Merchant of August
Def(Th):",
	dh012_acth_amnt_oth_mer_aug   	decimal(13,2) comment "Def(En): Amount Other Merchant of August
Def(Th):",
	dh012_acth_nmbr_retail_sep    	integer      comment "Def(En): Item Retail of September
Def(Th):",
	dh012_acth_amnt_retail_sep    	decimal(13,2) comment "Def(En): Amount Retail of September
Def(Th):",
	dh012_acth_nmbr_ca_atm_sep    	integer      comment "Def(En): Item Cash Advance AT Atm of September
Def(Th):",
	dh012_acth_amnt_ca_atm_sep    	decimal(13,2) comment "Def(En): Amount Cash Advance At Atm of September
Def(Th):",
	dh012_acth_nmbr_ca_man_sep    	integer      comment "Def(En): Item Cash Advance AT Counter of September
Def(Th):",
	dh012_acth_amnt_ca_man_sep    	decimal(13,2) comment "Def(En): Amount Cash Advance At Counter of September
Def(Th):",
	dh012_acthr_interest_sep      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of September",
	dh012_acthr_curr_base_rate_sep	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of September",
	dh012_acthr_limit_1_sep       	integer      comment "Def(En): Retail Limit1 of September
Def(Th):",
	dh012_acthr_limit_2_sep       	integer      comment "Def(En): Retail Limit2 of September
Def(Th):",
	dh012_acthr_rate_2_sep        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of September",
	dh012_acthr_rate_3_sep        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of September",
	dh012_acthr_limit_option_sep  	smallint     comment "Def(En): Retail Limit Option  of September
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_sep      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of September",
	dh012_acthc_curr_base_rate_sep	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of September",
	dh012_acthc_limit_1_sep       	integer      comment "Def(En): Cash Advance Limit1 of September
Def(Th):",
	dh012_acthc_limit_2_sep       	integer      comment "Def(En): Cash Advance Limit2 of September
Def(Th):",
	dh012_acthc_rate_2_sep        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of September",
	dh012_acthc_rate_3_sep        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of September",
	dh012_acthc_limit_option_sep  	smallint     comment "Def(En): Cash Advance Limit Option of September
Def(Th):",
	dh012_acth_nmbr_annual_fee_sep	integer      comment "Def(En): Item Annual Fee of September
Def(Th):",
	dh012_acth_amnt_annual_fee_sep	decimal(13,2) comment "Def(En): Amount Annual Fee of September
Def(Th):",
	dh012_acth_nmbr_late_chg_sep  	integer      comment "Def(En): Item Late Charge of September
Def(Th):",
	dh012_acth_amnt_late_chg_sep  	decimal(13,2) comment "Def(En): Amount Late Charge of September
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_sep 	integer      comment "Def(En): Item Over Limit Fee of September
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_sep 	decimal(13,2) comment "Def(En): Amount Over Limit Fee of September
Def(Th):",
	dh012_acth_nmbr_misc_chg_sep  	integer      comment "Def(En): Item Miscellaneous Charge Fee of September
Def(Th):",
	dh012_acth_amnt_misc_chg_sep  	decimal(13,2) comment "Def(En): Amount Miscellaneous Charge Fee of September
Def(Th):",
	dh012_acth_nmbr_svc_chg_sep   	integer      comment "Def(En): Item Service Charge Fee of September
Def(Th):",
	dh012_acth_amnt_svc_chg_sep   	decimal(13,2) comment "Def(En): Amount Service Charge Fee of September
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_sep	integer      comment "Def(En): Item Cash Advance Per Fee of September
Def(Th):",
	dh012_acth_amnt_ca_per_fee_sep	decimal(13,2) comment "Def(En): Amount Cash Advance Per Fee of September
Def(Th):",
	dh012_acth_amnt_payment_sep   	decimal(13,2) comment "Def(En): Amount Payment of September
Def(Th):",
	dh012_acth_amnt_curr_bal_sep  	decimal(13,2) comment "Def(En): Amount Current Balance as at statement of September
Def(Th):",
	dh012_acth_bb_beg_balance_sep 	integer      comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of September
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_sep  	integer      comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of September
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_sep    	integer      comment "Def(En):
Def(Th): Bonus Bucket Used ?? of September
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_sep   	integer      comment "Def(En): Credit Limit  as at statement of September
Def(Th):",
	dh012_acth_avail_credit_sep   	integer      comment "Def(En): Avail Credit  as at statement of September
Def(Th):",
	dh012_acth_cash_limit_sep     	integer      comment "Def(En): Cash Limit  as at statement of September
Def(Th):",
	dh012_acth_avail_cash_sep     	integer      comment "Def(En): Avail Cash  as at statement of September
Def(Th):",
	dh012_acth_nmbr_airline_sep   	integer      comment "Def(En): Item Airline of September
Def(Th):",
	dh012_acth_amnt_airline_sep   	decimal(13,2) comment "Def(En): Amount Airline of September
Def(Th):",
	dh012_acth_nmbr_hotel_sep     	integer      comment "Def(En): Item Hotel of September
Def(Th):",
	dh012_acth_amnt_hotel_sep     	decimal(13,2) comment "Def(En): Amount Hotel of September
Def(Th):",
	dh012_acth_nmbr_car_rental_sep	integer      comment "Def(En): Item Car Rental of September
Def(Th):",
	dh012_acth_amnt_car_rental_sep	decimal(13,2) comment "Def(En): Amount Car Rental of September
Def(Th):",
	dh012_acth_nmbr_restaurant_sep	integer      comment "Def(En): Item Restaurant of September
Def(Th):",
	dh012_acth_amnt_restaurant_sep	decimal(13,2) comment "Def(En): Amount Restaurant of September
Def(Th):",
	dh012_acth_nmbr_mail_order_sep	integer      comment "Def(En): Item Mail Order of September
Def(Th):",
	dh012_acth_amnt_mail_order_sep	decimal(13,2) comment "Def(En): Amount Mail Order of September
Def(Th):",
	dh012_acth_nmbr_atm_cash_sep  	integer      comment "Def(En): Item ATM Cash Advance of September
Def(Th):",
	dh012_acth_amnt_atm_cash_sep  	decimal(13,2) comment "Def(En): Amount ATM Cash Advance of September
Def(Th):",
	dh012_acth_nmbr_man_cash_sep  	integer      comment "Def(En): Item Manual Cash Advance At Counter Kbank of September
Def(Th):",
	dh012_acth_amnt_man_cash_sep  	decimal(13,2) comment "Def(En): Amount Manual Cash Advance At Counter Kbank of September
Def(Th):",
	dh012_acth_nmbr_quasi_cash_sep	integer      comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of September
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_sep	decimal(13,2) comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of September
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_sep   	integer      comment "Def(En): Item Other Merchant of September
Def(Th):",
	dh012_acth_amnt_oth_mer_sep   	decimal(13,2) comment "Def(En): Amount Other Merchant of September
Def(Th):",
	dh012_acth_nmbr_retail_oct    	integer      comment "Def(En): Item Retail of October
Def(Th):",
	dh012_acth_amnt_retail_oct    	decimal(13,2) comment "Def(En): Amount Retail of October
Def(Th):",
	dh012_acth_nmbr_ca_atm_oct    	integer      comment "Def(En): Item Cash Advance AT Atm of October
Def(Th):",
	dh012_acth_amnt_ca_atm_oct    	decimal(13,2) comment "Def(En): Amount Cash Advance At Atm of October
Def(Th):",
	dh012_acth_nmbr_ca_man_oct    	integer      comment "Def(En): Item Cash Advance AT Counter of October
Def(Th):",
	dh012_acth_amnt_ca_man_oct    	decimal(13,2) comment "Def(En): Amount Cash Advance At Counter of October
Def(Th):",
	dh012_acthr_interest_oct      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of October",
	dh012_acthr_curr_base_rate_oct	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of October",
	dh012_acthr_limit_1_oct       	integer      comment "Def(En): Retail Limit1 of October
Def(Th):",
	dh012_acthr_limit_2_oct       	integer      comment "Def(En): Retail Limit2 of October
Def(Th):",
	dh012_acthr_rate_2_oct        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of October",
	dh012_acthr_rate_3_oct        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of October",
	dh012_acthr_limit_option_oct  	smallint     comment "Def(En): Retail Limit Option  of October
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_oct      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of October",
	dh012_acthc_curr_base_rate_oct	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of October",
	dh012_acthc_limit_1_oct       	integer      comment "Def(En): Cash Advance Limit1 of October
Def(Th):",
	dh012_acthc_limit_2_oct       	integer      comment "Def(En): Cash Advance Limit2 of October
Def(Th):",
	dh012_acthc_rate_2_oct        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of October",
	dh012_acthc_rate_3_oct        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of October",
	dh012_acthc_limit_option_oct  	smallint     comment "Def(En): Cash Advance Limit Option of October
Def(Th):",
	dh012_acth_nmbr_annual_fee_oct	integer      comment "Def(En): Item Annual Fee of October
Def(Th):",
	dh012_acth_amnt_annual_fee_oct	decimal(13,2) comment "Def(En): Amount Annual Fee of October
Def(Th):",
	dh012_acth_nmbr_late_chg_oct  	integer      comment "Def(En): Item Late Charge of October
Def(Th):",
	dh012_acth_amnt_late_chg_oct  	decimal(13,2) comment "Def(En): Amount Late Charge of October
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_oct 	integer      comment "Def(En): Item Over Limit Fee of October
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_oct 	decimal(13,2) comment "Def(En): Amount Over Limit Fee of October
Def(Th):",
	dh012_acth_nmbr_misc_chg_oct  	integer      comment "Def(En): Item Miscellaneous Charge Fee of October
Def(Th):",
	dh012_acth_amnt_misc_chg_oct  	decimal(13,2) comment "Def(En): Amount Miscellaneous Charge Fee of October
Def(Th):",
	dh012_acth_nmbr_svc_chg_oct   	integer      comment "Def(En): Item Service Charge Fee of October
Def(Th):",
	dh012_acth_amnt_svc_chg_oct   	decimal(13,2) comment "Def(En): Amount Service Charge Fee of October
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_oct	integer      comment "Def(En): Item Cash Advance Per Fee of October
Def(Th):",
	dh012_acth_amnt_ca_per_fee_oct	decimal(13,2) comment "Def(En): Amount Cash Advance Per Fee of October
Def(Th):",
	dh012_acth_amnt_payment_oct   	decimal(13,2) comment "Def(En): Amount Payment of October
Def(Th):",
	dh012_acth_amnt_curr_bal_oct  	decimal(13,2) comment "Def(En): Amount Current Balance as at statement of October
Def(Th):",
	dh012_acth_bb_beg_balance_oct 	integer      comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of October
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_oct  	integer      comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of October
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_oct    	integer      comment "Def(En):
Def(Th): Bonus Bucket Used ?? of October
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_oct   	integer      comment "Def(En): Credit Limit  as at statement of October
Def(Th):",
	dh012_acth_avail_credit_oct   	integer      comment "Def(En): Avail Credit  as at statement of October
Def(Th):",
	dh012_acth_cash_limit_oct     	integer      comment "Def(En): Cash Limit  as at statement of October
Def(Th):",
	dh012_acth_avail_cash_oct     	integer      comment "Def(En): Avail Cash  as at statement of October
Def(Th):",
	dh012_acth_nmbr_airline_oct   	integer      comment "Def(En): Item Airline of October
Def(Th):",
	dh012_acth_amnt_airline_oct   	decimal(13,2) comment "Def(En): Amount Airline of October
Def(Th):",
	dh012_acth_nmbr_hotel_oct     	integer      comment "Def(En): Item Hotel of October
Def(Th):",
	dh012_acth_amnt_hotel_oct     	decimal(13,2) comment "Def(En): Amount Hotel of October
Def(Th):",
	dh012_acth_nmbr_car_rental_oct	integer      comment "Def(En): Item Car Rental of October
Def(Th):",
	dh012_acth_amnt_car_rental_oct	decimal(13,2) comment "Def(En): Amount Car Rental of October
Def(Th):",
	dh012_acth_nmbr_restaurant_oct	integer      comment "Def(En): Item Restaurant of October
Def(Th):",
	dh012_acth_amnt_restaurant_oct	decimal(13,2) comment "Def(En): Amount Restaurant of October
Def(Th):",
	dh012_acth_nmbr_mail_order_oct	integer      comment "Def(En): Item Mail Order of October
Def(Th):",
	dh012_acth_amnt_mail_order_oct	decimal(13,2) comment "Def(En): Amount Mail Order of October
Def(Th):",
	dh012_acth_nmbr_atm_cash_oct  	integer      comment "Def(En): Item ATM Cash Advance of October
Def(Th):",
	dh012_acth_amnt_atm_cash_oct  	decimal(13,2) comment "Def(En): Amount ATM Cash Advance of October
Def(Th):",
	dh012_acth_nmbr_man_cash_oct  	integer      comment "Def(En): Item Manual Cash Advance At Counter Kbank of October
Def(Th):",
	dh012_acth_amnt_man_cash_oct  	decimal(13,2) comment "Def(En): Amount Manual Cash Advance At Counter Kbank of October
Def(Th):",
	dh012_acth_nmbr_quasi_cash_oct	integer      comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of October
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_oct	decimal(13,2) comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of October
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_oct   	integer      comment "Def(En): Item Other Merchant of October
Def(Th):",
	dh012_acth_amnt_oth_mer_oct   	decimal(13,2) comment "Def(En): Amount Other Merchant of October
Def(Th):",
	dh012_acth_nmbr_retail_nov    	integer      comment "Def(En): Item Retail of November
Def(Th):",
	dh012_acth_amnt_retail_nov    	decimal(13,2) comment "Def(En): Amount Retail of November
Def(Th):",
	dh012_acth_nmbr_ca_atm_nov    	integer      comment "Def(En): Item Cash Advance AT Atm of November
Def(Th):",
	dh012_acth_amnt_ca_atm_nov    	decimal(13,2) comment "Def(En): Amount Cash Advance At Atm of November
Def(Th):",
	dh012_acth_nmbr_ca_man_nov    	integer      comment "Def(En): Item Cash Advance AT Counter of November
Def(Th):",
	dh012_acth_amnt_ca_man_nov    	decimal(13,2) comment "Def(En): Amount Cash Advance At Counter of November
Def(Th):",
	dh012_acthr_interest_nov      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of November",
	dh012_acthr_curr_base_rate_nov	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of November",
	dh012_acthr_limit_1_nov       	integer      comment "Def(En): Retail Limit1 of November
Def(Th):",
	dh012_acthr_limit_2_nov       	integer      comment "Def(En): Retail Limit2 of November
Def(Th):",
	dh012_acthr_rate_2_nov        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of November",
	dh012_acthr_rate_3_nov        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of November",
	dh012_acthr_limit_option_nov  	smallint     comment "Def(En): Retail Limit Option  of November
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_nov      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of November",
	dh012_acthc_curr_base_rate_nov	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of November",
	dh012_acthc_limit_1_nov       	integer      comment "Def(En): Cash Advance Limit1 of November
Def(Th):",
	dh012_acthc_limit_2_nov       	integer      comment "Def(En): Cash Advance Limit2 of November
Def(Th):",
	dh012_acthc_rate_2_nov        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of November",
	dh012_acthc_rate_3_nov        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of November",
	dh012_acthc_limit_option_nov  	smallint     comment "Def(En): Cash Advance Limit Option of November
Def(Th):",
	dh012_acth_nmbr_annual_fee_nov	integer      comment "Def(En): Item Annual Fee of November
Def(Th):",
	dh012_acth_amnt_annual_fee_nov	decimal(13,2) comment "Def(En): Amount Annual Fee of November
Def(Th):",
	dh012_acth_nmbr_late_chg_nov  	integer      comment "Def(En): Item Late Charge of November
Def(Th):",
	dh012_acth_amnt_late_chg_nov  	decimal(13,2) comment "Def(En): Amount Late Charge of November
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_nov 	integer      comment "Def(En): Item Over Limit Fee of November
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_nov 	decimal(13,2) comment "Def(En): Amount Over Limit Fee of November
Def(Th):",
	dh012_acth_nmbr_misc_chg_nov  	integer      comment "Def(En): Item Miscellaneous Charge Fee of November
Def(Th):",
	dh012_acth_amnt_misc_chg_nov  	decimal(13,2) comment "Def(En): Amount Miscellaneous Charge Fee of November
Def(Th):",
	dh012_acth_nmbr_svc_chg_nov   	integer      comment "Def(En): Item Service Charge Fee of November
Def(Th):",
	dh012_acth_amnt_svc_chg_nov   	decimal(13,2) comment "Def(En): Amount Service Charge Fee of November
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_nov	integer      comment "Def(En): Item Cash Advance Per Fee of November
Def(Th):",
	dh012_acth_amnt_ca_per_fee_nov	decimal(13,2) comment "Def(En): Amount Cash Advance Per Fee of November
Def(Th):",
	dh012_acth_amnt_payment_nov   	decimal(13,2) comment "Def(En): Amount Payment of November
Def(Th):",
	dh012_acth_amnt_curr_bal_nov  	decimal(13,2) comment "Def(En): Amount Current Balance as at statement of November
Def(Th):",
	dh012_acth_bb_beg_balance_nov 	integer      comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of November
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_nov  	integer      comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of November
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_nov    	integer      comment "Def(En):
Def(Th): Bonus Bucket Used ?? of November
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_nov   	integer      comment "Def(En): Credit Limit  as at statement of November
Def(Th):",
	dh012_acth_avail_credit_nov   	integer      comment "Def(En): Avail Credit  as at statement of November
Def(Th):",
	dh012_acth_cash_limit_nov     	integer      comment "Def(En): Cash Limit  as at statement of November
Def(Th):",
	dh012_acth_avail_cash_nov     	integer      comment "Def(En): Avail Cash  as at statement of November
Def(Th):",
	dh012_acth_nmbr_airline_nov   	integer      comment "Def(En): Item Airline of November
Def(Th):",
	dh012_acth_amnt_airline_nov   	decimal(13,2) comment "Def(En): Amount Airline of November
Def(Th):",
	dh012_acth_nmbr_hotel_nov     	integer      comment "Def(En): Item Hotel of November
Def(Th):",
	dh012_acth_amnt_hotel_nov     	decimal(13,2) comment "Def(En): Amount Hotel of November
Def(Th):",
	dh012_acth_nmbr_car_rental_nov	integer      comment "Def(En): Item Car Rental of November
Def(Th):",
	dh012_acth_amnt_car_rental_nov	decimal(13,2) comment "Def(En): Amount Car Rental of November
Def(Th):",
	dh012_acth_nmbr_restaurant_nov	integer      comment "Def(En): Item Restaurant of November
Def(Th):",
	dh012_acth_amnt_restaurant_nov	decimal(13,2) comment "Def(En): Amount Restaurant of November
Def(Th):",
	dh012_acth_nmbr_mail_order_nov	integer      comment "Def(En): Item Mail Order of November
Def(Th):",
	dh012_acth_amnt_mail_order_nov	decimal(13,2) comment "Def(En): Amount Mail Order of November
Def(Th):",
	dh012_acth_nmbr_atm_cash_nov  	integer      comment "Def(En): Item ATM Cash Advance of November
Def(Th):",
	dh012_acth_amnt_atm_cash_nov  	decimal(13,2) comment "Def(En): Amount ATM Cash Advance of November
Def(Th):",
	dh012_acth_nmbr_man_cash_nov  	integer      comment "Def(En): Item Manual Cash Advance At Counter Kbank of November
Def(Th):",
	dh012_acth_amnt_man_cash_nov  	decimal(13,2) comment "Def(En): Amount Manual Cash Advance At Counter Kbank of November
Def(Th):",
	dh012_acth_nmbr_quasi_cash_nov	integer      comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of November
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_nov	decimal(13,2) comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of November
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_nov   	integer      comment "Def(En): Item Other Merchant of November
Def(Th):",
	dh012_acth_amnt_oth_mer_nov   	decimal(13,2) comment "Def(En): Amount Other Merchant of November
Def(Th):",
	dh012_acth_nmbr_retail_dec    	integer      comment "Def(En): Item Retail of December
Def(Th):",
	dh012_acth_amnt_retail_dec    	decimal(13,2) comment "Def(En): Amount Retail of December
Def(Th):",
	dh012_acth_nmbr_ca_atm_dec    	integer      comment "Def(En): Item Cash Advance AT Atm of December
Def(Th):",
	dh012_acth_amnt_ca_atm_dec    	decimal(13,2) comment "Def(En): Amount Cash Advance At Atm of December
Def(Th):",
	dh012_acth_nmbr_ca_man_dec    	integer      comment "Def(En): Item Cash Advance AT Counter of December
Def(Th):",
	dh012_acth_amnt_ca_man_dec    	decimal(13,2) comment "Def(En): Amount Cash Advance At Counter of December
Def(Th):",
	dh012_acthr_interest_dec      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of December",
	dh012_acthr_curr_base_rate_dec	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of December",
	dh012_acthr_limit_1_dec       	integer      comment "Def(En): Retail Limit1 of December
Def(Th):",
	dh012_acthr_limit_2_dec       	integer      comment "Def(En): Retail Limit2 of December
Def(Th):",
	dh012_acthr_rate_2_dec        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of December",
	dh012_acthr_rate_3_dec        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of December",
	dh012_acthr_limit_option_dec  	smallint     comment "Def(En): Retail Limit Option  of December
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_dec      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of December",
	dh012_acthc_curr_base_rate_dec	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of December",
	dh012_acthc_limit_1_dec       	integer      comment "Def(En): Cash Advance Limit1 of December
Def(Th):",
	dh012_acthc_limit_2_dec       	integer      comment "Def(En): Cash Advance Limit2 of December
Def(Th):",
	dh012_acthc_rate_2_dec        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of December",
	dh012_acthc_rate_3_dec        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of December",
	dh012_acthc_limit_option_dec  	smallint     comment "Def(En): Cash Advance Limit Option of December
Def(Th):",
	dh012_acth_nmbr_annual_fee_dec	integer      comment "Def(En): Item Annual Fee of December
Def(Th):",
	dh012_acth_amnt_annual_fee_dec	decimal(13,2) comment "Def(En): Amount Annual Fee of December
Def(Th):",
	dh012_acth_nmbr_late_chg_dec  	integer      comment "Def(En): Item Late Charge of December
Def(Th):",
	dh012_acth_amnt_late_chg_dec  	decimal(13,2) comment "Def(En): Amount Late Charge of December
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_dec 	integer      comment "Def(En): Item Over Limit Fee of December
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_dec 	decimal(13,2) comment "Def(En): Amount Over Limit Fee of December
Def(Th):",
	dh012_acth_nmbr_misc_chg_dec  	integer      comment "Def(En): Item Miscellaneous Charge Fee of December
Def(Th):",
	dh012_acth_amnt_misc_chg_dec  	decimal(13,2) comment "Def(En): Amount Miscellaneous Charge Fee of December
Def(Th):",
	dh012_acth_nmbr_svc_chg_dec   	integer      comment "Def(En): Item Service Charge Fee of December
Def(Th):",
	dh012_acth_amnt_svc_chg_dec   	decimal(13,2) comment "Def(En): Amount Service Charge Fee of December
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_dec	integer      comment "Def(En): Item Cash Advance Per Fee of December
Def(Th):",
	dh012_acth_amnt_ca_per_fee_dec	decimal(13,2) comment "Def(En): Amount Cash Advance Per Fee of December
Def(Th):",
	dh012_acth_amnt_payment_dec   	decimal(13,2) comment "Def(En): Amount Payment of December
Def(Th):",
	dh012_acth_amnt_curr_bal_dec  	decimal(13,2) comment "Def(En): Amount Current Balance as at statement of December
Def(Th):",
	dh012_acth_bb_beg_balance_dec 	integer      comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of December
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_dec  	integer      comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of December
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_dec    	integer      comment "Def(En):
Def(Th): Bonus Bucket Used ?? of December
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_dec   	integer      comment "Def(En): Credit Limit  as at statement of December
Def(Th):",
	dh012_acth_avail_credit_dec   	integer      comment "Def(En): Avail Credit  as at statement of December
Def(Th):",
	dh012_acth_cash_limit_dec     	integer      comment "Def(En): Cash Limit  as at statement of December
Def(Th):",
	dh012_acth_avail_cash_dec     	integer      comment "Def(En): Avail Cash  as at statement of December
Def(Th):",
	dh012_acth_nmbr_airline_dec   	integer      comment "Def(En): Item Airline of December
Def(Th):",
	dh012_acth_amnt_airline_dec   	decimal(13,2) comment "Def(En): Amount Airline of December
Def(Th):",
	dh012_acth_nmbr_hotel_dec     	integer      comment "Def(En): Item Hotel of December
Def(Th):",
	dh012_acth_amnt_hotel_dec     	decimal(13,2) comment "Def(En): Amount Hotel of December
Def(Th):",
	dh012_acth_nmbr_car_rental_dec	integer      comment "Def(En): Item Car Rental of December
Def(Th):",
	dh012_acth_amnt_car_rental_dec	decimal(13,2) comment "Def(En): Amount Car Rental of December
Def(Th):",
	dh012_acth_nmbr_restaurant_dec	integer      comment "Def(En): Item Restaurant of December
Def(Th):",
	dh012_acth_amnt_restaurant_dec	decimal(13,2) comment "Def(En): Amount Restaurant of December
Def(Th):",
	dh012_acth_nmbr_mail_order_dec	integer      comment "Def(En): Item Mail Order of December
Def(Th):",
	dh012_acth_amnt_mail_order_dec	decimal(13,2) comment "Def(En): Amount Mail Order of December
Def(Th):",
	dh012_acth_nmbr_atm_cash_dec  	integer      comment "Def(En): Item ATM Cash Advance of December
Def(Th):",
	dh012_acth_amnt_atm_cash_dec  	decimal(13,2) comment "Def(En): Amount ATM Cash Advance of December
Def(Th):",
	dh012_acth_nmbr_man_cash_dec  	integer      comment "Def(En): Item Manual Cash Advance At Counter Kbank of December
Def(Th):",
	dh012_acth_amnt_man_cash_dec  	decimal(13,2) comment "Def(En): Amount Manual Cash Advance At Counter Kbank of December
Def(Th):",
	dh012_acth_nmbr_quasi_cash_dec	integer      comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of December
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_dec	decimal(13,2) comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of December
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_dec   	integer      comment "Def(En): Item Other Merchant of December
Def(Th):",
	dh012_acth_amnt_oth_mer_dec   	decimal(13,2) comment "Def(En): Amount Other Merchant of December
Def(Th):",
	dh012_acth_nmbr_retail_12m    	integer      comment "Def(En): Item Retail
Def(Th):",
	dh012_acth_amnt_retail_12m    	decimal(13,2) comment "Def(En): Amount Retail
Def(Th):",
	dh012_acth_nmbr_ca_atm_12m    	integer      comment "Def(En): Item Cash Advance AT Atm
Def(Th):",
	dh012_acth_amnt_ca_atm_12m    	decimal(13,2) comment "Def(En): Amount Cash Advance At Atm
Def(Th):",
	dh012_acth_nmbr_ca_man_12m    	integer      comment "Def(En): Item Cash Advance AT Counter
Def(Th):",
	dh012_acth_amnt_ca_man_12m    	decimal(13,2) comment "Def(En): Amount Cash Advance At Counter
Def(Th):",
	dh012_acthr_interest_12m      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail",
	dh012_acthr_curr_base_rate_12m	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน",
	dh012_acthr_limit_1_12m       	integer      comment "Def(En): Retail Limit1
Def(Th):",
	dh012_acthr_limit_2_12m       	integer      comment "Def(En): Retail Limit2
Def(Th):",
	dh012_acthr_rate_2_12m        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2",
	dh012_acthr_rate_3_12m        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3",
	dh012_acthr_limit_option_12m  	smallint     comment "Def(En): Retail Limit Option 
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_12m      	decimal(11,2) comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance",
	dh012_acthc_curr_base_rate_12m	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน",
	dh012_acthc_limit_1_12m       	integer      comment "Def(En): Cash Advance Limit1
Def(Th):",
	dh012_acthc_limit_2_12m       	integer      comment "Def(En): Cash Advance Limit2
Def(Th):",
	dh012_acthc_rate_2_12m        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2",
	dh012_acthc_rate_3_12m        	decimal(8,7) comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3",
	dh012_acthc_limit_option_12m  	smallint     comment "Def(En): Cash Advance Limit Option
Def(Th):",
	dh012_acth_nmbr_annual_fee_12m	integer      comment "Def(En): Item Annual Fee
Def(Th):",
	dh012_acth_amnt_annual_fee_12m	decimal(13,2) comment "Def(En): Amount Annual Fee
Def(Th):",
	dh012_acth_nmbr_late_chg_12m  	integer      comment "Def(En): Item Late Charge
Def(Th):",
	dh012_acth_amnt_late_chg_12m  	decimal(13,2) comment "Def(En): Amount Late Charge
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_12m 	integer      comment "Def(En): Item Over Limit Fee
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_12m 	decimal(13,2) comment "Def(En): Amount Over Limit Fee
Def(Th):",
	dh012_acth_nmbr_misc_chg_12m  	integer      comment "Def(En): Item Miscellaneous Charge Fee
Def(Th):",
	dh012_acth_amnt_misc_chg_12m  	decimal(13,2) comment "Def(En): Amount Miscellaneous Charge Fee
Def(Th):",
	dh012_acth_nmbr_svc_chg_12m   	integer      comment "Def(En): Item Service Charge Fee
Def(Th):",
	dh012_acth_amnt_svc_chg_12m   	decimal(13,2) comment "Def(En): Amount Service Charge Fee
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_12m	integer      comment "Def(En): Item Cash Advance Per Fee
Def(Th):",
	dh012_acth_amnt_ca_per_fee_12m	decimal(13,2) comment "Def(En): Amount Cash Advance Per Fee
Def(Th):",
	dh012_acth_amnt_payment_12m   	decimal(13,2) comment "Def(En): Amount Payment
Def(Th):",
	dh012_acth_amnt_curr_bal_12m  	decimal(13,2) comment "Def(En): Amount Current Balance as at statement
Def(Th):",
	dh012_acth_bb_beg_balance_12m 	integer      comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ??
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_12m  	integer      comment "Def(En):
Def(Th): Bonus Bucket Earn ??
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_12m    	integer      comment "Def(En):
Def(Th): Bonus Bucket Used ??
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_12m   	integer      comment "Def(En): Credit Limit  as at statement
Def(Th):",
	dh012_acth_avail_credit_12m   	integer      comment "Def(En): Avail Credit  as at statement
Def(Th):",
	dh012_acth_cash_limit_12m     	integer      comment "Def(En): Cash Limit  as at statement
Def(Th):",
	dh012_acth_avail_cash_12m     	integer      comment "Def(En): Avail Cash  as at statement
Def(Th):",
	dh012_acth_nmbr_airline_12m   	integer      comment "Def(En): Item Airline
Def(Th):",
	dh012_acth_amnt_airline_12m   	decimal(13,2) comment "Def(En): Amount Airline
Def(Th):",
	dh012_acth_nmbr_hotel_12m     	integer      comment "Def(En): Item Hotel
Def(Th):",
	dh012_acth_amnt_hotel_12m     	decimal(13,2) comment "Def(En): Amount Hotel
Def(Th):",
	dh012_acth_nmbr_car_rental_12m	integer      comment "Def(En): Item Car Rental
Def(Th):",
	dh012_acth_amnt_car_rental_12m	decimal(13,2) comment "Def(En): Amount Car Rental
Def(Th):",
	dh012_acth_nmbr_restaurant_12m	integer      comment "Def(En): Item Restaurant
Def(Th):",
	dh012_acth_amnt_restaurant_12m	decimal(13,2) comment "Def(En): Amount Restaurant
Def(Th):",
	dh012_acth_nmbr_mail_order_12m	integer      comment "Def(En): Item Mail Order
Def(Th):",
	dh012_acth_amnt_mail_order_12m	decimal(13,2) comment "Def(En): Amount Mail Order
Def(Th):",
	dh012_acth_nmbr_atm_cash_12m  	integer      comment "Def(En): Item ATM Cash Advance
Def(Th):",
	dh012_acth_amnt_atm_cash_12m  	decimal(13,2) comment "Def(En): Amount ATM Cash Advance
Def(Th):",
	dh012_acth_nmbr_man_cash_12m  	integer      comment "Def(En): Item Manual Cash Advance At Counter Kbank
Def(Th):",
	dh012_acth_amnt_man_cash_12m  	decimal(13,2) comment "Def(En): Amount Manual Cash Advance At Counter Kbank
Def(Th):",
	dh012_acth_nmbr_quasi_cash_12m	integer      comment "Def(En):
Def(Th): Item Quasi Cash Advance ??
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_12m	decimal(13,2) comment "Def(En):
Def(Th): Amount Quasi Cash Advance ??
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_12m   	integer      comment "Def(En): Item Other Merchant
Def(Th):",
	dh012_acth_amnt_oth_mer_12m   	decimal(13,2) comment "Def(En): Amount Other Merchant
Def(Th):",
	dh012_d_filler                	string       comment "Def(En): Space
Def(Th):",
	load_tms                      	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                    	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                      	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                        	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                        	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_kb1dh012_cpcah' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);