-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_kb1dh014_cc1dmpgl.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-12    Panita T.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_KB1DH014_CC1DMPGL
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_kb1dh014_cc1dmpgl (
	pos_dt                        	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh014__org                    	smallint     comment "Def(En): ORG Of Card
001 - Credit Card 
200- KEC 
Def(Th):",
	dh014__type                   	smallint     comment "Def(En): TYPE Of Card 
011 - Cash Card 
111 -  KEC   
นอกนั้น เป็น บัตรเครดิต
Def(Th):",
	dh014_affinity                	string       comment "Def(En): AFFINITY   Code 
บอกบัตร Credit ร่วมกับบริษัทไหน
 00  ไม่ได้  Co กับบริษัท
Def(Th):",
	dh014_project_code            	string       comment "Def(En): PROJECT CODE   
project code  ของบัตร ใช้ในตอนโปรโมชั่น
Def(Th):",
	dh014_filler_1                	string       comment "Def(En): SPACES
Def(Th):",
	dh014_legal_entity            	smallint     comment "Def(En): LEGAL ENTITY  บัตรกสิกร หรือ บัตรในเครือ 
001 -  บัตรกสิกร นอกนั้น เป็นบัตรในเครือ
Def(Th):",
	dh014_rc                      	integer      comment "Def(En): RC code  สังกัด 
 41001  บัตรเครดิต และ บัตร  CashCard
 40800  บัตร  KEC
Def(Th):",
	dh014_account                 	integer      comment "Def(En):
Def(Th): account code (หัวบัญชี GL)",
	dh014_function                	smallint     comment "Def(En): 
Def(Th): FUNCTION  บอกประเภทบัตร
 1  บัตรเครดิต
 4  บัตร KEC",
	dh014_line_of_business        	smallint     comment "Def(En): LINE OF BUSINESS  =  0 ( Default  เป็นศุนย์)
Def(Th):",
	dh014_gl_product              	integer      comment "Def(En): GL PRODUCT CODE 
Def(Th): รหัส product  code ด้าน GL",
	dh014_inter_co                	smallint     comment "Def(En): INTER CODE  =  0 ( Default  เป็นศุนย์)
Def(Th):",
	dh014_intra_co                	integer      comment "Def(En): INTRA CODE =  0 ( Default  เป็นศุนย์)
Def(Th):",
	dh014_project                 	smallint     comment "Def(En): PROJECT CODE  =  0 ( Default  เป็นศุนย์) 
Def(Th):",
	dh014_fics                    	integer      comment "Def(En):
Def(Th): FICS  code เลข  BL account no (Unused field)",
	dh014_future_use              	smallint     comment "Def(En): Future Use =  0 ( Default  เป็นศุนย์) 
Def(Th):",
	dh014_filler_2                	string       comment "Def(En): space
Def(Th):",
	dh014_sub_product             	integer      comment "Def(En):
Def(Th): sub product code มีค่าเท่ากับ
 PRODUCT CODE + PRODUCT FEATURE",
	dh014__fics_code              	integer      comment "Def(En):
Def(Th): FICS CODE เลข  BL account no (Unused field)",
	dh014_fics_name               	string       comment "Def(En): FICS NAME    (Unsed Field)
Def(Th):",
	dh014_account_code            	integer      comment "Def(En): ACCOUNT CODE     
Def(Th): หัวบัญชี GL มีค่าเท่ากับ DH014-ACCOUNT",
	dh014_account_name            	string       comment "Def(En): ACCOUNT NAME
Def(Th): ชื่อหัวบัญชี GL",
	dh014_product                 	integer      comment "Def(En):
Def(Th): PRODUCT CODE ของ GL",
	dh014_product_feauture        	smallint     comment "Def(En):
Def(Th): PRODUCT FEAUTURE ของ GL",
	dh014_product_name            	string       comment "Def(En):  
Def(Th): PRODUCT NAME    ชื่อของประเภทบัตรเครดิต 
 เป็นชื่อของ DH014-SUB-PRODUCT",
	dh014_product_description_thai	string       comment "Def(En):
Def(Th): DESCRIPTION OF PRODUCT  NAME  คำอธิบายภาษาไทย",
	dh014_filler_3                	string       comment "Def(En): SPACES
Def(Th):",
	load_tms                      	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                    	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                      	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                        	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                        	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_kb1dh014_cc1dmpgl' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);