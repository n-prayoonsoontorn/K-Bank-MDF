-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_kb1dh017_cpamt.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-11    Panita T.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_KB1DH017_CPAMT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_kb1dh017_cpamt (
	pos_dt                         	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh017_h_proc_dte               	date         comment "Def(En): Processing Date
Def(Th): วันทีของข้อมูล",
	dh017_cmt_orgn_nmbr            	smallint     comment "Def(En): ORG Number
Def(Th):",
	dh017_cmt_type                 	smallint     comment "Def(En): Type Number 
Def(Th):",
	dh017_cmt_card_nmbr            	bigint       comment "Def(En): Card Number
Def(Th):",
	dh017_cmt_effective_dte        	date         comment "Def(En): 
Def(Th): วันที่ทำรายการ",
	dh017_cmt_code                 	smallint     comment "Def(En): Transaction Code
Def(Th):",
	dh017_cmt_amnt                 	decimal(9,2) comment "Def(En): Transaction Amount
Def(Th):",
	dh017_cmt_posting_dte          	date         comment "Def(En): 
Def(Th): วันที่ Post รายการเข้าระบบ Cardlink",
	dh017_cmt_source_code          	smallint     comment "Def(En): 
Def(Th): แหล่งที่มาของรายการนี้",
	dh017_cmt_auth_code            	string       comment "Def(En): Auth Code
Def(Th):",
	dh017_cmt_rn_dte               	smallint     comment "Def(En): Date Last 3 Digit
Def(Th):",
	dh017_cmt_rn_batch_nmbr        	smallint     comment "Def(En): Post Batch Date
Def(Th): หมายเลข Batch Number ที่ Post เข้าระบบ Cardlink",
	dh017_cmt_rn_seq_nmbr          	smallint     comment "Def(En): Post Seq No.
Def(Th): หมายเลข Seq ที่ Post เข้าระบบ Cardlink",
	dh017_cmt_merch_orgn           	smallint     comment "Def(En): Merchant Org Number
Def(Th):",
	dh017_cmt_merch_acct           	integer      comment "Def(En): Merchant Account Number
Def(Th):",
	dh017_cmt_merch_category       	smallint     comment "Def(En): Merchant Category 
Def(Th): ประเภทกลุ่มร้านค้า",
	dh017_cmt_dba_name             	string       comment "Def(En): 
Def(Th): ชื่อร้านค้าที่ทำรายการ",
	dh017_cmt_dba_city             	string       comment "Def(En): 
Def(Th): จังหวัดที่ร้านค้าลงทะเบียน",
	dh017_cmt_dba_country          	string       comment "Def(En): 
Def(Th): ประเทศที่ร้านค้าลงทะเบียน",
	dh017_cmt_merch_state          	string       comment "Def(En): 
Def(Th): รัฐ ที่ร้านค้าลงทะเบียน",
	dh017_cmt_auth_flag            	string       comment "Def(En): Auth Flag
Def(Th):",
	dh017_cmt_split_char           	string       comment "Def(En): Split Char 
Def(Th): Flag แยกข้อมูลแต่ละระบบ",
	dh017_cmt_whsed_flag           	smallint     comment "Def(En): Warehouse Flag (รอโพส)
Def(Th):",
	dh017_cmt_posting_flag         	smallint     comment "Def(En): 
Def(Th):",
	dh017_cmt_rev_tran_id          	smallint     comment "Def(En): Transactionn Reverse ID
Def(Th):",
	dh017_cmt_kbank_conv_amt       	decimal(12,2) comment "Def(En): KBank Convert Amount
Def(Th):",
	dh017_cmt_kbank_multi_ind      	string       comment "Def(En): KBank Multi Currency Indicator
Def(Th):",
	dh017_cmt_acq_ref_nbr          	string       comment "Def(En): Acquire Reference Number
Def(Th): รหัสอ้างอิงกับร้านค้าต่างธนาคาร",
	dh017_cmt_pymt_type_ind        	smallint     comment "Def(En): Payment Type Indicator
Def(Th):",
	dh017_cmt_rps                  	string       comment "Def(En): REQUEST-PYT-SERVICE
Def(Th):",
	dh017_cmt_chgbk_rt             	string       comment "Def(En): Charge Back 
Def(Th):",
	dh017_cmt_ahf_orig_curr_code   	smallint     comment "Def(En): Original Currency Code
Def(Th):",
	dh017_cmt_ahf_orig_curr_amt    	decimal(12,2) comment "Def(En): Original Currency Amount
Def(Th):",
	dh017_cmt_ahf_orig_curr_decimal	smallint     comment "Def(En): Original Currency Decimal
Def(Th):",
	dh017_cmt_ahf_onus_curr_conv   	smallint     comment "Def(En): Original Currency Convert
Def(Th):",
	dh017_cmt_mc_sec_protocol      	string       comment "Def(En): Mastercard Sec Protocol
Def(Th):",
	dh017_cmt_mc_ch_authentic      	string       comment "Def(En): Mastercard CH Authentic
Def(Th):",
	dh017_cmt_mc_ucaf_ind          	string       comment "Def(En): Mastercard UCAF Indicator
Def(Th): ข้อมูลเกี่ยวกับ Currnecy เฉพาะ Master Card",
	dh017_cmt_setl_ind             	string       comment "Def(En): Settlement Indicator
Def(Th):",
	dh017_cmt_tran_type            	smallint     comment "Def(En): Transaction Type  
Def(Th): ประเภท Transaction ที่ทาง Visa/MC ส่งมา เช่น
5  คือ TC40,43
6  คือ TC 41,42
7 คือ TC 30,31
9 คือ TC อื่นๆ",
	dh017_cmt_intl_acq             	string       comment "Def(En): International Acquirer
Def(Th): ข้อมูล International Acquirer ที่ทาง Visa/MC ส่งมาให้",
	dh017_cmt_intl_iss             	string       comment "Def(En): International  Issuer
Def(Th): ข้อมูล International  Issuer ที่ทาง Visa/MC ส่งมาให้",
	dh017_cmt_intl_mer             	string       comment "Def(En): International  Merchant
Def(Th): ข้อมูล International merchant ที่ทาง Visa/MC ส่งมาให้",
	dh017_cmt_card_card_type       	string       comment "Def(En): 
Def(Th): ประเภทของบัตร Visa, MC",
	dh017_cmt_auth_amt             	bigint       comment "Def(En): Auth Amount
Def(Th):",
	dh017_cmt_auth_ccy             	smallint     comment "Def(En): Auth Currency Code
Def(Th):",
	dh017_cmt_orig_source_code     	smallint     comment "Def(En): Original Source Code 
Def(Th): แหล่งที่มาของรายการ",
	dh017_cmt_pos_mode             	string       comment "Def(En): Pos Mode
Def(Th):",
	dh017_cmt_pymt_auth            	string       comment "Def(En): Payment Auth
Def(Th):",
	dh017_cmt_installment_ind      	string       comment "Def(En): Installment Indicator  
Def(Th): Flag บอกว่าเป็นรายการ Installment หรือไม่",
	dh017_cmt_kbank_curr_code      	smallint     comment "Def(En): Kbank Currency Code
Def(Th):",
	dh017_cmt_dcc_flag             	string       comment "Def(En): DCC Flag (Dual Currency)
Def(Th):",
	dh017_cmt_mult_seq_nbr         	smallint     comment "Def(En): Multi Sequence Number
Def(Th):",
	dh017_cmt_mult_seq_total_cnt   	smallint     comment "Def(En): Multi Sequence Total Count
Def(Th):",
	load_tms                       	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                     	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                       	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                         	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                         	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_kb1dh017_cpamt' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);