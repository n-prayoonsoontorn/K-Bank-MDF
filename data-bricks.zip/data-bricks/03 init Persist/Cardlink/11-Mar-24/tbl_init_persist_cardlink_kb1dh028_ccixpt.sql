-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_kb1dh028_ccixpt.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-11    Panita T.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_KB1DH028_CCIXPT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_kb1dh028_ccixpt (
	pos_dt                              	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh028_mpaa_eff_timestamp            	timestamp    comment "Def(En):Date and time that the information in this
record becomes effective or was last updated.
(YYYYMMDD HH)
Def(Th):",
	dh028_mpaa_action_type              	string       comment "Def(En):Action type
Def(Th):",
	dh028_mpaa_table_id                 	string       comment "Def(En):Table ID
Def(Th):",
	dh028_mpaa_t40_bin_lo               	string       comment "Def(En):BIN Low
Def(Th): หมายถึง Bin เริ่มต้น",
	dh028_mpaa_t40_prod_id              	string       comment "Def(En):Product ID
Def(Th):",
	dh028_mpaa_t40_bin_hi               	string       comment "Def(En):BIN high
Def(Th): หมายถึง Bin สิ้นสุด",
	dh028_mpaa_t40_brand                	string       comment "Def(En):
Def(Th): เครื่อง EDC นี้สามารถรับสกุลเงินอะไรได้บ้าง",
	dh028_mpaa_t40_brand_pri_cde        	smallint     comment "Def(En):Brand primary code
The priority code assigned to the card program
identifier by the issuer, for the associated account
range. Priority codes begin with a low-value
number for the highest priority and continue in
ascending sequence
Def(Th):",
	dh028_mpaa_t40_mbr_id               	bigint       comment "Def(En):Member ID
Def(Th):",
	dh028_mpaa_t40_prod_type            	string       comment "Def(En):Product type
Def(Th):",
	dh028_mpaa_t40_end_pt               	integer      comment "Def(En):End point
The seven-digit routing endpoint associated with
the account range
Def(Th):",
	dh028_mpaa_t40_cntry_cde_a          	string       comment "Def(En):Country Name
Def(Th):",
	dh028_mpaa_t40_cntry_cde_n          	smallint     comment "Def(En):Country code
Def(Th):",
	dh028_mpaa_t40_region               	string       comment "Def(En):Region
Def(Th):",
	dh028_mpaa_t40_prod_class           	string       comment "Def(En):Product class
Used in interchange processing.
Valid values:
Refer to the IPM Clearing Formats manual, Private
Data, Subelement definitions for PDS 0158
Business Activity, Subfield 8, Product Class
Override Indicator for the Product Class values.
Def(Th):",
	dh028_mpaa_t40_txn_routing_ind      	string       comment "Def(En):Transaction routing indicator
Def(Th):",
	dh028_mpaa_t40_1st_pres_reasgn_sw   	string       comment "Def(En):Product reassignment switch for first
presentment transactions.
Valid values:
Y = Product reassigned
N = Product not reassigned
Def(Th):",
	dh028_mpaa_t40_prod_reassign_sw     	string       comment "Def(En):Product reassign switch
Def(Th):",
	dh028_mpaa_opt_in_sw                	string       comment "Def(En):Option indicator switch
The account range is a participant in purchase with
cash back transactions.
Def(Th):",
	dh028_mpaa_t40_lic_prod_id          	string       comment "Def(En):Licence product ID
Def(Th):",
	dh028_mpaa_t40_paypass_msi          	string       comment "Def(En):Paypass MSI
The Mapping Service Indicator identifies issuing
account ranges that require a Mapping Service
Def(Th):",
	dh028_mpaa_t40_acct_lvl_ptcn_ind    	string       comment "Def(En):The account level management participation
indicator
Def(Th):",
	dh028_mpaa_t40_acct_lvl_activatn_dte	string       comment "Def(En):Account level activate date
Def(Th):",
	dh028_mpaa_t40_ch_bill_ccy_dfl      	smallint     comment "Def(En):Cardholder Billing Currency default
Def(Th):",
	dh028_mpaa_t40_ch_bill_ccy_exp_del  	smallint     comment "Def(En):Cardholder Billing Currency Exponent Default.
Def(Th): หมายถึง สกุลเงินนี้มีทศนิยมกี่ Digit",
	dh028_mpaa_t40_ch_bill_txn_ccy1     	smallint     comment "Def(En):Cardholder Billing Primary Transaction Currency Code1
Def(Th):",
	dh028_mpaa_t40_ch_bill_prm_ccy1     	smallint     comment "Def(En):Cardholder Billing Primary Currency1
Def(Th):",
	dh028_mpaa_t40_ch_bill_prm_exp1     	smallint     comment "Def(En):Cardholder Billing Primary Currency1 exponent 
Def(Th): สกุลเงินนี้มีทศนิยมกี่ Digit)",
	dh028_mpaa_t40_ch_bill_txn_ccy2     	smallint     comment "Def(En):Cardholder Billing Primary Transaction Currency Code2
Def(Th):",
	dh028_mpaa_t40_ch_bill_prm_ccy2     	smallint     comment "Def(En):Cardholder Billing Primary Currency2
Def(Th):",
	dh028_mpaa_t40_ch_bill_prm_exp2     	smallint     comment "Def(En):Cardholder Billing Primary Currency2 exponent
Def(Th): สกุลเงินนี้มีทศนิยมกี่ Digit",
	dh028_mpaa_t40_ch_bill_txn_ccy3     	smallint     comment "Def(En):Cardholder Billing Primary Transaction Currency Code3
Def(Th):",
	dh028_mpaa_t40_ch_bill_prm_ccy3     	smallint     comment "Def(En):Cardholder Billing Primary Currency3
Def(Th):",
	dh028_mpaa_t40_ch_bill_prm_exp3     	smallint     comment "Def(En):Cardholder Billing Primary Currency3 exponent 
Def(Th): สกุลเงินนี้มีทศนิยมกี่ Digit",
	dh028_mpaa_t40_ch_bill_txn_ccy4     	smallint     comment "Def(En):Cardholder Billing Primary Transaction Currency Code4
Def(Th):",
	dh028_mpaa_t40_ch_bill_prm_ccy4     	smallint     comment "Def(En):Cardholder Billing Primary Currency4
Def(Th):",
	dh028_mpaa_t40_ch_bill_prm_exp4     	smallint     comment "Def(En):Cardholder Billing Primary Currency4 exponent 
Def(Th): สกุลเงินนี้มีทศนิยมกี่ Digit",
	load_tms                            	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                          	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                            	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                              	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                              	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_kb1dh028_ccixpt' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);