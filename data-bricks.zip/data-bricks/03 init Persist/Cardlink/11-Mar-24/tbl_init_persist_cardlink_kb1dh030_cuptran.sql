-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_kb1dh030_cuptran.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-11    Panita T.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_KB1DH030_CUPTRAN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_kb1dh030_cuptran (
	pos_dt                          	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh030_dlogc_acq_inst_id         	string       comment "Def(En): Acquirer installment ID
รหัสร้านค้า Installment
Def(Th):",
	dh030_dlogc_forward_inst_id     	string       comment "Def(En): Forward installment ID
Def(Th):",
	dh030_dlogc_sys_trace_nbr       	integer      comment "Def(En): หมายเลข Trace No
Def(Th):",
	dh030_dlogc_trans_date_time     	timestamp    comment "Def(Th): วัน และ เวลา ทำรายการ Transaction Date
Def(Th):",
	dh030_dlogc_trans_date          	date         comment "Def(En)
Def(Th): วันที่ทำรายการ Transaction Date",
	dh030_dlogc_trans_time          	integer      comment "Def(En)
Def(Th): เวลาทำรายการ Transaction Date",
	dh030_dlogc_card_no             	string       comment "Def(En)
Def(Th): หมายเลขบัตร",
	dh030_dlogc_trans_amount        	decimal(12,2) comment "Def(En)
Def(Th): จำนวนเงินที่ทำรายการ",
	dh030_dlogc_mti                 	smallint     comment "Def(En): Message Type Indentifier
Def(Th):",
	dh030_dlogc_processing_code     	integer      comment "Def(En): Processing code
Def(Th):",
	dh030_dlogc_merch_type          	smallint     comment "Def(En)
Def(Th): รหัสประเภทร้านค้า 
Merchant Category",
	dh030_dlogc_terminal_no         	integer      comment "Def(En): Terminal no.
Def(Th):",
	dh030_dlogc_acq_inst_id_nbr     	integer      comment "Def(En): Acquirer installment ID number
Def(Th):",
	dh030_dlogc_merch_cup_id        	integer      comment "Def(En)
Def(Th): รหัสร้านค้า China Union Pay",
	dh030_dlogc_merch_name          	string       comment "Def(En)
Def(Th): ชื่อร้านค้า",
	dh030_dlogc_ref_nbr             	string       comment "Def(En)
Def(Th): หมายเลขอ้างอิง",
	dh030_dlogc_pos_code            	smallint     comment "Def(En): POS Code 
(Point of service condition code)
Def(Th):",
	dh030_dlogc_auth_id             	string       comment "Def(En): Authorize ID รหัส Auth
Def(Th):",
	dh030_dlogc_receive_inst_id     	bigint       comment "Def(En)
Def(Th): รหัสการผ่อนชำระที่ได้รับ",
	dh030_dlogc_origin_trace_nbr    	integer      comment "Def(En): Original trace number
Def(Th):",
	dh030_dlogc_response_code       	smallint     comment "Def(En): Response Code
Def(Th):",
	dh030_dlogc_trans_currency      	smallint     comment "Def(En)
Def(Th): สกุลเงินที่ใช้ทำธุรกรรม",
	dh030_dlogc_pos_entry_mode      	smallint     comment "Def(En): POS entry mode
รหัสบอกว่าทำรายการเข้ามาแบบไหน เช่น  แบบ Chip หรือแบบรูด หรือ Key-IN
Def(Th):",
	dh030_dlogc_settle_currency     	smallint     comment "Def(En)
Def(Th): สกุลเงินที่ใช้ในการ Settlement",
	dh030_dlogc_settle_amount       	decimal(12,2) comment "Def(En)
Def(Th): จำนวนเงินที่ Settlement",
	dh030_dlogc_settle_exch_rate    	integer      comment "Def(En): Exchange rate of Settlement
Def(Th):",
	dh030_dlogc_settle_dec_digit    	smallint     comment "Def(En): Settlement digit
Def(Th):",
	dh030_dlogc_settle_exch_rate_amt	integer      comment "Def(En): Exchange rate amount of Settlement
Def(Th):",
	dh030_dlogc_settle_date         	smallint     comment "Def(En)
Def(Th): วันที่ทำการ Settlement (MMDD)
This field is the transaction settlement date between the acquirer and the issuer.",
	dh030_dlogc_exch_date           	smallint     comment "Def(En)
Def(Th): วันที่ทำการแลกเปลี่ยนเงิน(MMDD)
This field is the effective date of the conversion rate for the currency conversion from the original transaction currency to the settlement currency.",
	dh030_dlogc_receive_serv_fee    	bigint       comment "Def(En)
Def(Th): ค่าธรรมเนียมในการให้บริการที่ได้รับ (ไม่มีทศนิยมมั้ย)",
	dh030_dlogc_pay_serv_fee        	bigint       comment "Def(En)
Def(Th): ค่าธรรมเนียมในการให้บริการที่จ่าย (ไม่มีทศนิยมมั้ย)",
	dh030_dlogc_switch_serv_fee     	bigint       comment "Def(En)
Def(Th): ค่าธรรมเนียมในการให้บริการที่แลกเปลี่ยน  (ไม่มีทศนิยมมั้ย)",
	dh030_dlogc_serv_fee_curr       	smallint     comment "Def(En)
Def(Th): สกุลเงินที่ใช้เรียกเก็บค่าธรรมเนียมในการให้บริการ",
	dh030_dlogc_serv_fee_exch_rate  	integer      comment "Def(En)
Def(Th): อัตราในการคิดค่าบริการการแลกเปลี่ยนเงิน",
	dh030_dlogc_card_tran_fee       	bigint       comment "Def(En)
Def(Th): ค่าธรรมเนียมในการทำธุรกรรม",
	dh030_dlogc_tran_fee_currency   	smallint     comment "Def(En)
Def(Th): สกุลเงินที่ใช้เรียกเก็บค่าธรรมเนียมในการทำธุรกรรม",
	dh030_dlogc_tran_fee_exch_rate  	integer      comment "Def(En)
Def(Th): อัตราค่าธรรมเนียมในการแลกเปลี่ยนเงิน",
	dh030_dlogc_stl_rate            	decimal(13,9) comment "Def(En)
Def(Th): อัตราการ Settlement",
	dh030_dlogc_outgo_rate          	decimal(13,9) comment "Def(En)
Def(Th): อัตราการส่งออก",
	dh030_dlogc_tran_org            	string       comment "Def(En): ORG ของ Merchant ที่ทำรายการ
Def(Th):",
	dh030_dlogc_tran_swift_code     	string       comment "Def(En): Transection swift code
Def(Th):",
	dh030_dlogc_settle_org          	string       comment "Def(En): ORG ของ Settlement currency
Def(Th):",
	dh030_dlogc_settle_swift_code   	string       comment "Def(En): Settlement swift code
Def(Th):",
	dh030_dlogc_orig_amount         	decimal(12,2) comment "Def(En)
Def(Th): จำนวนเงินตั้งต้น",
	dh030_dlogc_cup_flag            	string       comment "Def(En): CUP flag
Def(Th):",
	dh030_dlogc_merch_cup_id_new    	string       comment "Def(En)
Def(Th): รหัสร้านค้า China Union Pay",
	dh030_d_filler                  	string       comment "Def(En): Space
Def(Th):",
	load_tms                        	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                      	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                        	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                          	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                          	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_kb1dh030_cuptran' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);