-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_kb1dh031_cc1d583b.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-11    Panita T.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_KB1DH031_CC1D583B
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_kb1dh031_cc1d583b (
	pos_dt                            	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh031_d583b_batch_proc_date_ymd   	date         comment "Def(En): Batch Process Date
Def(Th):",
	dh031_d583b_tape_create_date_ymd  	date         comment "Def(En): Batch Process Date
Def(Th):",
	dh031_d583b_merchant_file_date_ymd	date         comment "Def(En):
Def(Th): วันที่จากMerchant",
	dh031_d583b_merchant_id           	integer      comment "Def(En): Merchant ID
Def(Th):",
	dh031_d583b_merchant_eng_name     	string       comment "Def(En): Merchant name (EN)
Def(Th):",
	dh031_d583b_system_code           	smallint     comment "Def(En): System code
Def(Th):",
	dh031_d583b_owner_ind             	smallint     comment "Def(En): Owner Identifier
Def(Th): ถ้าเป็นรายการจาก UI จะเป็น Terminal ID 3 หลักแรก
ถ้าเป็นรายการจาก LI จะมีค่าเป็น 203",
	dh031_d583b_terminal_no           	smallint     comment "Def(En): Terminal no.
Def(Th):",
	dh031_d583b_edc_batch_no          	smallint     comment "Def(En): EDC Batch no.
Def(Th):",
	dh031_d583b_trans_code            	smallint     comment "Def(En): Transaction code
Def(Th):",
	dh031_d583b_vs_mc_acct_no         	bigint       comment "Def(En): 
Def(Th): หมายเลขบัญชีสำหรับVisa/Mastercard",
	dh031_d583b_cd_acct_no            	bigint       comment "Def(En): 
Def(Th): หมายเลขบัญชีสำหรับ Kbank",
	dh031_d583b_merch_cepp            	string       comment "Def(En): 
Def(Th): Merchant ผ่อนชำระ",
	dh031_d583b_user_code_3           	string       comment "Def(En): User code3 
Def(Th): User code3 จากไฟล์ Merchant",
	dh031_d583b_user_code_1           	string       comment "Def(En): User code1
Def(Th): User code1 จากไฟล์ Merchant",
	dh031_d583b_branch                	smallint     comment "Def(En):
Def(Th): รหัสสาขาของเบอร์บัญชี ที่ใช้เข้าเงินร้านค้า",
	dh031_d583b_print_flag            	string       comment "Def(En): Print flag
Def(Th): Print flag 
มาจากไฟล์ CPBMER ฟิลด์MMD-ED-USER-FIELD (3)",
	dh031_d583b_merchant_org          	smallint     comment "Def(En): Merchant org
Def(Th):",
	dh031_d583b_curr_code             	smallint     comment "Def(En): Currency code
Def(Th):",
	dh031_d583b_curr_rate             	decimal(4,2) comment "Def(En): Currency rate
Def(Th):",
	dh031_d583b_ecom_flag             	string       comment "Def(En): E-Commerce flag
Def(Th):",
	dh031_d583b_ecom_transfer_flag    	string       comment "Def(En): E-Commerce transfer flag
Def(Th):",
	dh031_d583b_ecom_mall_comm_rate   	decimal(4,2) comment "Def(En): Commission rate
Def(Th): Commission rate สำหรับรายการE-Commerce",
	dh031_d583b_purchase_card_flag    	string       comment "Def(En): Purchase card flag
Def(Th):",
	dh031_d583b_mmd_merch_type        	smallint     comment "Def(En): MMD merchant type
Def(Th):",
	dh031_d583b_mmd_pos_mode          	string       comment "Def(En): Pos Entry Mode
Def(Th): Pos Entry Mode
บอกว่าทำรายการมาจากไหน",
	dh031_d583b_mmd_mail_phone_ind    	string       comment "Def(En):
Def(Th): เป็นรายการ Mail Order หรือไม่
ดูจากไฟล์ CPBMER ฟิลด์MMD-MAIL-PHONE-IND",
	dh031_d583b_bl_flag               	string       comment "Def(En):
Def(Th): Flag ของหัวบัญชีเข้าเงินร้านค้า",
	dh031_d583b_pmgw_sim_flag         	string       comment "Def(En): Payment gateway sim flag
Def(Th):",
	dh031_d583b_tr_date               	string       comment "Def(En): Transaction date
Def(Th):",
	dh031_d583b_tax_id                	string       comment "Def(En): Tax ID
Def(Th):",
	dh031_d583b_user_code             	string       comment "Def(En): User code
Def(Th):",
	dh031_d583b_vs_on_total_amt       	decimal(12,2) comment "Def(En): Total amount of Visa onus card
Def(Th):",
	dh031_d583b_vs_lo_total_amt       	decimal(12,2) comment "Def(En): Total amount of Visa local card
Def(Th):",
	dh031_d583b_vs_in_total_amt       	decimal(12,2) comment "Def(En): Total amount of Visa inter card
Def(Th):",
	dh031_d583b_vs_plt_total_amt      	decimal(12,2) comment "Def(En): Total amount of Visa platinium card
Def(Th):",
	dh031_d583b_vs_pli_total_amt      	decimal(12,2) comment "Def(En): Total amount of Visa platinium inter card
Def(Th):",
	dh031_d583b_vs_asso_total_amt     	decimal(12,2) comment "Def(En): Total amount of Visa ASSO card (บัตรสมาคม)
Def(Th):",
	dh031_d583b_vs_custom_total_amt   	decimal(12,2) comment "Def(En): Total amount of Visa custom card
Def(Th):",
	dh031_d583b_vs_electn_total_amt   	decimal(12,2) comment "Def(En): Total amount of Visa electronic card
Def(Th):",
	dh031_d583b_mc_on_total_amt       	decimal(12,2) comment "Def(En): Total amount of Mastercard onus
Def(Th):",
	dh031_d583b_mc_lo_total_amt       	decimal(12,2) comment "Def(En): Total amount of Mastercard local
Def(Th):",
	dh031_d583b_mc_in_total_amt       	decimal(12,2) comment "Def(En): Total amount of Mastercard inter
Def(Th):",
	dh031_d583b_mc_plt_total_amt      	decimal(12,2) comment "Def(En): Total amount of Mastercard platinium
Def(Th):",
	dh031_d583b_mc_pli_total_amt      	decimal(12,2) comment "Def(En): Total amount of Mastercard platinium inter
Def(Th):",
	dh031_d583b_mc_asso_total_amt     	decimal(12,2) comment "Def(En): Total amount of Mastercard ASSO (บัตรสมาคม)
Def(Th):",
	dh031_d583b_mc_custom_total_amt   	decimal(12,2) comment "Def(En): Total amount of Mastercard custom
Def(Th):",
	dh031_d583b_cd_total_amt          	decimal(12,2) comment "Def(En): Total amount of Kbank Credit card
Def(Th):",
	dh031_d583b_ec_total_amt          	decimal(12,2) comment "Def(En): Total amount of Electronic card
Def(Th):",
	dh031_d583b_pc_total_amt          	decimal(12,2) comment "Def(En): Total amount of PURCHASE CARD บัตรบุณรอด 
Def(Th):",
	dh031_d583b_jcb_lo_total_amt      	decimal(12,2) comment "Def(En): Total amount of JCB local card
Def(Th):",
	dh031_d583b_jcb_in_total_amt      	decimal(12,2) comment "Def(En): Total amount of JCB inter card
Def(Th):",
	dh031_d583b_oth_total_amt         	decimal(12,2) comment "Def(En): Total amount of other card
Def(Th):",
	dh031_d583b_numeric_detect        	string       comment "Def(En): Numeric detect
Def(Th):",
	dh031_d583b_vs_on_slip            	integer      comment "Def(En): Number's slip from Visa ouns card
Def(Th):",
	dh031_d583b_vs_lo_slip            	integer      comment "Def(En): Number's slip from Visa local card
Def(Th):",
	dh031_d583b_vs_in_slip            	integer      comment "Def(En): Number's slip from Visa inter card
Def(Th):",
	dh031_d583b_vs_plt_slip           	integer      comment "Def(En): Number's slip from Visa platinium card
Def(Th):",
	dh031_d583b_vs_pli_slip           	integer      comment "Def(En): Number's slip from Visa platinium inter
Def(Th):",
	dh031_d583b_vs_asso_slip          	integer      comment "Def(En): Number's slip from Visa ASSO card
Def(Th):",
	dh031_d583b_vs_custom_slip        	integer      comment "Def(En): Number's slip from Visa custom card
Def(Th):",
	dh031_d583b_vs_electn_slip        	integer      comment "Def(En): Number's slip from Visa electronic card
Def(Th):",
	dh031_d583b_mc_on_slip            	integer      comment "Def(En): Number's slip from Mastercard onus card
Def(Th):",
	dh031_d583b_mc_lo_slip            	integer      comment "Def(En): Number's slip from Mastercard local card
Def(Th):",
	dh031_d583b_mc_in_slip            	integer      comment "Def(En): Number's slip from Mastercard inter card
Def(Th):",
	dh031_d583b_mc_plt_slip           	integer      comment "Def(En): Number's slip from Mastercard platinium card
Def(Th):",
	dh031_d583b_mc_pli_slip           	integer      comment "Def(En): Number's slip from Mastercard platinium inter card
Def(Th):",
	dh031_d583b_mc_asso_slip          	integer      comment "Def(En): Number's slip from Mastercard ASSO card
Def(Th):",
	dh031_d583b_mc_custom_slip        	integer      comment "Def(En): Number's slip from Mastercard custom card
Def(Th):",
	dh031_d583b_cd_slip               	integer      comment "Def(En): Number's slip from Kbank Credit card
Def(Th):",
	dh031_d583b_ec_slip               	integer      comment "Def(En): Number's slip from Electronic card
Def(Th):",
	dh031_d583b_pc_slip               	integer      comment "Def(En): Number's slip from Purchase Card
Def(Th):",
	dh031_d583b_jcb_lo_slip           	integer      comment "Def(En): Number's slip from JCB local card
Def(Th):",
	dh031_d583b_jcb_in_slip           	integer      comment "Def(En): Number's slip from JCB inter card
Def(Th):",
	dh031_d583b_oth_slip              	integer      comment "Def(En): Number's slip from other card
Def(Th):",
	dh031_d583b_vs_on_comm_rate       	decimal(4,2) comment "Def(En): Commission rate of Visa onus card
Def(Th):",
	dh031_d583b_vs_lo_comm_rate       	decimal(4,2) comment "Def(En): Commission rate of Visa local card
Def(Th):",
	dh031_d583b_vs_in_comm_rate       	decimal(4,2) comment "Def(En): Commission rate of Visa inter card
Def(Th):",
	dh031_d583b_vs_plt_comm_rate      	decimal(4,2) comment "Def(En): Commission rate of Visa platinium card
Def(Th):",
	dh031_d583b_vs_pli_comm_rate      	decimal(4,2) comment "Def(En): Commission rate of Visa platinium inter card
Def(Th):",
	dh031_d583b_vs_electn_comm_rate   	decimal(4,2) comment "Def(En): Commission rate of Visa electronic card
Def(Th):",
	dh031_d583b_mc_on_comm_rate       	decimal(4,2) comment "Def(En): Commission rate of Mastercard onus
Def(Th):",
	dh031_d583b_mc_lo_comm_rate       	decimal(4,2) comment "Def(En): Commission rate of Mastercard local
Def(Th):",
	dh031_d583b_mc_in_comm_rate       	decimal(4,2) comment "Def(En): Commission rate of Mastercard inter
Def(Th):",
	dh031_d583b_mc_plt_comm_rate      	decimal(4,2) comment "Def(En): Commission rate of Mastercard platinium
Def(Th):",
	dh031_d583b_mc_pli_comm_rate      	decimal(4,2) comment "Def(En): Commission rate of Mastercard platinium inter
Def(Th):",
	dh031_d583b_cd_comm_rate          	decimal(4,2) comment "Def(En): Commission rate of Credit card
Def(Th):",
	dh031_d583b_ec_comm_rate          	decimal(4,2) comment "Def(En): Commission rate of Electronic card
Def(Th):",
	dh031_d583b_pc_comm_rate          	decimal(4,2) comment "Def(En): Commission rate of Plastic card
Def(Th):",
	dh031_d583b_jcb_lo_comm_rate      	decimal(4,2) comment "Def(En): Commission rate of JCB local card
Def(Th):",
	dh031_d583b_jcb_in_comm_rate      	decimal(4,2) comment "Def(En): Commission rate of JCB inter card
Def(Th):",
	dh031_d583b_oth_comm_rate         	decimal(4,2) comment "Def(En): Commission rate of other card
Def(Th):",
	dh031_d583b_ovs_on_total_amt      	decimal(12,2) comment "Def(En): Original total amount of Visa onus card.
Def(Th):",
	dh031_d583b_ovs_lo_total_amt      	decimal(12,2) comment "Def(En): Original total amount of Visa local card.
Def(Th):",
	dh031_d583b_ovs_in_total_amt      	decimal(12,2) comment "Def(En): Original total amount of Visa inter card.
Def(Th):",
	dh031_d583b_ovs_plt_total_amt     	decimal(12,2) comment "Def(En): Original total amount of Visa platinium card.
Def(Th):",
	dh031_d583b_ovs_pli_total_amt     	decimal(12,2) comment "Def(En): Original total amount of Visa platinium inter card.
Def(Th):",
	dh031_d583b_ovs_asso_total_amt    	decimal(12,2) comment "Def(En): Original total amount of Visa ASSO card.
Def(Th):",
	dh031_d583b_ovs_custom_total_amt  	decimal(12,2) comment "Def(En): Original total amount of Visa custom card.
Def(Th):",
	dh031_d583b_ovs_electn_total_amt  	decimal(12,2) comment "Def(En): Original total amount of Visa electronic card.
Def(Th):",
	dh031_d583b_omc_on_total_amt      	decimal(12,2) comment "Def(En): Original total amount of Mastercard onus card.
Def(Th):",
	dh031_d583b_omc_lo_total_amt      	decimal(12,2) comment "Def(En): Original total amount of Mastercard local card.
Def(Th):",
	dh031_d583b_omc_in_total_amt      	decimal(12,2) comment "Def(En): Original total amount of Mastercard inter card.
Def(Th):",
	dh031_d583b_omc_plt_total_amt     	decimal(12,2) comment "Def(En): Original total amount of Mastercard platinium card.
Def(Th):",
	dh031_d583b_omc_pli_total_amt     	decimal(12,2) comment "Def(En): Original total amount of Mastercard platinium inter card.
Def(Th):",
	dh031_d583b_omc_asso_total_amt    	decimal(12,2) comment "Def(En): Original total amount of Mastercard ASSO card.
Def(Th):",
	dh031_d583b_omc_custom_total_amt  	decimal(12,2) comment "Def(En): Original total amount of Mastercard custom card.
Def(Th):",
	dh031_d583b_ocd_total_amt         	decimal(12,2) comment "Def(En): Original total amount of Credit card.
Def(Th):",
	dh031_d583b_oec_total_amt         	decimal(12,2) comment "Def(En): Original total amount of Electronic card.
Def(Th):",
	dh031_d583b_opc_total_amt         	decimal(12,2) comment "Def(En): Original total amount of Plastic card.
Def(Th):",
	dh031_d583b_ojcb_lo_total_amt     	decimal(12,2) comment "Def(En): Original total amount of JCB local card.
Def(Th):",
	dh031_d583b_ojcb_in_total_amt     	decimal(12,2) comment "Def(En): Original total amount of JCB inter card.
Def(Th):",
	dh031_d583b_ooth_total_amt        	decimal(12,2) comment "Def(En): Original total amount of other card.
Def(Th):",
	dh031_d583b_vs_on_comm_amt        	decimal(12,4) comment "Def(En): Commission amount of Visa onus card
Def(Th):",
	dh031_d583b_vs_lo_comm_amt        	decimal(12,4) comment "Def(En): Commission amount of Visa local card
Def(Th):",
	dh031_d583b_vs_in_comm_amt        	decimal(12,4) comment "Def(En): Commission amount of Visa inter card
Def(Th):",
	dh031_d583b_vs_plt_comm_amt       	decimal(12,4) comment "Def(En): Commission amount of Visa platinium card
Def(Th):",
	dh031_d583b_vs_pli_comm_amt       	decimal(12,4) comment "Def(En): Commission amount of Visa platinium inter card
Def(Th):",
	dh031_d583b_ve_comm_amt           	decimal(12,4) comment "Def(En): Commission amount of Visa electronic card
Def(Th):",
	dh031_d583b_mc_on_comm_amt        	decimal(12,4) comment "Def(En): Commission amount of Mastercard onus
Def(Th):",
	dh031_d583b_mc_lo_comm_amt        	decimal(12,4) comment "Def(En): Commission amount of Mastercard local
Def(Th):",
	dh031_d583b_mc_in_comm_amt        	decimal(12,4) comment "Def(En): Commission amount of Mastercard inter
Def(Th):",
	dh031_d583b_mc_plt_comm_amt       	decimal(12,4) comment "Def(En): Commission amount of Mastercard platinium
Def(Th):",
	dh031_d583b_mc_pli_comm_amt       	decimal(12,4) comment "Def(En): Commission amount of Mastercard platinium inter
Def(Th):",
	dh031_d583b_cd_comm_amt           	decimal(12,4) comment "Def(En): Commission amount of Credit card
Def(Th):",
	dh031_d583b_ec_comm_amt           	decimal(12,4) comment "Def(En): Commission amount of Electronic card
Def(Th):",
	dh031_d583b_pc_comm_amt           	decimal(12,4) comment "Def(En): Commission amount of Plastic card
Def(Th):",
	dh031_d583b_jcb_lo_comm_amt       	decimal(12,4) comment "Def(En): Commission amount of JCB local card
Def(Th):",
	dh031_d583b_jcb_in_comm_amt       	decimal(12,4) comment "Def(En): Commission amount of JCB inter card
Def(Th):",
	dh031_d583b_oth_comm_amt          	decimal(12,4) comment "Def(En): Commission amount of other card
Def(Th):",
	dh031_d583b_vs_on_vat_amt         	decimal(9,2) comment "Def(En): VAT amount of Visa onus card
Def(Th):",
	dh031_d583b_vs_lo_vat_amt         	decimal(9,2) comment "Def(En): VAT amount of Visa local card
Def(Th):",
	dh031_d583b_vs_in_vat_amt         	decimal(9,2) comment "Def(En): VAT amount of Visa inter card
Def(Th):",
	dh031_d583b_vs_plt_vat_amt        	decimal(9,2) comment "Def(En): VAT amount of Visa platinium card
Def(Th):",
	dh031_d583b_vs_pli_vat_amt        	decimal(9,2) comment "Def(En): VAT amount of Visa platinium inter card
Def(Th):",
	dh031_d583b_mc_on_vat_amt         	decimal(9,2) comment "Def(En): VAT amount of Mastercard onus
Def(Th):",
	dh031_d583b_mc_lo_vat_amt         	decimal(9,2) comment "Def(En): VAT amount of Mastercard local
Def(Th):",
	dh031_d583b_mc_in_vat_amt         	decimal(9,2) comment "Def(En): VAT amount of Mastercard inter
Def(Th):",
	dh031_d583b_mc_plt_vat_amt        	decimal(9,2) comment "Def(En): VAT amount of Mastercard platinium
Def(Th):",
	dh031_d583b_mc_pli_vat_amt        	decimal(9,2) comment "Def(En): VAT amount of Mastercard platinium inter
Def(Th):",
	dh031_d583b_cd_vat_amt            	decimal(9,2) comment "Def(En): VAT amount of Credit card
Def(Th):",
	dh031_d583b_ec_vat_amt            	decimal(9,2) comment "Def(En): VAT amount of Electronic card
Def(Th):",
	dh031_d583b_pc_vat_amt            	decimal(9,2) comment "Def(En): VAT amount of Plastic card
Def(Th):",
	dh031_d583b_jcb_lo_vat_amt        	decimal(9,2) comment "Def(En): VAT amount of JCB local card
Def(Th):",
	dh031_d583b_jcb_in_vat_amt        	decimal(9,2) comment "Def(En): VAT amount of JCB inter card
Def(Th):",
	dh031_d583b_oth_vat_amt           	decimal(9,2) comment "Def(En): VAT amount of other card
Def(Th):",
	dh031_d583b_kt_branch             	smallint     comment "Def(En): 
Def(Th): รหัสสาขาบัญชีของร้านค้าหลังจากขึ้น KT (Brach 4 หลัก)",
	dh031_d583b_kt_branch_of_vs_mc    	smallint     comment "Def(En): Branch of Visa/Mastercard
Def(Th):",
	dh031_d583b_kt_type_of_vs_mc      	smallint     comment "Def(En): 
Def(Th): ประเภทของบัญชีที่เข้าเงินร้านค้า
1 = Current account
2 = Saving account",
	dh031_d583b_kt_prod_code_vs_mc    	integer      comment "Def(En): Product code of Visa/Mastercard
Def(Th):",
	dh031_d583b_kt_branch_of_cd       	smallint     comment "Def(En): Branch of Credit card
Def(Th):",
	dh031_d583b_kt_type_of_cd         	smallint     comment "Def(En): 
Def(Th): ประเภทของบัญชีที่เข้าเงินร้านค้า
1 = Current account
2 = Saving account
(เหมือน Field 150)",
	dh031_d583b_kt_prod_code_cd       	integer      comment "Def(En): Product code of Credit card
Def(Th):",
	dh031_d_filler                    	string       comment "Def(En): Space
Def(Th):",
	load_tms                          	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                        	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                          	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                            	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                            	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_kb1dh031_cc1d583b' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);