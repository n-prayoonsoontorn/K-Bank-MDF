-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_kb1dh039_ccnd5012.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-11    Panita T.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_KB1DH039_CCND5012
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_kb1dh039_ccnd5012 (
	pos_dt                                   	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh039_proc_date                          	date         comment "Def(En): PROCESSING DATE
Def(Th):",
	dh039_source_code1                       	string       comment "Def(En): SOURCE-CODE1 คือ ทำรายการจากที่ไหน
ED : ทำรายการจาก EDC KBank
VE  : Local EDC / Inter EDC ขึ้นอยู่กับว่า SOURCE-CODE 2 มีค่าเป็นอะไร เช่น ค่าเป็น 1 คือ Local EDC, ค่าเป็น 2 คือ Inter EDC
Def(Th):",
	dh039_source_code2                       	string       comment "Def(En): SOURCE-CODE2 
Def(Th):",
	dh039_trans_date                         	string       comment "Def(En): TRANSACTION DATE
Def(Th):",
	dh039_card_no                            	bigint       comment "Def(En): CARD NUMBER
Def(Th):",
	dh039_auth_no                            	string       comment "Def(En): Authorization Number
Def(Th):",
	dh039_txn_amt                            	decimal(12,2) comment "Def(En): ORIGINAL TRANSACTION AMOUNT
Def(Th):",
	dh039_txn_curr_code                      	string       comment "Def(En): TRANSACTION CURRENCY CODE
Def(Th):",
	dh039_trans_amt                          	decimal(12,2) comment "Def(En): TRANSACTION AMOUNT (เรียกเก็บเป็น THB BAHT)
Def(Th):",
	dh039_curr_code                          	string       comment "Def(En): CURRENCY CODE  (สกุลเงินที่เรียกเก็บ ณ ปัจจุบันเป็นเรียกเก็บเป็น THB BAHT) ดังนั้นฟิลด์นี้จึงมีค่าเป็น 764
Def(Th):",
	dh039_trans_dest_amtdh039_retrvl_ref_nbr 	bigint       comment "Def(En): Refference no.
Def(Th):",
	dh039_dest_curr_code                     	string       comment "Def(En): DESTINATION CURRENCY-CODED 
- 764 : ฟิลด์นี้จะมีค่าเป็น 764 เมื่อเป็นรายการจาก EDC Kbank (Source code มีเท่ากับ 'EDC')
- space : ฟิลด์นี้จะมีค่าเป็น space เมื่อไม่ใช่รายการที่ไม่ใช่มาจาก EDC Kbank 
Def(Th):",
	dh039_acq_ref_nbr                        	string       comment "Def(En): Acquire Reference Number
Def(Th):",
	dh039_merch_id                           	integer      comment "Def(En): MERCHARNT ID
Def(Th):",
	dh039_merch_name                         	string       comment "Def(En): MERCHARNT NAME
Def(Th):",
	dh039_merch_city                         	string       comment "Def(En): MERCHARNT-CITY 
Def(Th):",
	dh039_merch_country                      	string       comment "Def(En): MERCHARNT-COUNTRY 
Def(Th):",
	dh039_purc_amt_bht                       	decimal(12,2) comment "Def(En):  PURCHASE AMOUNT (THB BAHT)
Def(Th):",
	dh039_purc_code_bht                      	string       comment "Def(En):  PURCHASE CODE (THB BAHT)
Def(Th):",
	dh039_purc_amt_oth                       	decimal(12,2) comment "Def(En):  PURCHASE AMOUNT OTHER จะมีค่าเท่ากับ TXN-AMT (original transaction amount)
Def(Th):",
	dh039_purc_code_oth                      	string       comment "Def(En):  PURCHASE CODE OTHER จะมีค่าเท่ากับ TXN-CURR-CODE
Def(Th):",
	dh039_purc_date                          	string       comment "Def(En):  PURCHASE DATE
Def(Th):",
	dh039_trans_channel                      	string       comment "Def(En): Transaction Channel
Def(Th):",
	dh039_type_card                          	string       comment "Def(En): Type Card 
Def(Th):",
	dh039_tr_code                            	smallint     comment "Def(En): Transaction code
Def(Th):",
	dh039_merch_cat                          	string       comment "Def(En): MERCHARNT CATEGORY
Def(Th):",
	dh039_random_id                          	string       comment "Def(En): Random ID (encryption card number)
Def(Th):",
	filler                                   	string       comment "Def(En):
Def(Th):",
	load_tms                                 	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                               	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                                 	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                                   	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                                   	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_kb1dh039_ccnd5012' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);