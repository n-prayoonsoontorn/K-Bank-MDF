
#Databricks notebook source
!pip install databricks-sdk==0.12.0

# COMMAND ----------

# MAGIC %md ### Import Libraries

# COMMAND ----------

dbutils.widgets.text("start", "none")
dbutils.widgets.text("end", "none")
dbutils.widgets.text("view_name", "none")

# COMMAND ----------

import requests
import json
import uuid
import os
import base64
import time
from pyspark.sql import SparkSession

# COMMAND ----------
# MAGIC %md ### Environment configs
# COMMAND ----------

env = os.environ['ENVIRONMENT']
catalog = f"mdp{env}" # To be replaced with os.environ["CATALOG"]
print("Environment Information")
print("env:",env)
print("catalog:",catalog)

# COMMAND ----------
# MAGIC %md ### Execution Function
# COMMAND ----------

from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs
from databricks.sdk.service import workspace
        # Get Workspace URL & Token
api_token = (
    dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().getOrElse(None)
)
databricksURL = (
    dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiUrl().getOrElse(None)
)
# Databricks SDK
wspc = WorkspaceClient(host=databricksURL, token=api_token)

print("API token: ", api_token)
print("Databricks URL", databricksURL)
cluster_id = spark.conf.get("spark.databricks.clusterUsageTags.clusterId")

# COMMAND ----------


def get_notebook_content(notebook_path):
  response = requests.get(
    '%s/api/2.0/workspace/export' % (databricksURL),
    headers={'Authorization': 'Bearer %s' % api_token},
    json={
      "path": notebook_path,
      "format": "SOURCE"
    }
  )
  # Validate response code
  response.raise_for_status()
  # Decode notebook content
  data_byte = base64.b64decode(response.json()['content'])
  data = data_byte.decode('utf-8-sig')
  if data[0] != "-":
    raise SystemError("[System Error] Framework expects load scripts to be SQL Notebook")
  return data

def run_notebooks(notebook_path):
    init_files = os.listdir("/Workspace"+notebook_path)
    for filename in init_files:
        content = get_notebook_content(notebook_path + filename)
        content = content.replace("${catalog}", catalog).replace("${env}",env)
        try:
          spark.sql(content)
          print(f"Run {filename}")
        except Exception as e:
          print(f"Error executing notebook {notebook_path}{filename}: {e}")

# COMMAND ----------


def api_run_notebook(notebook_nm,param={}):
    token_id = str(uuid.uuid4())
    response = requests.post(
        '%s/api/2.0/jobs/runs/submit' % (databricksURL),
        headers={'Authorization': 'Bearer %s' % api_token},
        json={
        "run_name": token_id,
        "existing_cluster_id": cluster_id,
        "notebook_task": {
            "notebook_path" :  notebook_nm,
            "base_parameters": param
        },
        "idempotency_token": token_id
        }
    )
    return response
    
def get_notebook_content(notebook_path):
  response = requests.get(
    '%s/api/2.0/workspace/export' % (databricksURL),
    headers={'Authorization': 'Bearer %s' % api_token},
    json={
      "path": notebook_path,
      "format": "SOURCE"
    }
  )
  # Validate response code
  response.raise_for_status()
  # Decode notebook content
  data_byte = base64.b64decode(response.json()['content'])
  data = data_byte.decode('utf-8-sig')
  if data[0] != "-":
    raise SystemError("[System Error] Framework expects load scripts to be SQL Notebook")
  return data.replace("${catalog}", catalog).replace("${env}",env)

def run_notebooks(notebook_path, content, cnt):
    try:
      spark.sql(content)
      print(f"Run #{cnt} {notebook_path}")
    except Exception as e:
      error_log.append([notebook_path, str(e)])
      print(f"Error executing notebook {notebook_path}: {e}")

def runs_get(run_id):
    endpoint = f"{databricksURL}/api/2.0/jobs/runs/get"
    
    headers = {
        "Authorization": f"Bearer {api_token}",
        "Content-Type": "application/json"
    }
    parameters = {
        "run_id": run_id
    }
    
    response = requests.get(endpoint, headers=headers, params=parameters)
    response_json = response.json()
    return response_json["state"]["life_cycle_state"]

# COMMAND ----------
# MAGIC %md # Main
# COMMAND ----------

start = dbutils.widgets.get("start")
end =  dbutils.widgets.get("end")
view_name = dbutils.widgets.get("view_name")
if start == "none" and view_name == "none" and end == "none":
    # main 
    # get all list of path
    raw_files = os.listdir(f"/Workspace/ddl/mdp/table_init/mig_datalake/raw/")
    persist_files = os.listdir(f"/Workspace/ddl/mdp/table_init/mig_datalake/persist/")
    init_files = ["/ddl/mdp/table_init/mig_datalake/raw/" + filename for filename in raw_files] + ["/ddl/mdp/table_init/mig_datalake/persist/" + filename for filename in persist_files]  
    
    # create global temp 2 column (no|path)
    
    spark = SparkSession.builder.appName("session").getOrCreate()
    data = [[index+1, file] for index, file in enumerate(init_files)]
    df = spark.createDataFrame(data, ['no', 'path'])
    df.createOrReplaceGlobalTempView("init_temp_view")
    # spark.sql("select * from global_temp.init_temp_view")
    
    # submit run job - limit 200 init per job
    print(f'Total: {len(init_files)}')
    run_id = []
    for index in range(1, len(init_files)+1, 200):
        print(f'batch: {index} - {index+199}')
        response = api_run_notebook('/script/mdp/post_deployment/mig_datalake/MDP_INGESTION_BSL_0002/execute_init',param={'start':str(index),'end':str(index + 199),'view_name':'init_temp_datalake'})
        run_id.append(response.json()['run_id'])

    print(f'run_id: {run_id}')


    # check status of all jobs every 30 sec
    status = []
    error_log = []
    # log table
    while "PENDING" in status or "RUNNING" in status or len(status) != len(run_id):
        status = []
        time.sleep(30)
        for id in run_id:
            status.append(runs_get(id))
        print(status)
        
    # drop global temp view after all jobs is done
    spark.sql("drop table global_temp.init_temp_view")
    
# COMMAND ----------
# MAGIC %md ### Execute init table
# COMMAND ----------

if start !="none" and view_name !="none" and end !='none':
    #looping from global temp view execute init 
    #select global temp view filter range
    batch = spark.sql(f"select * from global_temp.init_temp_view where no between {start} and {end}").collect()

    
    #looping get content and execute spark.sql
    cnt = 1
    error_log = []
    for row in batch:
        content = get_notebook_content(row['path'])
        run_notebooks(row['path'], content, cnt)
        cnt += 1

    print(start)
    print(end)
    print(view_name)
    


time.sleep(60)

# COMMAND ----------

if error_log:
    df = spark.createDataFrame(error_log, ['path', 'error'])
    df.display()
    
# COMMAND ----------

dbutils.notebook.exit("SUCCESS")

# COMMAND ----------

# MAGIC %md %sql
# MAGIC show tables in mdpuat.raw_datalake
# MAGIC