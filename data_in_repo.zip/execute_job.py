

# COMMAND

# MAGIC  %md
# MAGIC  **Instruction**
# MAGIC   - Trigger run Ingestion workflow with input parameters
# MAGIC   - Summary Result for all ingestion job which be run in this notebook
 
# COMMAND 

# MAGIC  %md # Get environment and Function

# COMMAND 

import os
import requests
import base64
import json
import time
from typing import Dict
from typing import List
from pyspark.sql import Row
from pyspark.sql import DataFrame
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql.types import LongType
from pyspark.sql.types import ArrayType

from databricks.sdk import WorkspaceClient

# COMMAND 

from databricks.sdk import WorkspaceClient
        # Get Workspace URL & Token
api_token = (
    dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().getOrElse(None)
)
databricksURL = (
    dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiUrl().getOrElse(None)
)
# Databricks SDK
w = WorkspaceClient(host=databricksURL, token=api_token)

print("API token: ", api_token)
print("Databricks URL", databricksURL)

# COMMAND 


def get_job_id(job_list: List, name:str)-> str:
    """
    Retrieves the job ID based on the job name from a list of job dictionaries.

    Args:
    - job_list (list): List of dictionaries containing job details.
    - name (str): Name of the job to retrieve the ID.

    Returns:
    - int or None: Job ID associated with the specified name, or None if not found.
    """
    for item in job_list:
        job_dict = item.as_dict()  # Assuming the items in the list have an `as_dict()` method
        if job_dict.get('settings', {}).get('name') == name:
            return job_dict.get('job_id')

def run_databricks_workflow(job_nm: str, pos_dt: str, conf_file_path: str, job_list: List[dict]) -> None:
    """
    Runs a Databricks workflow for a specific job and appends details to a job list.

    Args:
    - job_nm (str): Name of the job.
    - pos_dt (str): Position date.
    - conf_file_path (str): Path to the configuration file.
    - job_list (List[dict]): List containing dictionaries of job details.

    Returns:
    - None
    """
    # Fetch the job ID for 'sit-mdp-framework'
    ingt_job_id = get_job_id(w.jobs.list(), 'mdp-framework')

    # Define Python parameters for the job run
    python_params = [
        "--pos_dt", pos_dt,
        "--config_file_path", conf_file_path,
        "--adb_job_id", "{{job_id}}",
        "--adb_run_id", "{{parent_run_id}}"
    ]

    # Run the job and retrieve the run ID
    resp = w.jobs.run_now(job_id=ingt_job_id, python_params=python_params)
    run_id = resp.response.as_dict()["run_id"]

    # Create a dictionary with job details and append it to the job_list
    job_dict = {"job_name": job_nm, "run_id": run_id, "date": pos_dt}
    job_list.append(job_dict)

    time.sleep(5)

    return job_list

def run_loop_ingt_wf(run_mapping: List[Dict[str, str]]) -> Dict[str, List[str]]:
    """
    Run Databricks workflows for specified jobs and dates.

    Args:
        run_mapping (List[Dict[str, str]]): List of dictionaries containing job information,
            including 'job_name', 'job_config', and 'ingest_spec'.
        dt_list (List[str]): List of dates for which the workflows should be executed.

    Returns:
        Dict[str, List[str]]: Dictionary containing job information and corresponding run statuses.
    """
    job_list = list()
    max_concurrent_runs = 30
    cnt_run = 0

    for mapping in run_mapping:
        job_name = mapping["job_name"]
        job_config = mapping["job_config"]
        pos_dt = mapping["pos_dt"]

        job_list = run_databricks_workflow(job_name, pos_dt, job_config, job_list)
        cnt_run += 1
        if cnt_run == max_concurrent_runs:
            time.sleep(1200)
            cnt_run = 0

    return job_list

def get_all_job_status(job_st_lst: List[Dict]) -> DataFrame:
    """
    Retrieves the status of multiple jobs and returns a PySpark DataFrame.

    Args:
        job_st_lst (List[Dict]): List of dictionaries containing job information.

    Returns:
        DataFrame: PySpark DataFrame with selected columns.
    """
    expt_clmn = ["job_name", "run_id", "date", "job_status", "input_param", "run_page_url"]

    for index, job_info in enumerate(job_st_lst):
        if job_info.get("job_status",None) == None:
            run_id = job_info["run_id"]
            rslt_json = w.jobs.get_run(run_id).as_dict()
            rslt_st = rslt_json["state"].get("result_state",None)
            inpt_parm = rslt_json["overriding_parameters"]["python_params"]
            run_page_url = rslt_json["run_page_url"]
            job_st_lst[index]["job_status"] = rslt_st
            job_st_lst[index]["input_param"] = inpt_parm
            job_st_lst[index]["run_page_url"] = run_page_url

    # Define the schema for the DataFrame
    schema = StructType([
    StructField("job_name", StringType(), True),
    StructField("run_id", LongType(), True),
    StructField("date", StringType(), True),
    StructField("job_status", StringType(), True),
    StructField("input_param", ArrayType(StringType()), True),
    StructField("run_page_url", StringType(), True)
])
    df = spark.createDataFrame(job_st_lst,schema)
    df = df.select(*expt_clmn)
    return df

# COMMAND 

env = os.environ["ENVIRONMENT"]
catalog = f"mdp{env}" # To be replaced with os.environ["CATALOG"]
print("Environment Inforamation")
print("env:",env)
print("catalog:",catalog)

# COMMAND 

# MAGIC %md # Job lists
# table_list_rdm = ['rdm_cst_ip_lgl_stc_tp_cd',
# 'rdm_cst_nat_cd',
# 'rdm_cst_mar_st_cd',
# 'rdm_cst_ctf_tp_cd',
# 'rdm_cst_ocp_cd',
# 'rdm_cst_prof_cd',
# 'rdm_cst_idv_incm_seg_cd',
# 'rdm_cst_seg_cd',
# 'rdm_card_tp_cd',
# 'rdm_pim_coa_pd',
# 'rdm_idy_cl_cd',
# 'rdm_idy_cl_sub_grp_cd'
# ]

# COMMAND 

run_mapping_1 = [
    {'job_name': 'ingest_cis_ipxar_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ipxar_d.json'},
    {'job_name': 'ingest_cis_ip_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ip_d.json'},
    {'job_name': 'ingest_cis_ar_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ar_d.json'},
    {'job_name': 'ingest_cis_relar_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_relar_d.json'},
    {'job_name': 'ingest_cis_doctp_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_doctp_d.json'},
    {'job_name': 'ingest_cis_cntreltp_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_cntreltp_d.json'},
    {'job_name': 'ingest_cis_ipxcontact_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ipxcontact_d.json'},
    {'job_name': 'ingest_cis_conttp_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_conttp_d.json'},
    {'job_name': 'ingest_cis_continfo_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_continfo_d.json'},
    {'job_name': 'ingest_cis_idv_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_idv_d.json'},
    {'job_name': 'ingest_cis_org_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_org_d.json'},
    {'job_name': 'ingest_cis_ipsegment_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ipsegment_d.json'},
    {'job_name': 'ingest_cis_histsegm_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_histsegm_d.json'},
    {'job_name': 'ingest_cis_addr_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_addr_d.json'},
    {'job_name': 'ingest_cis_ipxaddr_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ipxaddr_d.json'},
    {'job_name': 'ingest_cis_dntcnt_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_dntcnt_d.json'},
    {'job_name': 'ingest_cis_othdoc_d', 'pos_dt': '2024-02-13', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_othdoc_d.json'},
    {'job_name': 'ingest_cis_ipxar_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ipxar_d.json'},
    {'job_name': 'ingest_cis_ip_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ip_d.json'},
    {'job_name': 'ingest_cis_ar_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ar_d.json'},
    {'job_name': 'ingest_cis_relar_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_relar_d.json'},
    {'job_name': 'ingest_cis_doctp_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_doctp_d.json'},
    {'job_name': 'ingest_cis_cntreltp_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_cntreltp_d.json'},
    {'job_name': 'ingest_cis_ipxcontact_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ipxcontact_d.json'},
    {'job_name': 'ingest_cis_conttp_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_conttp_d.json'},
    {'job_name': 'ingest_cis_continfo_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_continfo_d.json'},
    {'job_name': 'ingest_cis_idv_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_idv_d.json'},
    {'job_name': 'ingest_cis_org_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_org_d.json'},
    {'job_name': 'ingest_cis_ipsegment_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ipsegment_d.json'},
    {'job_name': 'ingest_cis_histsegm_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_histsegm_d.json'},
    {'job_name': 'ingest_cis_addr_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_addr_d.json'},
    {'job_name': 'ingest_cis_ipxaddr_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ipxaddr_d.json'},
    {'job_name': 'ingest_cis_dntcnt_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_dntcnt_d.json'},
    {'job_name': 'ingest_cis_othdoc_d', 'pos_dt': '2024-02-14', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_othdoc_d.json'},
    {'job_name': 'ingest_cis_ipxar_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ipxar_d.json'},
    {'job_name': 'ingest_cis_ip_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ip_d.json'},
    {'job_name': 'ingest_cis_ar_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ar_d.json'},
    {'job_name': 'ingest_cis_relar_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_relar_d.json'},
    {'job_name': 'ingest_cis_doctp_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_doctp_d.json'},
    {'job_name': 'ingest_cis_cntreltp_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_cntreltp_d.json'},
    {'job_name': 'ingest_cis_ipxcontact_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ipxcontact_d.json'},
    {'job_name': 'ingest_cis_conttp_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_conttp_d.json'},
    {'job_name': 'ingest_cis_continfo_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_continfo_d.json'},
    {'job_name': 'ingest_cis_idv_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_idv_d.json'},
    {'job_name': 'ingest_cis_org_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_org_d.json'},
    {'job_name': 'ingest_cis_ipsegment_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ipsegment_d.json'},
    {'job_name': 'ingest_cis_histsegm_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_histsegm_d.json'},
    {'job_name': 'ingest_cis_addr_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_addr_d.json'},
    {'job_name': 'ingest_cis_ipxaddr_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_ipxaddr_d.json'},
    {'job_name': 'ingest_cis_dntcnt_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_dntcnt_d.json'},
    {'job_name': 'ingest_cis_othdoc_d', 'pos_dt': '2024-02-15', 'job_config': f'/Volumes/mdp{env}/artifact/config/mdp/ingest/cis/job_config_ingest_cis_othdoc_d.json'}
]

# COMMAND 

# MAGIC %md # Execute job run

# COMMAND 

# MAGIC %md job_st_lst_1 = run_loop_ingt_wf(run_mapping_1)

# COMMAND

# MAGIC %md # Get all job status

# COMMAND

st_df_1 = get_all_job_status(job_st_lst_1)
st_df_1.display()

# COMMAND

# MAGIC %md # Get failed job status
st_df_1.filter("job_status='FAILED'").display()