-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_gcp_pir_detail_txn.sql
# Area: gcp
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-20   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_GCP.GCP_PIR_DETAIL_TXN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_gcp.gcp_pir_detail_txn (
	pos_dt                      	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	pir_nmbr                    	string       comment "Def(En): primary key (batch reference no) to link to PIR_HEADER_TXN
Def(Th): ใช้เป็น key เพื่อ link ไป table PIR_HEADER_TXN",
	internal_txn_nmbr           	string       comment "Def(En): running number for instrument
Def(Th):",
	instrument_code             	string       comment "Def(En): define group of product
( PO = Cheque / FT = Fund Trasfers / LW = Smart,Bahtnet)
Def(Th): กลุ่มของผลิตภัณฑ์",
	payment_type                	string       comment "Def(En): 
Def(Th):",
	principal_amnt              	decimal(20,4) comment "Def(En): Total amount that bank deduct from client ( include charge amount, if
charge beneficiary ; PRINCIPAL_AMNT = CHARGES_AMNT + INSTRUMENT_AMNT
charge client ; PRINCIPAL_AMNT = INSTRUMENT_AMNT)
Def(Th): ยอดเงินทั้งหมดที่หักจากลูกค้า (รวมค่า charge)",
	charges_amnt                	decimal(20,4) comment "Def(En): Def(En): Charge Amount
Def(Th): ยอดเงิน charge",
	instrument_amnt             	decimal(20,4) comment "Def(En): Def(En): Instrument Amount
Def(Th): ยอดเงินที่ทำรายการ (หักค่า charge แล้ว)",
	alias_payout_location_code  	string       comment "Def(En): Alias PYOUT Location Code
Def(Th):",
	primary_payout_location_code	string       comment "Def(En): Primary PYOUT Location Code
Def(Th):",
	disp_bank_code              	string       comment "Def(En): Display Bank Number
Def(Th):",
	disp_branch_code            	string       comment "Def(En): Display Branch Number
Def(Th):",
	inst_date                   	date         comment "Def(En): Def(En): Effective Date = Disburse Date
Def(Th): วันที่ปลายทางรับเงิน / วันที่เช็คมีผล",
	benef_code                  	string       comment "Def(En): create txn. By using beneficiary master that client already created (if it's null means this beneficiary be adhoc.)
Def(Th): สร้างรายการโดยการใช้ผู้รับปลายทางที่สร้างเก็บไว้ (ถ้าว่างแสดงว่าเป็น adhoc)",
	benef_description           	string       comment "Def(En): 
Def(Th):",
	benef_bank_code             	string       comment "Def(En): Beneficiary Bank Number
Def(Th):",
	benef_branch_code           	string       comment "Def(En): Beneficiary Branch Number
Def(Th):",
	benef_account_nmbr          	string       comment "Def(En): Def(En): Beneficiary's Account Number
Def(Th): บัญชีผู้รับเงินปลายทาง",
	benef_account_identifier    	string       comment "Def(En): Beneficiary Arrangement Id
Def(Th):",
	benef_add_1                 	string       comment "Def(En): 
Def(Th):",
	benef_add_2                 	string       comment "Def(En): 
Def(Th):",
	benef_add_3                 	string       comment "Def(En): Beneficiary Address 3
Def(Th):",
	benef_add_4                 	string       comment "Def(En): Beneficiary Address 4
Def(Th):",
	benef_add_5                 	string       comment "Def(En): Beneficiary Address 5
Def(Th):",
	benef_payment_details       	string       comment "Def(En): Beneficiary Payment Detail
Def(Th):",
	delivery_mode               	string       comment "Def(En): Deliverability Mode
Def(Th):",
	inst_print_branch_code      	string       comment "Def(En): Instrument Print Branch Number
Def(Th):",
	override_code               	string       comment "Def(En): Override Code
Def(Th):",
	status_flag                 	string       comment "Def(En): Status Flag
Def(Th):",
	maker_code                  	string       comment "Def(En): Maker Id
Def(Th):",
	maker_datetime              	timestamp    comment "Def(En): Maker Stamp Date Time
Def(Th):",
	maker_branch_code           	string       comment "Def(En): Maker Branch Number
Def(Th):",
	checker_code                	string       comment "Def(En): Add New / Update
Def(Th):",
	checker_datetime            	timestamp    comment "Def(En): Checker Stamp Date Time
Def(Th):",
	reject_remarks              	string       comment "Def(En): Reject Remark
Def(Th):",
	inst_status                 	string       comment "Def(En): status of transaction (RD = Ready for download, SG = Schedule Generated)
Def(Th): สถานะของรายการ (RD พร้อมสำหรับ download, SG = ส่ง file ให้ระบบอื่น )
Ex. สมมติเป็น smart ทำรายการเข้ามาจะขึ้นว่า RD พอหักเงินได้เรียบร้อยแล้ว พอถึงเวลาส่งไปให้ระบบ smart จะขึ้นเป็น SG )",
	live_record_key_nmbr        	string       comment "Def(En): only cheque ; when cheque lost, create new cheque by stop with dup. So this field will be running number = 00002 (but new cheque number)
Def(Th): กรณี cheque หาย จะสร้าง cheque ใบใหม่ขึ้นมาให้โดยที่ใบเก่าไม่มีผลแล้ว ดังนั้น field นี้จะเป็น running number = 00002 แต่เลข cheque เป็นเลขใหม่",
	instruction_ref_nmbr        	string       comment "Def(En): Instruction Refer Number
Def(Th):",
	deduct_charges_flag         	string       comment "Def(En): bank deducted charge amount from Client/Beneficiary (N = Client / Y = Beneficiary)
Def(Th): หักค่า charge ที่ใคร (N = ลูกค้า / Y = ปลายทาง)",
	fx_rate                     	decimal(20,7) comment "Def(En): Foreign Exchange Rate
Def(Th):",
	payment_ccy_code            	string       comment "Def(En): Payment Currency Code
Def(Th):",
	payment_priority_flag       	string       comment "Def(En): Payment Priority Flag
Def(Th):",
	bank_bank_info              	string       comment "Def(En): Bank Bank Information
Def(Th):",
	debit_amnt                  	decimal(20,4) comment "Def(En): Debit Amount
Def(Th):",
	gl_status_flag              	string       comment "Def(En): General Ledger Status Flag
Def(Th):",
	gl_maker_code               	string       comment "Def(En): General Ledger Maker Code
Def(Th):",
	gl_maker_datetime           	timestamp    comment "Def(En): General Ledger Maker Date Time
Def(Th):",
	gl_maker_branch_code        	string       comment "Def(En): General Ledger Maker Branch Number
Def(Th):",
	gl_checker_code             	string       comment "Def(En): General Ledger Checker Id
Def(Th):",
	gl_checker_datetime         	timestamp    comment "Def(En): General Ledger Checker Stamp Date Time
Def(Th):",
	gl_reject_remarks           	string       comment "Def(En): General Ledger Reject Remark
Def(Th):",
	lcy_amnt                    	decimal(20,4) comment "Def(En): LCY Amount
Def(Th):",
	micr_nmbr                   	string       comment "Def(En): MICR Number
Def(Th):",
	reference_nmbr              	string       comment "Def(En): Refer Number
Def(Th):",
	lot_nmbr                    	string       comment "Def(En): Lot Number
Def(Th):",
	signatory_code_1            	string       comment "Def(En): Signatories CD1
Def(Th):",
	signatory_code_2            	string       comment "Def(En): Signatories CD2
Def(Th):",
	deal_ref                    	string       comment "Def(En): Deal Refer Number
Def(Th):",
	cnv_inst_amnt               	decimal(20,4) comment "Def(En): Conversion Instrument Amount
Def(Th):",
	cnv_ccy                     	string       comment "Def(En): Conversion Currency Code
Def(Th):",
	retail_acct_no              	string       comment "Def(En): Retail Arrangement Id
Def(Th):",
	retail_acct_branch_code     	string       comment "Def(En): Retail Arrangement Branch Number
Def(Th):",
	retail_acct_ccy_code        	string       comment "Def(En): Retail Arrangement Currency Code
Def(Th):",
	debit_ref_nmbr              	string       comment "Def(En): Debit Refer Number
Def(Th):",
	debit_desc                  	string       comment "Def(En): Debit Description
Def(Th):",
	credit_ref_nmbr             	string       comment "Def(En): Credit Refer Number
Def(Th):",
	credit_desc                 	string       comment "Def(En): Credit Description
Def(Th):",
	invoice_date                	date         comment "Def(En): Invoice Date
Def(Th):",
	benef_id                    	string       comment "Def(En): Beneficiary Id
Def(Th):",
	other_benef_id              	string       comment "Def(En): Other Beneficiary Id
Def(Th):",
	benef_non_resi_indicator    	string       comment "Def(En): Beneficiary Non Resident Indicator Flag
Def(Th):",
	purpose_code_desc           	string       comment "Def(En): Purpose Code Description
Def(Th):",
	by_order_of                 	string       comment "Def(En): By Order Of
Def(Th):",
	payment_ref_invoice_nmbr    	string       comment "Def(En): Payment Refer Invoice Number
Def(Th):",
	co_drawee_branch            	string       comment "Def(En): Company DRWEE Branch Number
Def(Th):",
	co_auth_person_name         	string       comment "Def(En): Company Authorized Person Name
Def(Th):",
	co_auth_person_ic           	string       comment "Def(En): Company Authorized Person IC Code
Def(Th):",
	cms_returned_error_code     	string       comment "Def(En): CMS Return Error Code
Def(Th):",
	cms_returned_reason         	string       comment "Def(En): CMS Return Reason
Def(Th):",
	bank_code_indicator         	string       comment "Def(En): Bank Code Indicator
Def(Th):",
	benef_business_regs         	string       comment "Def(En): Beneficiary Business Register Number
Def(Th):",
	benef_passport_no           	string       comment "Def(En): 
Def(Th):",
	form_p_r_no                 	string       comment "Def(En): Form P R Number
Def(Th):",
	co_mailing_postcode         	bigint       comment "Def(En): Company MAILING Postcode
Def(Th):",
	co_mailing_city             	string       comment "Def(En): Company MAILING City
Def(Th):",
	co_mailing_state            	string       comment "Def(En): Company MAILING State
Def(Th):",
	co_mailing_country          	string       comment "Def(En): Company MAILING Country
Def(Th):",
	co_advice_layout            	string       comment "Def(En): Company Advance LAYOUT
Def(Th):",
	mc_funding_acct_nmbr        	string       comment "Def(En): MC FUNDNG Arrangement Id
Def(Th):",
	addenda_record_layout       	string       comment "Def(En): ADDNDA Record LAYOUT
Def(Th):",
	addenda_record_count        	integer      comment "Def(En): ADDNDA Record Count
Def(Th):",
	co_coll_br                  	string       comment "Def(En): Company Collected Branch Number
Def(Th):",
	cashweb_pir_nmbr            	string       comment "Def(En): Def(En): mean to PHDNUMBER link to PIRHEADER (cash web)
Def(Th): ใช้ link ไป table ของ cash web
Def(Th):",
	fpx_serial_no               	smallint     comment "Def(En): FPX Serial Number
Def(Th):",
	micr_fix_sh_acct_no         	string       comment "Def(En): MICR Fix SH Arrangement Id
Def(Th):",
	pickup_branch_code          	string       comment "Def(En): Pickup Branch Number
Def(Th):",
	exchange_doc_code           	string       comment "Def(En): Exchange Document Code
Def(Th):",
	pickup_date                 	date         comment "Def(En): Pickup Date
Def(Th):",
	pickup_remarks              	string       comment "Def(En): Pickup Remark
Def(Th):",
	delv_point_code             	string       comment "Def(En): Deliverability Point Code
Def(Th):",
	adv_delv_mode               	string       comment "Def(En): Advance Deliverability Mode
Def(Th):",
	wht_req                     	string       comment "Def(En): Withhold Request Flag
Def(Th):",
	shipping_code               	string       comment "Def(En): SHIPPNG Code
Def(Th):",
	collector_code              	string       comment "Def(En): Collector Code
Def(Th):",
	benef_payment_details2      	string       comment "Def(En): Beneficiary Payment DTL2
Def(Th):",
	benef_payment_details3      	string       comment "Def(En): Beneficiary Payment DTL3
Def(Th):",
	benef_payment_details4      	string       comment "Def(En): Beneficiary Payment DTL4
Def(Th):",
	benef_ccy                   	string       comment "Def(En): Beneficiary Currency Code
Def(Th):",
	benef_fax                   	string       comment "Def(En): 
Def(Th):",
	benef_mobile                	string       comment "Def(En): 
Def(Th):",
	benef_email                 	string       comment "Def(En): 
Def(Th):",
	benef_ivr_code              	string       comment "Def(En): Beneficiary IVR Code
Def(Th):",
	mail_to                     	string       comment "Def(En): 
Def(Th):",
	mail_to_address1            	string       comment "Def(En): 
Def(Th):",
	mail_to_address2            	string       comment "Def(En): 
Def(Th):",
	mail_to_address3            	string       comment "Def(En): Mail To ADR3
Def(Th):",
	mail_to_address4            	string       comment "Def(En): Mail To ADR4
Def(Th):",
	pros_status                 	string       comment "Def(En): PROS Status Flag
Def(Th):",
	attempt                     	smallint     comment "Def(En): ATTMPT Flag
Def(Th):",
	gl_req_datetime             	timestamp    comment "Def(En): General Ledger Request Date Time
Def(Th):",
	utr_sr_no                   	string       comment "Def(En): UTR SR Number
Def(Th):",
	coordinator_code            	string       comment "Def(En): Coordinate Code
Def(Th):",
	ifsc_code                   	string       comment "Def(En): IFSC Code
Def(Th):",
	iban                        	string       comment "Def(En): IBAN
Def(Th):",
	rcswiftbiccode              	string       comment "Def(En): RC Society for Worldwide Interbank Telecommunications BIC Code
Def(Th):",
	funding_country             	string       comment "Def(En): FUNDNG Country
Def(Th):",
	bene_cell_nmbr              	string       comment "Def(En): Beneficiary Cell Number
Def(Th):",
	bene_pin_code               	string       comment "Def(En): 
Def(Th):",
	remit_txn_ref_no            	string       comment "Def(En): REMIT Transaction Refer Number
Def(Th):",
	fd_form_sr_nmbr             	string       comment "Def(En): Fixed Deposit Form SR Number
Def(Th):",
	disb_country                	string       comment "Def(En): DISB Country
Def(Th):",
	fd_tenure                   	bigint       comment "Def(En): Fixed Deposit TENURE
Def(Th):",
	bene_phone_nmbr             	string       comment "Def(En): 
Def(Th):",
	seller_code                 	string       comment "Def(En): Seller Code
Def(Th):",
	ratetype                    	string       comment "Def(En): Rate Type Code
Def(Th):",
	debit_payment_amnt_flag     	string       comment "Def(En): Debit Payment Amount Flag
Def(Th):",
	dr_cr_flag                  	string       comment "Def(En): Debit Credit Flag
Def(Th):",
	inst_narration              	string       comment "Def(En): Instrument NARRATION
Def(Th):",
	inter_seller_txn            	string       comment "Def(En): Intermediate Seller Transaction Flag
Def(Th):",
	opposite_seller_code        	string       comment "Def(En): OPPOSTE Seller Code
Def(Th):",
	inter_seller_txn_ref_nmbr   	string       comment "Def(En): Intermediate Seller Transaction Refer Number
Def(Th):",
	op_party_name               	string       comment "Def(En): OP PARTY Name
Def(Th):",
	op_address1                 	string       comment "Def(En): 
Def(Th):",
	op_address2                 	string       comment "Def(En): 
Def(Th):",
	op_address3                 	string       comment "Def(En): OP ADR3
Def(Th):",
	op_address4                 	string       comment "Def(En): OP ADR4
Def(Th):",
	op_tel_nmbr                 	string       comment "Def(En): 
Def(Th):",
	op_fax_nmbr                 	string       comment "Def(En): 
Def(Th):",
	op_email                    	string       comment "Def(En): 
Def(Th):",
	op_contact_person           	string       comment "Def(En): 
Def(Th):",
	op_co_mailing_city          	string       comment "Def(En): OP Company MAILING City
Def(Th):",
	op_co_mailing_state         	string       comment "Def(En): OP Company MAILING State
Def(Th):",
	op_co_mailing_country       	string       comment "Def(En): OP Company MAILING Country
Def(Th):",
	supporting_doc_name         	string       comment "Def(En): Support Document Name
Def(Th):",
	delivery_status             	string       comment "Def(En): Deliverability Status Code
Def(Th):",
	unique_reference_id         	string       comment "Def(En): Unique Refer Id
Def(Th):",
	duplicate_record_ref        	string       comment "Def(En): Duplicate Record Refer Number
Def(Th):",
	cw_myproduct                	string       comment "Def(En): CW MY Product Code
Def(Th):",
	cw_trans_ref                	string       comment "Def(En): CW Transaction Refer Number
Def(Th):",
	signatory_code_3            	string       comment "Def(En): Signatories CD3
Def(Th):",
	corr_bank_type              	string       comment "Def(En): Correct Bank Type Code
Def(Th):",
	corr_bank_details_1         	string       comment "Def(En): Correct Bank DTL1
Def(Th):",
	corr_bank_details_2         	string       comment "Def(En): Correct Bank DTL2
Def(Th):",
	corr_bank_details_3         	string       comment "Def(En): Correct Bank DTL3
Def(Th):",
	corr_bank_details_4         	string       comment "Def(En): Correct Bank DTL4
Def(Th):",
	corr_bank_bic               	string       comment "Def(En): Correct Bank BIC Code
Def(Th):",
	corr_bank_nostro_acc        	string       comment "Def(En): Correct Bank NOSTRO Arrangement Id
Def(Th):",
	intermediary_bank_type      	string       comment "Def(En): Intermediate Bank Type Code
Def(Th):",
	intermediary_bank_details_1 	string       comment "Def(En): Intermediate Bank DTL1
Def(Th):",
	intermediary_bank_details_2 	string       comment "Def(En): Intermediate Bank DTL2
Def(Th):",
	intermediary_bank_details_3 	string       comment "Def(En): Intermediate Bank DTL3
Def(Th):",
	intermediary_bank_details_4 	string       comment "Def(En): Intermediate Bank DTL4
Def(Th):",
	intermediary_bank_bic       	string       comment "Def(En): Intermediate Bank BIC Code
Def(Th):",
	intermediary_bank_nostro_acc	string       comment "Def(En): Intermediate Bank NOSTRO Arrangement Id
Def(Th):",
	sms_lang                    	string       comment "Def(En): SMS Language Code
Def(Th):",
	pickup_location             	string       comment "Def(En): Def(En): pick up location
Def(Th):",
	rule_code                   	string       comment "Def(En): Rule Code
Def(Th):",
	bene_name_in_english        	string       comment "Def(En): 
Def(Th):",
	cmis_parameter              	string       comment "Def(En): product code that can categorize to diff zone / same zone (Ex. DCT/DCU, FTR/FTL, PCT/PCU, ...)
Def(Th): รหัสผลิตภัณฑ์ที่สามารถบอกได้ว่าเป็น diff zone / same zone (ตัวอย่าง DCT/DCU)",
	enrichment_value1           	string       comment "Def(En): ENRICHMNT VAL1
Def(Th):",
	enrichment_value2           	string       comment "Def(En): ENRICHMNT VAL2
Def(Th):",
	enrichment_value3           	string       comment "Def(En): ENRICHMNT VAL3
Def(Th):",
	enrichment_value4           	string       comment "Def(En): ENRICHMNT VAL4
Def(Th):",
	enrichment_value5           	string       comment "Def(En): ENRICHMNT VAL5
Def(Th):",
	kbank_deposit_product_code  	string       comment "Def(En): account type (SA/CA/FIX)
Def(Th): ประเภทของบัญชี (ออมทรัพย์/กระแสรายวัน/ประจำ)",
	merchant_code               	string       comment "Def(En): 
Def(Th):",
	merchant_name               	string       comment "Def(En): 
Def(Th):",
	ref1_value                  	string       comment "Def(En): 
Def(Th):",
	ref2_value                  	string       comment "Def(En): 
Def(Th):",
	ref3_value                  	string       comment "Def(En): 
Def(Th):",
	merchant_id                 	string       comment "Def(En): 
Def(Th):",
	pre_schedule_flag           	string       comment "Def(En): 
Def(Th): Flag ของรายการนั้นๆ ว่า Pre schdule.  ไปแล้วหรือยัง",
	promptpay_type              	string       comment "Def(En): 
Def(Th): แยกชนิดข้อมูลของพร้อมเพย์ว่าเป็น เลขบัตรประชาชน/TaxID หรือ เบอร์มือถือ",
	promptpay_id                	string       comment "Def(En): 
Def(Th): Proxy id ของพร้อมเพย์ (ไม่รวม Actual Account)",
	load_tms                    	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                  	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                    	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                      	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                      	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_gcp/gcp_pir_detail_txn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);