-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_gcp_pir_header_txn.sql
# Area: gcp
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-20   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_GCP.GCP_PIR_HEADER_TXN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_gcp.gcp_pir_header_txn (
	pos_dt                   	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	pir_nmbr                 	string       comment "Def(En): primary key for linking to other table
Def(Th):",
	product_code             	string       comment "Def(En): product code
Def(Th): รหัสผลิตภัณฑ์",
	activation_date          	date         comment "Def(En): Debit Date (deduct money)
Def(Th): วันที่หักเงิน",
	client_code              	string       comment "Def(En): Client Code
Def(Th):",
	arrangement_code         	string       comment "Def(En): D+0 : deduct money today and pay today
 D-1 : deduct money today but pay next day
 D-2 : deduct money today but pay next 2 days
Def(Th): D+0 : หักเงินวันนี้ จ่ายวันนี้
 D-1 : หักเงินวันนี้ จ่ายพรุ่งนี้
 D-2 : หักเงินวันนี้ จ่ายอีก 2 วัน",
	account_name             	string       comment "Def(En): Account Name
Def(Th):",
	account_nmbr             	string       comment "Def(En): Debit Account Number
Def(Th):",
	account_branch           	string       comment "Def(En): Debit Account Branch
Def(Th):",
	client_debit_date        	date         comment "Def(En): Debit Date = Activation Date
Def(Th): วันที่หักเงิน",
	client_disbursement_date 	date         comment "Def(En): Disburse Date = Effective Date
Def(Th): วันที่เข้าเงินให้กับปลายทาง (วันที่รายการมีผล)",
	total_instruments        	integer      comment "Def(En): Total No. of instrument within 1 batch

Def(Th): จำนวน instrument ใน 1 batch",
	total_amnt               	decimal(20,4) comment "Def(En): Total Amount within 1 batch (principle amount that deduct from customer)
Def(Th): ยอดเงินรวม(ที่หักจากลูกค้า)",
	reported_instruments     	integer      comment "Def(En): Report Instrument Number (as Count)
Def(Th):",
	reported_amnt            	decimal(20,4) comment "Def(En): Report Amount
Def(Th):",
	pir_reference_nmbr       	string       comment "Def(En): PHDREFERENCE in PIRHEADER table
Def(Th):",
	pir_date                 	date         comment "Def(En): date to create txn. on cash in 
Def(Th): วันที่สร้างรายการใน cash in",
	entry_date               	date         comment "Def(En): date that send batch from cash web to cash in = PIR_DATE
Def(Th): วันที่ส่ง batch มาที่ cash in (ได้รับการ authorize แล้ว)",
	pay_in_mode              	string       comment "Def(En): Payin Mode
Def(Th):",
	total_inst_released      	integer      comment "Def(En): TOTAL INSTRUMENTS
Def(Th):",
	total_released_amnt      	decimal(20,4) comment "Def(En): TOTAL AMNT
Def(Th):",
	delivery_mode            	string       comment "Def(En): Deliverability Mode
Def(Th):",
	hand_off_date            	date         comment "Def(En): Disbursement date = Effective Date

Def(Th):",
	pir_remarks              	string       comment "Def(En): PIR Remark
Def(Th):",
	batch_nmbr               	string       comment "Def(En): Batch Number
Def(Th):",
	pickup_location          	string       comment "Def(En): pick up location (product = cheque)
Def(Th):",
	pickup_point             	string       comment "Def(En): Pickup Point
Def(Th):",
	upload_source            	string       comment "Def(En): Upload Source
Def(Th):",
	upload_reference_nmbr    	string       comment "Def(En): Upload Refer Number
Def(Th):",
	upload_reject_status_flag	string       comment "Def(En): Upload Reject Status Flag
Def(Th):",
	override_code            	string       comment "Def(En): Override Code
Def(Th):",
	zero_proof_flag          	string       comment "Def(En): Zero PROOF Flag
Def(Th):",
	status_flag              	string       comment "Def(En): Status Flag
Def(Th):",
	maker_code               	string       comment "Def(En): Maker Code
Def(Th):",
	maker_datetime           	timestamp    comment "Def(En): Maker Date Time (Timestamp)
Def(Th):",
	maker_branch_code        	string       comment "Def(En): Maker Branch Number
Def(Th):",
	checker_code             	string       comment "Def(En): Add New / Update
Def(Th):",
	checker_datetime         	timestamp    comment "Def(En): Checker Date Time
Def(Th):",
	reject_remarks           	string       comment "Def(En): Reject Remark
Def(Th):",
	upload_source_type       	string       comment "Def(En): Upload Source Type Code
Def(Th):",
	debit_amnt               	decimal(20,4) comment "Def(En): Debit Amount
Def(Th):",
	payment_category_code    	string       comment "Def(En): Payment Categorization Code
Def(Th):",
	debit_ccy_code           	string       comment "Def(En): Debit Currency Code
Def(Th):",
	payment_priority_flag    	string       comment "Def(En): Payment Priority Flag
Def(Th):",
	fx_rate                  	decimal(20,7) comment "Def(En): Foreign Exchange Rate
Def(Th):",
	debit_released_amnt      	decimal(20,4) comment "Def(En): Debit Release Amount
Def(Th):",
	upload_flag              	string       comment "Def(En): Upload Flag
Def(Th):",
	charge_ccy_level         	string       comment "Def(En): Charge Currency Level Code
Def(Th):",
	charge_acct_nmbr         	string       comment "Def(En): Account Number for charge
Def(Th): บัญชีสำหรับเก็บค่า charge",
	charge_acct_ccy_code     	string       comment "Def(En): Charge Arrangement Currency Code
Def(Th):",
	charge_acct_branch_code  	string       comment "Def(En): Charge Arrangement Branch Number
Def(Th):",
	cnv_pir_amnt             	decimal(20,4) comment "Def(En): Conversion PIR Amount
Def(Th):",
	cnv_ccy                  	string       comment "Def(En): Conversion Currency Code
Def(Th):",
	processing_type          	string       comment "Def(En): Process Type Code
Def(Th):",
	testing_indicator        	string       comment "Def(En): Test Indicator Code
Def(Th):",
	confidential_indicator   	string       comment "Def(En): Confidence Indicator Flag
Def(Th):",
	flexible_simple          	string       comment "Def(En): FLEXBL Simple Code
Def(Th):",
	ude_product_code         	string       comment "Def(En): UDE Product Code
Def(Th):",
	mc_funding_acct_nmbr     	string       comment "Def(En): MC FUNDNG Arrangement Id
Def(Th):",
	mc_funding_branch_code   	string       comment "Def(En): MC FUNDNG Branch Number
Def(Th):",
	mc_funding_acct_ccy_code 	string       comment "Def(En): MC FUNDNG Arrangement Currency Code
Def(Th):",
	phd_pay_mode             	string       comment "Def(En): PHD Pay Mode
Def(Th):",
	cf_payment               	string       comment "Def(En): CF Payment Flag
Def(Th):",
	invoice_int_ref_nmbr     	string       comment "Def(En): Invoice Interest Refer Number
Def(Th):",
	pros_status              	string       comment "Def(En): PROS Status Flag
Def(Th):",
	attempt                  	smallint     comment "Def(En): ATTMPT Code
Def(Th):",
	gl_req_datetime          	timestamp    comment "Def(En): General Ledger Request Date Time (Timestamp)
Def(Th):",
	acct_level_flag          	string       comment "Def(En): Arrangement Level Flag
Def(Th):",
	seller_code              	string       comment "Def(En): Seller Code
Def(Th):",
	pir_narration            	string       comment "Def(En): PIR NARRATION
Def(Th):",
	upload_source_ref        	string       comment "Def(En): uploaded file name 
Def(Th): ชื่อ file ที่ upload",
	cms_returned_error_code  	string       comment "Def(En): CMS Return Error Code
Def(Th):",
	cms_returned_reason      	string       comment "Def(En): CMS Return Reason
Def(Th):",
	gl_status_flag           	string       comment "Def(En): General Ledger Status Flag
Def(Th):",
	gl_maker_code            	string       comment "Def(En): General Ledger Maker Id
Def(Th):",
	gl_maker_datetime        	timestamp    comment "Def(En): General Ledger Maker Stamp Date Time (Timestamp)
Def(Th):",
	gl_maker_branch_code     	string       comment "Def(En): General Ledger Maker Branch Number
Def(Th):",
	gl_checker_code          	string       comment "Def(En): General Ledger Checker Id
Def(Th):",
	gl_checker_datetime      	timestamp    comment "Def(En): General Ledger Checker Stamp Date Time (Timestamp)
Def(Th):",
	gl_reject_remarks        	string       comment "Def(En): General Ledger Reject Remark
Def(Th):",
	pay_channel              	string       comment "Def(En): Pay Channel Code
Def(Th):",
	channel_code             	string       comment "Def(En): Channel Code (Client Upload / Client Entry)
Def(Th):",
	repost_gl_flag           	string       comment "Def(En): Repost General Ledger Flag
Def(Th):",
	gl_repost_type           	string       comment "Def(En): General Ledger Repost Type Code
Def(Th):",
	gl_verify_attempts       	integer      comment "Def(En): General Ledger Verifiable ATTMPT
Def(Th):",
	repost_attempt_completed 	smallint     comment "Def(En): Repost ATTMPT Complete
Def(Th):",
	host_gl_type             	string       comment "Def(En): HOST General Ledger Type Code
Def(Th):",
	bill_pay                 	string       comment "Def(En): Bill Payment Flag
Def(Th):",
	pay_type                 	string       comment "Def(En): 
Def(Th): แยกชนิดข้อมูลของโปรดักพร้อมเพย์และโปรดักที่มีอย่แล้ว",
	load_tms                 	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id               	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                 	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                   	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                   	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_gcp/gcp_pir_header_txn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);