-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_pcb_dep_cls500029.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-21    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_PCB_DEP.PCB_DEP_CLS500029
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_pcb_dep.pcb_dep_cls500029 (
	pos_dt      	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	rec_type    	string        comment "Record Type - This is to indicate the body record type (Detail record)",
	cl_scm_tp_id	string        comment "Def(En):Classification Scheme Type Id",
	cl_scm_id   	string        comment "Def(En):Classification Scheme Id",
	cl_id       	string        comment "Def(En):Classification Id",
	eff_dt      	date          comment "Def(En):Effective Date",
	prn_cl_id   	string        comment "Def(En):Parent Classification Id",
	cl_nm_eng   	string        comment "Def(En):English Classification Name",
	cl_nm_th    	string        comment "Def(En):Thai Classification Name",
	cl_nm_used  	string        comment "Def(En):Name used for Classification",
	sort_seq    	string        comment "Def(En):Sort Sequence",
	arthm_opr   	string        comment "Def(En):Arithmetic Operator",
	own         	string        comment "Def(En):Owner",
	end_dt      	date          comment "Def(En):End Date",
	mn_rng      	string        comment "Def(En):Minimum Range",
	mx_rng      	string        comment "Def(En):Maximum Range",
	load_tms    	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id  	string        comment "Source system ID",
	ptn_yyyy    	string        comment "Partition field - year",
	ptn_mm      	string        comment "Partition field - month",
	ptn_dd      	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_pcb_dep/pcb_dep_cls500029' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);