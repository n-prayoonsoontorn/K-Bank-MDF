-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_ud_privatefund_balance.sql
# Area: ud
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-02-21    Pinyarat C.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_UD.UD_PRIVATEFUND_BALANCE
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_ud.ud_privatefund_balance (
	pos_dt    	date          comment "Business Date or Batch date From Control-M (yyyy-MM-dd)",
	rectype   	string        comment "Type of record, this will be Detail (D01)",
	src_pos_dt	date          comment "Def(En): Position Date (Source)
Def(Th): ยอดวันที่",
	ident_no  	string        comment "Def(En): Identify customer number
Def(Th): เลขที่บัตรประชาชน, เลขที่ passport ของผู้ถือหลักทรัพย์ ๆลๆ",
	otsnd_bal 	decimal(21,2) comment "Def(En):  Balance
Def(Th): ยอดคงเหลือของ Private fund",
	db_ac_no  	string        comment "Def(En):  Settlement account no (Debit)
Def(Th):  บัญชีชำระเงินของลูกค้า ที่ใช้ในการลงทุนโดย KA",
	ka_cst_no 	string        comment "Def(En):  PI number (private fund id) 
Def(Th):  ตัวเลขระบุกอง Private fund ของ KA (PI number)",
	doc_itm_cd	string        comment "Def(En):Code to identify type of document 
Def(Th):ประเภทเอกสารสำคัญ เช่น บัตรประชาชน, หนังสือเดินทาง",
	pv_type   	string        comment "Def(En):  Private Fund Type",
	cont_dt   	date          comment "Def(En): Contract Date
Def(Th): วันเริ่มต้นสัญญา",
	load_tms  	timestamp     comment "Ingestion job date and timestamp",
	src_sys_id	string        comment "Source system ID",
	ptn_yyyy  	string        comment "Partition field - year",
	ptn_mm    	string        comment "Partition field - month",
	ptn_dd    	string        comment "Partition field - day"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_ud/ud_privatefund_balance' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);