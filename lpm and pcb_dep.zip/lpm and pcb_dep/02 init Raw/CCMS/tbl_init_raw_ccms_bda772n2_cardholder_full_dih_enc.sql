-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_ccms_bda772n2_cardholder_full_dih_enc.sql
# Area: ccms
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-08    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CCMS.CCMS_BDA772N2_CARDHOLDER_FULL_DIH_ENC
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_ccms.ccms_bda772n2_cardholder_full_dih_enc (
	pos_dt                   	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	cardrandom               	string       comment "Def(En): CardRandom
Def(Th):",
	cardmasking              	string       comment "Def(En): Card Masking
Def(Th):",
	cardservicetype          	string       comment "Def(En): Type of Card
Def(Th):",
	cardholdername           	string       comment "Def(En): Card owner Name
Def(Th):",
	branchorder              	string       comment "Def(En): 
Def(Th): สาขาที่สั่งบัตร",
	buildcarddate            	string       comment "Def(En): 
Def(Th): วันที่สั่งบัตร gen emboss file",
	cardtype                 	string       comment "Def(En): Card type for set fee
Def(Th):",
	cardstyle                	string       comment "Def(En): Card style
Def(Th):",
	pinmailer                	string       comment "Def(En): 
Def(Th): flag ที่บอกว่าบัตรนี้ต้องทำการพิมพ์ซอง PIN ไหม",
	mbrnum                   	string       comment "Def(En): The member number, or card seq number, for the card. [สามารถใช้บอกได้ว่า มีบัตรเสริมหรือไม่]
Def(Th):",
	cardstatus               	string       comment "Def(En): Status Card
Def(Th):",
	issuedate                	string       comment "Def(En): 
Def(Th): Virtual - วันที่ทำการออกบัตร
Physical - วันที่ทำการผูกบัญชี หรือ activate card (change status from Inactive to Need PIN Change)",
	activedate               	string       comment "Def(En): 
Def(Th): วันที่ลูกค้าทำการ Active Card 
Virtual = issue date
Physical = ลูกค้าเปลี่ยน PIN (Need PIN Change ==> Active status)",
	expireddate              	string       comment "Def(En): ExpiredDate
Def(Th):",
	canceldate               	string       comment "Def(En): 
Def(Th): วันที่ทำการอายัดบัตร",
	canceltime               	string       comment "Def(En): 
Def(Th): เวลาที่ทำการอายัดบัตร",
	cancelbyuserid           	string       comment "Def(En): 
Def(Th): User ID ทีทำการอายัดบัตร",
	badpincount              	string       comment "Def(En): 
Def(Th): จำนวนครั้งที่ใส่ PIN ผิด (EDC)",
	badpinchannel            	string       comment "Def(En): 
Def(Th): Channel ที่ใส่ PIN ผิด",
	resetpincount            	string       comment "Def(En): 
Def(Th): จำนวนครั้งที่ Reset PIN",
	pinoffset                	string       comment "Def(En): 
Def(Th): ใช้ veriry PIN",
	tranind                  	string       comment "Def(En): 
Def(Th): Terminal ID ที่ลุกค้าทำล่าสุด เพื่อ check ว่า ลูกค้าไม่ได้ทำมาซ้ำ",
	transeqnum               	string       comment "Def(En): 
Def(Th): Sequence Number ของ Terminal ID  ที่ลุกค้าทำล่าสุด เพื่อ check ว่า ลูกค้าไม่ได้ทำมาซ้ำ",
	lastmadate               	string       comment "Def(En): Identifies the last file maintenance action on this record
Def(Th):",
	lastmatime               	string       comment "Def(En): Identifies the last file maintenance action on this record
Def(Th):",
	lastmabyusergroup        	string       comment "Def(En): Identifies the last file maintenance action on this record
Def(Th):",
	lastmabyuserid           	string       comment "Def(En): Identifies the last file maintenance action on this record
Def(Th):",
	updatetype               	string       comment "Def(En): UpdateType
Def(Th):",
	totalusecount            	string       comment "Def(En): TotalUseCount
Def(Th):",
	lasttrandate             	string       comment "Def(En): Last transaction date
Def(Th):",
	purchaseregisflag        	string       comment "Def(En): Flag allow purchase goods and service 
Def(Th):",
	purchaselimit            	string       comment "Def(En): 
Def(Th): วงเงินซื้อต่อวัน",
	setpurchaselimitdate     	string       comment "Def(En): 
Def(Th): วันที่ทำการ set วงเงินซื้อ",
	setpurchaselimittime     	string       comment "Def(En): 
Def(Th): เวลาที่ทำการ set วงเงินซื้อ",
	setpurchaselimituserid   	string       comment "Def(En): 
Def(Th): User ID ที่ทำการ set วงเงินซื้อ",
	cashwithdrawlimit        	string       comment "Def(En): 
Def(Th): วงเงินถอนด้วยบัญชีต่อวัน",
	cashadvancelimit         	string       comment "Def(En): 
Def(Th): วงเงินถอนด้วยบัตรเครดิตต่อวัน",
	setwithdrawlimitdate     	string       comment "Def(En): 
Def(Th): วันที่ทำการ set วงเงินถอนด้วยบัญชี",
	setwithdrawlimittime     	string       comment "Def(En): 
Def(Th):เวลาที่ทำการ set วงเงินถอนด้วยบัญชี",
	setwithdrawlimituserid   	string       comment "Def(En): 
Def(Th): User ID ที่ทำการ set วงเงินถอนด้วยบัญชี",
	transferlimit            	string       comment "Def(En): 
Def(Th): วงเงินโอนต่อวัน (ไม่นับรวมการโอนเงินภายในบัตร-Linkage Transfer)",
	settransferlimitdate     	string       comment "Def(En): 
Def(Th): วันที่ทำการ set วงเงินโอน",
	settransferlimittime     	string       comment "Def(En): 
Def(Th): เวลาที่ทำการ set วงเงินโอน",
	settransferlimituserid   	string       comment "Def(En): 
Def(Th): User ID ที่ทำการ set วงเงินโอน",
	purchaseusage            	string       comment "Def(En): 
Def(Th): ยอดใช้จ่ายที่ซื้อสินค้าผ่านเว็บ หรือ เครื่อง EDC ต่อวัน",
	purchasecount            	string       comment "Def(En): 
Def(Th): จำนวนครั้งที่ใช้ซื้อสินค้าผ่านผ่านเว็บ หรือ เครื่อง EDC ต่อวัน",
	purchaselastdate         	string       comment "Def(En): 
Def(Th): วันที่ใช้ซื้อสินค้าผ่านเว็บ หรือ เครื่อง EDC ล่าสุด",
	cashwithdrawusage        	string       comment "Def(En): 
Def(Th): ยอดเงินที่ใช้ถอนเงินด้วยบัญชีต่อวัน",
	cashadvanceusage         	string       comment "Def(En): 
Def(Th): ยอดเงินที่ใช้ถอนเงินด้วยวงเงินบัตรเครดิตต่อวัน",
	cashwithdrawcount        	string       comment "Def(En): 
Def(Th): จำนวนครั้งที่ใช้ถอนเงินด้วยบัญชี",
	cashwithdrawlastdate     	string       comment "Def(En): 
Def(Th): วันที่ใช้ถอนเงินด้วยบัญชีล่าสุด",
	linkagetransferusage     	string       comment "Def(En): 
Def(Th): ยอดจำนวนเงินการโอนเงินภายในบัตรต่อวัน",
	linkagetransfercount     	string       comment "Def(En): 
Def(Th): จำนวนเครั้งการโอนเงินภายในบัตรต่อวัน",
	thirdtransferusage       	string       comment "Def(En): 
Def(Th):ยอดจำนวนเงินการโอนเงินบุคคลที่สามต่อวัน",
	thirdtransfercount       	string       comment "Def(En): 
Def(Th): จำนวนเครั้งการโอนเงินบุคคลที่สามต่อวัน",
	orftusage                	string       comment "Def(En): 
Def(Th): ยอดจำนวนเงินการโอนเงินต่างธนาคารต่อวัน",
	orftcount                	string       comment "Def(En): 
Def(Th): จำนวนเครั้งการโอนเงินต่างธนาคารต่อวัน",
	transferlastdate         	string       comment "Def(En): 
Def(Th): วันที่ทำการโอนเงินต่างธนาคาร หรือ โอนเงินบุคคลที่สาม",
	transferusage            	string       comment "Def(En): 
Def(Th): ยอดจำนวนเงินที่ทำการโอนเงินเงินต่างธนาคาร (ORFTUsage) รวมกับยอดจำนวนเงินที่ทำการโอนเงินบุคคลที่สาม (ThirdTransferUsage)",
	balanceinqcount          	string       comment "Def(En): 
Def(Th): ทำรายการถามยอดต่อวัน",
	pinchangecount           	string       comment "Def(En):
Def(Th): จำนวนการเปลี่ยน PIN",
	interbankfeedate         	string       comment "Def(En): InterbankFeeDate
Def(Th):",
	interbankfeemonthlycount 	string       comment "Def(En): InterbankFeeMonthlyCount
Def(Th):",
	withdrawalfeedate        	string       comment "Def(En): WithdrawalFeeDate
Def(Th):",
	withdrawalfeecount       	string       comment "Def(En): WithdrawalFeeCount
Def(Th):",
	thirdpartyfeedate        	string       comment "Def(En): ThirdPartyFeeDate
Def(Th):",
	thirdpartyfeecount       	string       comment "Def(En): ThirdPartyCount
Def(Th):",
	paymentfeedate           	string       comment "Def(En): PaymentFeeDate
Def(Th):",
	paymentfeecount          	string       comment "Def(En): PaymentFeeCount
Def(Th):",
	atcforchip1              	string       comment "Def(En): Application Transaction Counter for CHIP-CARD 1 (VISA)
Def(Th):",
	atcforchip2              	string       comment "Def(En): Application Transaction Counter for CHIP-CARD 2 (TH-STD)
Def(Th):",
	fallbackallowflag        	string       comment "Def(En): บัตรนี้อนุญาติให้ทำ Fall Back หรือไม่",
	savingaccount            	string       comment "Def(En): Account number
Def(Th):",
	savingaccountbranch      	string       comment "Def(En): Account owner branch
Def(Th):",
	savingaccounttype        	string       comment "Def(En): Account type
Def(Th):",
	currentaccount           	string       comment "Def(En): Account number
Def(Th):",
	currentaccountbranch     	string       comment "Def(En): Account owner branch
Def(Th):",
	currentaccounttype       	string       comment "Def(En): Account type
Def(Th):",
	creditnum                	string       comment "Def(En): Account number
Def(Th):",
	creditbranch             	string       comment "Def(En): Account owner branch
Def(Th):",
	credittype               	string       comment "Def(En): Account type
Def(Th):",
	pendinganuualfeedate     	string       comment "Def(En): 
Def(Th):  วันที่ทำการติด Pending Annual Fee",
	pendingannualfeeflag     	string       comment "Def(En): Annual fee flag
Def(Th):",
	pendingannualfeecount    	string       comment "Def(En): 
Def(Th): จำนวนครั้งที่ติด Annual Fee",
	pendingannualfeeamt      	string       comment "Def(En): 
Def(Th): จำนวนเงินที่ติด Annual Fee",
	entryfee                 	string       comment "Def(En): 
Def(Th): ค่าธรรมเนียมบัตรแรกเข้า",
	firstyearfee             	string       comment "Def(En): 
Def(Th): ค่าธรรมเนียมบัตรปีแรก",
	annualfee                	string       comment "Def(En): 
Def(Th): ค่าธรรมเนียมรายปีของบัตร",
	duedate                  	string       comment "Def(En): 
Def(Th): เดือนปีที่ครบกำหนดการเก็บค่าธรรมเนียมรายปี",
	lastyearfee              	string       comment "Def(En): 
Def(Th): จำนวนเงินค่าธรรมเนียมรายปีของบัตรที่ลูกค้าจ่ายล่าสุด",
	lastyearfeedeductdate    	string       comment "Def(En): 
Def(Th): วันที่จ่ายค่าธรรมเนียมรายปีของบัตรที่ลูกค้าจ่ายล่าสุด",
	refundflag               	string       comment "Def(En): 
Def(Th): Refund flag",
	refundamount             	string       comment "Def(En): 
Def(Th): เงินที่จะทำการ refund",
	refunddate               	string       comment "Def(En): 
Def(Th): วันที่ทำการ refund สำเร็จ",
	refundbyuserid           	string       comment "Def(En): 
Def(Th): User ที่ทำการคืนเงิน",
	staffflag                	string       comment "Def(En): 
Def(Th): บัตรนี้เป็นพนักงานกสิกรไทยหรือไม่",
	useairportloungedate     	string       comment "Def(En): 
Def(Th): วันที่ใข้บริการ Miracle Lounge",
	previousairportloungedate	string       comment "Def(En): 
Def(Th): วันที่ใข้บริการ Miracle Lounge ครั้งที่แล้ว",
	airportloungecount       	string       comment "Def(En): 
Def(Th): จำนวนที่ใช้บริการ Miracle Lounge",
	cardencryptedpb          	string       comment "Def(En): 
Def(Th): เบอร์บัตรที่ทำการ encrypted ด้วย Random Key",
	filler                   	string       comment "Def(En): 
Def(Th):",
	load_tms                 	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id               	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                 	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                   	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                   	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_ccms/ccms_bda772n2_cardholder_full_dih_enc' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);