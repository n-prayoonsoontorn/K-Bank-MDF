-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cis_othdoc.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-08    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CIS.CIS_OTHDOC
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cis.cis_othdoc (
	pos_dt           	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	method           	string       comment "Def(En): Ingestion Method
Def(Th): วิธีการนำเข้า",
	othdoc_ip_id     	string       comment "Def(En): Customer id
Def(Th): เลขที่ลูกค้า",
	othdoc_doc_tp    	string       comment "Def(En): Document Type code
Def(Th): รหัสประเภทเอกสาร",
	othdoc_doc_id    	string       comment "Def(En): Other Document Identification no.
Def(Th): เลขที่เอกสารอื่นๆ",
	othdoc_stat      	string       comment "Def(En): Document status code
Def(Th): รหัสสถานะเอกสาร",
	othdoc_doc_dept  	string       comment "Def(En): Document issuer department
Def(Th): หน่วยงานที่ออกเอกสาร",
	othdoc_doc_iss_dt	string       comment "Def(En): Document issue date
Def(Th): วันที่ออกเอกสาร",
	othdoc_doc_exp_dt	string       comment "Def(En): Document expire date
Def(Th): วันที่เอกสารหมดอายุ",
	othdoc_user_id   	string       comment "Def(En): User id
Def(Th): รหัสผู้ทำรายการ",
	othdoc_upd_dt    	string       comment "Def(En): Update date time
Def(Th): วันและเวลาที่ทำรายการ",
	load_tms         	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id       	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy         	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm           	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd           	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cis/cis_othdoc' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);