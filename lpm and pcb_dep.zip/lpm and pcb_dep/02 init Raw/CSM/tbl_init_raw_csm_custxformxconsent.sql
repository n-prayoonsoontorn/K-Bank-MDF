-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_csm_custxformxconsent.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-08    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CSM.CSM_CUSTXFORMXCONSENT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_csm.csm_custxformxconsent (
	pos_dt                  	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	custfc_cust_id          	string       comment "Def(En): Cust ID (CIS ID)
Def(Th): เลขที่ลูกค้า (CIS ID)",
	custfc_form_id          	string       comment "Def(En): Form ID
Def(Th): เลขที่ฟอร์มสำหรับกรอก consent",
	custfc_consent_eff_date 	string       comment "Def(En):Effective date
Def(Th):วันที่ให้ consent",
	custfc_consent_exp_date 	string       comment "Def(En):Expire date
Def(Th):วันที่สิ้นสุดค่า consent",
	custfc_re_consent_date  	string       comment "Def(En):Reconsent date
Def(Th):วันที่ต้องถาม consent ใหม่",
	custfc_channel_cd       	string       comment "Def(En):Channel code
Def(Th):ช่องทางที่ให้ consent",
	custfc_originate_product	string       comment "Def(En):Originate product
Def(Th):product ที่ทำรายการที่ให้ consent",
	custfc_evidence_url     	string       comment "Def(En):Evidence URL
Def(Th):URL รูปภาพหลักฐานการให้ consent",
	custfc_consent_flag     	string       comment "Def(En):Consent flag
Def(Th):ค่า consent ที่ลูกค้าให้",
	custfc_upd_user         	string       comment "Def(En):Update by UserID
Def(Th):user ที่แก้ไขข้อมูล",
	custfc_upd_user_name    	string       comment "Def(En):Update by User name
Def(Th):ชื่อ-นามสกุล ของ user
(No value in phase1)",
	custfc_upd_user_deptcd  	string       comment "Def(En):Department code of user
Def(Th):รหัสหน่วยงานหรือสาขาของ user ที่ทำรายการ",
	custfc_upd_user_deptnm  	string       comment "Def(En):Department name of user
Def(Th):ชื่อหน่วยงานของ user ที่ทำรายการ
(No value in phase1)",
	custfc_upd_dt           	string       comment "Def(En):Update date
Def(Th):วันที่อัพเดทข้อมูล",
	load_tms                	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id              	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                  	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                  	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_csm/csm_custxformxconsent' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);