-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_csm_formxappr.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-08    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CSM.CSM_FORMXAPPR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_csm.csm_formxappr (
	pos_dt             	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	formappr_cd        	string       comment "Def(En): Form APPR ID
Def(Th): รหัสของวัตถุประสงค์ของฟอร์มสำหรับใส่ระดับ derived",
	formappr_form_id   	string       comment "Def(En):Form ID
Def(Th):เลขที่ของ Form",
	formappr_apprgrp_cd	string       comment "Def(En):APPR group code
Def(Th):รหัสกลุ่มของวัตถุประสงค์",
	formappr_action_cd 	string       comment "Def(En):Action code
Def(Th):เลขที่ action",
	formappr_purpose_cd	string       comment "Def(En):Purpose code
Def(Th):เลขที่ purpose",
	formappr_prod_cd   	string       comment "Def(En):Product code
Def(Th):เลขที่ product",
	formappr_recvtp_cd 	string       comment "Def(En):Receiver type code
Def(Th):เลขที่ receiver type",
	formappr_company_cd	string       comment "Def(En):Company code
Def(Th):เลขที่ company (receiver)",
	formappr_upd_user  	string       comment "Def(En):Update by UserID
Def(Th):user ที่แก้ไขข้อมูล",
	formappr_upd_dt    	string       comment "Def(En):Update date
Def(Th):วันที่อัพเดทข้อมูล",
	load_tms           	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id         	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy           	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm             	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd             	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_csm/csm_formxappr' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);