-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cardlink_kb1dh001_cp1t170_02.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK.CARDLINK_KB1DH001_CP1T170_02
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink.cardlink_kb1dh001_cp1t170_02 (
	pos_dt                         	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh001_pt_record_seq_t          	string       comment "Def(En): Record sequence transaction
Def(Th):",
	dh001_pt_cust_nmbr_t           	string       comment "Def(En): Customer number Transaction
Def(Th):",
	dh001_pt_card_type_t           	string       comment "Def(En): Card type transaction
Def(Th):",
	dh001_pt_basic_or_supp_t       	string       comment "Def(En): Basic or supplement card
Def(Th):",
	dh001_pt_card_nmbr_t           	string       comment "Def(En): Card number of transaction
Def(Th):",
	dh001_pt_branch_nmbr_t         	string       comment "Def(En): Branch number of transaction
Def(Th):",
	dh001_pt_cr_zip_code_t         	string       comment "Def(En): Zip code of transaction
Def(Th):",
	dh001_pt_principle_staff_flag_t	string       comment "Def(En): Staff flag of transaction
Def(Th):",
	dh001_pt_trans_addr            	string       comment "Def(En): Transaction number (value from CPSTRN)
Def(Th):",
	dh001_pt_effective_dte         	string       comment "Def(En): Effective date (Transaction date)
Def(Th):",
	dh001_pt_code                  	string       comment "Def(En): Transaction code
Def(Th):",
	dh001_pt_amnt                  	string       comment "Def(En): transaciton amount
Def(Th):",
	dh001_pt_posting_dte           	string       comment "Def(En): Posting date
Def(Th):",
	dh001_pt_source_code           	string       comment "Def(En): Source of input transaction
Def(Th):",
	dh001_pt_dba_name              	string       comment "Def(En): Merchant or DBA name
Def(Th):",
	dh001_pt_dba_city              	string       comment "Def(En): Merchant or DBA City
Def(Th):",
	dh001_pt_dba_country           	string       comment "Def(En): Merchant or DBA Country
Def(Th):",
	dh001_pt_acq_ref_nbr           	string       comment "Def(En): Referance number of transaction
Def(Th):",
	dh001_pt_ahf_orig_curr_code    	string       comment "Def(En): Original currency code
Def(Th):",
	dh001_pt_ahf_orig_curr_amt     	string       comment "Def(En): Original currency amount
Def(Th):",
	dh001_pt_sort_stmt_dte_t       	string       comment "Def(En): Statement date
Def(Th):",
	dh001_pt_sort_flag_t           	string       comment "Def(En): sort flag 
Def(Th):",
	filler                         	string       comment "Def(En): 
Def(Th):",
	load_tms                       	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                     	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                       	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                         	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                         	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink/cardlink_kb1dh001_cp1t170_02' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);