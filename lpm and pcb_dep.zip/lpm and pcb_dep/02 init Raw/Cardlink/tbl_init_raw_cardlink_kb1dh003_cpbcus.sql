-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cardlink_kb1dh003_cpbcus.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK.CARDLINK_KB1DH003_CPBCUS
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink.cardlink_kb1dh003_cpbcus (
	pos_dt                    	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh003_org_nbr             	string       comment "Def(En): Orgnization number 
Def(Th):",
	dh003_acct_nbr            	string       comment "Def(En): Customer number
Def(Th):",
	dh003_status              	string       comment "Def(En): Customer Status 
Def(Th):",
	dh003_short_name          	string       comment "Def(En): Customer Short Name 
Def(Th):",
	dh003_co_owner            	string       comment "Def(En): CO-owner name
Def(Th):",
	dh003_zip_code            	string       comment "Def(En): Post code
Def(Th):",
	dh003_crlimit             	string       comment "Def(En): Customer Credit Limit 
Def(Th):",
	dh003_smsa                	string       comment "Def(En): Standard Metropolitan Static Area
Def(Th):",
	dh003_census_tract        	string       comment "Def(En): Census tract number 
Def(Th):",
	dh003_tax_id_type         	string       comment "Def(En): Tax Type 
Def(Th):",
	dh003_tax_id_nmbr         	string       comment "Def(En): 
Def(Th): ถ้าตำแหน่งแรกของ Customer no. ขึ้นต้นด้วย 1 หรือ 5 ให้หยิบ หมายเลขบัตรประชาชน จากฟิลด์ 1DH003-TAX-ID-NMBR หรือ 1DH003-GOVERNMENT-ID-KB  
ทั้งนี้ในระบบ CardLink ทั้ง 2 ฟิลด์ redefines กัน ดังนั้น 1DH003-GOVERNMENT-ID-KB จะมีข้อมูลเหมือนกับ 1DH003-TAX-ID-NMBR",
	dh003_government_id_kb    	string       comment "Def(En): 
Def(Th): ถ้าตำแหน่งแรกของ Customer no. ขึ้นต้นด้วย 1 หรือ 5 ให้หยิบ หมายเลขบัตรประชาชน จากฟิลด์ 1DH003-TAX-ID-NMBR หรือ 1DH003-GOVERNMENT-ID-KB  
ทั้งนี้ในระบบ CardLink ทั้ง 2 ฟิลด์ redefines กัน ดังนั้น 1DH003-GOVERNMENT-ID-KB จะมีข้อมูลเหมือนกับ 1DH003-TAX-ID-NMBR",
	dh003_co_tax_id_type      	string       comment "Def(En): CO-Tax Type 
Def(Th):",
	dh003_co_tax_id_nmbr      	string       comment "Def(En): 
Def(Th): ถ้าตำแหน่งแรกของ Customer no. ไม่ได้ขึ้นต้นด้วย 1 และ 5 ให้หยิบ หมายเลขบัตรประชาชน จากฟิลด์ 1DH003-CO-TAX-ID-NMBR",
	dh003_dte_birth           	string       comment "Def(En): Customer Birth date 
Def(Th):",
	dh003_co_dte_birth        	string       comment "Def(En): CO-Birth date 
Def(Th):",
	dh003_dte_lst_maint       	string       comment "Def(En): Date Last Maintant 
Def(Th):",
	dh003_home_phone          	string       comment "Def(En): Customer home Phome no
Def(Th):",
	dh003_co_home_phone       	string       comment "Def(En): co-home Phome no
Def(Th):",
	dh003_thai_title_tfb      	string       comment "Def(En): THAI TITLE
Def(Th):",
	dh003_office_phone        	string       comment "Def(En): office  Phone no
Def(Th):",
	dh003_co_office_phone     	string       comment "Def(En): co-office phone
Def(Th):",
	dh003_vat_code            	string       comment "Def(En): VAT code
Def(Th):",
	dh003_government_id_tfb   	string       comment "Def(En): VAT code digits
Def(Th): ข้อมูลของ VAT code จะเก็บอยู่ที่ตำแหน่งที่ 9 ไป 10",
	dh003_off_phone_flag      	string       comment "Def(En): office  Phone flag
0 = Call
1 = Not Call
Def(Th):",
	dh003_co_off_phone_flag   	string       comment "Def(En): CO office phone flag
0 = Call
1 = Not Call
Def(Th):",
	dh003_return_doc_flag_tfb 	string       comment "Def(En): return DOC flag 
Def(Th): Flag การส่ง Statement
0 = ส่ง
3, 5 = ไม่ส่ง",
	dh003_employer            	string       comment "Def(En): EMPLOYER 
Def(Th):",
	dh003_co_employer         	string       comment "Def(En): Co EMPLOYER 
Def(Th): ฟิลด์นี้ เก็บข้อมูล 2 ส่วน
1.อาชีพ/ตำแหน่ง ของลูกค้า   ตำแหน่งที่ 1-20
2.เบอร์โทรศัพท์มือถือ ของลูกค้า ตำแหน่งที่ 21-30",
	dh003_mobile_no           	string       comment "Def(En): mobile no.
Def(Th):",
	dh003_instl_line          	string       comment "Def(En): Instalment credit line 
Def(Th):",
	dh003_cash_line           	string       comment "Def(En): Cash credit line 
Def(Th):",
	dh003_avail_cash          	string       comment "Def(En): available cash 
Def(Th):",
	dh003_foreign_country_ind 	string       comment "Def(En): foreign country ind 
Def(Th):",
	dh003_billing_cycle       	string       comment "Def(En): Billing Cycle control Statement 
Def(Th):",
	dh003_avail_credit        	string       comment "Def(En): available Credit 
Def(Th):",
	dh003_crt_liable_flag     	string       comment "Def(En): liable flag
Def(Th):",
	dh003_addl_usage_01       	string       comment "Def(En): customer additional address fields for statement
Def(Th):",
	dh003_addl_usage_02       	string       comment "Def(En): customer additional address fields for card mailer
Def(Th):",
	dh003_addl_usage_03       	string       comment "Def(En): customer additional address fields for PIN mailer
Def(Th):",
	dh003_addl_usage_04       	string       comment "Def(En): customer additional address fields for collection
Def(Th):",
	dh003_addl_usage_05       	string       comment "Def(En): customer additional address fields for direct mail
Def(Th):",
	dh003_addl_usage_06       	string       comment "Def(En): Determined usage for customer additional address fields.
Def(Th): ปัจจุบันยังไม่มีการใช้ฟิลด์นี้",
	dh003_addl_usage_07       	string       comment "Def(En): Determined usage for customer additional address fields.
Def(Th): ปัจจุบันยังไม่มีการใช้ฟิลด์นี้",
	dh003_addl_usage_08       	string       comment "Def(En): Determined usage for customer additional address fields.
Def(Th): ปัจจุบันยังไม่มีการใช้ฟิลด์นี้",
	dh003_addl_usage_09       	string       comment "Def(En): Determined usage for customer additional address fields.
Def(Th): ปัจจุบันยังไม่มีการใช้ฟิลด์นี้",
	dh003_addl_usage_10       	string       comment "Def(En): Determined usage for customer additional address fields.
Def(Th): ปัจจุบันยังไม่มีการใช้ฟิลด์นี้",
	dh003_addl_usage_11       	string       comment "Def(En): Determined usage for customer additional address fields.
Def(Th): ปัจจุบันยังไม่มีการใช้ฟิลด์นี้",
	dh003_addl_usage_12       	string       comment "Def(En): Determined usage for customer additional address fields.
Def(Th): ปัจจุบันยังไม่มีการใช้ฟิลด์นี้",
	dh003_addl_info_tag       	string       comment "Def(En): additional information flag
Def(Th):",
	dh003_eu_surn             	string       comment "Def(En): Surname
Def(Th):",
	dh003_eu_inits            	string       comment "Def(En): Number of dependant of whom responsible 
Def(Th):",
	dh003_eu_title            	string       comment "Def(En): Title name
Def(Th):",
	dh003_eu_sex              	string       comment "Def(En): sex
Def(Th): 0=หญิง
1=ชาย",
	dh003_eu_behav_score      	string       comment "Def(En): Customer Behavioral Score 
Def(Th):",
	dh003_eu_home_owner       	string       comment "Def(En): Home owner 
Def(Th):",
	dh003_eu_type_of_res      	string       comment "Def(En): Type fo resident 
Def(Th):",
	dh003_eu_per_of_res       	string       comment "Def(En): Period of residence 
Def(Th):",
	dh003_eu_acorn_code       	string       comment "Def(En): acorn code
Def(Th):",
	dh003_eu_lez_code         	string       comment "Def(En): Local Expenditure Zone Code
Def(Th):",
	dh003_eu_bank_acct_ind    	string       comment "Def(En): Bank account indicator
Def(Th):",
	dh003_eu_marital_status   	string       comment "Def(En): Marital status
Def(Th):",
	dh003_eu_nbr_of_deps      	string       comment "Def(En): Number of Dependants
Def(Th):",
	dh003_eu_occpn_code       	string       comment "Def(En): Occupation code
Def(Th):",
	dh003_eu_per_occpn        	string       comment "Def(En): Period of occupation
Def(Th):",
	dh003_eu_customer_class   	string       comment "Def(En): Cutomer Classification
Def(Th):",
	dh003_eu_employer_code    	string       comment "Def(En): Employer code
Def(Th):",
	dh003_eu_direct_mail      	string       comment "Def(En): Direct mail 
Def(Th):",
	dh003_eu_jnt_ownership    	string       comment "Def(En): Customer Name L2
Def(Th):",
	dh003_eu_guarantor        	string       comment "Def(En): A user defined field indicating whether the  customer is suitable to be a considered as a guarantor for third entry.
0 = decision criteria require
1 = Potential guarantor
2 = Existing guarantor
9 = Not recomment to be a quarantor
Def(Th):",
	dh003_crlimit_perm        	string       comment "Def(En): Permanent Credit limit
Def(Th):",
	dh003_crlimit_temp        	string       comment "Def(En): Temporary Credit limit 
Def(Th):",
	dh003_crlimit_temp_eff_dte	string       comment "Def(En): Temp Credit Limit Effective date 
Def(Th):",
	dh003_crlimit_temp_exp_dte	string       comment "Def(En): Temp Credit Limit Exp date     
Def(Th):",
	dh003_avail_instl         	string       comment "Def(En): Available Installment 
Def(Th):",
	dh003_cycle_chg_tfb       	string       comment "Def(En): City 
Def(Th):",
	dh003_var_na_length       	string       comment "Def(En): Variable length
Def(Th):",
	dh003_name_1              	string       comment "Def(En): English name 
Def(Th): เป็นข้อมูลเดียวกันกับ 1DH003-ENG-NAME-TFB",
	dh003_name_2              	string       comment "Def(En): Thai name
Def(Th): เป็นข้อมูลเดียวกันกับ 1DH003-THAI-NAME-TFB position 1 - 30",
	dh003_name_3              	string       comment "Def(En): Thai name
Def(Th):  เป็นข้อมูลเดียวกันกับ 1DH003-THAI-NAME-TFB position 31 -60",
	dh003_addr_1              	string       comment "Def(En): Address 1
Def(Th):  ซึ่งเป็นข้อมูลเดียวกันกับ 1DH003-ADDR-1-TFB positon 1 - 30",
	dh003_addr_2              	string       comment "Def(En): Address 1
Def(Th):  เป็นข้อมูลเดียวกันกับ 1DH003-ADDR-1-TFB positon 31 - 50 บวกกับฟิลด์ CR-ADDR-21-TFB",
	dh003_addl_addr_1         	string       comment "Def(En): additional address 1
Def(Th):",
	dh003_addl_addr_2         	string       comment "Def(En): additional address 1
Def(Th):",
	dh003_addl_addr_3         	string       comment "Def(En): additional address 1
Def(Th):",
	dh003_addl_city           	string       comment "Def(En): additional city
Def(Th):",
	dh003_addl_exp_dte        	string       comment "Def(En): additional expire date
Def(Th):",
	dh003_addl_zip            	string       comment "Def(En): additional zip
Def(Th):",
	dh003_city                	string       comment "Def(En): Kbank Enhance Adddress 22
Def(Th): 1.ไม่ใช่จังหวัด
2.เป็นข้อมูลที่อยู่ ซึ่งเป็นข้อมูลเดียวกันกับฟิลด์ CR-ADDR-22-TFB ที่ตำแหน่งที่ 1 - 28",
	dh003_state               	string       comment "Def(En): 
Def(Th): ไม่ใช่ข้อมูลประเทศ เป็นข้อมูลของที่อยู่ ซึ่งเป็นข้อมูลเดียวกันกับฟิลด์ CR-ADDR-22-TFB ที่ตำแหน่งที่ 29 - 30",
	dh003_memo_1              	string       comment "Def(En): Memo line 1
Def(Th):",
	dh003_memo_2              	string       comment "Def(En): Memo line 2
Def(Th):",
	dh003_eng_name_tfb        	string       comment "Def(En): Kbank Enhance English name
Def(Th):",
	dh003_thai_name_tfb       	string       comment "Def(En): Kbank Enhance Thai name
Def(Th):",
	dh003_addr_1_tfb          	string       comment "Def(En): Kbank Enhance Adddress 1 
Def(Th): ที่อยู่ที่ใช้ในการส่ง statement",
	dh003_addr_21_tfb         	string       comment "Def(En): Kbank Enhance Adddress 21
Def(Th): ที่อยู่ที่ใช้ในการส่ง statement",
	dh003_addr_22_tfb         	string       comment "Def(En): Kbank Enhance Adddress 22
Def(Th):  ที่อยู่ที่ใช้ในการส่ง statement",
	dh003_name_address_01     	string       comment "Def(En): Name address occurs 1 
Def(Th): ข้อมูลที่เป็นชุดเดียวกันกับ Kbank Enhance Address",
	dh003_name_address_02     	string       comment "Def(En): Name address occurs 2
Def(Th): ข้อมูลที่เป็นชุดเดียวกันกับ Kbank Enhance Address",
	dh003_name_address_03     	string       comment "Def(En): Name address occurs 3 
Def(Th): ข้อมูลที่เป็นชุดเดียวกันกับ Kbank Enhance Address",
	dh003_name_address_04     	string       comment "Def(En): Name address occurs 4 
Def(Th): ข้อมูลที่เป็นชุดเดียวกันกับ Kbank Enhance Address",
	dh003_name_address_05     	string       comment "Def(En): Name address occurs 5
Def(Th): ข้อมูลที่เป็นชุดเดียวกันกับ Kbank Enhance Address",
	dh003_name_address_06     	string       comment "Def(En): Name address occurs 6
Def(Th): ข้อมูลที่เป็นชุดเดียวกันกับ Kbank Enhance Address",
	dh003_name_address_07     	string       comment "Def(En): Name address occurs 7
Def(Th): ข้อมูลที่เป็นชุดเดียวกันกับ Kbank Enhance Address",
	dh003_name_address_08     	string       comment "Def(En): Name address occurs 8
Def(Th): ข้อมูลที่เป็นชุดเดียวกันกับ Kbank Enhance Address",
	dh003_name_address_09     	string       comment "Def(En): Name address occurs 9
Def(Th): ข้อมูลที่เป็นชุดเดียวกันกับ Kbank Enhance Address",
	dh003_name_address_10     	string       comment "Def(En): Name address occurs 10
Def(Th): ข้อมูลที่เป็นชุดเดียวกันกับ Kbank Enhance Address",
	dh003_name_address_11     	string       comment "Def(En): Name address occurs 11
Def(Th): ข้อมูลที่เป็นชุดเดียวกันกับ Kbank Enhance Address",
	dh003_memo_line_01        	string       comment "Def(En): Memo line 1 
Def(Th): ข้อมูลชุดเดียวกันกับ 1DH003-MEMO-1",
	dh003_memo_line_02        	string       comment "Def(En): Memo line 2 
Def(Th): ข้อมูลชุดเดียวกันกับ 1DH003-MEMO-2",
	filler                    	string       comment "Def(En):
Def(Th):",
	load_tms                  	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink/cardlink_kb1dh003_cpbcus' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);