-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cardlink_kb1dh005_kbbcrd.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK.CARDLINK_KB1DH005_KBBCRD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink.cardlink_kb1dh005_kbbcrd (
	pos_dt                       	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	1dh005_org_nbr               	string       comment "Def(En): Organization
Def(Th):",
	1dh005_type_nbr              	string       comment "Def(En): TYPE 
Def(Th):",
	1dh005_card_nbr              	string       comment "Def(En): CARD NO 
Def(Th):",
	1dh005_card_appl_scorecrd    	string       comment "Def(En):
Def(Th): CARD APPL SCORECARD
this field send to CC1D289G
โดยคำนวณจากระบบ transaction เช่นคำนวณมาจากเพศ รายได้ ถ้าได้คะแนนดี แสดงว่าใบสมัครผ่าน แต่ไม่ยอมให้แสดงที่หน้าจอ KBIH จะแสดงว่าเป็น 0000",
	1dh005_consent_ltr           	string       comment "Def(En):
Def(Th): Consent Letter Flag มีค่าเป็น 'Y' 'N' เป็น field ที่รับค่ามาจาก transact   จะมา show ที่หน้า screen KBIH ตรง CONSENT LTR FLAG
เนื่องจากมีการส่งต่อให้ DIH ต้องตรวจสอบว่า DIH เอาไปใช้ทำอะไร ปัจจุบันทาง Transact สามารถส่งได้ทั้ง Y และ N โดยพนักงาน transact จะใส่ให้ตามเอกสารที่ประกอบการสมัคร โดยปกติถ้าเป็น 'N ใบสมัครนี้จะไม่ผ่านแต่ต้องไปตรวจสอบว่าบน CLNK สามารถแก้ไขค่านี้ได้โดยตรงหรือไม่",
	1dh005_consent_date          	string       comment "Def(En):
Def(Th): Date of Concent Bureau เป็น field ที่รับค่าจาก transact  จะมา show ที่หน้า screen KBIH ตรง CONSENT BUREAU DT",
	1dh005_terminate_date        	string       comment "Def(En):
Def(Th): TERMINATE-DATE มี program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้ field แต่มี show หน้าจอ KBIH  DEFAULT ค่าเป็น 0) ไปตรวจสอบจากถัง kbbcrd ว่ายังมี record ไหนที่มีข้อมูลหรือไม่",
	1dh005_activate_cd           	string       comment "Def(En):
Def(Th): Branch Code to Receive Card รับค่า field นี้จาก transact และ show ที่หน้า KBIH ตรง activate code
พี่กร แจ้งว่าเดิมอาจจะต้องการจะแยกเป็น acitvate ซึ่งใน V2 มีค่า activate flag อยู่แล้ว
พี่โชคแจ้งปัญหาว่าบัตรยังไม่ activate ยังสามารถใช้ผ่าน CDA, โดยตัว JCB ควรจะตรวจสอบชุดที่ไม่ได้วิ่ง autorize เช่น CDA เราใช้ program control สำหรับบัตร KBANk
และอีกกรณีคือบัตรยังไม่ acitivate แต่ผูกบัญชี SA/CA สามารถถอนเงินจาก SA/CA ได้ จาก ATM ได้",
	1dh005_fee_insur             	string       comment "Def(En):
Def(Th): FEE-INSURANCE FLAG มี program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้ field  แต่ show ที่หน้า KBIH DEFAULT ค่าเป็น 0) 
ทาง BU แจ้งว่าถ้าprogram ไม่ได้นำไปใช้ที่ไหนจริงๆ ก็ให้ยกเลิกค่านี้ไปได้",
	1dh005_fee_ins_pymt_per      	string       comment "Def(En):
Def(Th): FEE-INSURANCE (PERCENT)  มี program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้ field แต่ show ที่หน้า KBIH  ) 
ทาง BU แจ้งว่าถ้าprogram ไม่ได้นำไปใช้ที่ไหนจริงๆ ก็ให้ยกเลิกค่านี้ไปได้",
	1dh005_join_fee_per          	string       comment "Def(En):
Def(Th): JOINING FEE OF CREDIT LIMIT (PERCENT) มี program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้ field  แต่ show ที่หน้า KBIH DEFAULT ค่าเป็น 0) 
ทาง BU แจ้งว่าถ้าprogram ไม่ได้นำไปใช้ที่ไหนจริงๆ ก็ให้ยกเลิกค่านี้ไปได้",
	1dh005_min_join_fee          	string       comment "Def(En):
Def(Th): MINIMUM JOINING FEE   มี program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้ field  แต่ show ที่หน้า KBIH DEFAULT ค่าเป็น 0 ) 
ทาง BU แจ้งว่าถ้าprogram ไม่ได้นำไปใช้ที่ไหนจริงๆ ก็ให้ยกเลิกค่านี้ไปได้",
	1dh005_annual_fee_per        	string       comment "Def(En):
Def(Th): ANNUAL FEE  OF CREDIT LIMIT (PERCENT) มี program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้ field  แต่ show ที่หน้า KBIH )",
	1dh005_min_annaul_fee        	string       comment "Def(En):
Def(Th): MINIMUM ANNUAL FEE   มี program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้ field  แต่ show ที่หน้า KBIH  DEFAULT ค่าเป็น 0 )",
	1dh005_other_fee             	string       comment "Def(En):
Def(Th): OTHER-FEE  มี program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้ field  แต่ show ที่หน้า KBIH DEFAULT ค่าเป็น 0 )",
	1dh005_credit_loss           	string       comment "Def(En):
Def(Th): CREDIT LOSS คือค่า principal (ยอดเงินต้นของ write off) D8563-BASE-AMT หรือ 1D0924-BASE-AMT  (Field นี้ ถูกupdate โดย ข้อมูล write off) และนำมา show ที่หน้า KBIH",
	1dh005_earned_intr           	string       comment "Def(En):
Def(Th): EARNED INTEREST คือค่า reverse interest จาก write off มาจาก D8563-BASE-INT  หรือ 1D0924-BASE-INT    (Field นี้ ถูกupdate โดย ข้อมูล write off) และนำมา show ที่หน้า KBIH",
	1dh005_lst_contract_date     	string       comment "Def(En):
Def(Th): คือค่า CM-FILE-PROC-DTE และจะนำไปใช้ต่อใน โปรแกรมCC1B6307 file   CC1D6307 (field D6307-LST-CONTRACT-DATE)
job cc1j6307 ตรวจสอบว่าส่งไปให้ prob หรือไม่",
	1dh005_shadow_limit_upp      	string       comment "Def(En):
Def(Th): SHADOW-LIMIT-UPPER รับค่าจาก file CC1D6304 (ต้นทางมาจากระบบ PROBE แต่ปัจจุบันไม่ส่งค่านี้มา จึงมีค่าเป็น 0) และ show ที่ KBIH 

ให้ดูว่าใน V2 มีพวก shadow ดูว่าทาง BU คือพี่โชคและพี่ยุ่ง อยากจะใช้ค่านี้ใน V2 หรือยังต้องการจะใช้ probe 
ถ้า clnk มีก็ควรจะใช้บน CLNK",
	1dh005_cash_limit_per        	string       comment "Def(En):
Def(Th): Percent of Cash advance  ดูว่า V2 สามารถมี fucntion นี้ทำเป็น % ได้หรือไม่",
	1dh005_temp_normal_cl        	string       comment "Def(En):
Def(Th): จำนวนเงิน สำหรับ ตรวจสอบการขอวงเงินชั่วคราวกรณีปกติ
พี่โชคสงสัยว่าทางฝ่ายลส (ปัจจุบัน S1 ที่ให้ call center ดูระบบไปหยิบจากที่ไหนไปส่งให้) ใช้ค่านี้ในการดูเพื่อเพิ่ม temp
ควรจะไปปตรวจสอบว่าทาง ลส ใช้ค่าตรงไหนบ้างในการดูเพื่อเพิ่ม temp

ให้ ntt ไปตรวจสอบอีกครั้งว่ามีการนำค่านี้ไปใช้ส่งให้ระบบไหนอีกหรือไม่ และกลับมา confrim ทางพี่โชค พี่อิสพี่จอย เพื่อตัดสินใจอีกครั้ง",
	1dh005_temp_spec_cl          	string       comment "Def(En):
Def(Th): จำนวนเงิน สำหรับ ตรวจสอบการขอวงเงินชั้วคราวกรณีพิเศษ",
	1dh005_acc_perf_ind          	string       comment "Def(En):
Def(Th): ACCOUNT PERFORMANCE IND
ให้หาค่า content ที่เก็บในไฟล์ว่ามีค่าอะไรบ้าง",
	1dh005_acc_risk_grade        	string       comment "Def(En):
Def(Th): ACC-RISK-GRADE : Account Risk Grade
คือ รหัสบอกว่า บัตรใบนี้เป็นลูกค้าดีหรือไม่ เช่น Risk Grace = 4,5 เป็นลูกค้าดี , Risk Grade = 00 คือยังไม่ได้ Define ว่าเป็นลูกค้าดีหรือไม่เพราะเป็นลูกค้าใหม่  ซึ่งฟิลด์นี้จะถูก Update ข้อมูลจากระบบ PROBE",
	1dh005_card_beh_scorecard    	string       comment "Def(En):
Def(Th): CARD BEHAVIOR SCORE : ปัจจุบันมีค่าเป็น 0  (มีแค่ program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้ field นี้)",
	1dh005_shadow_limit_low      	string       comment "Def(En):
Def(Th): SHADOW-LIMIT-LOWER รับค่าจาก file CC1D6304     (ต้นทางมาจากระบบ PROBE แและ show ที่ KBIH",
	1dh005_spare_acc_grd         	string       comment "Def(En):
Def(Th): คือค่า PRFB-SPARE-ACC-GRADEซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE) และนำมา showที่ KBIH",
	1dh005_spare_acc_perf_ind    	string       comment "Def(En):
Def(Th): คือค่า PRFB-SPARE-ACC-PERF-IND ซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE) และนำมา showที่ KBIH",
	1dh005_seg_code_1            	string       comment "Def(En):
Def(Th): คือค่าPRFB-SEGMENTATION-CODE-1ซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE) และนำมา showที่ KBIH",
	1dh005_seg_code_2            	string       comment "Def(En):
Def(Th): คือค่า PRFB-SEGMENTATION-CODE-2 ซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE) และนำมา showที่ KBIH",
	1dh005_seg_code_3            	string       comment "Def(En):
Def(Th): คือค่า PRFB-SEGMENTATION-CODE-3 ซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE) และนำมา showที่ KBIH",
	1dh005_coll_mgmt_code_1      	string       comment "Def(En):
Def(Th): คือค่า PRFB-COLLECTION-MGMT-CODE-1 ซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE) มาshow ที่หน้าจอ KBIH และfield นี้ส่งต่อค่าให้ file CC1D283 (D283-COLL-MGMT-CODE-1) และ CC1D289 (D289-COLL-MGMT-CODE-1 ) และ CC1D289G(D289G-COLL-MGMT-CODE-1) และส่งให้ระบบ LPM",
	1dh005_coll_mgmt_code_2      	string       comment "Def(En):
Def(Th): คือค่า PRFB-COLLECTION-MGMT-CODE-2 ซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE)  มาshow ที่หน้าจอ KBIH และfield นี้ส่งต่อค่าให้ file CC1D283 (D283-COLL-MGMT-CODE-2) และ CC1D289 (D289-COLL-MGMT-CODE-2 ) และ CC1D289G(D289G-COLL-MGMT-CODE-2)  และส่งให้ระบบ LPM",
	1dh005_coll_mgmt_code_3      	string       comment "Def(En):
Def(Th): คือค่า PRFB-COLLECTION-MGMT-CODE-3 ซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE)  มาshow ที่หน้าจอ KBIH และfield นี้ส่งต่อค่าให้ file CC1D283 (D283-COLL-MGMT-CODE-3) และ CC1D289 (D289-COLL-MGMT-CODE-3) และ CC1D289G(D289G-COLL-MGMT-CODE-3)  และส่งให้ระบบ LPM",
	1dh005_mkt1_code_1           	string       comment "Def(En):
Def(Th): คือค่า PRFB-MARKETING-1-CODE-1  ซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE) และ show ที่หน้าจอ KBIH",
	1dh005_mkt1_code_2           	string       comment "Def(En):
Def(Th): คือค่าRFB-MARKETING-1-CODE-2 ซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE) และ show ที่หน้าจอ KBIH",
	1dh005_mkt1_code_3           	string       comment "Def(En):
Def(Th): คือค่า PRFB-MARKETING-1-CODE-3  ซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE) และ show ที่หน้าจอ KBIH",
	1dh005_mkt2_code_1           	string       comment "Def(En):
Def(Th): คือค่า PRFB-MARKETING-2-CODE-1  ซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE) และ show ที่หน้าจอ KBIH",
	1dh005_mkt2_code_2           	string       comment "Def(En):
Def(Th): คือค่า PRFB-MARKETING-2-CODE-2     ซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE) และ show ที่หน้าจอ KBIH",
	1dh005_mkt2_code_3           	string       comment "Def(En):
Def(Th): คือค่า PRFB-MARKETING-2-CODE-3 ซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE) และ show ที่หน้าจอ KBIH",
	1dh005_perm_limi_offer       	string       comment "Def(En):
Def(Th): คือค่าPRFB-LIMIT-PERCENTAGE(percent ของวงเงินถาวรที่สามารถใช้เพิ่มได้) ซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE) ค่านี้ส่งต่อให้ file CPACP.SUCCESS.CONVERT,                     CPACP.SUCCESS.CONVERT.G1,                     CPACP.SUCCESS.CONVERT.G2, CPACP.KB4D9086.SUCCESS.CONVERT.G1,      CPACP.KB4D9086.SUCCESS.CONVERT.G2, CPACP.KB1D9086.PAYWAVE.SUCCESS, CPACP.SUCCESS.CONVERT.ADD.INFINITE, CPACP.SUCCESS.CONVERT.ADD.WISDOM, CPACP.SUCCESS.CONVERT.ADD.PREMIER, CPACP.SUCCESS.CONVERT.KBWD9086, CPACP.SUCCESS.CONVERT.VISA,     CPACP.SUCCESS.CONVERT.MASTER, CPACP.SUCCESS.CONVERT.UPGUPL",
	1dh005_temp_norm_offer       	string       comment "Def(En):
Def(Th): คือค่า PRFB-TEMP-NORMAL-CL-PERC (วงเงินชั่วคราวแบบปกติ) ซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE) ไม่ได้ใช้ใน inhouse",
	1dh005_temp_spec_offer       	string       comment "Def(En):
Def(Th): PRFB-TEMP-SPECIAL-CL-PERC (วงเงินชั่วคราวแบบพิเศษ) ซึ่งรับมาจากระบบ PROBE (FEEDBACK-FILE) ไม่ได้ใช้ใน inhouse",
	1dh005_area                  	string       comment "Def(En):
Def(Th): set ค่าเป็น 01 กับ 02 โดย program CC0B630 โดยดู codition flag ที่อยู่จัดส่งเอกสารและ zip-code (ไม่ได้ใช่ต่อใน inhouse)
ไปดูรายละเอียดการตรวจสอบเงื่อนไขอีกครั้ง และดูว่ามีการนำไปใช้ที่ไหนหรือไม่
เป็นการแสดงว่าเป็นกทม และตจว
ซึ่งให้ทาง NTT ตรวจสอบแล้วไม่พบว่าใช้ที่ไหน จะส่งให้ทาง BU confirm ว่าจะยังคงใช้หรือไม่",
	1dh005_mail_addr             	string       comment "Def(En):
Def(Th): mail Address
ตรวจสอบกับ transact ว่าปัจจุบันมี valueเท่าไหร่
V2 มีค่า temp addr",
	1dh005_card_collect          	string       comment "Def(En):
Def(Th): flag ที่รับ จาก transact  คือค่า                Place to receive Card
'1' - สาขา
'2' - ฝ่ายบัตรเครดิต
'3' - ที่บ้าน
'4' - ที่ทำงาน
'5' - ที่บ้าน(คอนโดฯ)
'6' - ที่ทำงาน/อาคาร
'9' - ฝ่ายสินเชื่อผู้บริโภค และส่งค่าต่อให้ file CC1D1161",
	1dh005_dte_lst_cash_lmt      	string       comment "Def(En): Date of adjust Cash Limit 
Def(Th):",
	1dh005_loyalty_id            	string       comment "Def(En):
Def(Th): คือค่า LOYALIN-CURR-ID จาก file LOYALTY-FILE
ใช้ WRT ของเดิม ปัจจุบันไม่ได้ใช้แล้ว",
	1dh005_csh_provis_bal        	string       comment "Def(En):
Def(Th): CASH PRIVIOS BALANCE  มีแค่ program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้ ) 
ให้ไปตรวจสอบว่ามี value หรือไม่ ใน V2 ให้ไปใช้ตาม standrd  และดูว่าที่ v2 มีแสดงให้เห็นในหน้าจอหรือไม่",
	1dh005_csh_provis_intr       	string       comment "Def(En):
Def(Th): CASH PRIVIOS INTEREST  มีแค่ program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้ )",
	1dh005_csh_neg_provis_bal    	string       comment "Def(En):
Def(Th): CASH NEGATIVE PRIVIOS BALANCE  มีแค่ program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้ )",
	1dh005_csh_neg_provis_intr   	string       comment "Def(En):
Def(Th): CASH NEGATIVE PRIVIOS INTEREST  มีแค่ program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้ )",
	1dh005_csh_neg_antici_bal    	string       comment "Def(En):
Def(Th): มีแค่ program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้ )",
	1dh005_csh_neg_antici_intr   	string       comment "Def(En):
Def(Th): มีแค่ program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้ )",
	1dh005_csh_accrued_intr      	string       comment "Def(En):
Def(Th): CASH ACCRUED INTEREST มีแค่ program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้ CASH ACCREUED INTEREST ที่มาจาก field ของ KBBCRD ใช้ CASH ACCRUED INTEREST ที่มาจาก CPBCRD แทน)",
	1dh005_cash_svc_cur          	string       comment "Def(En):
Def(Th): CASH SERVICE CURR มีแค่ program ที่ extract file kbbcrd ส่งให้ dih เท่านั้นที่ใช้ (ใน inhouse ไม่มีใช้)",
	1dh005_rebate_flag           	string       comment "Def(En):
Def(Th): REBATE FLAG SET ค่าเป็น 'y' หรือ space  ในโปรแกรม CC2B630 condition : KM-TYPE-NBR  =  827  OR  927  OR 937 จะมีค่าเป็น 'Y' นอกนั้น เป็น space",
	1dh005_vip_flag              	string       comment "Def(En):
Def(Th): FLEET CARD VIP FLAG มีค่าเป็น 1 กับ 0                  รับ data จาก HAT FLEETWEB , file KB2D427,  KB1D0427,KB2D0427,KB3D0427,KB4D0427,KB5D0427,KB6D0427,KB7D0427,KBDB0427                     IF  KB2D0427-VIP  =  'VIP'        
    MOVE  '1'  TO  KM-VIP-FLAG    
ELSE                              
    MOVE  '0'  TO  KM-VIP-FLAG    
END-IF.   ส่งค่าใช้ใน file  KB1D0318  (fleet card)",
	1dh005_pin_flag              	string       comment "Def(En):
Def(Th): FLEET CARD  PIN-FLAG ส่งค่าต่อที่ file KB1D0318,CC1D115(D115-FLEET-PIN-FLAG),CC1D116 (D116-FLEET-PIN-FLAG)",
	1dh005_fleet_select_prod     	string       comment "Def(En):
Def(Th): รับข้อมูลจากระบบ มีค่าเป็น 1 กับ 0    รับ data จาก HAT FLEETWEB , file KB2D427,  KB1D0427,KB2D0427,KB3D0427,KB4D0427,KB5D0427,KB6D0427,KB7D0427,KBDB0427        CODITION                                                                                 IF   CARDHWEB-ALL  =  'Y'                    
    MOVE  '0'  TO  KM-FLEET-SELECT-PROD     
ELSE                                        
    MOVE  '1'  TO  KM-FLEET-SELECT-PROD     
END-IF.  แล้วส่งค่าให้ KB1D0318",
	1dh005_fleet_limit_flag      	string       comment "Def(En):
Def(Th): รับข้อมูลจากระบบ มีค่าเป็น 1 กับ 0     รับ data จาก HAT FLEETWEB , file KB2D427,  KB1D0427,KB2D0427,KB3D0427,KB4D0427,KB5D0427,KB6D0427,KB7D0427,KBDB0427     แล้วส่งค่าให้ KB1D0318                                                      condition:                                                               IF  CARDHWEB-UNIT = 'LITRE'                                      MOVE  '1'  TO  KM-FLEET-LIMIT-FLAG 
ELSE                                   
    MOVE  '0'  TO  KM-FLEET-LIMIT-FLAG 
END-IF.",
	1dh005_fleet_limit_per_tran  	string       comment "Def(En):
Def(Th): รับข้อมูลจากระบบ hat CARDHWEB FLEETWEB , file KB2D427,  KB1D0427,KB2D0427,KB3D0427,KB4D0427,KB5D0427,KB6D0427,KB7D0427,KBDB0427 และนำค่ามาส่งต่อให้ KB1D0318",
	1dh005_fleet_limit_per_day   	string       comment "Def(En):
Def(Th): รับข้อมูลจากระบบ hat CARDHWEB FLEETWEB , file KB2D427,  KB1D0427,KB2D0427,KB3D0427,KB4D0427,KB5D0427,KB6D0427,KB7D0427,KBDB0427 และนำค่ามาส่งต่อให้ KB1D0318",
	1dh005_fleet_limit_per_week  	string       comment "Def(En):
Def(Th): รับข้อมูลจากระบบ hat CARDHWEB FLEETWEB , file KB2D427,  KB1D0427,KB2D0427,KB3D0427,KB4D0427,KB5D0427,KB6D0427,KB7D0427,KBDB0427 และนำค่ามาส่งต่อให้ KB1D0318",
	1dh005_fleet_limit_per_month 	string       comment "Def(En):
Def(Th): รับข้อมูลจากระบบ hat CARDHWEB FLEETWEB , file KB2D427,  KB1D0427,KB2D0427,KB3D0427,KB4D0427,KB5D0427,KB6D0427,KB7D0427,KBDB0427 และนำค่ามาส่งต่อให้ KB1D0318",
	1dh005_fleet_usage_in_day    	string       comment "Def(En):
Def(Th): ยอดใช้ fleet card ต่อ วัน",
	1dh005_fleet_usage_in_week   	string       comment "Def(En):
Def(Th): ยอดใช้ fleet card ต่อสัปดาห์",
	1dh005_fleet_usage_in_month  	string       comment "Def(En):
Def(Th): ยอดใช้ fleet card ต่อเดือน",
	1dh005_fleet_previos_odometer	string       comment "Def(En): ODOMETER  PREVIOUS
Def(Th):",
	1dh005_fleet_current_odometer	string       comment "Def(En): ODOMETER  CURRENT
Def(Th):",
	filler                       	string       comment "Def(En):
Def(Th):",
	load_tms                     	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                   	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                     	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                       	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                       	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink/cardlink_kb1dh005_kbbcrd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);