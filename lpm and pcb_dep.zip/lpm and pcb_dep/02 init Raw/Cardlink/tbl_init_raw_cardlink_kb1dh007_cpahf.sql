-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cardlink_kb1dh007_cpahf.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK.CARDLINK_KB1DH007_CPAHF
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink.cardlink_kb1dh007_cpahf (
	pos_dt                   	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh007_d_org              	string       comment "Def(En): Organization
Def(Th):",
	dh007_d_type             	string       comment "Def(En): Card Type
Def(Th):",
	dh007_d_acct             	string       comment "Def(En): Card No.
Def(Th):",
	dh007_d_seq              	string       comment "Def(En): Sequence of Transaction
Def(Th):",
	dh007_d_eff_dte          	string       comment "Def(En): Effective Date
Def(Th):",
	dh007_d_trans_code       	string       comment "Def(En): Transaction Code
Def(Th):",
	dh007_d_amnt             	string       comment "Def(En): Amount
Def(Th):",
	dh007_d_posting_dte      	string       comment "Def(En): Posting Date
Def(Th):",
	dh007_d_source           	string       comment "Def(En): Source of Transaction
Def(Th):",
	dh007_d_reference        	string       comment "Def(En): Reference
Def(Th):",
	dh007_d_merch_category   	string       comment "Def(En): Merchant Category Code
Def(Th):",
	dh007_d_desc             	string       comment "Def(En): Description
Def(Th):",
	dh007_d_merch_state      	string       comment "Def(En): Merchant State
Def(Th):",
	dh007_d_orig_ref_nbr     	string       comment "Def(En): Original reference number
Def(Th):",
	dh007_d_orig_curr_code   	string       comment "Def(En): Original current code
Def(Th):",
	dh007_d_orig_curr_amt    	string       comment "Def(En): Orginal current amount
Def(Th):",
	dh007_d_orig_curr_decimal	string       comment "Def(En): Original current decimal
Def(Th):",
	dh007_d_auth_code        	string       comment "Def(En): Authorization code 
Def(Th):",
	dh007_d_pos_mode         	string       comment "Def(En): POS Entry Mode of original transaction
Def(Th):",
	dh007_d_filler           	string       comment "Def(En): Space
Def(Th):",
	load_tms                 	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id               	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                 	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                   	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                   	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink/cardlink_kb1dh007_cpahf' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);