-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cardlink_kb1dh012_cpcah.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK.CARDLINK_KB1DH012_CPCAH
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink.cardlink_kb1dh012_cpcah (
	pos_dt                        	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh012_acth_org_nmbr           	string       comment "Def(En): ORG Number
Def(Th):",
	dh012_acth_type               	string       comment "Def(En):
Def(Th): Type Number  คือ Type ของบัตรเครดิต",
	dh012_acth_card_nmbr          	string       comment "Def(En): Card Number
Def(Th):",
	dh012_acth_lst_maint          	string       comment "Def(En): Last Maintenance Date
Def(Th):",
	dh012_acth_ctd_tbl_entry      	string       comment "Def(En): Specify which Table Entry to point to for  THE CYCLE-TO-DATE VALUE                            
Def(Th):",
	dh012_acth_stmt_dte_1         	string       comment "Def(En): The Statement Date of January
Def(Th):",
	dh012_acth_stmt_dte_2         	string       comment "Def(En): The Statement Date of February
Def(Th):",
	dh012_acth_stmt_dte_3         	string       comment "Def(En): The Statement Date of March
Def(Th):",
	dh012_acth_stmt_dte_4         	string       comment "Def(En): The Statement Date of April
Def(Th):",
	dh012_acth_stmt_dte_5         	string       comment "Def(En): The Statement Date of May
Def(Th):",
	dh012_acth_stmt_dte_6         	string       comment "Def(En): The Statement Date of June
Def(Th):",
	dh012_acth_stmt_dte_7         	string       comment "Def(En): The Statement Date of July
Def(Th):",
	dh012_acth_stmt_dte_8         	string       comment "Def(En): The Statement Date of August
Def(Th):",
	dh012_acth_stmt_dte_9         	string       comment "Def(En): The Statement Date of September
Def(Th):",
	dh012_acth_stmt_dte_10        	string       comment "Def(En): The Statement Date of October
Def(Th):",
	dh012_acth_stmt_dte_11        	string       comment "Def(En): The Statement Date of November
Def(Th):",
	dh012_acth_stmt_dte_12        	string       comment "Def(En): The Statement Date of December
Def(Th):",
	dh012_acth_nmbr_retail_jan    	string       comment "Def(En): Item Retail of January
Def(Th):",
	dh012_acth_amnt_retail_jan    	string       comment "Def(En): Amount Retail of January
Def(Th):",
	dh012_acth_nmbr_ca_atm_jan    	string       comment "Def(En): Item Cash Advance AT Atm of January
Def(Th):",
	dh012_acth_amnt_ca_atm_jan    	string       comment "Def(En): Amount Cash Advance At Atm of January
Def(Th):",
	dh012_acth_nmbr_ca_man_jan    	string       comment "Def(En): Item Cash Advance AT Counter of January
Def(Th):",
	dh012_acth_amnt_ca_man_jan    	string       comment "Def(En): Amount Cash Advance At Counter of January
Def(Th):",
	dh012_acthr_interest_jan      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of January",
	dh012_acthr_curr_base_rate_jan	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of January",
	dh012_acthr_limit_1_jan       	string       comment "Def(En): Retail Limit1 of January
Def(Th):",
	dh012_acthr_limit_2_jan       	string       comment "Def(En): Retail Limit2 of January
Def(Th):",
	dh012_acthr_rate_2_jan        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of January",
	dh012_acthr_rate_3_jan        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of January",
	dh012_acthr_limit_option_jan  	string       comment "Def(En): Retail Limit Option  of January
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_jan      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of January",
	dh012_acthc_curr_base_rate_jan	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of January",
	dh012_acthc_limit_1_jan       	string       comment "Def(En): Cash Advance Limit1 of January
Def(Th):",
	dh012_acthc_limit_2_jan       	string       comment "Def(En): Cash Advance Limit2 of January
Def(Th):",
	dh012_acthc_rate_2_jan        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of January",
	dh012_acthc_rate_3_jan        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of January",
	dh012_acthc_limit_option_jan  	string       comment "Def(En): Cash Advance Limit Option of January
Def(Th):",
	dh012_acth_nmbr_annual_fee_jan	string       comment "Def(En): Item Annual Fee of January
Def(Th):",
	dh012_acth_amnt_annual_fee_jan	string       comment "Def(En): Amount Annual Fee of January
Def(Th):",
	dh012_acth_nmbr_late_chg_jan  	string       comment "Def(En): Item Late Charge of January
Def(Th):",
	dh012_acth_amnt_late_chg_jan  	string       comment "Def(En): Amount Late Charge of January
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_jan 	string       comment "Def(En): Item Over Limit Fee of January
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_jan 	string       comment "Def(En): Amount Over Limit Fee of January
Def(Th):",
	dh012_acth_nmbr_misc_chg_jan  	string       comment "Def(En): Item Miscellaneous Charge Fee of January
Def(Th):",
	dh012_acth_amnt_misc_chg_jan  	string       comment "Def(En): Amount Miscellaneous Charge Fee of January
Def(Th):",
	dh012_acth_nmbr_svc_chg_jan   	string       comment "Def(En): Item Service Charge Fee of January
Def(Th):",
	dh012_acth_amnt_svc_chg_jan   	string       comment "Def(En): Amount Service Charge Fee of January
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_jan	string       comment "Def(En): Item Cash Advance Per Fee of January
Def(Th):",
	dh012_acth_amnt_ca_per_fee_jan	string       comment "Def(En): Amount Cash Advance Per Fee of January
Def(Th):",
	dh012_acth_amnt_payment_jan   	string       comment "Def(En): Amount Payment of January
Def(Th):",
	dh012_acth_amnt_curr_bal_jan  	string       comment "Def(En): Amount Current Balance as at statement of January
Def(Th):",
	dh012_acth_bb_beg_balance_jan 	string       comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of January
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_jan  	string       comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of January
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_jan    	string       comment "Def(En):
Def(Th): Bonus Bucket Used ?? of January
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_jan   	string       comment "Def(En): Credit Limit  as at statement of January
Def(Th):",
	dh012_acth_avail_credit_jan   	string       comment "Def(En): Avail Credit  as at statement of January
Def(Th):",
	dh012_acth_cash_limit_jan     	string       comment "Def(En): Cash Limit  as at statement of January
Def(Th):",
	dh012_acth_avail_cash_jan     	string       comment "Def(En): Avail Cash  as at statement of January
Def(Th):",
	dh012_acth_nmbr_airline_jan   	string       comment "Def(En): Item Airline of January
Def(Th):",
	dh012_acth_amnt_airline_jan   	string       comment "Def(En): Amount Airline of January
Def(Th):",
	dh012_acth_nmbr_hotel_jan     	string       comment "Def(En): Item Hotel of January
Def(Th):",
	dh012_acth_amnt_hotel_jan     	string       comment "Def(En): Amount Hotel of January
Def(Th):",
	dh012_acth_nmbr_car_rental_jan	string       comment "Def(En): Item Car Rental of January
Def(Th):",
	dh012_acth_amnt_car_rental_jan	string       comment "Def(En): Amount Car Rental of January
Def(Th):",
	dh012_acth_nmbr_restaurant_jan	string       comment "Def(En): Item Restaurant of January
Def(Th):",
	dh012_acth_amnt_restaurant_jan	string       comment "Def(En): Amount Restaurant of January
Def(Th):",
	dh012_acth_nmbr_mail_order_jan	string       comment "Def(En): Item Mail Order of January
Def(Th):",
	dh012_acth_amnt_mail_order_jan	string       comment "Def(En): Amount Mail Order of January
Def(Th):",
	dh012_acth_nmbr_atm_cash_jan  	string       comment "Def(En): Item ATM Cash Advance of January
Def(Th):",
	dh012_acth_amnt_atm_cash_jan  	string       comment "Def(En): Amount ATM Cash Advance of January
Def(Th):",
	dh012_acth_nmbr_man_cash_jan  	string       comment "Def(En): Item Manual Cash Advance At Counter Kbank of January
Def(Th):",
	dh012_acth_amnt_man_cash_jan  	string       comment "Def(En): Amount Manual Cash Advance At Counter Kbank of January
Def(Th):",
	dh012_acth_nmbr_quasi_cash_jan	string       comment "Def(En): Item Quasi Cash Advance ?? of January
กลุ่ม MCC ร้านค้าเสมือนเงินสด
Def(Th):",
	dh012_acth_amnt_quasi_cash_jan	string       comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of January
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_jan   	string       comment "Def(En): Item Other Merchant of January
Def(Th):",
	dh012_acth_amnt_oth_mer_jan   	string       comment "Def(En): Amount Other Merchant of January
Def(Th):",
	dh012_acth_nmbr_retail_feb    	string       comment "Def(En): Item Retail of Febuary
Def(Th):",
	dh012_acth_amnt_retail_feb    	string       comment "Def(En): Amount Retail of Febuary
Def(Th):",
	dh012_acth_nmbr_ca_atm_feb    	string       comment "Def(En): Item Cash Advance AT Atm of Febuary
Def(Th):",
	dh012_acth_amnt_ca_atm_feb    	string       comment "Def(En): Amount Cash Advance At Atm of Febuary
Def(Th):",
	dh012_acth_nmbr_ca_man_feb    	string       comment "Def(En): Item Cash Advance AT Counter of Febuary
Def(Th):",
	dh012_acth_amnt_ca_man_feb    	string       comment "Def(En): Amount Cash Advance At Counter of Febuary
Def(Th):",
	dh012_acthr_interest_feb      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of Febuary",
	dh012_acthr_curr_base_rate_feb	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of Febuary",
	dh012_acthr_limit_1_feb       	string       comment "Def(En): Retail Limit1 of Febuary
Def(Th):",
	dh012_acthr_limit_2_feb       	string       comment "Def(En): Retail Limit2 of Febuary
Def(Th):",
	dh012_acthr_rate_2_feb        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of Febuary",
	dh012_acthr_rate_3_feb        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of Febuary",
	dh012_acthr_limit_option_feb  	string       comment "Def(En): Retail Limit Option  of Febuary
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_feb      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of Febuary",
	dh012_acthc_curr_base_rate_feb	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of Febuary",
	dh012_acthc_limit_1_feb       	string       comment "Def(En): Cash Advance Limit1 of Febuary
Def(Th):",
	dh012_acthc_limit_2_feb       	string       comment "Def(En): Cash Advance Limit2 of Febuary
Def(Th):",
	dh012_acthc_rate_2_feb        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of Febuary",
	dh012_acthc_rate_3_feb        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of Febuary",
	dh012_acthc_limit_option_feb  	string       comment "Def(En): Cash Advance Limit Option of Febuary
Def(Th):",
	dh012_acth_nmbr_annual_fee_feb	string       comment "Def(En): Item Annual Fee of Febuary
Def(Th):",
	dh012_acth_amnt_annual_fee_feb	string       comment "Def(En): Amount Annual Fee of Febuary
Def(Th):",
	dh012_acth_nmbr_late_chg_feb  	string       comment "Def(En): Item Late Charge of Febuary
Def(Th):",
	dh012_acth_amnt_late_chg_feb  	string       comment "Def(En): Amount Late Charge of Febuary
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_feb 	string       comment "Def(En): Item Over Limit Fee of Febuary
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_feb 	string       comment "Def(En): Amount Over Limit Fee of Febuary
Def(Th):",
	dh012_acth_nmbr_misc_chg_feb  	string       comment "Def(En): Item Miscellaneous Charge Fee of Febuary
Def(Th):",
	dh012_acth_amnt_misc_chg_feb  	string       comment "Def(En): Amount Miscellaneous Charge Fee of Febuary
Def(Th):",
	dh012_acth_nmbr_svc_chg_feb   	string       comment "Def(En): Item Service Charge Fee of Febuary
Def(Th):",
	dh012_acth_amnt_svc_chg_feb   	string       comment "Def(En): Amount Service Charge Fee of Febuary
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_feb	string       comment "Def(En): Item Cash Advance Per Fee of Febuary
Def(Th):",
	dh012_acth_amnt_ca_per_fee_feb	string       comment "Def(En): Amount Cash Advance Per Fee of Febuary
Def(Th):",
	dh012_acth_amnt_payment_feb   	string       comment "Def(En): Amount Payment of Febuary
Def(Th):",
	dh012_acth_amnt_curr_bal_feb  	string       comment "Def(En): Amount Current Balance as at statement of Febuary
Def(Th):",
	dh012_acth_bb_beg_balance_feb 	string       comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of Febuary
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_feb  	string       comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of Febuary
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_feb    	string       comment "Def(En):
Def(Th): Bonus Bucket Used ?? of Febuary
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_feb   	string       comment "Def(En): Credit Limit  as at statement of Febuary
Def(Th):",
	dh012_acth_avail_credit_feb   	string       comment "Def(En): Avail Credit  as at statement of Febuary
Def(Th):",
	dh012_acth_cash_limit_feb     	string       comment "Def(En): Cash Limit  as at statement of Febuary
Def(Th):",
	dh012_acth_avail_cash_feb     	string       comment "Def(En): Avail Cash  as at statement of Febuary
Def(Th):",
	dh012_acth_nmbr_airline_feb   	string       comment "Def(En): Item Airline of Febuary
Def(Th):",
	dh012_acth_amnt_airline_feb   	string       comment "Def(En): Amount Airline of Febuary
Def(Th):",
	dh012_acth_nmbr_hotel_feb     	string       comment "Def(En): Item Hotel of Febuary
Def(Th):",
	dh012_acth_amnt_hotel_feb     	string       comment "Def(En): Amount Hotel of Febuary
Def(Th):",
	dh012_acth_nmbr_car_rental_feb	string       comment "Def(En): Item Car Rental of Febuary
Def(Th):",
	dh012_acth_amnt_car_rental_feb	string       comment "Def(En): Amount Car Rental of Febuary
Def(Th):",
	dh012_acth_nmbr_restaurant_feb	string       comment "Def(En): Item Restaurant of Febuary
Def(Th):",
	dh012_acth_amnt_restaurant_feb	string       comment "Def(En): Amount Restaurant of Febuary
Def(Th):",
	dh012_acth_nmbr_mail_order_feb	string       comment "Def(En): Item Mail Order of Febuary
Def(Th):",
	dh012_acth_amnt_mail_order_feb	string       comment "Def(En): Amount Mail Order of Febuary
Def(Th):",
	dh012_acth_nmbr_atm_cash_feb  	string       comment "Def(En): Item ATM Cash Advance of Febuary
Def(Th):",
	dh012_acth_amnt_atm_cash_feb  	string       comment "Def(En): Amount ATM Cash Advance of Febuary
Def(Th):",
	dh012_acth_nmbr_man_cash_feb  	string       comment "Def(En): Item Manual Cash Advance At Counter Kbank of Febuary
Def(Th):",
	dh012_acth_amnt_man_cash_feb  	string       comment "Def(En): Amount Manual Cash Advance At Counter Kbank of Febuary
Def(Th):",
	dh012_acth_nmbr_quasi_cash_feb	string       comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of Febuary
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_feb	string       comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of Febuary
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_feb   	string       comment "Def(En): Item Other Merchant of Febuary
Def(Th):",
	dh012_acth_amnt_oth_mer_feb   	string       comment "Def(En): Amount Other Merchant of Febuary
Def(Th):",
	dh012_acth_nmbr_retail_mar    	string       comment "Def(En): Item Retail of Mar
Def(Th):",
	dh012_acth_amnt_retail_mar    	string       comment "Def(En): Amount Retail of Mar
Def(Th):",
	dh012_acth_nmbr_ca_atm_mar    	string       comment "Def(En): Item Cash Advance AT Atm of Mar
Def(Th):",
	dh012_acth_amnt_ca_atm_mar    	string       comment "Def(En): Amount Cash Advance At Atm of Mar
Def(Th):",
	dh012_acth_nmbr_ca_man_mar    	string       comment "Def(En): Item Cash Advance AT Counter of Mar
Def(Th):",
	dh012_acth_amnt_ca_man_mar    	string       comment "Def(En): Amount Cash Advance At Counter of Mar
Def(Th):",
	dh012_acthr_interest_mar      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of Mar",
	dh012_acthr_curr_base_rate_mar	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of Mar",
	dh012_acthr_limit_1_mar       	string       comment "Def(En): Retail Limit1 of Mar
Def(Th):",
	dh012_acthr_limit_2_mar       	string       comment "Def(En): Retail Limit2 of Mar
Def(Th):",
	dh012_acthr_rate_2_mar        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of Mar",
	dh012_acthr_rate_3_mar        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of Mar",
	dh012_acthr_limit_option_mar  	string       comment "Def(En): Retail Limit Option  of Mar
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_mar      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of Mar",
	dh012_acthc_curr_base_rate_mar	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of Mar",
	dh012_acthc_limit_1_mar       	string       comment "Def(En): Cash Advance Limit1 of Mar
Def(Th):",
	dh012_acthc_limit_2_mar       	string       comment "Def(En): Cash Advance Limit2 of Mar
Def(Th):",
	dh012_acthc_rate_2_mar        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of Mar",
	dh012_acthc_rate_3_mar        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of Mar",
	dh012_acthc_limit_option_mar  	string       comment "Def(En): Cash Advance Limit Option of Mar
Def(Th):",
	dh012_acth_nmbr_annual_fee_mar	string       comment "Def(En): Item Annual Fee of Mar
Def(Th):",
	dh012_acth_amnt_annual_fee_mar	string       comment "Def(En): Amount Annual Fee of Mar
Def(Th):",
	dh012_acth_nmbr_late_chg_mar  	string       comment "Def(En): Item Late Charge of Mar
Def(Th):",
	dh012_acth_amnt_late_chg_mar  	string       comment "Def(En): Amount Late Charge of Mar
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_mar 	string       comment "Def(En): Item Over Limit Fee of Mar
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_mar 	string       comment "Def(En): Amount Over Limit Fee of Mar
Def(Th):",
	dh012_acth_nmbr_misc_chg_mar  	string       comment "Def(En): Item Miscellaneous Charge Fee of Mar
Def(Th):",
	dh012_acth_amnt_misc_chg_mar  	string       comment "Def(En): Amount Miscellaneous Charge Fee of Mar
Def(Th):",
	dh012_acth_nmbr_svc_chg_mar   	string       comment "Def(En): Item Service Charge Fee of Mar
Def(Th):",
	dh012_acth_amnt_svc_chg_mar   	string       comment "Def(En): Amount Service Charge Fee of Mar
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_mar	string       comment "Def(En): Item Cash Advance Per Fee of Mar
Def(Th):",
	dh012_acth_amnt_ca_per_fee_mar	string       comment "Def(En): Amount Cash Advance Per Fee of Mar
Def(Th):",
	dh012_acth_amnt_payment_mar   	string       comment "Def(En): Amount Payment of Mar
Def(Th):",
	dh012_acth_amnt_curr_bal_mar  	string       comment "Def(En): Amount Current Balance as at statement of Mar
Def(Th):",
	dh012_acth_bb_beg_balance_mar 	string       comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of Mar
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_mar  	string       comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of Mar
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_mar    	string       comment "Def(En):
Def(Th): Bonus Bucket Used ?? of Mar
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_mar   	string       comment "Def(En): Credit Limit  as at statement of Mar
Def(Th):",
	dh012_acth_avail_credit_mar   	string       comment "Def(En): Avail Credit  as at statement of Mar
Def(Th):",
	dh012_acth_cash_limit_mar     	string       comment "Def(En): Cash Limit  as at statement of Mar
Def(Th):",
	dh012_acth_avail_cash_mar     	string       comment "Def(En): Avail Cash  as at statement of Mar
Def(Th):",
	dh012_acth_nmbr_airline_mar   	string       comment "Def(En): Item Airline of Mar
Def(Th):",
	dh012_acth_amnt_airline_mar   	string       comment "Def(En): Amount Airline of Mar
Def(Th):",
	dh012_acth_nmbr_hotel_mar     	string       comment "Def(En): Item Hotel of Mar
Def(Th):",
	dh012_acth_amnt_hotel_mar     	string       comment "Def(En): Amount Hotel of Mar
Def(Th):",
	dh012_acth_nmbr_car_rental_mar	string       comment "Def(En): Item Car Rental of Mar
Def(Th):",
	dh012_acth_amnt_car_rental_mar	string       comment "Def(En): Amount Car Rental of Mar
Def(Th):",
	dh012_acth_nmbr_restaurant_mar	string       comment "Def(En): Item Restaurant of Mar
Def(Th):",
	dh012_acth_amnt_restaurant_mar	string       comment "Def(En): Amount Restaurant of Mar
Def(Th):",
	dh012_acth_nmbr_mail_order_mar	string       comment "Def(En): Item Mail Order of Mar
Def(Th):",
	dh012_acth_amnt_mail_order_mar	string       comment "Def(En): Amount Mail Order of Mar
Def(Th):",
	dh012_acth_nmbr_atm_cash_mar  	string       comment "Def(En): Item ATM Cash Advance of Mar
Def(Th):",
	dh012_acth_amnt_atm_cash_mar  	string       comment "Def(En): Amount ATM Cash Advance of Mar
Def(Th):",
	dh012_acth_nmbr_man_cash_mar  	string       comment "Def(En): Item Manual Cash Advance At Counter Kbank of Mar
Def(Th):",
	dh012_acth_amnt_man_cash_mar  	string       comment "Def(En): Amount Manual Cash Advance At Counter Kbank of Mar
Def(Th):",
	dh012_acth_nmbr_quasi_cash_mar	string       comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of Mar
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_mar	string       comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of Mar
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_mar   	string       comment "Def(En): Item Other Merchant of Mar
Def(Th):",
	dh012_acth_amnt_oth_mer_mar   	string       comment "Def(En): Amount Other Merchant of Mar
Def(Th):",
	dh012_acth_nmbr_retail_apr    	string       comment "Def(En): Item Retail of April
Def(Th):",
	dh012_acth_amnt_retail_apr    	string       comment "Def(En): Amount Retail of April
Def(Th):",
	dh012_acth_nmbr_ca_atm_apr    	string       comment "Def(En): Item Cash Advance AT Atm of April
Def(Th):",
	dh012_acth_amnt_ca_atm_apr    	string       comment "Def(En): Amount Cash Advance At Atm of April
Def(Th):",
	dh012_acth_nmbr_ca_man_apr    	string       comment "Def(En): Item Cash Advance AT Counter of April
Def(Th):",
	dh012_acth_amnt_ca_man_apr    	string       comment "Def(En): Amount Cash Advance At Counter of April
Def(Th):",
	dh012_acthr_interest_apr      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of April",
	dh012_acthr_curr_base_rate_apr	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of April",
	dh012_acthr_limit_1_apr       	string       comment "Def(En): Retail Limit1 of April
Def(Th):",
	dh012_acthr_limit_2_apr       	string       comment "Def(En): Retail Limit2 of April
Def(Th):",
	dh012_acthr_rate_2_apr        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of April",
	dh012_acthr_rate_3_apr        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of April",
	dh012_acthr_limit_option_apr  	string       comment "Def(En): Retail Limit Option  of April
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_apr      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of April",
	dh012_acthc_curr_base_rate_apr	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of April",
	dh012_acthc_limit_1_apr       	string       comment "Def(En): Cash Advance Limit1 of April
Def(Th):",
	dh012_acthc_limit_2_apr       	string       comment "Def(En): Cash Advance Limit2 of April
Def(Th):",
	dh012_acthc_rate_2_apr        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of April",
	dh012_acthc_rate_3_apr        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of April",
	dh012_acthc_limit_option_apr  	string       comment "Def(En): Cash Advance Limit Option of April
Def(Th):",
	dh012_acth_nmbr_annual_fee_apr	string       comment "Def(En): Item Annual Fee of April
Def(Th):",
	dh012_acth_amnt_annual_fee_apr	string       comment "Def(En): Amount Annual Fee of April
Def(Th):",
	dh012_acth_nmbr_late_chg_apr  	string       comment "Def(En): Item Late Charge of April
Def(Th):",
	dh012_acth_amnt_late_chg_apr  	string       comment "Def(En): Amount Late Charge of April
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_apr 	string       comment "Def(En): Item Over Limit Fee of April
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_apr 	string       comment "Def(En): Amount Over Limit Fee of April
Def(Th):",
	dh012_acth_nmbr_misc_chg_apr  	string       comment "Def(En): Item Miscellaneous Charge Fee of April
Def(Th):",
	dh012_acth_amnt_misc_chg_apr  	string       comment "Def(En): Amount Miscellaneous Charge Fee of April
Def(Th):",
	dh012_acth_nmbr_svc_chg_apr   	string       comment "Def(En): Item Service Charge Fee of April
Def(Th):",
	dh012_acth_amnt_svc_chg_apr   	string       comment "Def(En): Amount Service Charge Fee of April
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_apr	string       comment "Def(En): Item Cash Advance Per Fee of April
Def(Th):",
	dh012_acth_amnt_ca_per_fee_apr	string       comment "Def(En): Amount Cash Advance Per Fee of April
Def(Th):",
	dh012_acth_amnt_payment_apr   	string       comment "Def(En): Amount Payment of April
Def(Th):",
	dh012_acth_amnt_curr_bal_apr  	string       comment "Def(En): Amount Current Balance as at statement of April
Def(Th):",
	dh012_acth_bb_beg_balance_apr 	string       comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of April
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_apr  	string       comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of April
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_apr    	string       comment "Def(En):
Def(Th): Bonus Bucket Used ?? of April
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_apr   	string       comment "Def(En): Credit Limit  as at statement of April
Def(Th):",
	dh012_acth_avail_credit_apr   	string       comment "Def(En): Avail Credit  as at statement of April
Def(Th):",
	dh012_acth_cash_limit_apr     	string       comment "Def(En): Cash Limit  as at statement of April
Def(Th):",
	dh012_acth_avail_cash_apr     	string       comment "Def(En): Avail Cash  as at statement of April
Def(Th):",
	dh012_acth_nmbr_airline_apr   	string       comment "Def(En): Item Airline of April
Def(Th):",
	dh012_acth_amnt_airline_apr   	string       comment "Def(En): Amount Airline of April
Def(Th):",
	dh012_acth_nmbr_hotel_apr     	string       comment "Def(En): Item Hotel of April
Def(Th):",
	dh012_acth_amnt_hotel_apr     	string       comment "Def(En): Amount Hotel of April
Def(Th):",
	dh012_acth_nmbr_car_rental_apr	string       comment "Def(En): Item Car Rental of April
Def(Th):",
	dh012_acth_amnt_car_rental_apr	string       comment "Def(En): Amount Car Rental of April
Def(Th):",
	dh012_acth_nmbr_restaurant_apr	string       comment "Def(En): Item Restaurant of April
Def(Th):",
	dh012_acth_amnt_restaurant_apr	string       comment "Def(En): Amount Restaurant of April
Def(Th):",
	dh012_acth_nmbr_mail_order_apr	string       comment "Def(En): Item Mail Order of April
Def(Th):",
	dh012_acth_amnt_mail_order_apr	string       comment "Def(En): Amount Mail Order of April
Def(Th):",
	dh012_acth_nmbr_atm_cash_apr  	string       comment "Def(En): Item ATM Cash Advance of April
Def(Th):",
	dh012_acth_amnt_atm_cash_apr  	string       comment "Def(En): Amount ATM Cash Advance of April
Def(Th):",
	dh012_acth_nmbr_man_cash_apr  	string       comment "Def(En): Item Manual Cash Advance At Counter Kbank of April
Def(Th):",
	dh012_acth_amnt_man_cash_apr  	string       comment "Def(En): Amount Manual Cash Advance At Counter Kbank of April
Def(Th):",
	dh012_acth_nmbr_quasi_cash_apr	string       comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of April
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_apr	string       comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of April
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_apr   	string       comment "Def(En): Item Other Merchant of April
Def(Th):",
	dh012_acth_amnt_oth_mer_apr   	string       comment "Def(En): Amount Other Merchant of April
Def(Th):",
	dh012_acth_nmbr_retail_may    	string       comment "Def(En): Item Retail of May
Def(Th):",
	dh012_acth_amnt_retail_may    	string       comment "Def(En): Amount Retail of May
Def(Th):",
	dh012_acth_nmbr_ca_atm_may    	string       comment "Def(En): Item Cash Advance AT Atm of May
Def(Th):",
	dh012_acth_amnt_ca_atm_may    	string       comment "Def(En): Amount Cash Advance At Atm of May
Def(Th):",
	dh012_acth_nmbr_ca_man_may    	string       comment "Def(En): Item Cash Advance AT Counter of May
Def(Th):",
	dh012_acth_amnt_ca_man_may    	string       comment "Def(En): Amount Cash Advance At Counter of May
Def(Th):",
	dh012_acthr_interest_may      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of May",
	dh012_acthr_curr_base_rate_may	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of May",
	dh012_acthr_limit_1_may       	string       comment "Def(En): Retail Limit1 of May
Def(Th):",
	dh012_acthr_limit_2_may       	string       comment "Def(En): Retail Limit2 of May
Def(Th):",
	dh012_acthr_rate_2_may        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of May",
	dh012_acthr_rate_3_may        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of May",
	dh012_acthr_limit_option_may  	string       comment "Def(En): Retail Limit Option  of May
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_may      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of May",
	dh012_acthc_curr_base_rate_may	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of May",
	dh012_acthc_limit_1_may       	string       comment "Def(En): Cash Advance Limit1 of May
Def(Th):",
	dh012_acthc_limit_2_may       	string       comment "Def(En): Cash Advance Limit2 of May
Def(Th):",
	dh012_acthc_rate_2_may        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of May",
	dh012_acthc_rate_3_may        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of May",
	dh012_acthc_limit_option_may  	string       comment "Def(En): Cash Advance Limit Option of May
Def(Th):",
	dh012_acth_nmbr_annual_fee_may	string       comment "Def(En): Item Annual Fee of May
Def(Th):",
	dh012_acth_amnt_annual_fee_may	string       comment "Def(En): Amount Annual Fee of May
Def(Th):",
	dh012_acth_nmbr_late_chg_may  	string       comment "Def(En): Item Late Charge of May
Def(Th):",
	dh012_acth_amnt_late_chg_may  	string       comment "Def(En): Amount Late Charge of May
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_may 	string       comment "Def(En): Item Over Limit Fee of May
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_may 	string       comment "Def(En): Amount Over Limit Fee of May
Def(Th):",
	dh012_acth_nmbr_misc_chg_may  	string       comment "Def(En): Item Miscellaneous Charge Fee of May
Def(Th):",
	dh012_acth_amnt_misc_chg_may  	string       comment "Def(En): Amount Miscellaneous Charge Fee of May
Def(Th):",
	dh012_acth_nmbr_svc_chg_may   	string       comment "Def(En): Item Service Charge Fee of May
Def(Th):",
	dh012_acth_amnt_svc_chg_may   	string       comment "Def(En): Amount Service Charge Fee of May
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_may	string       comment "Def(En): Item Cash Advance Per Fee of May
Def(Th):",
	dh012_acth_amnt_ca_per_fee_may	string       comment "Def(En): Amount Cash Advance Per Fee of May
Def(Th):",
	dh012_acth_amnt_payment_may   	string       comment "Def(En): Amount Payment of May
Def(Th):",
	dh012_acth_amnt_curr_bal_may  	string       comment "Def(En): Amount Current Balance as at statement of May
Def(Th):",
	dh012_acth_bb_beg_balance_may 	string       comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of May
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_may  	string       comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of May
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_may    	string       comment "Def(En):
Def(Th): Bonus Bucket Used ?? of May
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_may   	string       comment "Def(En): Credit Limit  as at statement of May
Def(Th):",
	dh012_acth_avail_credit_may   	string       comment "Def(En): Avail Credit  as at statement of May
Def(Th):",
	dh012_acth_cash_limit_may     	string       comment "Def(En): Cash Limit  as at statement of May
Def(Th):",
	dh012_acth_avail_cash_may     	string       comment "Def(En): Avail Cash  as at statement of May
Def(Th):",
	dh012_acth_nmbr_airline_may   	string       comment "Def(En): Item Airline of May
Def(Th):",
	dh012_acth_amnt_airline_may   	string       comment "Def(En): Amount Airline of May
Def(Th):",
	dh012_acth_nmbr_hotel_may     	string       comment "Def(En): Item Hotel of May
Def(Th):",
	dh012_acth_amnt_hotel_may     	string       comment "Def(En): Amount Hotel of May
Def(Th):",
	dh012_acth_nmbr_car_rental_may	string       comment "Def(En): Item Car Rental of May
Def(Th):",
	dh012_acth_amnt_car_rental_may	string       comment "Def(En): Amount Car Rental of May
Def(Th):",
	dh012_acth_nmbr_restaurant_may	string       comment "Def(En): Item Restaurant of May
Def(Th):",
	dh012_acth_amnt_restaurant_may	string       comment "Def(En): Amount Restaurant of May
Def(Th):",
	dh012_acth_nmbr_mail_order_may	string       comment "Def(En): Item Mail Order of May
Def(Th):",
	dh012_acth_amnt_mail_order_may	string       comment "Def(En): Amount Mail Order of May
Def(Th):",
	dh012_acth_nmbr_atm_cash_may  	string       comment "Def(En): Item ATM Cash Advance of May
Def(Th):",
	dh012_acth_amnt_atm_cash_may  	string       comment "Def(En): Amount ATM Cash Advance of May
Def(Th):",
	dh012_acth_nmbr_man_cash_may  	string       comment "Def(En): Item Manual Cash Advance At Counter Kbank of May
Def(Th):",
	dh012_acth_amnt_man_cash_may  	string       comment "Def(En): Amount Manual Cash Advance At Counter Kbank of May
Def(Th):",
	dh012_acth_nmbr_quasi_cash_may	string       comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of May
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_may	string       comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of May
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_may   	string       comment "Def(En): Item Other Merchant of May
Def(Th):",
	dh012_acth_amnt_oth_mer_may   	string       comment "Def(En): Amount Other Merchant of May
Def(Th):",
	dh012_acth_nmbr_retail_jun    	string       comment "Def(En): Item Retail of June
Def(Th):",
	dh012_acth_amnt_retail_jun    	string       comment "Def(En): Amount Retail of June
Def(Th):",
	dh012_acth_nmbr_ca_atm_jun    	string       comment "Def(En): Item Cash Advance AT Atm of June
Def(Th):",
	dh012_acth_amnt_ca_atm_jun    	string       comment "Def(En): Amount Cash Advance At Atm of June
Def(Th):",
	dh012_acth_nmbr_ca_man_jun    	string       comment "Def(En): Item Cash Advance AT Counter of June
Def(Th):",
	dh012_acth_amnt_ca_man_jun    	string       comment "Def(En): Amount Cash Advance At Counter of June
Def(Th):",
	dh012_acthr_interest_jun      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of June",
	dh012_acthr_curr_base_rate_jun	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of June",
	dh012_acthr_limit_1_jun       	string       comment "Def(En): Retail Limit1 of June
Def(Th):",
	dh012_acthr_limit_2_jun       	string       comment "Def(En): Retail Limit2 of June
Def(Th):",
	dh012_acthr_rate_2_jun        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of June",
	dh012_acthr_rate_3_jun        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of June",
	dh012_acthr_limit_option_jun  	string       comment "Def(En): Retail Limit Option  of June
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_jun      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of June",
	dh012_acthc_curr_base_rate_jun	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of June",
	dh012_acthc_limit_1_jun       	string       comment "Def(En): Cash Advance Limit1 of June
Def(Th):",
	dh012_acthc_limit_2_jun       	string       comment "Def(En): Cash Advance Limit2 of June
Def(Th):",
	dh012_acthc_rate_2_jun        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of June",
	dh012_acthc_rate_3_jun        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of June",
	dh012_acthc_limit_option_jun  	string       comment "Def(En): Cash Advance Limit Option of June
Def(Th):",
	dh012_acth_nmbr_annual_fee_jun	string       comment "Def(En): Item Annual Fee of June
Def(Th):",
	dh012_acth_amnt_annual_fee_jun	string       comment "Def(En): Amount Annual Fee of June
Def(Th):",
	dh012_acth_nmbr_late_chg_jun  	string       comment "Def(En): Item Late Charge of June
Def(Th):",
	dh012_acth_amnt_late_chg_jun  	string       comment "Def(En): Amount Late Charge of June
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_jun 	string       comment "Def(En): Item Over Limit Fee of June
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_jun 	string       comment "Def(En): Amount Over Limit Fee of June
Def(Th):",
	dh012_acth_nmbr_misc_chg_jun  	string       comment "Def(En): Item Miscellaneous Charge Fee of June
Def(Th):",
	dh012_acth_amnt_misc_chg_jun  	string       comment "Def(En): Amount Miscellaneous Charge Fee of June
Def(Th):",
	dh012_acth_nmbr_svc_chg_jun   	string       comment "Def(En): Item Service Charge Fee of June
Def(Th):",
	dh012_acth_amnt_svc_chg_jun   	string       comment "Def(En): Amount Service Charge Fee of June
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_jun	string       comment "Def(En): Item Cash Advance Per Fee of June
Def(Th):",
	dh012_acth_amnt_ca_per_fee_jun	string       comment "Def(En): Amount Cash Advance Per Fee of June
Def(Th):",
	dh012_acth_amnt_payment_jun   	string       comment "Def(En): Amount Payment of June
Def(Th):",
	dh012_acth_amnt_curr_bal_jun  	string       comment "Def(En): Amount Current Balance as at statement of June
Def(Th):",
	dh012_acth_bb_beg_balance_jun 	string       comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of June
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_jun  	string       comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of June
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_jun    	string       comment "Def(En):
Def(Th): Bonus Bucket Used ?? of June
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_jun   	string       comment "Def(En): Credit Limit  as at statement of June
Def(Th):",
	dh012_acth_avail_credit_jun   	string       comment "Def(En): Avail Credit  as at statement of June
Def(Th):",
	dh012_acth_cash_limit_jun     	string       comment "Def(En): Cash Limit  as at statement of June
Def(Th):",
	dh012_acth_avail_cash_jun     	string       comment "Def(En): Avail Cash  as at statement of June
Def(Th):",
	dh012_acth_nmbr_airline_jun   	string       comment "Def(En): Item Airline of June
Def(Th):",
	dh012_acth_amnt_airline_jun   	string       comment "Def(En): Amount Airline of June
Def(Th):",
	dh012_acth_nmbr_hotel_jun     	string       comment "Def(En): Item Hotel of June
Def(Th):",
	dh012_acth_amnt_hotel_jun     	string       comment "Def(En): Amount Hotel of June
Def(Th):",
	dh012_acth_nmbr_car_rental_jun	string       comment "Def(En): Item Car Rental of June
Def(Th):",
	dh012_acth_amnt_car_rental_jun	string       comment "Def(En): Amount Car Rental of June
Def(Th):",
	dh012_acth_nmbr_restaurant_jun	string       comment "Def(En): Item Restaurant of June
Def(Th):",
	dh012_acth_amnt_restaurant_jun	string       comment "Def(En): Amount Restaurant of June
Def(Th):",
	dh012_acth_nmbr_mail_order_jun	string       comment "Def(En): Item Mail Order of June
Def(Th):",
	dh012_acth_amnt_mail_order_jun	string       comment "Def(En): Amount Mail Order of June
Def(Th):",
	dh012_acth_nmbr_atm_cash_jun  	string       comment "Def(En): Item ATM Cash Advance of June
Def(Th):",
	dh012_acth_amnt_atm_cash_jun  	string       comment "Def(En): Amount ATM Cash Advance of June
Def(Th):",
	dh012_acth_nmbr_man_cash_jun  	string       comment "Def(En): Item Manual Cash Advance At Counter Kbank of June
Def(Th):",
	dh012_acth_amnt_man_cash_jun  	string       comment "Def(En): Amount Manual Cash Advance At Counter Kbank of June
Def(Th):",
	dh012_acth_nmbr_quasi_cash_jun	string       comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of June
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_jun	string       comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of June
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_jun   	string       comment "Def(En): Item Other Merchant of June
Def(Th):",
	dh012_acth_amnt_oth_mer_jun   	string       comment "Def(En): Amount Other Merchant of June
Def(Th):",
	dh012_acth_nmbr_retail_jul    	string       comment "Def(En): Item Retail of July
Def(Th):",
	dh012_acth_amnt_retail_jul    	string       comment "Def(En): Amount Retail of July
Def(Th):",
	dh012_acth_nmbr_ca_atm_jul    	string       comment "Def(En): Item Cash Advance AT Atm of July
Def(Th):",
	dh012_acth_amnt_ca_atm_jul    	string       comment "Def(En): Amount Cash Advance At Atm of July
Def(Th):",
	dh012_acth_nmbr_ca_man_jul    	string       comment "Def(En): Item Cash Advance AT Counter of July
Def(Th):",
	dh012_acth_amnt_ca_man_jul    	string       comment "Def(En): Amount Cash Advance At Counter of July
Def(Th):",
	dh012_acthr_interest_jul      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of July",
	dh012_acthr_curr_base_rate_jul	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of July",
	dh012_acthr_limit_1_jul       	string       comment "Def(En): Retail Limit1 of July
Def(Th):",
	dh012_acthr_limit_2_jul       	string       comment "Def(En): Retail Limit2 of July
Def(Th):",
	dh012_acthr_rate_2_jul        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of July",
	dh012_acthr_rate_3_jul        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of July",
	dh012_acthr_limit_option_jul  	string       comment "Def(En): Retail Limit Option  of July
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_jul      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of July",
	dh012_acthc_curr_base_rate_jul	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of July",
	dh012_acthc_limit_1_jul       	string       comment "Def(En): Cash Advance Limit1 of July
Def(Th):",
	dh012_acthc_limit_2_jul       	string       comment "Def(En): Cash Advance Limit2 of July
Def(Th):",
	dh012_acthc_rate_2_jul        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of July",
	dh012_acthc_rate_3_jul        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of July",
	dh012_acthc_limit_option_jul  	string       comment "Def(En): Cash Advance Limit Option of July
Def(Th):",
	dh012_acth_nmbr_annual_fee_jul	string       comment "Def(En): Item Annual Fee of July
Def(Th):",
	dh012_acth_amnt_annual_fee_jul	string       comment "Def(En): Amount Annual Fee of July
Def(Th):",
	dh012_acth_nmbr_late_chg_jul  	string       comment "Def(En): Item Late Charge of July
Def(Th):",
	dh012_acth_amnt_late_chg_jul  	string       comment "Def(En): Amount Late Charge of July
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_jul 	string       comment "Def(En): Item Over Limit Fee of July
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_jul 	string       comment "Def(En): Amount Over Limit Fee of July
Def(Th):",
	dh012_acth_nmbr_misc_chg_jul  	string       comment "Def(En): Item Miscellaneous Charge Fee of July
Def(Th):",
	dh012_acth_amnt_misc_chg_jul  	string       comment "Def(En): Amount Miscellaneous Charge Fee of July
Def(Th):",
	dh012_acth_nmbr_svc_chg_jul   	string       comment "Def(En): Item Service Charge Fee of July
Def(Th):",
	dh012_acth_amnt_svc_chg_jul   	string       comment "Def(En): Amount Service Charge Fee of July
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_jul	string       comment "Def(En): Item Cash Advance Per Fee of July
Def(Th):",
	dh012_acth_amnt_ca_per_fee_jul	string       comment "Def(En): Amount Cash Advance Per Fee of July
Def(Th):",
	dh012_acth_amnt_payment_jul   	string       comment "Def(En): Amount Payment of July
Def(Th):",
	dh012_acth_amnt_curr_bal_jul  	string       comment "Def(En): Amount Current Balance as at statement of July
Def(Th):",
	dh012_acth_bb_beg_balance_jul 	string       comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of July
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_jul  	string       comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of July
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_jul    	string       comment "Def(En):
Def(Th): Bonus Bucket Used ?? of July
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_jul   	string       comment "Def(En): Credit Limit  as at statement of July
Def(Th):",
	dh012_acth_avail_credit_jul   	string       comment "Def(En): Avail Credit  as at statement of July
Def(Th):",
	dh012_acth_cash_limit_jul     	string       comment "Def(En): Cash Limit  as at statement of July
Def(Th):",
	dh012_acth_avail_cash_jul     	string       comment "Def(En): Avail Cash  as at statement of July
Def(Th):",
	dh012_acth_nmbr_airline_jul   	string       comment "Def(En): Item Airline of July
Def(Th):",
	dh012_acth_amnt_airline_jul   	string       comment "Def(En): Amount Airline of July
Def(Th):",
	dh012_acth_nmbr_hotel_jul     	string       comment "Def(En): Item Hotel of July
Def(Th):",
	dh012_acth_amnt_hotel_jul     	string       comment "Def(En): Amount Hotel of July
Def(Th):",
	dh012_acth_nmbr_car_rental_jul	string       comment "Def(En): Item Car Rental of July
Def(Th):",
	dh012_acth_amnt_car_rental_jul	string       comment "Def(En): Amount Car Rental of July
Def(Th):",
	dh012_acth_nmbr_restaurant_jul	string       comment "Def(En): Item Restaurant of July
Def(Th):",
	dh012_acth_amnt_restaurant_jul	string       comment "Def(En): Amount Restaurant of July
Def(Th):",
	dh012_acth_nmbr_mail_order_jul	string       comment "Def(En): Item Mail Order of July
Def(Th):",
	dh012_acth_amnt_mail_order_jul	string       comment "Def(En): Amount Mail Order of July
Def(Th):",
	dh012_acth_nmbr_atm_cash_jul  	string       comment "Def(En): Item ATM Cash Advance of July
Def(Th):",
	dh012_acth_amnt_atm_cash_jul  	string       comment "Def(En): Amount ATM Cash Advance of July
Def(Th):",
	dh012_acth_nmbr_man_cash_jul  	string       comment "Def(En): Item Manual Cash Advance At Counter Kbank of July
Def(Th):",
	dh012_acth_amnt_man_cash_jul  	string       comment "Def(En): Amount Manual Cash Advance At Counter Kbank of July
Def(Th):",
	dh012_acth_nmbr_quasi_cash_jul	string       comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of July
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_jul	string       comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of July
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_jul   	string       comment "Def(En): Item Other Merchant of July
Def(Th):",
	dh012_acth_amnt_oth_mer_jul   	string       comment "Def(En): Amount Other Merchant of July
Def(Th):",
	dh012_acth_nmbr_retail_aug    	string       comment "Def(En): Item Retail of August
Def(Th):",
	dh012_acth_amnt_retail_aug    	string       comment "Def(En): Amount Retail of August
Def(Th):",
	dh012_acth_nmbr_ca_atm_aug    	string       comment "Def(En): Item Cash Advance AT Atm of August
Def(Th):",
	dh012_acth_amnt_ca_atm_aug    	string       comment "Def(En): Amount Cash Advance At Atm of August
Def(Th):",
	dh012_acth_nmbr_ca_man_aug    	string       comment "Def(En): Item Cash Advance AT Counter of August
Def(Th):",
	dh012_acth_amnt_ca_man_aug    	string       comment "Def(En): Amount Cash Advance At Counter of August
Def(Th):",
	dh012_acthr_interest_aug      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of August",
	dh012_acthr_curr_base_rate_aug	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of August",
	dh012_acthr_limit_1_aug       	string       comment "Def(En): Retail Limit1 of August
Def(Th):",
	dh012_acthr_limit_2_aug       	string       comment "Def(En): Retail Limit2 of August
Def(Th):",
	dh012_acthr_rate_2_aug        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of August",
	dh012_acthr_rate_3_aug        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of August",
	dh012_acthr_limit_option_aug  	string       comment "Def(En): Retail Limit Option  of August
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_aug      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of August",
	dh012_acthc_curr_base_rate_aug	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of August",
	dh012_acthc_limit_1_aug       	string       comment "Def(En): Cash Advance Limit1 of August
Def(Th):",
	dh012_acthc_limit_2_aug       	string       comment "Def(En): Cash Advance Limit2 of August
Def(Th):",
	dh012_acthc_rate_2_aug        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of August",
	dh012_acthc_rate_3_aug        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of August",
	dh012_acthc_limit_option_aug  	string       comment "Def(En): Cash Advance Limit Option of August
Def(Th):",
	dh012_acth_nmbr_annual_fee_aug	string       comment "Def(En): Item Annual Fee of August
Def(Th):",
	dh012_acth_amnt_annual_fee_aug	string       comment "Def(En): Amount Annual Fee of August
Def(Th):",
	dh012_acth_nmbr_late_chg_aug  	string       comment "Def(En): Item Late Charge of August
Def(Th):",
	dh012_acth_amnt_late_chg_aug  	string       comment "Def(En): Amount Late Charge of August
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_aug 	string       comment "Def(En): Item Over Limit Fee of August
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_aug 	string       comment "Def(En): Amount Over Limit Fee of August
Def(Th):",
	dh012_acth_nmbr_misc_chg_aug  	string       comment "Def(En): Item Miscellaneous Charge Fee of August
Def(Th):",
	dh012_acth_amnt_misc_chg_aug  	string       comment "Def(En): Amount Miscellaneous Charge Fee of August
Def(Th):",
	dh012_acth_nmbr_svc_chg_aug   	string       comment "Def(En): Item Service Charge Fee of August
Def(Th):",
	dh012_acth_amnt_svc_chg_aug   	string       comment "Def(En): Amount Service Charge Fee of August
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_aug	string       comment "Def(En): Item Cash Advance Per Fee of August
Def(Th):",
	dh012_acth_amnt_ca_per_fee_aug	string       comment "Def(En): Amount Cash Advance Per Fee of August
Def(Th):",
	dh012_acth_amnt_payment_aug   	string       comment "Def(En): Amount Payment of August
Def(Th):",
	dh012_acth_amnt_curr_bal_aug  	string       comment "Def(En): Amount Current Balance as at statement of August
Def(Th):",
	dh012_acth_bb_beg_balance_aug 	string       comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of August
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_aug  	string       comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of August
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_aug    	string       comment "Def(En):
Def(Th): Bonus Bucket Used ?? of August
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_aug   	string       comment "Def(En): Credit Limit  as at statement of August
Def(Th):",
	dh012_acth_avail_credit_aug   	string       comment "Def(En): Avail Credit  as at statement of August
Def(Th):",
	dh012_acth_cash_limit_aug     	string       comment "Def(En): Cash Limit  as at statement of August
Def(Th):",
	dh012_acth_avail_cash_aug     	string       comment "Def(En): Avail Cash  as at statement of August
Def(Th):",
	dh012_acth_nmbr_airline_aug   	string       comment "Def(En): Item Airline of August
Def(Th):",
	dh012_acth_amnt_airline_aug   	string       comment "Def(En): Amount Airline of August
Def(Th):",
	dh012_acth_nmbr_hotel_aug     	string       comment "Def(En): Item Hotel of August
Def(Th):",
	dh012_acth_amnt_hotel_aug     	string       comment "Def(En): Amount Hotel of August
Def(Th):",
	dh012_acth_nmbr_car_rental_aug	string       comment "Def(En): Item Car Rental of August
Def(Th):",
	dh012_acth_amnt_car_rental_aug	string       comment "Def(En): Amount Car Rental of August
Def(Th):",
	dh012_acth_nmbr_restaurant_aug	string       comment "Def(En): Item Restaurant of August
Def(Th):",
	dh012_acth_amnt_restaurant_aug	string       comment "Def(En): Amount Restaurant of August
Def(Th):",
	dh012_acth_nmbr_mail_order_aug	string       comment "Def(En): Item Mail Order of August
Def(Th):",
	dh012_acth_amnt_mail_order_aug	string       comment "Def(En): Amount Mail Order of August
Def(Th):",
	dh012_acth_nmbr_atm_cash_aug  	string       comment "Def(En): Item ATM Cash Advance of August
Def(Th):",
	dh012_acth_amnt_atm_cash_aug  	string       comment "Def(En): Amount ATM Cash Advance of August
Def(Th):",
	dh012_acth_nmbr_man_cash_aug  	string       comment "Def(En): Item Manual Cash Advance At Counter Kbank of August
Def(Th):",
	dh012_acth_amnt_man_cash_aug  	string       comment "Def(En): Amount Manual Cash Advance At Counter Kbank of August
Def(Th):",
	dh012_acth_nmbr_quasi_cash_aug	string       comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of August
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_aug	string       comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of August
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_aug   	string       comment "Def(En): Item Other Merchant of August
Def(Th):",
	dh012_acth_amnt_oth_mer_aug   	string       comment "Def(En): Amount Other Merchant of August
Def(Th):",
	dh012_acth_nmbr_retail_sep    	string       comment "Def(En): Item Retail of September
Def(Th):",
	dh012_acth_amnt_retail_sep    	string       comment "Def(En): Amount Retail of September
Def(Th):",
	dh012_acth_nmbr_ca_atm_sep    	string       comment "Def(En): Item Cash Advance AT Atm of September
Def(Th):",
	dh012_acth_amnt_ca_atm_sep    	string       comment "Def(En): Amount Cash Advance At Atm of September
Def(Th):",
	dh012_acth_nmbr_ca_man_sep    	string       comment "Def(En): Item Cash Advance AT Counter of September
Def(Th):",
	dh012_acth_amnt_ca_man_sep    	string       comment "Def(En): Amount Cash Advance At Counter of September
Def(Th):",
	dh012_acthr_interest_sep      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of September",
	dh012_acthr_curr_base_rate_sep	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of September",
	dh012_acthr_limit_1_sep       	string       comment "Def(En): Retail Limit1 of September
Def(Th):",
	dh012_acthr_limit_2_sep       	string       comment "Def(En): Retail Limit2 of September
Def(Th):",
	dh012_acthr_rate_2_sep        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of September",
	dh012_acthr_rate_3_sep        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of September",
	dh012_acthr_limit_option_sep  	string       comment "Def(En): Retail Limit Option  of September
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_sep      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of September",
	dh012_acthc_curr_base_rate_sep	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of September",
	dh012_acthc_limit_1_sep       	string       comment "Def(En): Cash Advance Limit1 of September
Def(Th):",
	dh012_acthc_limit_2_sep       	string       comment "Def(En): Cash Advance Limit2 of September
Def(Th):",
	dh012_acthc_rate_2_sep        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of September",
	dh012_acthc_rate_3_sep        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of September",
	dh012_acthc_limit_option_sep  	string       comment "Def(En): Cash Advance Limit Option of September
Def(Th):",
	dh012_acth_nmbr_annual_fee_sep	string       comment "Def(En): Item Annual Fee of September
Def(Th):",
	dh012_acth_amnt_annual_fee_sep	string       comment "Def(En): Amount Annual Fee of September
Def(Th):",
	dh012_acth_nmbr_late_chg_sep  	string       comment "Def(En): Item Late Charge of September
Def(Th):",
	dh012_acth_amnt_late_chg_sep  	string       comment "Def(En): Amount Late Charge of September
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_sep 	string       comment "Def(En): Item Over Limit Fee of September
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_sep 	string       comment "Def(En): Amount Over Limit Fee of September
Def(Th):",
	dh012_acth_nmbr_misc_chg_sep  	string       comment "Def(En): Item Miscellaneous Charge Fee of September
Def(Th):",
	dh012_acth_amnt_misc_chg_sep  	string       comment "Def(En): Amount Miscellaneous Charge Fee of September
Def(Th):",
	dh012_acth_nmbr_svc_chg_sep   	string       comment "Def(En): Item Service Charge Fee of September
Def(Th):",
	dh012_acth_amnt_svc_chg_sep   	string       comment "Def(En): Amount Service Charge Fee of September
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_sep	string       comment "Def(En): Item Cash Advance Per Fee of September
Def(Th):",
	dh012_acth_amnt_ca_per_fee_sep	string       comment "Def(En): Amount Cash Advance Per Fee of September
Def(Th):",
	dh012_acth_amnt_payment_sep   	string       comment "Def(En): Amount Payment of September
Def(Th):",
	dh012_acth_amnt_curr_bal_sep  	string       comment "Def(En): Amount Current Balance as at statement of September
Def(Th):",
	dh012_acth_bb_beg_balance_sep 	string       comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of September
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_sep  	string       comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of September
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_sep    	string       comment "Def(En):
Def(Th): Bonus Bucket Used ?? of September
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_sep   	string       comment "Def(En): Credit Limit  as at statement of September
Def(Th):",
	dh012_acth_avail_credit_sep   	string       comment "Def(En): Avail Credit  as at statement of September
Def(Th):",
	dh012_acth_cash_limit_sep     	string       comment "Def(En): Cash Limit  as at statement of September
Def(Th):",
	dh012_acth_avail_cash_sep     	string       comment "Def(En): Avail Cash  as at statement of September
Def(Th):",
	dh012_acth_nmbr_airline_sep   	string       comment "Def(En): Item Airline of September
Def(Th):",
	dh012_acth_amnt_airline_sep   	string       comment "Def(En): Amount Airline of September
Def(Th):",
	dh012_acth_nmbr_hotel_sep     	string       comment "Def(En): Item Hotel of September
Def(Th):",
	dh012_acth_amnt_hotel_sep     	string       comment "Def(En): Amount Hotel of September
Def(Th):",
	dh012_acth_nmbr_car_rental_sep	string       comment "Def(En): Item Car Rental of September
Def(Th):",
	dh012_acth_amnt_car_rental_sep	string       comment "Def(En): Amount Car Rental of September
Def(Th):",
	dh012_acth_nmbr_restaurant_sep	string       comment "Def(En): Item Restaurant of September
Def(Th):",
	dh012_acth_amnt_restaurant_sep	string       comment "Def(En): Amount Restaurant of September
Def(Th):",
	dh012_acth_nmbr_mail_order_sep	string       comment "Def(En): Item Mail Order of September
Def(Th):",
	dh012_acth_amnt_mail_order_sep	string       comment "Def(En): Amount Mail Order of September
Def(Th):",
	dh012_acth_nmbr_atm_cash_sep  	string       comment "Def(En): Item ATM Cash Advance of September
Def(Th):",
	dh012_acth_amnt_atm_cash_sep  	string       comment "Def(En): Amount ATM Cash Advance of September
Def(Th):",
	dh012_acth_nmbr_man_cash_sep  	string       comment "Def(En): Item Manual Cash Advance At Counter Kbank of September
Def(Th):",
	dh012_acth_amnt_man_cash_sep  	string       comment "Def(En): Amount Manual Cash Advance At Counter Kbank of September
Def(Th):",
	dh012_acth_nmbr_quasi_cash_sep	string       comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of September
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_sep	string       comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of September
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_sep   	string       comment "Def(En): Item Other Merchant of September
Def(Th):",
	dh012_acth_amnt_oth_mer_sep   	string       comment "Def(En): Amount Other Merchant of September
Def(Th):",
	dh012_acth_nmbr_retail_oct    	string       comment "Def(En): Item Retail of October
Def(Th):",
	dh012_acth_amnt_retail_oct    	string       comment "Def(En): Amount Retail of October
Def(Th):",
	dh012_acth_nmbr_ca_atm_oct    	string       comment "Def(En): Item Cash Advance AT Atm of October
Def(Th):",
	dh012_acth_amnt_ca_atm_oct    	string       comment "Def(En): Amount Cash Advance At Atm of October
Def(Th):",
	dh012_acth_nmbr_ca_man_oct    	string       comment "Def(En): Item Cash Advance AT Counter of October
Def(Th):",
	dh012_acth_amnt_ca_man_oct    	string       comment "Def(En): Amount Cash Advance At Counter of October
Def(Th):",
	dh012_acthr_interest_oct      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of October",
	dh012_acthr_curr_base_rate_oct	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of October",
	dh012_acthr_limit_1_oct       	string       comment "Def(En): Retail Limit1 of October
Def(Th):",
	dh012_acthr_limit_2_oct       	string       comment "Def(En): Retail Limit2 of October
Def(Th):",
	dh012_acthr_rate_2_oct        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of October",
	dh012_acthr_rate_3_oct        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of October",
	dh012_acthr_limit_option_oct  	string       comment "Def(En): Retail Limit Option  of October
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_oct      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of October",
	dh012_acthc_curr_base_rate_oct	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of October",
	dh012_acthc_limit_1_oct       	string       comment "Def(En): Cash Advance Limit1 of October
Def(Th):",
	dh012_acthc_limit_2_oct       	string       comment "Def(En): Cash Advance Limit2 of October
Def(Th):",
	dh012_acthc_rate_2_oct        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of October",
	dh012_acthc_rate_3_oct        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of October",
	dh012_acthc_limit_option_oct  	string       comment "Def(En): Cash Advance Limit Option of October
Def(Th):",
	dh012_acth_nmbr_annual_fee_oct	string       comment "Def(En): Item Annual Fee of October
Def(Th):",
	dh012_acth_amnt_annual_fee_oct	string       comment "Def(En): Amount Annual Fee of October
Def(Th):",
	dh012_acth_nmbr_late_chg_oct  	string       comment "Def(En): Item Late Charge of October
Def(Th):",
	dh012_acth_amnt_late_chg_oct  	string       comment "Def(En): Amount Late Charge of October
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_oct 	string       comment "Def(En): Item Over Limit Fee of October
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_oct 	string       comment "Def(En): Amount Over Limit Fee of October
Def(Th):",
	dh012_acth_nmbr_misc_chg_oct  	string       comment "Def(En): Item Miscellaneous Charge Fee of October
Def(Th):",
	dh012_acth_amnt_misc_chg_oct  	string       comment "Def(En): Amount Miscellaneous Charge Fee of October
Def(Th):",
	dh012_acth_nmbr_svc_chg_oct   	string       comment "Def(En): Item Service Charge Fee of October
Def(Th):",
	dh012_acth_amnt_svc_chg_oct   	string       comment "Def(En): Amount Service Charge Fee of October
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_oct	string       comment "Def(En): Item Cash Advance Per Fee of October
Def(Th):",
	dh012_acth_amnt_ca_per_fee_oct	string       comment "Def(En): Amount Cash Advance Per Fee of October
Def(Th):",
	dh012_acth_amnt_payment_oct   	string       comment "Def(En): Amount Payment of October
Def(Th):",
	dh012_acth_amnt_curr_bal_oct  	string       comment "Def(En): Amount Current Balance as at statement of October
Def(Th):",
	dh012_acth_bb_beg_balance_oct 	string       comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of October
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_oct  	string       comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of October
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_oct    	string       comment "Def(En):
Def(Th): Bonus Bucket Used ?? of October
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_oct   	string       comment "Def(En): Credit Limit  as at statement of October
Def(Th):",
	dh012_acth_avail_credit_oct   	string       comment "Def(En): Avail Credit  as at statement of October
Def(Th):",
	dh012_acth_cash_limit_oct     	string       comment "Def(En): Cash Limit  as at statement of October
Def(Th):",
	dh012_acth_avail_cash_oct     	string       comment "Def(En): Avail Cash  as at statement of October
Def(Th):",
	dh012_acth_nmbr_airline_oct   	string       comment "Def(En): Item Airline of October
Def(Th):",
	dh012_acth_amnt_airline_oct   	string       comment "Def(En): Amount Airline of October
Def(Th):",
	dh012_acth_nmbr_hotel_oct     	string       comment "Def(En): Item Hotel of October
Def(Th):",
	dh012_acth_amnt_hotel_oct     	string       comment "Def(En): Amount Hotel of October
Def(Th):",
	dh012_acth_nmbr_car_rental_oct	string       comment "Def(En): Item Car Rental of October
Def(Th):",
	dh012_acth_amnt_car_rental_oct	string       comment "Def(En): Amount Car Rental of October
Def(Th):",
	dh012_acth_nmbr_restaurant_oct	string       comment "Def(En): Item Restaurant of October
Def(Th):",
	dh012_acth_amnt_restaurant_oct	string       comment "Def(En): Amount Restaurant of October
Def(Th):",
	dh012_acth_nmbr_mail_order_oct	string       comment "Def(En): Item Mail Order of October
Def(Th):",
	dh012_acth_amnt_mail_order_oct	string       comment "Def(En): Amount Mail Order of October
Def(Th):",
	dh012_acth_nmbr_atm_cash_oct  	string       comment "Def(En): Item ATM Cash Advance of October
Def(Th):",
	dh012_acth_amnt_atm_cash_oct  	string       comment "Def(En): Amount ATM Cash Advance of October
Def(Th):",
	dh012_acth_nmbr_man_cash_oct  	string       comment "Def(En): Item Manual Cash Advance At Counter Kbank of October
Def(Th):",
	dh012_acth_amnt_man_cash_oct  	string       comment "Def(En): Amount Manual Cash Advance At Counter Kbank of October
Def(Th):",
	dh012_acth_nmbr_quasi_cash_oct	string       comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of October
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_oct	string       comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of October
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_oct   	string       comment "Def(En): Item Other Merchant of October
Def(Th):",
	dh012_acth_amnt_oth_mer_oct   	string       comment "Def(En): Amount Other Merchant of October
Def(Th):",
	dh012_acth_nmbr_retail_nov    	string       comment "Def(En): Item Retail of November
Def(Th):",
	dh012_acth_amnt_retail_nov    	string       comment "Def(En): Amount Retail of November
Def(Th):",
	dh012_acth_nmbr_ca_atm_nov    	string       comment "Def(En): Item Cash Advance AT Atm of November
Def(Th):",
	dh012_acth_amnt_ca_atm_nov    	string       comment "Def(En): Amount Cash Advance At Atm of November
Def(Th):",
	dh012_acth_nmbr_ca_man_nov    	string       comment "Def(En): Item Cash Advance AT Counter of November
Def(Th):",
	dh012_acth_amnt_ca_man_nov    	string       comment "Def(En): Amount Cash Advance At Counter of November
Def(Th):",
	dh012_acthr_interest_nov      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of November",
	dh012_acthr_curr_base_rate_nov	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of November",
	dh012_acthr_limit_1_nov       	string       comment "Def(En): Retail Limit1 of November
Def(Th):",
	dh012_acthr_limit_2_nov       	string       comment "Def(En): Retail Limit2 of November
Def(Th):",
	dh012_acthr_rate_2_nov        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of November",
	dh012_acthr_rate_3_nov        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of November",
	dh012_acthr_limit_option_nov  	string       comment "Def(En): Retail Limit Option  of November
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_nov      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of November",
	dh012_acthc_curr_base_rate_nov	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of November",
	dh012_acthc_limit_1_nov       	string       comment "Def(En): Cash Advance Limit1 of November
Def(Th):",
	dh012_acthc_limit_2_nov       	string       comment "Def(En): Cash Advance Limit2 of November
Def(Th):",
	dh012_acthc_rate_2_nov        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of November",
	dh012_acthc_rate_3_nov        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of November",
	dh012_acthc_limit_option_nov  	string       comment "Def(En): Cash Advance Limit Option of November
Def(Th):",
	dh012_acth_nmbr_annual_fee_nov	string       comment "Def(En): Item Annual Fee of November
Def(Th):",
	dh012_acth_amnt_annual_fee_nov	string       comment "Def(En): Amount Annual Fee of November
Def(Th):",
	dh012_acth_nmbr_late_chg_nov  	string       comment "Def(En): Item Late Charge of November
Def(Th):",
	dh012_acth_amnt_late_chg_nov  	string       comment "Def(En): Amount Late Charge of November
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_nov 	string       comment "Def(En): Item Over Limit Fee of November
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_nov 	string       comment "Def(En): Amount Over Limit Fee of November
Def(Th):",
	dh012_acth_nmbr_misc_chg_nov  	string       comment "Def(En): Item Miscellaneous Charge Fee of November
Def(Th):",
	dh012_acth_amnt_misc_chg_nov  	string       comment "Def(En): Amount Miscellaneous Charge Fee of November
Def(Th):",
	dh012_acth_nmbr_svc_chg_nov   	string       comment "Def(En): Item Service Charge Fee of November
Def(Th):",
	dh012_acth_amnt_svc_chg_nov   	string       comment "Def(En): Amount Service Charge Fee of November
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_nov	string       comment "Def(En): Item Cash Advance Per Fee of November
Def(Th):",
	dh012_acth_amnt_ca_per_fee_nov	string       comment "Def(En): Amount Cash Advance Per Fee of November
Def(Th):",
	dh012_acth_amnt_payment_nov   	string       comment "Def(En): Amount Payment of November
Def(Th):",
	dh012_acth_amnt_curr_bal_nov  	string       comment "Def(En): Amount Current Balance as at statement of November
Def(Th):",
	dh012_acth_bb_beg_balance_nov 	string       comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of November
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_nov  	string       comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of November
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_nov    	string       comment "Def(En):
Def(Th): Bonus Bucket Used ?? of November
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_nov   	string       comment "Def(En): Credit Limit  as at statement of November
Def(Th):",
	dh012_acth_avail_credit_nov   	string       comment "Def(En): Avail Credit  as at statement of November
Def(Th):",
	dh012_acth_cash_limit_nov     	string       comment "Def(En): Cash Limit  as at statement of November
Def(Th):",
	dh012_acth_avail_cash_nov     	string       comment "Def(En): Avail Cash  as at statement of November
Def(Th):",
	dh012_acth_nmbr_airline_nov   	string       comment "Def(En): Item Airline of November
Def(Th):",
	dh012_acth_amnt_airline_nov   	string       comment "Def(En): Amount Airline of November
Def(Th):",
	dh012_acth_nmbr_hotel_nov     	string       comment "Def(En): Item Hotel of November
Def(Th):",
	dh012_acth_amnt_hotel_nov     	string       comment "Def(En): Amount Hotel of November
Def(Th):",
	dh012_acth_nmbr_car_rental_nov	string       comment "Def(En): Item Car Rental of November
Def(Th):",
	dh012_acth_amnt_car_rental_nov	string       comment "Def(En): Amount Car Rental of November
Def(Th):",
	dh012_acth_nmbr_restaurant_nov	string       comment "Def(En): Item Restaurant of November
Def(Th):",
	dh012_acth_amnt_restaurant_nov	string       comment "Def(En): Amount Restaurant of November
Def(Th):",
	dh012_acth_nmbr_mail_order_nov	string       comment "Def(En): Item Mail Order of November
Def(Th):",
	dh012_acth_amnt_mail_order_nov	string       comment "Def(En): Amount Mail Order of November
Def(Th):",
	dh012_acth_nmbr_atm_cash_nov  	string       comment "Def(En): Item ATM Cash Advance of November
Def(Th):",
	dh012_acth_amnt_atm_cash_nov  	string       comment "Def(En): Amount ATM Cash Advance of November
Def(Th):",
	dh012_acth_nmbr_man_cash_nov  	string       comment "Def(En): Item Manual Cash Advance At Counter Kbank of November
Def(Th):",
	dh012_acth_amnt_man_cash_nov  	string       comment "Def(En): Amount Manual Cash Advance At Counter Kbank of November
Def(Th):",
	dh012_acth_nmbr_quasi_cash_nov	string       comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of November
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_nov	string       comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of November
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_nov   	string       comment "Def(En): Item Other Merchant of November
Def(Th):",
	dh012_acth_amnt_oth_mer_nov   	string       comment "Def(En): Amount Other Merchant of November
Def(Th):",
	dh012_acth_nmbr_retail_dec    	string       comment "Def(En): Item Retail of December
Def(Th):",
	dh012_acth_amnt_retail_dec    	string       comment "Def(En): Amount Retail of December
Def(Th):",
	dh012_acth_nmbr_ca_atm_dec    	string       comment "Def(En): Item Cash Advance AT Atm of December
Def(Th):",
	dh012_acth_amnt_ca_atm_dec    	string       comment "Def(En): Amount Cash Advance At Atm of December
Def(Th):",
	dh012_acth_nmbr_ca_man_dec    	string       comment "Def(En): Item Cash Advance AT Counter of December
Def(Th):",
	dh012_acth_amnt_ca_man_dec    	string       comment "Def(En): Amount Cash Advance At Counter of December
Def(Th):",
	dh012_acthr_interest_dec      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail of December",
	dh012_acthr_curr_base_rate_dec	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน of December",
	dh012_acthr_limit_1_dec       	string       comment "Def(En): Retail Limit1 of December
Def(Th):",
	dh012_acthr_limit_2_dec       	string       comment "Def(En): Retail Limit2 of December
Def(Th):",
	dh012_acthr_rate_2_dec        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2 of December",
	dh012_acthr_rate_3_dec        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3 of December",
	dh012_acthr_limit_option_dec  	string       comment "Def(En): Retail Limit Option  of December
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_dec      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance of December",
	dh012_acthc_curr_base_rate_dec	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน of December",
	dh012_acthc_limit_1_dec       	string       comment "Def(En): Cash Advance Limit1 of December
Def(Th):",
	dh012_acthc_limit_2_dec       	string       comment "Def(En): Cash Advance Limit2 of December
Def(Th):",
	dh012_acthc_rate_2_dec        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2 of December",
	dh012_acthc_rate_3_dec        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3 of December",
	dh012_acthc_limit_option_dec  	string       comment "Def(En): Cash Advance Limit Option of December
Def(Th):",
	dh012_acth_nmbr_annual_fee_dec	string       comment "Def(En): Item Annual Fee of December
Def(Th):",
	dh012_acth_amnt_annual_fee_dec	string       comment "Def(En): Amount Annual Fee of December
Def(Th):",
	dh012_acth_nmbr_late_chg_dec  	string       comment "Def(En): Item Late Charge of December
Def(Th):",
	dh012_acth_amnt_late_chg_dec  	string       comment "Def(En): Amount Late Charge of December
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_dec 	string       comment "Def(En): Item Over Limit Fee of December
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_dec 	string       comment "Def(En): Amount Over Limit Fee of December
Def(Th):",
	dh012_acth_nmbr_misc_chg_dec  	string       comment "Def(En): Item Miscellaneous Charge Fee of December
Def(Th):",
	dh012_acth_amnt_misc_chg_dec  	string       comment "Def(En): Amount Miscellaneous Charge Fee of December
Def(Th):",
	dh012_acth_nmbr_svc_chg_dec   	string       comment "Def(En): Item Service Charge Fee of December
Def(Th):",
	dh012_acth_amnt_svc_chg_dec   	string       comment "Def(En): Amount Service Charge Fee of December
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_dec	string       comment "Def(En): Item Cash Advance Per Fee of December
Def(Th):",
	dh012_acth_amnt_ca_per_fee_dec	string       comment "Def(En): Amount Cash Advance Per Fee of December
Def(Th):",
	dh012_acth_amnt_payment_dec   	string       comment "Def(En): Amount Payment of December
Def(Th):",
	dh012_acth_amnt_curr_bal_dec  	string       comment "Def(En): Amount Current Balance as at statement of December
Def(Th):",
	dh012_acth_bb_beg_balance_dec 	string       comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ?? of December
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_dec  	string       comment "Def(En):
Def(Th): Bonus Bucket Earn ?? of December
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_dec    	string       comment "Def(En):
Def(Th): Bonus Bucket Used ?? of December
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_dec   	string       comment "Def(En): Credit Limit  as at statement of December
Def(Th):",
	dh012_acth_avail_credit_dec   	string       comment "Def(En): Avail Credit  as at statement of December
Def(Th):",
	dh012_acth_cash_limit_dec     	string       comment "Def(En): Cash Limit  as at statement of December
Def(Th):",
	dh012_acth_avail_cash_dec     	string       comment "Def(En): Avail Cash  as at statement of December
Def(Th):",
	dh012_acth_nmbr_airline_dec   	string       comment "Def(En): Item Airline of December
Def(Th):",
	dh012_acth_amnt_airline_dec   	string       comment "Def(En): Amount Airline of December
Def(Th):",
	dh012_acth_nmbr_hotel_dec     	string       comment "Def(En): Item Hotel of December
Def(Th):",
	dh012_acth_amnt_hotel_dec     	string       comment "Def(En): Amount Hotel of December
Def(Th):",
	dh012_acth_nmbr_car_rental_dec	string       comment "Def(En): Item Car Rental of December
Def(Th):",
	dh012_acth_amnt_car_rental_dec	string       comment "Def(En): Amount Car Rental of December
Def(Th):",
	dh012_acth_nmbr_restaurant_dec	string       comment "Def(En): Item Restaurant of December
Def(Th):",
	dh012_acth_amnt_restaurant_dec	string       comment "Def(En): Amount Restaurant of December
Def(Th):",
	dh012_acth_nmbr_mail_order_dec	string       comment "Def(En): Item Mail Order of December
Def(Th):",
	dh012_acth_amnt_mail_order_dec	string       comment "Def(En): Amount Mail Order of December
Def(Th):",
	dh012_acth_nmbr_atm_cash_dec  	string       comment "Def(En): Item ATM Cash Advance of December
Def(Th):",
	dh012_acth_amnt_atm_cash_dec  	string       comment "Def(En): Amount ATM Cash Advance of December
Def(Th):",
	dh012_acth_nmbr_man_cash_dec  	string       comment "Def(En): Item Manual Cash Advance At Counter Kbank of December
Def(Th):",
	dh012_acth_amnt_man_cash_dec  	string       comment "Def(En): Amount Manual Cash Advance At Counter Kbank of December
Def(Th):",
	dh012_acth_nmbr_quasi_cash_dec	string       comment "Def(En):
Def(Th): Item Quasi Cash Advance ?? of December
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_dec	string       comment "Def(En):
Def(Th): Amount Quasi Cash Advance ?? of December
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_dec   	string       comment "Def(En): Item Other Merchant of December
Def(Th):",
	dh012_acth_amnt_oth_mer_dec   	string       comment "Def(En): Amount Other Merchant of December
Def(Th):",
	dh012_acth_nmbr_retail_12m    	string       comment "Def(En): Item Retail
Def(Th):",
	dh012_acth_amnt_retail_12m    	string       comment "Def(En): Amount Retail
Def(Th):",
	dh012_acth_nmbr_ca_atm_12m    	string       comment "Def(En): Item Cash Advance AT Atm
Def(Th):",
	dh012_acth_amnt_ca_atm_12m    	string       comment "Def(En): Amount Cash Advance At Atm
Def(Th):",
	dh012_acth_nmbr_ca_man_12m    	string       comment "Def(En): Item Cash Advance AT Counter
Def(Th):",
	dh012_acth_amnt_ca_man_12m    	string       comment "Def(En): Amount Cash Advance At Counter
Def(Th):",
	dh012_acthr_interest_12m      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Retail",
	dh012_acthr_curr_base_rate_12m	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail ปัจจุบัน",
	dh012_acthr_limit_1_12m       	string       comment "Def(En): Retail Limit1
Def(Th):",
	dh012_acthr_limit_2_12m       	string       comment "Def(En): Retail Limit2
Def(Th):",
	dh012_acthr_rate_2_12m        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-2",
	dh012_acthr_rate_3_12m        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Retail-3",
	dh012_acthr_limit_option_12m  	string       comment "Def(En): Retail Limit Option 
(PCIT Page8)
SPLIT-RTLCSH-MULTIRATE     VALUE 0
SPLIT-RTLCSH-1RATE         VALUE 1
COMB-RTLCSH-1RATE          VALUE 2
Def(Th):",
	dh012_acthc_interest_12m      	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยของ Cash Advance",
	dh012_acthc_curr_base_rate_12m	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance ปัจจุบัน",
	dh012_acthc_limit_1_12m       	string       comment "Def(En): Cash Advance Limit1
Def(Th):",
	dh012_acthc_limit_2_12m       	string       comment "Def(En): Cash Advance Limit2
Def(Th):",
	dh012_acthc_rate_2_12m        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-2",
	dh012_acthc_rate_3_12m        	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ยของ Cash Advance-3",
	dh012_acthc_limit_option_12m  	string       comment "Def(En): Cash Advance Limit Option
Def(Th):",
	dh012_acth_nmbr_annual_fee_12m	string       comment "Def(En): Item Annual Fee
Def(Th):",
	dh012_acth_amnt_annual_fee_12m	string       comment "Def(En): Amount Annual Fee
Def(Th):",
	dh012_acth_nmbr_late_chg_12m  	string       comment "Def(En): Item Late Charge
Def(Th):",
	dh012_acth_amnt_late_chg_12m  	string       comment "Def(En): Amount Late Charge
Def(Th):",
	dh012_acth_nmbr_ovlmt_fee_12m 	string       comment "Def(En): Item Over Limit Fee
Def(Th):",
	dh012_acth_amnt_ovlmt_fee_12m 	string       comment "Def(En): Amount Over Limit Fee
Def(Th):",
	dh012_acth_nmbr_misc_chg_12m  	string       comment "Def(En): Item Miscellaneous Charge Fee
Def(Th):",
	dh012_acth_amnt_misc_chg_12m  	string       comment "Def(En): Amount Miscellaneous Charge Fee
Def(Th):",
	dh012_acth_nmbr_svc_chg_12m   	string       comment "Def(En): Item Service Charge Fee
Def(Th):",
	dh012_acth_amnt_svc_chg_12m   	string       comment "Def(En): Amount Service Charge Fee
Def(Th):",
	dh012_acth_nmbr_ca_per_fee_12m	string       comment "Def(En): Item Cash Advance Per Fee
Def(Th):",
	dh012_acth_amnt_ca_per_fee_12m	string       comment "Def(En): Amount Cash Advance Per Fee
Def(Th):",
	dh012_acth_amnt_payment_12m   	string       comment "Def(En): Amount Payment
Def(Th):",
	dh012_acth_amnt_curr_bal_12m  	string       comment "Def(En): Amount Current Balance as at statement
Def(Th):",
	dh012_acth_bb_beg_balance_12m 	string       comment "Def(En):
Def(Th): Bonus Bucket Begin Balance ??
(Kbank not use)
คะแนนคงเหลือ",
	dh012_acth_bb_earned_ctd_12m  	string       comment "Def(En):
Def(Th): Bonus Bucket Earn ??
(Kbank not use)
คะแนนที่ได้รับ",
	dh012_acth_bb_used_ctd_12m    	string       comment "Def(En):
Def(Th): Bonus Bucket Used ??
(Kbank not use)
คะแนนที่ใช้ไป",
	dh012_acth_credit_limit_12m   	string       comment "Def(En): Credit Limit  as at statement
Def(Th):",
	dh012_acth_avail_credit_12m   	string       comment "Def(En): Avail Credit  as at statement
Def(Th):",
	dh012_acth_cash_limit_12m     	string       comment "Def(En): Cash Limit  as at statement
Def(Th):",
	dh012_acth_avail_cash_12m     	string       comment "Def(En): Avail Cash  as at statement
Def(Th):",
	dh012_acth_nmbr_airline_12m   	string       comment "Def(En): Item Airline
Def(Th):",
	dh012_acth_amnt_airline_12m   	string       comment "Def(En): Amount Airline
Def(Th):",
	dh012_acth_nmbr_hotel_12m     	string       comment "Def(En): Item Hotel
Def(Th):",
	dh012_acth_amnt_hotel_12m     	string       comment "Def(En): Amount Hotel
Def(Th):",
	dh012_acth_nmbr_car_rental_12m	string       comment "Def(En): Item Car Rental
Def(Th):",
	dh012_acth_amnt_car_rental_12m	string       comment "Def(En): Amount Car Rental
Def(Th):",
	dh012_acth_nmbr_restaurant_12m	string       comment "Def(En): Item Restaurant
Def(Th):",
	dh012_acth_amnt_restaurant_12m	string       comment "Def(En): Amount Restaurant
Def(Th):",
	dh012_acth_nmbr_mail_order_12m	string       comment "Def(En): Item Mail Order
Def(Th):",
	dh012_acth_amnt_mail_order_12m	string       comment "Def(En): Amount Mail Order
Def(Th):",
	dh012_acth_nmbr_atm_cash_12m  	string       comment "Def(En): Item ATM Cash Advance
Def(Th):",
	dh012_acth_amnt_atm_cash_12m  	string       comment "Def(En): Amount ATM Cash Advance
Def(Th):",
	dh012_acth_nmbr_man_cash_12m  	string       comment "Def(En): Item Manual Cash Advance At Counter Kbank
Def(Th):",
	dh012_acth_amnt_man_cash_12m  	string       comment "Def(En): Amount Manual Cash Advance At Counter Kbank
Def(Th):",
	dh012_acth_nmbr_quasi_cash_12m	string       comment "Def(En):
Def(Th): Item Quasi Cash Advance ??
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_amnt_quasi_cash_12m	string       comment "Def(En):
Def(Th): Amount Quasi Cash Advance ??
กลุ่ม MCC ร้านค้าเสมือนเงินสด",
	dh012_acth_nmbr_oth_mer_12m   	string       comment "Def(En): Item Other Merchant
Def(Th):",
	dh012_acth_amnt_oth_mer_12m   	string       comment "Def(En): Amount Other Merchant
Def(Th):",
	dh012_d_filler                	string       comment "Def(En): Space
Def(Th):",
	load_tms                      	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                    	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                      	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                        	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                        	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink/cardlink_kb1dh012_cpcah' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);