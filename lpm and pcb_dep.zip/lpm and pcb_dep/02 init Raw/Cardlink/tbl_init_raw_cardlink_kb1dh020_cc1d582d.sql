-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cardlink_kb1dh020_cc1d582d.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK.CARDLINK_KB1DH020_CC1D582D
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink.cardlink_kb1dh020_cc1d582d (
	pos_dt                           	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh020_d582_batch_proc_date_ymd   	string       comment "Def(En):
Def(Th): วันที่ของข้อมูล",
	dh020_d582_create_date_ymd       	string       comment "Def(En):
Def(Th): วันที่สร้างไฟล์",
	dh020_d582_merchant_file_date_ymd	string       comment "Def(En):
Def(Th): วันที่ทำรายการที่ร้านค้า",
	dh020_d582_merchant_id           	string       comment "Def(En):
Def(Th): รหัสร้านค้า",
	dh020_d582_merchant_name         	string       comment "Def(En):
Def(Th): ชื่อร้านค้า",
	dh020_d582_owner_ind             	string       comment "Def(En): Owner ID
Def(Th):",
	dh020_d582_terminal_no           	string       comment "Def(En): Terminal no.
Def(Th):",
	dh020_d582_batch_no              	string       comment "Def(En): Batch no.
Def(Th):",
	dh020_d582_trans_seq_no          	string       comment "Def(En): Transaction Seq No.
Def(Th):",
	dh020_d582_trans_code            	string       comment "Def(En): Transaction Code
Def(Th):",
	dh020_d582_trans_date            	string       comment "Def(En):
Def(Th): วันที่ทำรายการ",
	dh020_d582_trans_time            	string       comment "Def(En):
Def(Th): เวลาที่ทำรายการ HH:MM",
	dh020_d582_vs_mc_acct_no         	string       comment "Def(En):
Def(Th): Visa Mastercard account no.
เลขที่บัญชีที่ร้านค้าลงทะเบียนกับทาง Visa, Mastercard",
	dh020_d582_cd_acct_no            	string       comment "Def(En):
Def(Th): Kbank Credit card account no.
เลขที่บัญชี KBank",
	dh020_d582_vs_comm_rate          	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Visa",
	dh020_d582_mc_comm_rate          	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Mastercard",
	dh020_d582_cd_comm_rate          	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Credit card",
	dh020_d582_card_no               	string       comment "Def(En): Card Number
Def(Th):",
	dh020_d582_trans_amount          	string       comment "Def(En): Transaction amount
Def(Th):",
	dh020_d582_card_id_method        	string       comment "Def(En):
Def(Th): Card ID Method Flag การคิดดอกเบี้ยของเครื่องรูด",
	dh020_d582_acct_data_source_code 	string       comment "Def(En):
Def(Th): แหล่งที่มาของข้อมูล",
	dh020_d582_auth_source_code      	string       comment "Def(En):
Def(Th): รหัสของแหล่งข้อมูลที่ขอ Authorize",
	dh020_d582_auth_no               	string       comment "Def(En): Authorize no.
Def(Th):",
	dh020_d582_system_code           	string       comment "Def(En): System code
Def(Th):",
	dh020_d582_user_code_3           	string       comment "Def(En): User code3
Def(Th):",
	dh020_d582_branch                	string       comment "Def(En):
Def(Th): รหัสสาขา",
	dh020_d582_cc1p554_flag          	string       comment "Def(En):
Def(Th): Flag แสดงสถานะของรายงาน CC1P554
Flag บอกว่าร้านค้านี้ จำเป็นต้องออกรายงานนี้หรือไม่ค่ะ",
	dh020_d582_cc1p584_flag          	string       comment "Def(En):
Def(Th): Flag แสดงสถานะของรายงาน CC1P584
Flag บอกว่าร้านค้านี้ จำเป็นต้องออกรายงานนี้หรือไม่ค่ะ",
	dh020_d582_ve_comm_rate          	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Visa Electron",
	dh020_d582_orig_amount           	string       comment "Def(En): Original amount
Def(Th):",
	dh020_d582_curr_code             	string       comment "Def(En): Currency code
Def(Th):",
	dh020_d582_ec_comm_rate          	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Electronic Cashcard บัตรธรรมดา",
	dh020_d582_ecom_transfer_flag    	string       comment "Def(En): E-Commerce transfer flag
Def(Th):",
	dh020_d582_ecom_mall_comm_rate   	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Electronic card (Rate ของร้าน ECOM ซึ่งแต่ละร้านจะไม่เหมือนกัน)",
	dh020_d582_ec_card_user_code     	string       comment "Def(En): User code of Electronic card
Def(Th):",
	dh020_d582_ec_card_per_trans     	string       comment "Def(En): Per trans of Electronic card
Def(Th):",
	dh020_d582_ec_card_bull_cost     	string       comment "Def(En): Bullatin cost of Electronic card
Def(Th): ต้นทุนของบัตร Electronic Cash  Card",
	dh020_d582_user_code_1           	string       comment "Def(En): User code1
Def(Th):",
	dh020_d582_merch_cepp            	string       comment "Def(En): Merchant Cepp 
Flag
Def(Th): Merchant Cepp 
Flag บอกว่าเป็นร้านค้า Installment หรือไม่",
	dh020_d582_mmd_merch_type        	string       comment "Def(En): Merchant Type
Def(Th):",
	dh020_d582_mmd_pos_mode          	string       comment "Def(En): Pos mode
Def(Th):",
	dh020_d582_mmd_mail_phone_ind    	string       comment "Def(En):
Def(Th): Flag บอกว่าร้านค้านี้ทำ Recurring ได้หรือไม่",
	dh020_d582_purcase_card_flag     	string       comment "Def(En):
Def(Th): Purchase card flag",
	dh020_d582_vs_on_comm_rate       	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Visa onus",
	dh020_d582_vs_lo_comm_rate       	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Visa local",
	dh020_d582_vs_in_comm_rate       	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Visa inter",
	dh020_d582_vs_plt_comm_rate      	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Visa platinium",
	dh020_d582_vs_pli_comm_rate      	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Visa platinium inter",
	dh020_d582_mc_on_comm_rate       	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Mastercard onus",
	dh020_d582_mc_lo_comm_rate       	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Mastercard local",
	dh020_d582_mc_in_comm_rate       	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Mastercard inter",
	dh020_d582_mc_plt_comm_rate      	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Mastercard platinium",
	dh020_d582_mc_pli_comm_rate      	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Mastercard platinium inter",
	dh020_d582_purc_comm_rate        	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของ Purchase",
	dh020_d582_curr_rate             	string       comment "Def(En): Currency rate
Def(Th):",
	dh020_d582_work_digit            	string       comment "Def(En): Work digit
Def(Th): ทศนิยมของเงินสกุลว่ามีกี่ตำแหน่ง",
	dh020_d582_vs_plt_status         	string       comment "Def(En): Visa platinium Status
Def(Th): Status บอกว่ารับบัตร Visa Platinum หรือไม่",
	dh020_d582_mc_plt_status         	string       comment "Def(En): Mastercard platinium Status 
Def(Th): Status บอกว่ารับบัตร MC Platinum หรือไม่",
	dh020_d582_card_type             	string       comment "Def(En): Card type 
Def(Th): ประเภทของบัตร  ที่อยู่ใน List 15 Occur
ใช้สำหรับกำหนดประเภทของบัตร สำหรับAcquire  เช่นเป็นบัตร TFB, Kbank Visa, Kbank MC เป็นต้น",
	dh020_d582_mmd_comm_rate         	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร MMD 
Commission Rate ของร้านค้า",
	dh020_d582_ec_card_per_trans2    	string       comment "Def(En): Electronic card per tran 
Def(Th): จำนวนเงินค่าธรรมเนียมแบบ Per Transaction ของบัตร Electronic Cash Card",
	dh020_d582_jcb_status            	string       comment "Def(En): JCB status
Def(Th): Status บอกว่ารับบัตร JCB หรือไม่",
	dh020_d582_jcb_lo_comm_rate      	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร JCB local",
	dh020_d582_jcb_in_comm_rate      	string       comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร JCB inter",
	dh020_d582_d584_tax_id           	string       comment "Def(En): Tax ID
Def(Th): Tax ID ของร้านค้า",
	dh020_d582_card_user_code        	string       comment "Def(En): User Code
Def(Th): User Code ของร้านค้า ที่บอกว่ารับบัตรประเภทอะไรบ้าง",
	dh020_d582_card_per_trans        	string       comment "Def(En): Charge commision Fee Per transaction
Def(Th):",
	dh020_d582_rec_of_charge         	string       comment "Def(En): Record of Charge
Def(Th):",
	dh020_d582_vs_pli_status         	string       comment "Def(En): Visa Platinum Inter Status
Def(Th):",
	dh020_d582_mc_pli_status         	string       comment "Def(En): Mastercard Platinum inter status
Def(Th):",
	dh020_d582_robinson_flag         	string       comment "Def(En):
Def(Th): Flag บอกว่าเป็นบัตร Robinson หรือไม่",
	dh020_d_filler                   	string       comment "Def(En): Space
Def(Th):",
	load_tms                         	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                       	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                         	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                           	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                           	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink/cardlink_kb1dh020_cc1d582d' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);