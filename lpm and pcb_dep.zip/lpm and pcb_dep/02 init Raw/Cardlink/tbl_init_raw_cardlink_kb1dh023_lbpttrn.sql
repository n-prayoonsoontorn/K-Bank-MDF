-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cardlink_kb1dh023_lbpttrn.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK.CARDLINK_KB1DH023_LBPTTRN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink.cardlink_kb1dh023_lbpttrn (
	pos_dt                     	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh023_lbuim_t_batch_nbr    	string       comment "Def(En): 
Def(Th): หมายเลข Batch Number ที่ Post รายการนี้",
	dh023_lbuim_t_seq_nbr      	string       comment "Def(En): 
Def(Th): Sequen Number ที่ Post รายการนี้",
	dh023_lbuim_t_cardhld_org  	string       comment "Def(En): Org Number
Def(Th):",
	dh023_lbuim_t_cardhld_type 	string       comment "Def(En): Type CLCB Number
Def(Th):",
	dh023_lbuim_t_cardhld_nbr  	string       comment "Def(En): Card Number
Def(Th):",
	dh023_lbuim_t_code         	string       comment "Def(En): Trans Code
Def(Th):",
	dh023_lbuim_t_desc         	string       comment "Def(En): Description ชื่อรายการ Post Point
Def(Th):",
	dh023_lbuim_t_instl_ind    	string       comment "Def(En): Installment Indicator
Def(Th):",
	dh023_lbuim_t_prod_cd      	string       comment "Def(En): Product Code
Def(Th):",
	dh023_lbuim_t_time         	string       comment "Def(En): Time
Def(Th):",
	dh023_lbuim_t_date         	string       comment "Def(En): Transaction Date
Def(Th):",
	dh023_lbuim_t_post_date    	string       comment "Def(En): 
Def(Th): วันที่ Post Point เข้าระบบ",
	dh023_lbuim_t_points       	string       comment "Def(En): 
Def(Th): จำนวนคะแนนที่ได้รับ",
	dh023_lbuim_t_amount       	string       comment "Def(En): 
Def(Th): จำนวนเงินของรายการสินค้า",
	dh023_lbuim_t_mcc          	string       comment "Def(En): MCC CODE
Def(Th):",
	dh023_lbuim_t_reference    	string       comment "Def(En): Reference 
Def(Th):",
	dh023_lbuim_t_source_id    	string       comment "Def(En): 
Def(Th): แหล่งที่นำมาเข้า Point",
	dh023_lbuim_t_operator     	string       comment "Def(En): Operator Code
Def(Th):",
	dh023_lbuim_t_partner_id   	string       comment "Def(En): Partner ID
Def(Th):",
	dh023_lbuim_t_program_id   	string       comment "Def(En): Program Point ID
Def(Th):",
	dh023_lbuim_t_merchant_org 	string       comment "Def(En): Merchant Org
Def(Th):",
	dh023_lbuim_t_merchant_nbr 	string       comment "Def(En): Merchant Number
Def(Th):",
	dh023_lbuim_t_dba_country  	string       comment "Def(En): Country Code
Def(Th):",
	dh023_lbuim_t_redm_amount  	string       comment "Def(En): Redeem Amount
Def(Th):",
	dh023_lbuim_t_prod_name_ext	string       comment "Def(En): Product Name Extend
Def(Th):",
	dh023_lbuim_t_auth_code    	string       comment "Def(En): Authorize Code
Def(Th):",
	dh023_lbuim_t_item         	string       comment "Def(En): 
Def(Th): จำนวนรายการที่นำมาคำนวนPoint",
	dh023_rquid                	string       comment "Def(En): 
Def(Th): หมายเลข  RQUID 
เฉพาะ  function  2 (Redeem) ,3 (Adjust)",
	dh023_trans_id             	string       comment "Def(En): 
Def(Th): หมายเลข  Trans_ID  
 เฉพาะ  function  2 (Redeem) ,3 (Adjust)",
	load_tms                   	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                 	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                   	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                     	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                     	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink/cardlink_kb1dh023_lbpttrn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);