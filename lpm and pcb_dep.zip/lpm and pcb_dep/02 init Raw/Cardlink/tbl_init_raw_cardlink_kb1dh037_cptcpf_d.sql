-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cardlink_kb1dh037_cptcpf_d.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK.CARDLINK_KB1DH037_CPTCPF_D
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink.cardlink_kb1dh037_cptcpf_d (
	pos_dt                  	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh037_d_record_nbr      	string       comment "Def(En): Record number in maintenance file
Def(Th):",
	dh037_d_org             	string       comment "Def(En): Organization 
001 : Credit Card
200 : KEC
Def(Th):",
	dh037_d_type            	string       comment "Def(En): Card Type
000 :- detail record of Customer 
Not equal 000 :- detail record of CardHolder
Def(Th):",
	dh037_d_carriage_control	string       comment "Def(En): Carriage control
0 :- CPCCPF-TOP-OF-PAGE 
1 , 4 THRU 9 :- SKIP-1-LINE
2 :- SKIP-2-LINES
3 :- SKIP-3-LINES
Def(Th):",
	dh037_d_cust_card_no    	string       comment "Def(En): Customer no. or Cardholder no.
Def(Th): Customer no. or Cardholder no.  มีทุกบรรทัด และฟิลด์นี้จะมีค่าเป็น Customer no. or Cardholder no. โดยพิจารณาจาก 
ถ้า Card type เท่ากับ 000 ฟิลด์นี้คือ Customer no.
ถ้า Card type ไม่เท่ากับ 000 ฟิลด์นี้คือ Cardholder no.",
	dh037_d_maint_no        	string       comment "Def(En): Maintenance no.
Def(Th): Maintenance no.
คือ transaction code  ในมุมของรายการที่มีการเปลี่ยนแปลง
ให้ดูรายละเอียด Mapping maintenance no. & Maintenace description ในไฟล์แนบ 
ฟิลด์นี้จะมีค่าเป็น space แต่เฉพาะกรณีที่ MAINT-DESC มีค่าเป็น 'DATE LAST MAINT'",
	dh037_d_maint_desc      	string       comment "Def(En): Maintenance description
DATE LAST MAINT
Def(Th): Maintenance description
DATE LAST MAINT : แสดงรายละเอียดว่า date last maintenance คือ วันที่เท่าไร
**NO FIELD CHANGES** :- คือ มีการ maintenance ฟิลด์บางส่วน แต่ฟิลด์นั้นไม่ได้ถูกกำหนดเป็นชื่อฟิลด์ที่แยกออกมาต่างหาก จึงไม่สามารถ identify ได้ว่า maintenance field อะไร",
	dh037_d_maint_old_data  	string       comment "Def(En): Old Maintenance Data
Def(Th): Old Maintenance Data  
Cardlink  จะส่งข้อมูลตามจริง จะไม่ได้มีการ reformat data  เช่น ฟิลด์นั้นเก็บข้อมูลเป็นวันที่ format เป็น DD/MM/YYYY ข้อมูลที่ส่งให้ จะไม่ทำการ reformat date เป็น YYYY-MM-DD",
	dh037_d_maint_new_data  	string       comment "Def(En): New Maintenance Data
Def(Th): New Maintenance Data
Cardlink  จะส่งข้อมูลตามจริง จะไม่ได้มีการ reformat data  เช่น ฟิลด์นั้นเก็บข้อมูลเป็นวันที่ format เป็น DD/MM/YYYY ข้อมูลที่ส่งให้ จะไม่ทำการ reformat date เป็น YYYY-MM-DD",
	dh037_d_maint_user      	string       comment "Def(En): Maintenance User
Def(Th): Maintenance User 
คนที่  log on  เข้ามาแก้ไข หรือ ชื่อโปรแกรมที่แก้ไข
ซึ่งฟิลด์นี้จะมีข้อมูลก็ต่อเมื่อ ฟิลด์ MAINT-DESC มีค่าเป็น 'DATE LAST MAINT' และ 
MAINT-NO มีค่าเป็น space",
	dh037_d_action          	string       comment "Def(En):
Def(Th): ACTION
- ADD   
- UPD   (Updted)
- Space : ฟิลด์นี้จะเป็น space ก็ต่อเมื่อ ฟิลด์ MAINT-NO มีค่าเป็น space",
	dh037_d_source_code     	string       comment "Def(En): Source code
L : Local Input  maintainace
U : User Input  
Def(Th): Source code 
L : Local Input  maintainace  ผ่าน  screen
U : User Input ผ่าน  UI
Space : ฟิลด์นี้จะเป็น space ก็ต่อเมื่อ ฟิลด์ MAINT-NO มีค่าเป็น space",
	dh037_d_term_id         	string       comment "Def(En): Terminal ID 
Def(Th): Terminal ID 
ฟิลด์นี้จะเป็น space ก็ต่อเมื่อ ฟิลด์ MAINT-NO มีค่าเป็น space",
	dh037_d_maint_date      	string       comment "Def(En): Maintenance Date
Def(Th): Maintenance Date
ฟิลด์นี้จะเป็น space ก็ต่อเมื่อ ฟิลด์ MAINT-NO มีค่าเป็น space",
	dh037_d_maint_time      	string       comment "Def(En): Maintenance Time
Def(Th): Maintenance Time
ฟิลด์นี้จะเป็น space ก็ต่อเมื่อ ฟิลด์ MAINT-NO มีค่าเป็น space",
	dh037_d_seq_no          	string       comment "Def(En):
Def(Th): เบอร์  sequence  ของรายการ",
	load_tms                	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id              	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                  	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                  	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink/cardlink_kb1dh037_cptcpf_d' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);