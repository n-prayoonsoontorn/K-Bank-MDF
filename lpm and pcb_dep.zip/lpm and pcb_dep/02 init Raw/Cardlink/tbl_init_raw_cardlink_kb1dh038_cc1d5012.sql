-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cardlink_kb1dh038_cc1d5012.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK.CARDLINK_KB1DH038_CC1D5012
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink.cardlink_kb1dh038_cc1d5012 (
	pos_dt              	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh038_proc_date     	string       comment "Def(En): PROCESSING DATE 
Def(Th): วันทีทำรายการ",
	dh038_source_code1  	string       comment "Def(En): SOURCE-CODE1
Def(Th):",
	dh038_source_code2  	string       comment "Def(En): SOURCE-CODE2 
Def(Th):",
	dh038_trans_date    	string       comment "Def(En): TRANSACTION DATE
Def(Th):",
	dh038_card_no       	string       comment "Def(En): CARD NUMBER
Def(Th):",
	dh038_auth_no       	string       comment "Def(En): Authorization Number
Def(Th):",
	dh038_txn_amt       	string       comment "Def(En): ORIGINAL TRANSACTION AMOUNT
Def(Th):",
	dh038_txn_curr_code 	string       comment "Def(En): TRANSACTION CURRENCY CODE
Def(Th):",
	dh038_trans_amt     	string       comment "Def(En): TRANSACTION AMOUNT
Def(Th): TRANSACTION AMOUNT (เรียกเก็บเป็น THB BAHT)",
	dh038_curr_code     	string       comment "Def(En): CURRENCY CODE
Def(Th): สกุลเงินที่เรียกเก็บ ณ ปัจจุบันเป็นเรียกเก็บเป็น THB BAHT ดังนั้นฟิลด์นี้จึงมีค่าเป็น 764",
	dh038_trans_dest_amt	string       comment "Def(En): Transaction destination
Def(Th):",
	dh038_dest_curr_code	string       comment "Def(En): DESTINATION CURRENCY-CODED 
- 764 : ฟิลด์นี้จะมีค่าเป็น 764 เมื่อเป็นรายการจาก EDC Kbank (Source code มีเท่ากับ 'EDC')
- space : ฟิลด์นี้จะมีค่าเป็น space เมื่อไม่ใช่รายการที่ไม่ใช่มาจาก EDC
Def(Th):",
	dh038_acq_ref_nbr   	string       comment "Def(En): Acquire Reference Number
Def(Th):",
	dh038_merch_id      	string       comment "Def(En): MERCHARNT ID
Def(Th):",
	dh038_merch_name    	string       comment "Def(En): MERCHARNT NAME 
Def(Th):",
	dh038_merch_city    	string       comment "Def(En): MERCHARNT-CITY
Def(Th):",
	dh038_merch_country 	string       comment "Def(En): MERCHARNT-COUNTRY
Def(Th):",
	filler1             	string       comment "Def(En): Spaces
Def(Th):",
	dh038_trans_channel 	string       comment "Def(En): Transaction Channel 
 Def(Th):",
	dh038_type_card     	string       comment "Def(En): Type Card
Def(Th):",
	dh038_tr_code       	string       comment "Def(En): Transaction code
Def(Th):",
	dh038_merch_cat     	string       comment "Def(En): MERCHARNT CATEGORY  MCC Code (00+D581-TRANS-CODE) จากไฟล์
(EDC-TRANS-FILE)CC1D581
Def(Th):",
	dh038_random_id     	string       comment "Def(En): Random ID (encryption card number)
Def(Th):",
	filler2             	string       comment "Def(En): Spaces
Def(Th):",
	load_tms            	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id          	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy            	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm              	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd              	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink/cardlink_kb1dh038_cc1d5012' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);