-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cardlink_kb1dh045_cc1d289g.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK.CARDLINK_KB1DH045_CC1D289G
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink.cardlink_kb1dh045_cc1d289g (
	pos_dt                      	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh045_card_nmbr             	string       comment "Def(En):
Def(Th): หมายเลขบัตรเครดิต",
	dh045_cust_nmbr             	string       comment "Def(En):
Def(Th): หมายเลขประจำตัวลูกค้ากรณีเป็นบัตรเสริมจะเป็นหมายเลข Customer เสริม (ALT-Customer)",
	dh045_card_flag             	string       comment "Def(En):
Def(Th): ประเภทของบัตรเครดิต  0=บัตรหลัก  ,1=บัตรเสริม",
	dh045_cancel_flag           	string       comment "Def(En):
Def(Th): สถานะของบัตรเครดิต
0 = บัตรใช้ได้ (นอกเหนือ Block ดังนี้ 
'E' 'F' 'D' 'S' 'L''W' 'B' 'Z' 'Y' 'O' 'U'
'K' 'X' 'M' 'I' 'A' 'J'.)
1 = บัตรใช้ไม่ได้ (Block เท่ากับ 'E' 'F' 'D' 'S' 'L'
'W' 'B' 'Z' 'Y' 'O' 'U''K' 'X' 'M' 'I' 'A' 'J'.)
2 = บัตรที่ระงับการสร้าง statement (cm-stmt-freq = 60 (60 รอบ Statement = 5 ปี))",
	dh045_main_cust_nmbr        	string       comment "Def(En):
Def(Th): 1)หมายเลขประจำตัวลูกค้าบัตรหลักกรณีที่หมายเลขบัตรเครดิตเป็นบัตรเสริม
2)กรณีที่หมายเลขบัตรเครดิตเป็นบัตรหลักจะมีค่าเป็น 0",
	dh045_cust_title            	string       comment "Def(En):
Def(Th): คำนำหน้าชื่อลูกค้าภาษาไทย",
	dh045_cust_name             	string       comment "Def(En):
Def(Th): ชื่อลูกค้าภาษาไทย",
	dh045_crlimit               	string       comment "Def(En):
Def(Th): วงเงินของบัตรเครดิต/XPC",
	dh045_curr_bal              	string       comment "Def(En):
Def(Th): ยอดหนี้คงค้างทั้งหมด (เงินต้น,ดอกเบี้ย,ค่าธรรมเนียม)",
	dh045_pay_cycle             	string       comment "Def(En):
Def(Th): ยอดชำระหลังจาก Cycle ล่าสุดจนถึงปัจจุบัน
(สูตร CM-RTL-PYMT-CTD + CM-CASH-PYMT-CTD) 
(มีค่าเฉพาะลูกค้าที่ cancel-flag = 2 นอกนั้นจะมีค่าเป็น 0)",
	dh045_cycle                 	string       comment "Def(En):
Def(Th): รอบการตัดยอดบัตรเครดิตประกอบด้วย
รอบบัตรเครดิต วันที่ 5,10,17,20,25,31 (สิ้นเดือน)
รอบ XPC วันที่ 2, 8, 13, 18, 23, 27",
	dh045_int_type              	string       comment "Def(En):
Def(Th): 0=คิดดอกเบี้ย (ไม่เท่ากับ 'A' 'B' 'W'  'Z'  'K'  'M')
,1=พักดอกเบี้ย  ('A' 'B' 'W'  'Z'  'K'  'M')",
	dh045_branch_no             	string       comment "Def(En):
Def(Th): รหัสสาขา",
	dh045_approve_id            	string       comment "Def(En):
Def(Th): รหัสประจำตัวพนักงานผู้อนุมัติ",
	dh045_date_last_payment_ymd 	string       comment "Def(En):
Def(Th): วันที่มียอดชำระครั้งสุดท้าย (ปีเดือนวัน)",
	dh045_collection_flag       	string       comment "Def(En):
Def(Th): ประเภทหนี้ของบัตรเครดิต (มาจาก USER-CODE-3(จัดชั้นหนี้ของลูกค้า) ตำแหน่งแรก)
ACCT-IN-CC             VALUE '0'.           
ACCT-IN-LCR           VALUE '1'.           
ACCT-IN-OTH           VALUE 'A' 'B' 'C' '8'",
	dh045_block_date_ymd        	string       comment "Def(En):
Def(Th): วันที่ Block บัตรเครดิต",
	dh045_dte_accr_thru_ymd     	string       comment "Def(En): 
Def(Th): วันที่คำนวณดอกเบี้ยค้างรับถึง",
	dh045_birth_date_ymd        	string       comment "Def(En):
Def(Th): วันเกิด",
	dh045_accrued_intr          	string       comment "Def(En):
Def(Th): ดอกเบี้ย (ดอกเบี้ยจากการซื้อสินค้า + ดอกเบี้ยถอนเงินสด)(COMPUTE D283-ACCRUED-INTR = CM-RTL-ACCRUED-INTR + CM-CASH-ACCRUED-INTR)",
	dh045_date_opened           	string       comment "Def(En):
Def(Th): วันที่บัตรใบแรกเข้าระบบ Cardlink (กรณีสมัครบัตรใบใหม่เข้ามาจะได้วันที่ของบัตรใบแรกเสมอ)",
	dh045_expiry_date_mmyy      	string       comment "Def(En):
Def(Th): วันที่บัตรหมดอายุ",
	dh045_npl_flag              	string       comment "Def(En):
Def(Th): SPACE=ไม่เป็น NPL , 1,2,8,9=เป็น NPL",
	dh045_npl_date_ymd          	string       comment "Def(En):
Def(Th): วันที่ติด NPL",
	dh045_staff_flag            	string       comment "Def(En):
Def(Th): N = ไม่เป็นพนักงาน ,S = เป็นพนักงาน",
	dh045_days_diff             	string       comment "Def(En):
Def(Th): จำนวนวันที่ค้างชำระ (นับจากหลังวัน Past Due ถึงวันที่ปัจจุบัน และจะเป็น 0 เมื่อลูกค้าไม่ติด  Delinquent)",
	dh045_block_code            	string       comment "Def(En):
Def(Th): ประเภทการ BLOCK ของบัตร",
	dh045_card_type             	string       comment "Def(En):
Def(Th): ประเภทของบัตร",
	dh045_pymt_flag             	string       comment "Def(En):
Def(Th): ประเภทการชำระเงิน 0 = ชำระขั้นต่ำ, 1 = ชำระเต็มจำนวน,6=ชำระเฉพาะดอกเบี้ย",
	dh045_cycle_due             	string       comment "Def(En):
Def(Th): จำนวน Cycle ที่ค้างชำระ (0,1 = Normal ,2 ถึง 9 = ผิดนัดชำระ)",
	dh045_user_code_3           	string       comment "Def(En):
Def(Th): ประเภทหนี้ของบัตรเครดิต (อ้างอิงเอกสารชุด user code3)",
	dh045_dte_lst_purchase_ymd  	string       comment "Def(En):
Def(Th): วันที่ซี้อสินค้าและบริการครั้งล่าสุด",
	dh045_dte_lst_cash_adv_ymd  	string       comment "Def(En):
Def(Th): วันที่ถอนเงินสดครั้งล่าสุด",
	dh045_dte_user_code_3       	string       comment "Def(En):
Def(Th): วันที่กำหนดประเภทหนี้บัตรเครดิต",
	dh045_dte_pymt_due_ymd      	string       comment "Def(En):
Def(Th): วันที่ครบกำหนดชำระเงิน",
	dh045_total_amnt_due        	string       comment "Def(En):
Def(Th): ยอดเงินที่ต้องชำระในวันที่ครบกำหนดชำระเงิน
ดูจากประเภทการชำระ (DH045-PYMT-FLAG)
ชำระเงิน 0 = ชำระขั้นต่ำ, 1 = ชำระเต็มจำนวน,6=ชำระเฉพาะดอกเบี้ย",
	dh045_dte_lst_stmt          	string       comment "Def(En):
Def(Th): วันที่สรุปยอดการใช้จ่ายของรอบบัญชีครั้งสุดท้าย",
	dh045_stmt_balance          	string       comment "Def(En):
Def(Th): จำนวนยอดหนี้ทั้งหมดของวัน Statement ครั้งล่าสุด",
	dh045_org_nmbr              	string       comment "Def(En):
Def(Th): รหัสองค์กร (001 = บัตรเครดิต , 200 = XPC)",
	dh045_ach_flag              	string       comment "Def(En):
Def(Th): วิธีการชำระเงิน (0=ลูกค้าชำระค่าใช้จ่ายเอง, 1=ชำระโดยการหักบัญชีอัตโนมัติ)",
	dh045_ach_db_nmbr           	string       comment "Def(En):
Def(Th): เลขที่บัญชีสำหรับใช้ในการหักบัญชีอัตโนมัติ",
	dh045_past_due              	string       comment "Def(En):
Def(Th): จำนวนเงินค้างชำระ 1-29 วัน",
	dh045_030days_delq          	string       comment "Def(En):
Def(Th): จำนวนเงินค้างชำระ 30-59 วัน",
	dh045_060days_delq          	string       comment "Def(En):
Def(Th): จำนวนเงินค้างชำระ 60-89 วัน",
	dh045_090days_delq          	string       comment "Def(En):
Def(Th): จำนวนเงินค้างชำระ 90-119 วัน",
	dh045_120days_delq          	string       comment "Def(En):
Def(Th): จำนวนเงินค้างชำระ 120-149 วัน",
	dh045_150days_delq          	string       comment "Def(En):
Def(Th): จำนวนเงินค้างชำระ 150-179 วัน",
	dh045_180days_delq          	string       comment "Def(En):
Def(Th): จำนวนเงินค้างชำระ 180-209 วัน",
	dh045_210days_delq          	string       comment "Def(En):
Def(Th): จำนวนเงินค้างชำระ 210 วันและมากกว่า 210 วัน",
	dh045_lst_pymt_amnt         	string       comment "Def(En):
Def(Th): จำนวนเงินที่ชำระล่าสุด",
	dh045_nmbr_rtn_checks       	string       comment "Def(En):
Def(Th): จำนวนเช็คคืน",
	dh045_olc_reason            	string       comment "Def(En):
Def(Th): เหตุผลในการติดตามหนี้",
	dh045_avail_credit          	string       comment "Def(En):
Def(Th): วงเงินคงเหลือที่สามารถใช้ได้",
	dh045_cash_balance          	string       comment "Def(En):
Def(Th): จำนวนเงินที่ถอนเงินสด (รวมเงินต้น+ดอกเบี้ย+ค่าธรรมเนียม)",
	dh045_rtl_balance           	string       comment "Def(En):
Def(Th): จำนวนเงินใช้ซื้อสินค้าและบริการ (รวมเงินต้น+ดอกเบี้ย+ค่าธรรมเนียม)",
	dh045_hi_balance            	string       comment "Def(En):
Def(Th): จำนวนเงินที่ใช้จ่ายสูงสุด (จะมีค่าเฉพาะกรณีใช้วงเงินเกิน Credit Limt โดยแสดงจำนวนยอดใช้จ่ายทั้งหมด)",
	dh045_hi_balance_ymd        	string       comment "Def(En):
Def(Th): วันที่เกิดยอดการใช้จ่ายสูงสุด",
	dh045_rtl_accru_intr        	string       comment "Def(En):
Def(Th): ดอกเบี้ยสะสมของการใช้ซื้อสินค้า",
	dh045_cash_accru_intr       	string       comment "Def(En):
Def(Th): ดอกเบี้ยสะสมของการใช้ถอนเงินสด",
	dh045_minimum_payment       	string       comment "Def(En):
Def(Th): จำนวนเงินขั้นต่ำที่ต้องชำระในรอบบัญชี",
	dh045_status                	string       comment "Def(En):
Def(Th): สถานะของบัตรเครดิต  
0=new, 1=active, 2=inactive, 3=conversion, 4=transfer, 5=charged-off, 6=transfer-out, 7=transfer-in, 8=close, 9=purge",
	dh045_nmbr_requested_4      	string       comment "Def(En):
Def(Th): รหัสโครงการ 2 หลักแรก",
	dh045_card_type_4           	string       comment "Def(En):
Def(Th): รหัสโครงการ 2 หลักท้าย",
	dh045_delq_counter_1        	string       comment "Def(En):
Def(Th): จำนวนครั้งที่ค้างชำระ 1 -29 วัน",
	dh045_delq_counter_2        	string       comment "Def(En):
Def(Th): จำนวนครั้งที่ค้างชำระ 30 วัน",
	dh045_delq_counter_3        	string       comment "Def(En):
Def(Th): จำนวนครั้งที่ค้างชำระ 60 วัน",
	dh045_delq_counter_4        	string       comment "Def(En):
Def(Th): จำนวนครั้งที่ค้างชำระ 90 วัน",
	dh045_delq_counter_5        	string       comment "Def(En):
Def(Th): จำนวนครั้งที่ค้างชำระ 120 วัน",
	dh045_delq_counter_6        	string       comment "Def(En):
Def(Th): จำนวนครั้งที่ค้างชำระ 150 วัน",
	dh045_delq_counter_7        	string       comment "Def(En):
Def(Th): จำนวนครั้งที่ค้างชำระ 180 วัน",
	dh045_delq_counter_8        	string       comment "Def(En):
Def(Th): จำนวนครั้งที่ค้างชำระ เมื่อ 210 วัน",
	dh045_delq_hist_1           	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 1",
	dh045_delq_hist_2           	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 2",
	dh045_delq_hist_3           	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 3",
	dh045_delq_hist_4           	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 4",
	dh045_delq_hist_5           	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 5",
	dh045_delq_hist_6           	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 6",
	dh045_delq_hist_7           	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 7",
	dh045_delq_hist_8           	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 8",
	dh045_delq_hist_9           	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 9",
	dh045_delq_hist_10          	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 10",
	dh045_delq_hist_11          	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 11",
	dh045_delq_hist_12          	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 12",
	dh045_delq_hist_13          	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 13",
	dh045_delq_hist_14          	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 14",
	dh045_delq_hist_15          	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 15",
	dh045_delq_hist_16          	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 16",
	dh045_delq_hist_17          	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 17",
	dh045_delq_hist_18          	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 18",
	dh045_delq_hist_19          	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 19",
	dh045_delq_hist_20          	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 20",
	dh045_delq_hist_21          	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 21",
	dh045_delq_hist_22          	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 22",
	dh045_delq_hist_23          	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 23",
	dh045_delq_hist_24          	string       comment "Def(En):
Def(Th): 24 month profile ประวัติการค้างย้อนหลังเดือนที่ 24",
	dh045_accru_int_not_post    	string       comment "Def(En):
Def(Th): ดอกเบี้ยสะสมนอกการ์ด ปัจจุบันค่าจะเป็น 0 เสมอ เนื่องจากไม่มีการ Move ค่า (Not Use)",
	dh045_crlimit_flag          	string       comment "Def(En):
Def(Th): FLAG ว่าบัญชีนี้มียอดใช้ของบัญชีเกินกว่าวงเงินระดับบัตร (Y= Current Balance > Credit Limit นอกนั้น ค่าจะเป็นว่าง)",
	dh045_crline_flag           	string       comment "Def(En):
Def(Th): FLAG ว่าบัญชีนี้มียอดใช้รวมทุกบัญชีเกินกว่าวงเงินระดับลูกค้า  (Y= Current Balance ทุกบัตร > Credit Limit นอกนั้น ค่าจะเป็นว่าง)",
	dh045_crline                	string       comment "Def(En):
Def(Th): วงเงินระดับของลูกค้า",
	dh045_sum_tot_bal           	string       comment "Def(En):
Def(Th): ยอดใช้รวมของทุกบัญชีของลูกค้ารายนั้น (รวมบัตรหลักกับบัตรเสริมเป็นรายเดียวกันทุกบัตรไม่สนใจเรื่อง oustanding (+/-))  ยอดจะเพิ่มขึ้นและลดลงตามการใช้จ่ายและการชำระ",
	dh045_diff_cr_sumbal        	string       comment "Def(En):
Def(Th): ยอดใช้รวมทุกบัญชีส่วนที่เกินกว่าวงเงินระดับลูกค้า  (กรณียอด DH045-SUM-TOT-BAL >DH045-CRLINE แสดงยอด DH045-SUM-TOT-BAL - DH045-CRLINE  กรณีอื่นเท่ากับ 0 )",
	dh045_max_days_diff         	string       comment "Def(En):
Def(Th): วันค้างที่มากที่สุดจากทุกบัญชีของลูกค้ารายนั้น (รวมบัตรหลักกับบัตรเสริมเป็นรายเดียวกันทุกบัตร)",
	dh045_ri_rate_1             	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ย (กรณีผิดนัด,กรณีจ่ายขั้นต่ำ)",
	dh045_main_customer         	string       comment "Def(En):
Def(Th): หมายเลขประจำตัวของลูกค้าที่เป็นบัตรหลัก",
	dh045_amnt_lst_purch        	string       comment "Def(En):
Def(Th): จำนวนเงินที่ใช้ซื้อสินค้าครั้งล่าสุด",
	dh045_amnt_lst_adv          	string       comment "Def(En):
Def(Th): จำนวนเงินที่ใช้เบิกถอนล่าสุด",
	dh045_xfr_org_nmbr          	string       comment "Def(En):
Def(Th): รหัสองค์กรของบัตรที่ transfer",
	dh045_xfr_type_nmbr         	string       comment "Def(En):
Def(Th): รหัสประเภทของบัตรที่ transfer",
	dh045_xfr_acct_nmbr         	string       comment "Def(En):
Def(Th): รหัสบัญชีของบัตรที่ transfer",
	dh045_dte_xfer_effective_ymd	string       comment "Def(En):
Def(Th): วันที่ที่ให้ระบบการสร้างข้อมูลบัตรที่ transfer",
	dh045_acc_perf_ind          	string       comment "Def(En):
Def(Th): INDEX ของบัญชี (ACC-PERFORM-INDEX)",
	dh045_acc_risk_grade        	string       comment "Def(En):
Def(Th): ระดับความเสี่ยงของบัญชี",
	dh045_coll_mgmt_code_1      	string       comment "Def(En):
Def(Th): รหัส COLLECTION CODE1",
	dh045_coll_mgmt_code_2      	string       comment "Def(En):
Def(Th): รหัส COLLECTION CODE2",
	dh045_coll_mgmt_code_3      	string       comment "Def(En):
Def(Th): รหัส COLLECTION CODE3",
	dh045_cash_limit_per        	string       comment "Def(En):
Def(Th): % ในการถอนเงินสด เช่น 50% หมายถึงถอนเงินสดได้ 50% ของวงเงินบัตร",
	dh045_pot_select_code       	string       comment "Def(En):
Def(Th): Product Offering Table
22,23 = ชำระขั้นต่ำ 3.33%
88 = ชำระขั้นต่ำ 3.33% (มาตรการโควิด)",
	dh045_pot_exp_date          	string       comment "Def(En):
Def(Th): วันที่ POT-SELECT-CODE Expire Format : YYMM",
	dh045_payments_in_cycle     	string       comment "Def(En):
Def(Th): ยอดชำระเงินของลูกค้าจากการสรุปยอดใช้จ่ายในรอบบัญชีปัจจุบัน",
	dh045_current_due           	string       comment "Def(En):
Def(Th): ยอดที่จะต้องชำระเงินในงวดสรุปยอดบัญชีล่าสุด",
	dh045_last_rtn_chk          	string       comment "Def(En):
Def(Th): วันที่ล่าสุดที่มีรายการคืน Cheque ปัจจุบัน (ปีเดือนวัน) *** จะถูก Update เมื่อ TC28 เข้ามาเท่านั้น ถ้าเป็นลูกค้าหนี้พิพากษาหรือ D = Debt Restructure (ปรับโครงสร้างหนี้) จะไม่มีการ Update ฟิวล์นี้",
	dh045_card_fee_date         	string       comment "Def(En):
Def(Th): วันที่จะเรียกเก็บค่าธรรมเนียมรายปีของบัตรครั้งต่อไป   Format : ปีเดือนวัน",
	dh045_dispute_amt           	string       comment "Def(En):
Def(Th): ยอดที่ลูกค้าปฏิเสธการใช้จ่าย
(ทำรายการ TC04 หรือ TC07 ยอดจะเพิ่ม)",
	dh045_cust_perf_ind         	string       comment "Def(En):
Def(Th): INDEX ของลูกหนี้ (CUST-PERFORM-INDEX)",
	dh045_cust_risk_grade       	string       comment "Def(En):
Def(Th): ระดับความเสี่ยงของลูกหนี้",
	dh045_principle             	string       comment "Def(En):
Def(Th): เงินต้น
(ยอดเงินต้น + Fee)",
	dh045_intr_income           	string       comment "Def(En):
Def(Th): ดอกเบี้ย
(ลูกค้าปกติ =ฟิวล์นี้คือดอกเบี้ย,ติด NPL = ฟิวล์นี้คือดอกเบี้ย Reverse )",
	dh045_memo                  	string       comment "Def(En):
Def(Th): ดอกเบี้ยที่ยังไม่รับรู้เป็นรายได้",
	dh045_rtl_cash_interest     	string       comment "Def(En):
Def(Th): ดอกเบี้ยที่เรียกเก็บใน Statement ล่าสุด",
	dh045_tax                   	string       comment "Def(En):
Def(Th): จำนวนเงินที่เสียภาษี",
	dh045_addr_1                	string       comment "Def(En):
Def(Th): ที่อยู่1",
	dh045_addr_2                	string       comment "Def(En):
Def(Th): ที่อยู่2",
	dh045_mail_code             	string       comment "Def(En):
Def(Th): รหัสไปรษณีย์",
	dh045_home_phone            	string       comment "Def(En):
Def(Th): เบอร์โทรศัพท์บ้าน",
	dh045_office_phone          	string       comment "Def(En):
Def(Th): เบอร์โทรศัพท์ที่ทำงาน",
	dh045_government_id         	string       comment "Def(En):
Def(Th): เลขที่บัตรประชาชน",
	dh045_sunggut               	string       comment "Def(En):
Def(Th): สังกัด",
	dh045_charge_of_acct        	string       comment "Def(En):
Def(Th): ประเภทหัวบัญชีเครดิต",
	dh045_marital_status        	string       comment "Def(En):
Def(Th): สถานะภาพสมรส",
	dh045_occpn_code            	string       comment "Def(En):
Def(Th): อาชีพ",
	dh045_sex                   	string       comment "Def(En):
Def(Th): เพศ",
	dh045_eng_name              	string       comment "Def(En):
Def(Th): ชื่อภาษาอังกฤษ",
	dh045_mobile_nmbr           	string       comment "Def(En):
Def(Th): หมายเลขโทรศัพท์มือถือ",
	dh045_curr_email            	string       comment "Def(En):
Def(Th): e-Mail Address ของลูกค้า",
	dh045_legal_entity          	string       comment "Def(En):
Def(Th): รหัสบริษัท",
	dh045_resp_center           	string       comment "Def(En):
Def(Th): รหัสสังกัด
(credit = 41001,kec/xpc = 44800)",
	dh045_gl_account            	string       comment "Def(En):
Def(Th): รหัสบัญชีประเภทเครดิต
(credit = 1202008,kec/xpc = 1202001)",
	dh045_function              	string       comment "Def(En):
Def(Th): รหัสฟังก์ชันงานของบัญชี GL
(credit = 1,kec/xpc = 4)",
	dh045_line_business         	string       comment "Def(En):
Def(Th): รหัสประเภทธุรกิจ",
	dh045_glprodcd              	string       comment "Def(En):
Def(Th): รหัสผลิตภัณฑ์",
	dh045_inter_company         	string       comment "Def(En):
Def(Th): รหัสบริษัทในการหักค่าใช้จ่ายระหว่างบริษัทในเครือ",
	dh045_intra_company         	string       comment "Def(En):
Def(Th): รหัสบริษัทในการหักค่าใช้จ่ายระหว่างฝ่ายงาน",
	dh045_project               	string       comment "Def(En):
Def(Th): รหัสโครงการของระบบ GL",
	dh045_gl_fics               	string       comment "Def(En):
Def(Th): รหัสหมายเลขบัญชี FICS เช่น 1421050",
	dh045_gl_filler2            	string       comment "Def(En):
Def(Th): เพื่อรองรับระบบ NEW GL (DMPGL-FUTURE-USE)",
	dh045_prodcd                	string       comment "Def(En):
Def(Th): SUB PRODUCT เพื่อรองรับระบบ NEW GL (DMPGL-SUB-PRODUCT)",
	dh045_rtl_svc_bnp           	string       comment "Def(En): Retail service charge 
Def(Th):",
	dh045_cash_svc_bnp          	string       comment "Def(En): Cash service charge 
Def(Th):",
	dh045_rtl_misc_fees         	string       comment "Def(En):  Retail past due and overlimit fees
Def(Th):",
	dh045_rtl_insur_bnp         	string       comment "Def(En):  Retail Insurance billed
Def(Th):",
	dh045_rtl_member_bnp        	string       comment "Def(En): Retail Membership billed
(มีข้อมูลเมื่อถึงวันเรียกเก็บ)
Def(Th):",
	dh045_annual_fee            	string       comment "Def(En): Annual Membership fees
(ยอดที่จะเรียกค่าธรรมเนียมรายปี)
Def(Th):",
	dh045_instl_amort_bnp       	string       comment "Def(En): Installment billed
Def(Th):",
	dh045_highest_flag          	string       comment "Def(En): Highest Cardholder flag (ของ ฝ่าย CV)
Def(Th):",
	dh045_lst_crlimit_dte       	string       comment "Def(En): Last credit limit date
Def(Th):",
	dh045_lst_crlimit           	string       comment "Def(En): Last credit limit  
Def(Th):",
	dh045_crlimit_temp_flag     	string       comment "Def(En): Temporary credit limit flag
Def(Th):",
	dh045_user_acct             	string       comment "Def(En): User Account number
Def(Th):",
	dh045_card_appl_scorecrd    	string       comment "Def(En): Application Score Card
Def(Th):",
	dh045_group_flag            	string       comment "Def(En): Platinum Group type
Def(Th):",
	load_tms                    	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                  	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                    	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                      	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                      	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink/cardlink_kb1dh045_cc1d289g' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);