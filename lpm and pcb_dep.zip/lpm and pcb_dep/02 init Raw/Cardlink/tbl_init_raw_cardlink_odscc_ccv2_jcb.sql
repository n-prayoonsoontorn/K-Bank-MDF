-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_cardlink_odscc_ccv2_jcb.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_CARDLINK.CARDLINK_ODSCC_CCV2_JCB
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_cardlink.cardlink_odscc_ccv2_jcb (
	pos_dt                  	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	card_bin                	string       comment "Def(En):Bin of Card No.
Def(Th):",
	card_no_encpt           	string       comment "Def(En): Card number (Encrypt)
Def(Th):",
	card_no_mask            	string       comment "Def(En): Card number (Mask)
Def(Th):",
	card_no_hash            	string       comment "Def(En): Card number (Hash)
Def(Th):",
	gmt_date_time           	string       comment "Def(En):Transmission data and time-GMT.
Def(Th):",
	acq_id                  	string       comment "Def(En):Acquirer Id.
Def(Th):",
	retrvl_ref_nbr          	string       comment "Def(En):Retrieval Reference No.
Def(Th):",
	system_trace_no         	string       comment "Def(En):Trace No. of transaction
Def(Th):",
	merch_nbr               	string       comment "Def(En):Merchant No
Def(Th):",
	date_stamp              	string       comment "Def(En):Transaction Date
Def(Th):",
	time_stamp              	string       comment "Def(En):Transaction Time
Def(Th):",
	seq_nbr                 	string       comment "Def(En):Sequence No.
Def(Th):",
	orig_seq_nbr            	string       comment "Def(En):Original Sequence No.
Def(Th):",
	log_rec_type            	string       comment "Def(En):Indicates the log record type
Def(Th):",
	txn_source_id           	string       comment "Def(En):The device that the transaction originated from
Def(Th):",
	orig_trans_id           	string       comment "Def(En):Original Tran Id.
Def(Th):",
	source_term_id          	string       comment "Def(En):Source name of transaction
Def(Th):",
	input_source            	string       comment "Def(En):Input source from Network
Def(Th):",
	receiving_trans_id      	string       comment "Def(En):Tran Name to receive transaction
Def(Th):",
	receiving_prog_id       	string       comment "Def(En):Program Name to receive transaction
Def(Th):",
	rec_type                	string       comment "Def(En):Record type of transaction
Def(Th):",
	rec_status              	string       comment "Def(En):Record status of transaction
Def(Th):",
	return_code             	string       comment "Def(En):Return Code of Transaction
Def(Th):",
	error_msg_ind           	string       comment "Def(En):Error Message Indicator
Def(Th):",
	error_msg_code          	string       comment "Def(En):Error Message Code
Def(Th):",
	error_msg_text          	string       comment "Def(En):Error message description
Def(Th):",
	destination_code        	string       comment "Def(En):Indicates the Destination for the outgoing request
Def(Th):",
	orig_b011_sys_audt_trace	string       comment "Def(En):unique queue ID to be used for TCP/IP in order for the  Queue
Def(Th):",
	orig_auth_code          	string       comment "Def(En):Transaction Authorized code
Def(Th):",
	card_type               	string       comment "Def(En):Type of Card
Def(Th):",
	on_us_txn_flag          	string       comment "Def(En):
Def(Th):",
	plastic_org             	string       comment "Def(En):Card Organisation
Def(Th):",
	plastic_type            	string       comment "Def(En):Card Type
Def(Th):",
	card_expir_date         	string       comment "Def(En):Card Expiry Date
Def(Th):",
	reversal_flag           	string       comment "Def(En):Indicates if transaction is Reversed
Def(Th):",
	force_auth_flag         	string       comment "Def(En):Indicates if transaction is a forced request
Def(Th):",
	spcl_hndling_flag       	string       comment "Def(En):Indicates if transaction is a a special handling record
Def(Th):",
	fraud_rec_flag          	string       comment "Def(En):
Def(Th):",
	instl_flag              	string       comment "Def(En):Indicates if transaction is Installment
Def(Th):",
	under_merch_floor_flag  	string       comment "Def(En):Indicates if transaction is transaction process upder the merchant floor limit or not
Def(Th):",
	time_sent               	string       comment "Def(En):Time at send out transaction
Def(Th):",
	time_received           	string       comment "Def(En):Time at receive  transaction
Def(Th):",
	decline_rsn             	string       comment "Def(En):Decline reason
Def(Th):",
	mcc_group               	string       comment "Def(En):Group of Merchant Category Code
Def(Th):",
	orig_gmt_date_time      	string       comment "Def(En):Original GMT date and time for reversal transaction
Def(Th):",
	b049_curr_code_exp      	string       comment "Def(En):Transaction currency code exponent
Def(Th):",
	b051_ch_curr_code_exp   	string       comment "Def(En):Cardholder billing  currency code exponent
Def(Th):",
	merch_org               	string       comment "Def(En):Merchant organization
Def(Th):",
	auth_cancel_flag        	string       comment "Def(En):Indicates for authorization transaction cancel flag
Def(Th):",
	netwk_route_ind         	string       comment "Def(En):Indicated to tell whether the transaction has been sent out to network or processed by host
Def(Th):",
	token                   	string       comment "Def(En):Token PAN No.
Def(Th):",
	token_pan               	string       comment "Def(En):Token PAN No.
Def(Th):",
	userid                  	string       comment "Def(En):User Id.
Def(Th):",
	tpdu_id_j               	string       comment "Def(En):
Def(Th):",
	tpdu_dest_id_j          	string       comment "Def(En):JCB destination station Id.
Def(Th):",
	tpdu_srce_id_j          	string       comment "Def(En):JCB source station Id.
Def(Th):",
	message_type_id         	string       comment "Def(En):Message type Id
Def(Th):",
	b003_proc_code          	string       comment "Def(En):Processing code .Describes the effectof transactionon the customer account and the type of accounts affected
Def(Th):",
	b003_txn_type_code      	string       comment "Def(En):Type of transaction
Def(Th):",
	b003_frm_acct_code      	string       comment "Def(En):From account affected
Def(Th):",
	b003_to_acct_code       	string       comment "Def(En):To account affected
Def(Th):",
	b004_txn_amt            	string       comment "Def(En):Transaction amount
Def(Th):",
	b006_ch_bill_amt        	string       comment "Def(En):Cardholder billing amount
Def(Th):",
	b009_rpt_rte_cnvrsn     	string       comment "Def(En):Conversion rate and settlement 
Def(Th):",
	b009_rrc_dec_sep        	string       comment "Def(En):Conversion rate decimal 
Def(Th):",
	b009_rrc_amt            	string       comment "Def(En):Conversion rate
Def(Th):",
	b010_ch_rte_cnvrsn      	string       comment "Def(En):The cardholder rate of conversion.
Def(Th):",
	b010_crc_dec_sep        	string       comment "Def(En):
Def(Th):",
	b010_crc_amt            	string       comment "Def(En):
Def(Th):",
	b012_lcl_txn_time       	string       comment "Def(En):Local Time of transaction processing
Def(Th):",
	b013_lcl_txn_date       	string       comment "Def(En):Local Transaction date and month
Def(Th):",
	b015_setl_date          	string       comment "Def(En):Transaction Settlement Date
Def(Th):",
	b016_convrsn_date       	string       comment "Def(En):Date conversion
Def(Th):",
	b018_merch_type         	string       comment "Def(En):Merchant Standard Industry code or SIC Code
Def(Th):",
	b019_cntry_code         	string       comment "Def(En):Countryly s code for location of the acquiring institution.Currently space for Mastercard
Def(Th):",
	b020_pan_extd_cntry_code	string       comment "Def(En):Code to identify the country he card issuer institution
Def(Th):",
	b022_pos_entry_mode     	string       comment "Def(En):Point-of-Service entry mode codeDef(Th):",
	b022_pos_em_pan         	string       comment "Def(En):PAN  entry mode used
Def(Th):",
	b022_pos_em_pin         	string       comment "Def(En):PIN entry capability
Def(Th):",
	b028_txn_fee_cd_j       	string       comment "Def(En):Indicates of transaction fee
Def(Th):",
	b028_txn_fee_amt_j      	string       comment "Def(En):Transaction fee amount
Def(Th):",
	b038_auth_code          	string       comment "Def(En):Authorisation code (only present if approved)
Def(Th):",
	b039_resp_code          	string       comment "Def(En):Response Code
Def(Th):",
	b040_svc_restrct_code   	string       comment "Def(En):Service restriction code
Def(Th):",
	b041_card_accpt         	string       comment "Def(En):Card acceptor terminal Identification code
Def(Th):",
	b041_card_accpt_store   	string       comment "Def(En):Merchant outlet or store number
Def(Th):",
	b041_card_accpt_term    	string       comment "Def(En):Code identify ing a specific terminal  within the outlet or store",
	b042_card_accpt_id      	string       comment "Def(En):Card acceptor ID code (Identifier of the card acceptor operating the point-of-sale or point-of-service terminal)
Def(Th):",
	b043_card_accpt_desc    	string       comment "Def(En):Card acceptor Description
Def(Th):",
	b043_card_accpt_name    	string       comment "Def(En):Card acceptor Name
Def(Th):",
	b043_card_accpt_city    	string       comment "Def(En):Card acceptor City
Def(Th):",
	b043_card_accpt_cntry   	string       comment "Def(En):Card acceptor Country
Def(Th):",
	b044_cav2_rslt_j        	string       comment "Def(En):CAV2 Result
Def(Th):",
	b044_avs_rslt_j         	string       comment "Def(En):AVS Result
Def(Th):",
	b045_track1_data_c      	string       comment "Def(En):Track1 data of the magnetic stripe 
Def(Th):",
	b049_curr_code          	string       comment "Def(En):Currency code of the transaction amount (B004-TXN-Amount)
Def(Th):",
	b050_setl_curr_code     	string       comment "Def(En):Currency code of the Settlemsnt amount (B005-SETL-Amount)
Def(Th):",
	b051_ch_curr_code       	string       comment "Def(En):Currency code for Cardholder billing amount (B006-CH-Amount)
Def(Th):",
	b052_pin_data_dbwd      	string       comment "Def(En):
Def(Th):",
	b053_security_cntl      	string       comment "Def(En):Security Related Control Information
Def(Th):",
	b055_chip_data          	string       comment "Def(En):Chip data
Def(Th):",
	b061_moto_txn_ind_j     	string       comment "Def(En):Indicatges of  MOTO Transaction",
	b061_recur_txn_ind_j    	string       comment "Def(En):Indicatges of  Recurring Transaction
Def(Th):",
	b061_pre_auth_ind_j     	string       comment "Def(En):Indicatges of  Pre-Authorization Transaction
Def(Th):",
	b061_pos_cntry_code_j   	string       comment "Def(En):Indicatges of  POS Condition code
Def(Th):",
	b090_orig_mti_j         	string       comment "Def(En):Original data MTI
Def(Th):",
	b090_orig_ref_nbr_j     	string       comment "Def(En):Original data Reference number
Def(Th):",
	b090_orig_date_time_j   	string       comment "Def(En):Original data for date time
Def(Th):",
	b090_orig_acq_id_j      	string       comment "Def(En):Original data acquiring number
Def(Th):",
	b090_orig_fwd_id_j      	string       comment "Def(En):Original data forwarding number
Def(Th):",
	b095_act_txn_amt_r      	string       comment "Def(En):
Def(Th):",
	b095_act_ch_bill_amt_r  	string       comment "Def(En):
Def(Th):",
	b120_tran_typ_j         	string       comment "Def(En):
Def(Th):",
	b120_pan_j              	string       comment "Def(En):Transation PAN number
Def(Th):",
	b120_act_code_j         	string       comment "Def(En):Transation action code
Def(Th):",
	b120_pur_dte_j          	string       comment "Def(En):Transation purge date
Def(Th):",
	b120_reg_ent_j          	string       comment "Def(En):Region entry
Def(Th):",
	load_tms                	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id              	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                  	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                  	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_cardlink/cardlink_odscc_ccv2_jcb' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);