-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_dgtl_fctrng_fact_acct.sql
# Area: dgtl_fctrng
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_DGTL_FCTRNG.DGTL_FCTRNG_FACT_ACCT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_dgtl_fctrng.dgtl_fctrng_fact_acct (
	pos_dt                  	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	ref_no                  	string       comment "Def(En): Reference No (Account No.) group by Seller, Limit, Buyer, Trans. date, invoice date, Currency to 1 Account No.
Def(Th):",
	old_ref_no              	string       comment "Def(En): Oldreference number incase changing reference from restructure loan
Def(Th):",
	cis_id                  	string       comment "Def(En): CIS ID
Def(Th):",
	prod_code               	string       comment "Def(En): Facility ID of Limit which Trade transaction apply to.
Def(Th): กรณี Advance Loan ตั๋วจะไม่มีเลขที่วงเงิน (Facility ID) ถ้าลูกค้าไม่มีวงเงิน Loan",
	limit_id                	string       comment "Def(En): Credit Limit ID by Facility_ID+Customer Acronym/Abbreviation in Bank Trade
Def(Th): กรณี Advance Loan ตั๋วจะไม่มีเลขที่วงเงิน (Facility ID) ถ้าลูกค้าไม่มีวงเงิน Loan",
	facility_level          	string       comment "Digital Factoring ไม่ส่งค่านี้",
	l6_limit_id             	string       comment "Digital Factoring ไม่ส่งค่านี้",
	issue_date              	string       comment "Def(En):
Def(Th): วันที่ Approve date ของ Ref. No. 
ซึ่งไม่รวม UnFact (ฝากเก็บ Invoice)",
	eff_date                	string       comment "Def(En): Effective date of contingent /loan  (start calculate interest)
Def(Th):",
	maturity-date           	string       comment "Def(En): Maturity date
Def(Th): วันที่ตั๋วครบกำหนดตามสัญญาไม่รวม Grace Period 

Note: Maturity date จะเป็นวันที่ตั๋วครบตามสัญญา แต่ถ้าลูกค้าได้รับการงดเว้นคิดดอกเบี้ยเป็นช่วงเวลา grace period ซึ่งวันที่ Due date จะเป็นวันที่ลูกค้าโดนคิดดอกเบียหลังจาก grace period (Due date = Maturity date + grace period)",
	due_date                	string       comment "Def(En): Due date
Def(Th): วันที่ตั๋วครบกำหนดตามสัญญารวม Grace Period 

Note: Maturity date จะเป็นวันที่ตั๋วครบตามสัญญา แต่ถ้าลูกค้าได้รับการงดเว้นคิดดอกเบี้ยเป็นช่วงเวลา grace period ซึ่งวันที่ Due date จะเป็นวันที่ลูกค้าโดนคิดดอกเบียหลังจาก grace period (Due date = Maturity date + grace period)

การคิด Aging เริ่มนับจาก Due-Date",
	close_date              	string       comment "Def(En): Transaction Close date 
Def(Th):",
	status                  	string       comment "Def(En): Loan/Contingent Transaction status
Status relate with Close date 
Status = Close --> Close date have value
Else status = Active
Def(Th):",
	term                    	string       comment "Def(En): TENOR for transaction
Def(Th):",
	term_unit               	string       comment "Def(En): Unit of Term
Def(Th):",
	ccy_code                	string       comment "Def(En): Original Currency Code of transaction
Def(Th):",
	prin_org_amount_ccy     	string       comment "Def(En): Initail Payment Amount Def(Th): ยอดเงินกู้ที่ลูกค้าเป็นหนี้ธนาคาร
กรณีเป็นเงิน THB Field นี้มีค่าเท่ากันกับ PRIN_ORG_AMOUNT_THB",
	prin_org_amount_thb     	string       comment "Def(En): Initail Payment Amount Def(Th): ยอดเงินกู้ที่ลูกค้าเป็นหนี้ธนาคาร
กรณีเป็นเงิน THB Field นี้มีค่าเท่ากันกับ PRIN_ORG_AMOUNT_CCY",
	prin_cur_amount_ccy     	string       comment "Def(En): Initail Payment Remain Amount
Def(Th): ยอดเงินกู้คงเหลือที่ลูกค้าเป็นหนี้ธนาคาร
กรณีเป็นเงิน THB Field นี้มีค่าเท่ากันกับ PRIN_ORG_AMOUNT_THB",
	prin_cur_amount_thb     	string       comment "Def(En): Initail Payment Remain Amount
Def(Th): ยอดเงินกู้คงเหลือที่ลูกค้าเป็นหนี้ธนาคาร
กรณีเป็นเงิน THB Field นี้มีค่าเท่ากันกับ PRIN_ORG_AMOUNT_THB",
	int_daily_accru_ccy     	string       comment "Def(En): Daily Accrued Interest amount as CCY Code
Def(Th):",
	int_daily_accru_thb     	string       comment "Def(En): Daily Accrued Interest amount in THB
Def(Th):",
	int_remain_amount_ccy   	string       comment "Def(En): Outstanding Interest amount or Remain Accrued Interest as CCY_CODE but
in case Discount product this field = 0
Def(Th):",
	int_remain_amount_thb   	string       comment "Def(En): Outstanding Interest amount or Remain Accrued Interest in THB but
in case Discount product this field = 0
Def(Th): ดอกเบี้ยค้างรับสะสม เช่นดอกเบี้ยวันละ 1 บาท 
วันที่ 1 ส่ง 1 บาท
วันที่ 2 ส่ง 2 บาท
วันที่ 3 ส่ง 3 บาท
วันที่ 4 ส่ง 4 บาท 
- กรณี มีมาจ่าย ดอกเบี้ย 1 บาท ค่านี้จะส่งวันที่ 4 เป็น 3 บาท
- กรณีเป็นประเภท เก็บดอกเบี้ยล่วงหน้า ค่านี้จะส่ง 0",
	disc_amount_ccy         	string       comment "Def(En): Discount amount in CCY
Def(Th): จะมีค่าก็ต่อเมื่อเป็น Discount product",
	disc_amount_thb         	string       comment "Def(En): Discount amount in THB
Def(Th): จะมีค่าก็ต่อเมื่อเป็น Discount product",
	amrz_amount_ccy         	string       comment "Def(En): Amortize amount in CCY
Def(Th): จะมีค่าก็ต่อเมื่อเป็น Discount product
ดอกเบี้ยรับ รับมาเป็นก้อน แล้วทยอยรับรู้ 
เช่น หักไว้ 90 บาท กำหนด 3 เดือน 
เช่นดอกเบี้ยวันละ 1 บาท 
วันที่ 1 ส่ง 1 บาท
วันที่ 2 ส่ง 2 บาท
วันที่ 3 ส่ง 3 บาท
วันที่ 30 ส่ง 30 บาท 
กรณี มีมาจ่ายค่าจะไม่มีผลกระทบ ส่งตามการรับรู้รายได้ไปเหมือนเดิม",
	amrz_amount_thb         	string       comment "Def(En): Amortize amount in THB
Def(Th): จะมีค่าก็ต่อเมื่อเป็น Discount product
ดอกเบี้ยรับ รับมาเป็นก้อน แล้วทยอยรับรู้ 
เช่น หักไว้ 90 บาท กำหนด 3 เดือน 
เช่นดอกเบี้ยวันละ 1 บาท 
วันที่ 1 ส่ง 1 บาท
วันที่ 2 ส่ง 2 บาท
วันที่ 3 ส่ง 3 บาท
วันที่ 30 ส่ง 30 บาท 
กรณีลูกค้ามีมาจ่ายค่าจะไม่มีผลกระทบ ส่งตามการรับรู้รายได้ไปเหมือนเดิม",
	int_receive_ccy         	string       comment "Def(En): Interest Receive in CCY
- Accural basis : Accumulate Accured Interest but it is amount month to date only
Def(Th):",
	int_receive_thb         	string       comment "Def(En): Interest Receive in THB
- Accural basis : Accumulate Accured Interest but it is amount month to date only
Def(Th): รายได้ดอกเบี้ยรับ เกณฑ์ accrue  
Post Int สิ้นเดือน 
เช่นดอกเบี้ยวันละ 1 บาท 
วันที่ 1 ส่ง 1 บาท
วันที่ 2 ส่ง 2 บาท
วันที่ 3 ส่ง 3 บาท
วันที่ 30 ส่ง 30 บาท 
กรณีลูกค้ามีมาจ่ายค่าจะไม่มีผลกระทบ ส่งตามการรับรู้รายได้ไปเหมือนเดิม
พอขึ้นเดือนใหม่ต้องเริ่มนับใหม่ สะสมเฉพาะในเดือน",
	int_daily_late_chrg_ccy 	string       comment "Def(En): Daily Interest Late Charge amount as CCY_CODE
จะมีค่าเมื่อ transaction ถูกคิด Interest Late Charge 
Def(Th):",
	int_daily_late_chrg_thb 	string       comment "Def(En): Daily Interest Late Charge amount in THB
จะมีค่าเมื่อ transaction ถูกคิด Interest Late Charge
Def(Th):",
	int_late_chrg_remain_ccy	string       comment "Def(En): Remain Interest Late Charge amount as CCY_CODE
จะมีค่าเมื่อ transaction ถูกคิด Interest Late Charge
Def(Th):",
	int_late_chrg_remain_thb	string       comment "Def(En): Remain Interest Late Charge amount in THB
จะมีค่าเมื่อ transaction ถูกคิด Interest Late Charge
Def(Th):",
	reverse_accru_ccy       	string       comment "Def(En): Reverse Accrued Interest Amount as CCY_CODE
Def(Th):",
	reverse_accru_thb       	string       comment "Def(En): Reverse Accrued Interest Amount in THB
Def(Th):",
	memo_accru_ccy          	string       comment "Def(En): Memo Accrual Interest Amount as CCY_CODE
Def(Th):",
	memo_accru_thb          	string       comment "Def(En): Memo Accrual Interest Amount in THB
Def(Th):",
	unpaid_fee_thb          	string       comment "Def(En): Total unpaid Fee amount in THB
Def(Th): ค่าธรรมเนียมค้างชำระสะสม",
	date_of_last_payment    	string       comment "Def(En): Last Payment Date of any payment event (Principle , Interest , Fee )

If the last payment date does not exist (first payment) then this field should send blank

LPM : 
If the last payment date does not exist (first payment), this field is required to send all zeros
Def(Th):",
	amt_last_payment_ccy    	string       comment "Def(En): Payment amount of Last payment in CCY
Def(Th):",
	amt_last_payment_thb    	string       comment "Def(En): Payment amount of Last payment in THB
Def(Th):",
	amt_accum_payment_ccy   	string       comment "Def(En): Accumulate all payment amount in CCY (Interest , Principle, Fee , Expense)
Def(Th):",
	amt_accum_payment_thb   	string       comment "Def(En): Accumulate all payment amount in THB (Interest , Principle, Fee , Expense)
Def(Th):",
	mid_rate                	string       comment "Def(En): KBank Mid Rate (at Today EOD)
Note: Use this rate incase require to convert CCY amount to THB 
Def(Th):",
	eff_rate                	string       comment "Def(En): Effective interest rate (all in rate for normal transaction)
Def(Th):",
	rate_type               	string       comment "Def(En): Rate type code 
Def(Th):",
	sign                    	string       comment "Def(En): SPREAD SIGN
Def(Th):",
	spread_rate             	string       comment "Def(En): SPREAD_RATE
Spread rate no value send
DIH format : 0.0000000 
LPM format : 000000000
Def(Th):",
	int_late_chg_rate       	string       comment "Def(En): Late charge rate (Default rate - normal rate)
Def(Th): จะมีค่าเมื่อ transaction ถูกคิด Interest Late Charge",
	max_rate                	string       comment "Def(En): Default rate (Maximum rate to charge customer)
Def(Th):",
	int_pay_type            	string       comment "Def(En): Interest Payment Frequency is the frequency in which the customer pays their interest.
Def(Th):",
	kbank_product_code      	string       comment "Def(En): Kbank Product Code of Loan or Contingent transaction
Def(Th):",
	type_of_loan            	string       comment "Def(En): To define Contigent or loan
Def(Th):",
	reverse_flag            	string       comment "Def(En): Reverse / Memo 
Def(Th): ถูกคำนวณที่ระบบ TFRS9 ทาง Digital Factoring ไม่ส่งค่านี้",
	reverse_date            	string       comment "Def(En): Reverse / Memo 
Def(Th): ถูกคำนวณที่ระบบ TFRS9 ทาง Digital Factoring ไม่ส่งค่านี้",
	dpd-prin                	string       comment "Def(En): Day Pass Due (Aging) of Principle
Def(Th): มีค่าเมื่อตั๋ว overdue
เริ่มนับจาก Due Date + Grace for Collection",
	dpd-int                 	string       comment "Def(En): Day Pass Due (Aging) of Interest
Def(Th): มีค่าเมื่อตั๋วผิดนัดชำระดอกเบี้ย
เริ่มนับจาก Due Date + Grace for Collection",
	dpd-bot                 	string       comment "Def(En): Day Pass Due (Aging) of BOT
Def(Th): มีค่าเมื่อตั๋ว overdue หรือ ผิดนัดชำระดอกเบี้ย
เริ่มนับจาก Due Date + Grace for Collection",
	dpd_start_date          	string       comment "Def(En): Start date of Day pass due for aging BOT
Def(Th): มีค่าเมื่อตั๋ว overdue หรือ ผิดนัดชำระดอกเบี้ย",
	overdue_amount_ccy      	string       comment "Def(En): Overdue amount in CCY of Interest or Priciple or Interest + Principle depend on overdue type
Def(Th): 
มีค่าต่อเมือลูกค้าผิดนัดชำระเงินต้นและหรือดอกเบี้ย",
	overdue_amount_thb      	string       comment "Def(En): Overdue amount in THB of Interest or Priciple or Interest + Principle depend on overdue type
Def(Th): 
มีค่าต่อเมือลูกค้าผิดนัดชำระเงินต้นและหรือดอกเบี้ย",
	regis_repay_dda         	string       comment "Def(En): DDA account register to pay loan/contingent 
Def(Th):",
	borrower_type           	string       comment "Def(En): Type of borrower
Def(Th):",
	grace_flag              	string       comment "Def(En): Grace period flag 
Def(Th):",
	grace_start_date        	string       comment "Def(En): Grace period Start date 
Def(Th): จะมีค่าต่อเมื่อ GRACE_FLAG = Y",
	grace_end_date          	string       comment "Def(En): Grace period End date 
Def(Th): จะมีค่าต่อเมื่อ GRACE_FLAG = Y",
	center-code             	string       comment "Def(En): RC Code
Def(Th):",
	prin_coa_lgl_ent        	string       comment "Def(En): LEGAL ENTITY (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_rspl_cntr      	string       comment "Def(En): RESPONSIBILITY CENTER (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_ac             	string       comment "Def(En): OGL ACCOUNT (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_fnc            	string       comment "Def(En): FUNCTION (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_line_of_bsn    	string       comment "Def(En): LINE OF BUSINESS (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_pd             	string       comment "Def(En): PRODUCT CODE (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_intco          	string       comment "Def(En): INTER COMPANY (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_inrco          	string       comment "Def(En): INTRA COMPANY (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_prj            	string       comment "Def(En): PROJECT (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_futr_used1     	string       comment "Def(En): FUTURE USED1 (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_futr_used2     	string       comment "Def(En): FUTURE USED2 (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_pd_ftr_code    	string       comment "Def(En): SUB PRODUCT - Kbank Product Code 9 digit (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_lgl_ent    	string       comment "Def(En): LEGAL ENTITY (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_rspl_cntr  	string       comment "Def(En): RESPONSIBILITY CENTER (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_ac         	string       comment "Def(En): OGL ACCOUNT (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_fnc        	string       comment "Def(En): FUNCTION (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_line_of_bsn	string       comment "Def(En): LINE OF BUSINESS (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_pd         	string       comment "Def(En): PRODUCT CODE (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_intco      	string       comment "Def(En): INTER COMPANY (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_inrco      	string       comment "Def(En): INTRA COMPANY (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_prj        	string       comment "Def(En): PROJECT (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_futr_used1 	string       comment "Def(En): FUTURE USED1 (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_futr_used2 	string       comment "Def(En): FUTURE USED2 (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_pd_ftr_code	string       comment "Def(En): SUB PRODUCT - Kbank Product Code 9 digit (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_lgl_ent     	string       comment "Def(En): LEGAL ENTITY (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_rspl_cntr   	string       comment "Def(En): RESPONSIBILITY CENTER (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_ac          	string       comment "Def(En): OGL ACCOUNT (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_fnc         	string       comment "Def(En): FUNCTION (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_line_of_bsn 	string       comment "Def(En): LINE OF BUSINESS (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_pd          	string       comment "Def(En): PRODUCT CODE (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_intco       	string       comment "Def(En): INTER COMPANY (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_inrco       	string       comment "Def(En): INTRA COMPANY (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_prj         	string       comment "Def(En): PROJECT (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_futr_used1  	string       comment "Def(En): FUTURE USED1 (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_futr_used2  	string       comment "Def(En): FUTURE USED2 (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_pd_ftr_code 	string       comment "Def(En): SUB PRODUCT - Kbank Product Code 9 digit (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_lgl_ent        	string       comment "Def(En): LEGAL ENTITY (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_rspl_cntr      	string       comment "Def(En): RESPONSIBILITY CENTER (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_ac             	string       comment "Def(En): OGL ACCOUNT (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_fnc            	string       comment "Def(En): FUNCTION (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_line_of_bsn    	string       comment "Def(En): LINE OF BUSINESS (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_pd             	string       comment "Def(En): PRODUCT CODE (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_intco          	string       comment "Def(En): INTER COMPANY (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_inrco          	string       comment "Def(En): INTRA COMPANY (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_prj            	string       comment "Def(En): PROJECT (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_futr_used1     	string       comment "Def(En): FUTURE USED1 (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_futr_used2     	string       comment "Def(En): FUTURE USED2 (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_pd_ftr_code    	string       comment "Def(En): SUB PRODUCT - Kbank Product Code 9 digit (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_lgl_ent    	string       comment "Def(En): LEGAL ENTITY (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_rspl_cntr  	string       comment "Def(En): RESPONSIBILITY CENTER (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_ac         	string       comment "Def(En): OGL ACCOUNT (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_fnc        	string       comment "Def(En): FUNCTION (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_line_of_bsn	string       comment "Def(En): LINE OF BUSINESS (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_pd         	string       comment "Def(En): PRODUCT CODE (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_intco      	string       comment "Def(En): INTER COMPANY (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_inrco      	string       comment "Def(En): INTRA COMPANY (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_prj        	string       comment "Def(En): PROJECT (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_futr_used1 	string       comment "Def(En): FUTURE USED1 (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_futr_used2 	string       comment "Def(En): FUTURE USED2 (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_pd_ftr_code	string       comment "Def(En): SUB PRODUCT - Kbank Product Code 9 digit (as Master setup for Chart of Account)
Def(Th):",
	acr_bss_code            	string       comment "Def(En): [Use by TFRS9]
Accrual Basis Code is the basis on which the interest accrual on an account is calculated. 
Def(Th):",
	amrz_tp                 	string       comment "Def(En): Amortization Type
Trade : Principle is paid at Maturity date only : Send '2'
Def(Th):",
	orig_book_bal_ccy       	string       comment "Def(En): The original book balance (CCY) is the starting book balance. This field should always remain the same until the account is closed. The balance should be set according to its currency. 

Original book balance will be differed from original par balance in case of product with discount only. Original Book Balance = Original Par Balance - Original Discount.
Def(Th):",
	orig_book_bal_thb       	string       comment "Def(En): The original book balance (THB) is the starting book balance. This field should always remain the same until the account is closed. 

Original book balance will be differed from original par balance in case of product with discount only. Original Book Balance = Original Par Balance - Original Discount.
Def(Th):",
	orig_prem_dcn_ccy       	string       comment "Def(En): The Original Premium/Discount (CCY) is the starting premium/discount amount. This field should always remain the same until the account is closed and it should be equal to total discount amount. The amount should be according to its currency. 
The value should be send as minus value
Def(Th):",
	orig_prem_dcn_thb       	string       comment "Def(En): The Original Premium/Discount (THB) is the starting premium/discount amount. This field should always remain the same until the account is closed and it should be equal to total discount amount. 
The value should be send as minus value
Def(Th):",
	crn_book_bal_ccy        	string       comment "Def(En): Current Book Balance (CCY) should be equal to current par balance in case of non discount loan otherwise field current book balance = Current Par Balance - Current Premium/Discount
Def(Th):",
	crn_book_bal_thb        	string       comment "Def(En): Current Book Balance (THB) should be equal to current par balance in case of non discount loan otherwise field current book balance = Current Par Balance - Current Premium/Discount
Def(Th):",
	crn_prem_dcn_ccy        	string       comment "Def(En): [Use by TFRS9]

The current premium/discount (CCY) is the income or expense that bank has not yet recognized at the position date.

This field will be used for product with discount thus it will relate to field discount type. The expected value for this field must have minus sign (for discount). This field will be calculated 7 days

If monthend is non-working day : at last working day before monthend, current premium/discount value has to be value at monthend date (same data as Monthly file)

note:  Purchase product will be '0'
Def(Th):",
	crn_prem_dcn_thb        	string       comment "Def(En): The current premium/discount(THB) is the income or expense that bank has not yet recognized at the position date.

This field will be used for product with discount thus it will relate to field discount type. The expected value for this field must have minus sign (for discount). This field will be calculated 7 days

If monthend is non-working day : at last working day before monthend, current premium/discount value has to be value at monthend date (same data as Monthly file)

note:  Purchase product will be '0'
Def(Th):",
	av_book_bal_ccy         	string       comment "Def(En): Average Book Balance(CCY): ACCUMULATE Month to date of Daily Average Book Balance 

Daily Average Book balance is calculated from current book balance divide by number of days in that month. Daily Average Book balance is calculated 7 days.

ACCUMULATE amount start from loan effective date until day before Loan outstanding is 0.

For last working day of the week , ACCUMULATE amount has to include non-working day.
If monthend is non-working day : at last working day before monthend, ACCUMULATE amount has to include non-working day.

Case#1  : Loan transaction start and mature in same month of Position date
Accumulate amount start from start loan effective date until the day before Loan outstanding is 0.
Example : Effective Date = 1-Feb , Maturity = 8-Feb, Cur Book Bal = 1M
Position date = 5 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28);
Position date = 8 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28) +  (1M/28) +  (1M/28);


Case#2  : Loan transaction start in same month of Position date but mature on later month
Accumulate amount start from start loan effective date until monthend date.
Example : Effective Date = 1-Feb , Maturity = 2-Mar, Cur Book Bal = 1M
Position date = 5 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28);
Position date = 28 Feb 
<AV_BOOK_BAL> = 28 * (1M/28);

Case#3  : Loan transaction start in previous month but mature in same month of Position date
Accumulate amount start from 1st day of the month until the day before Loan outstanding is 0.
Example : Effective Date = 1-Jan , Maturity = 8-Feb, Cur Book Bal = 1M
Position date = 5 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28);
Position date = 8 Feb 
<AV_BOOK_BAL>  =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28) +  (1M/28) +  (1M/28);

Case#4  : Loan transaction start in previous month and mature on later month
Accumulate amount start from 1st day of the month until monthend date.
Example : Effective Date = 1-Jan , Maturity = 2-Mar, Cur Book Bal = 1M
Position date = 5 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28);
Position date = 28 Feb 
<AV_BOOK_BAL> = 28 * (1M/28);
Def(Th):",
	av_book_bal_thb         	string       comment "Def(En): Average Book Balance(THB): ACCUMULATE Month to date of Daily Average Book Balance 

Daily Average Book balance is calculated from current book balance divide by number of days in that month. Daily Average Book balance is calculated 7 days.

ACCUMULATE amount start from loan effective date until day before Loan outstanding is 0.

For last working day of the week , ACCUMULATE amount has to include non-working day.
If monthend is non-working day : at last working day before monthend, ACCUMULATE amount has to include non-working day.

Case#1  : Loan transaction start and mature in same month of Position date
Accumulate amount start from start loan effective date until the day before Loan outstanding is 0.
Example : Effective Date = 1-Feb , Maturity = 8-Feb, Cur Book Bal = 1M
Position date = 5 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28);
Position date = 8 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28) +  (1M/28) +  (1M/28);


Case#2  : Loan transaction start in same month of Position date but mature on later month
Accumulate amount start from start loan effective date until monthend date.
Example : Effective Date = 1-Feb , Maturity = 2-Mar, Cur Book Bal = 1M
Position date = 5 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28);
Position date = 28 Feb 
<AV_BOOK_BAL> = 28 * (1M/28);

Case#3  : Loan transaction start in previous month but mature in same month of Position date
Accumulate amount start from 1st day of the month until the day before Loan outstanding is 0.
Example : Effective Date = 1-Jan , Maturity = 8-Feb, Cur Book Bal = 1M
Position date = 5 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28);
Position date = 8 Feb 
<AV_BOOK_BAL>  =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28) +  (1M/28) +  (1M/28);

Case#4  : Loan transaction start in previous month and mature on later month
Accumulate amount start from 1st day of the month until monthend date.
Example : Effective Date = 1-Jan , Maturity = 2-Mar, Cur Book Bal = 1M
Position date = 5 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28);
Position date = 28 Feb 
<AV_BOOK_BAL> = 28 * (1M/28);
Def(Th):",
	av_par_bal_ccy          	string       comment "Def(En): Average Par Balance (CCY): ACCUMULATE Month to date of Daily Average Par Balance 

Daily Average Par Balance is calculated from Current PAR Balance divide by number of days in that month. Daily Average Par balance is calculated 7 days.

ACCUMULATE amount start from loan effective date until day before Loan outstanding is 0.

For last working day of the week , ACCUMULATE amount has to include non-working day.
If monthend is non-working day : at last working day before monthend, ACCUMULATE amount has to include non-working day.

Case#1  : Loan transaction start and mature in same month of Position date
Accumulate amount start from start loan effective date until the day before Loan outstanding is 0.

Case#2  : Loan transaction start in same month of Position date but mature on later month
Accumulate amount start from start loan effective date until monthend date.

Case#3  : Loan transaction start in previous month but mature in same month of Position date
Accumulate amount start from 1st day of the month until the day before Loan outstanding is 0.

Case#4  : Loan transaction start in previous month and mature on later month
Accumulate amount start from 1st day of the month until monthend date.

note: refer example of each case from Average Book Balance
Def(Th):",
	av_par_bal_thb          	string       comment "Def(En): Average Par Balance(THB) : ACCUMULATE Month to date of Daily Average Par Balance 

Daily Average Par Balance is calculated from Current PAR Balance divide by number of days in that month. Daily Average Par balance is calculated 7 days.

ACCUMULATE amount start from loan effective date until day before Loan outstanding is 0.

For last working day of the week , ACCUMULATE amount has to include non-working day.
If monthend is non-working day : at last working day before monthend, ACCUMULATE amount has to include non-working day.

Case#1  : Loan transaction start and mature in same month of Position date
Accumulate amount start from start loan effective date until the day before Loan outstanding is 0.

Case#2  : Loan transaction start in same month of Position date but mature on later month
Accumulate amount start from start loan effective date until monthend date.

Case#3  : Loan transaction start in previous month but mature in same month of Position date
Accumulate amount start from 1st day of the month until the day before Loan outstanding is 0.

Case#4  : Loan transaction start in previous month and mature on later month
Accumulate amount start from 1st day of the month until monthend date.

note: refer example of each case from Average Book Balance
Def(Th):",
	crn_idnx_rate           	string       comment "Def(En): Current index rate is the index rate of the account interest rate type at the position date.
Current index rate will send 
- 0 : when current Interest rate type (INT_CHG_F) is Fixed rate
- Base rate (at current date) : when current Interest rate type (INT_CHG_F)  is Float rate
Def(Th):",
	orig_int_rate           	string       comment "Def(En): Original Interest Rate is Effective Interest rate (all in rate) at loan effective date
Def(Th):",
	int_chg_f               	string       comment "Def(En): Interest Change Flag (current interest rate type) 
Interest Calculate Type 
Def(Th):",
	last_int_pymt_dt        	string       comment "Def(En): Last Interest Payment Date is the date in which the interest payment is last scheduled before position date. If last interest payment date does not exist then this field should be set to origination date/Effective date. 
Def(Th):",
	last_pnp_pymt_dt        	string       comment "Def(En): Last Principal Payment Date is the date in which the principal payment is last schedule before position date.
If the last principal payment date does not exist (first payment) then the last principal payment date is the origination date/Effective date.
Def(Th):",
	last_rprc_dt            	string       comment "Def(En): Last Reprice Date
If Interest rate is 
- Fix rate : send Effective date
- Float rate : send Position date 
Def(Th):",
	nxt_int_pymt_dt         	string       comment "Def(En): Next Interest Payment Date

If interest schedule is
Monthly = send next billing date
Maturity = send Maturity date
Def(Th):",
	overdue_flag            	string       comment "Def(En): Identifier Transaction Overdue product
(Overdue for Principle)
Def(Th):",
	value_dt                	string       comment "Def(En): Value date of transaction
Def(Th): ระบบ Digital Factoring จะไม่ส่งค่านี้ให้ เนื่องจากระบบส่งข้อมูลทุกวัน เป็นแบบ daily",
	ppymt_bal_amt_ccy       	string       comment "Def(En): Prepayment Balance amount (CCY) is the total prepayment amount that exclude amount pay on maturity date
Def(Th):",
	ppymt_bal_amt_thb       	string       comment "Def(En): Prepayment Balance amount(THB) is the total prepayment amount that exclude amount pay on maturity date
Def(Th):",
	ppymt_dt                	string       comment "Def(En): Prepayment date is the latest date of prepayment (before maturity date)
Def(Th):",
	ppymt_f                 	string       comment "Def(En): Prepayment Flag
Def(Th):",
	weighted_avg_ind_rate   	string       comment "Def(En): Weighted Average Index Rate (Month to date) = sum (Daily Weight Index Rate) / sum (Loan Outstanding)

Daily Weight Index Rate = Loan Outstanding * CRN_IDNX_RATE 
Daily Weight Index Rate is calculated everyday (7 days). The value of fields (Loan Outstanding and CRN_IDNX_RATE) for non-working day use same value from last working day.

If monthend is non-working day : at last working day before monthend, Weighted Average Index Rate has to include amount of non-working day (same data as Monthly file)

Ex. Position date is 4/5/07 : Weighted Average Index Rate = 5.41


Def(Th):",
	orig_admn_rate          	string       comment "Def(En): Original Admin Rate
Def(Th):",
	src_system              	string       comment "Def(En): SYSTEM that generate data
Def(Th):",
	accum_acr_int_ccy       	string       comment "Def(En): Accumulate accrue interest
Def(Th): ดอกเบี้ยสะสม ถ้ามีการมาจ่ายเงิน ค่านี้จะไม่ลดลง 

กรณีเงิน THB ค่านี้จะเหมือนกับ ACCUM_ACR_INT_THB",
	accum_acr_int_thb       	string       comment "Def(En): Accumulate accrue interest
Def(Th): ดอกเบี้ยสะสม ถ้ามีการมาจ่ายเงิน ค่านี้จะไม่ลดลง 

กรณีเงิน THB ค่านี้จะเหมือนกับ ACCUM_ACR_INT_CCY",
	lpm_class               	string       comment "Def(En): LPM Classification Level
Def(Th):",
	cust_type               	string       comment "Def(En): Def(En):Code that refer to involved party legal structure type
Def(Th):รหัสบุคคล/นิติบุคคลที่เสียภาษี",
	min_fee_rate            	string       comment "Def(En): Minimum Fee Rate 
Def(Th): อัตราค่าธรรมเนียมต่ำสุด (ยกเว้นประเภทกลุ่มตราสารอนุพันธ์)",
	min_fee_rate_unit       	string       comment "Def(En): Minimum Fee Rate Unit Def(Th): หน่วยของอัตราค่าธรรมเนียมต่ำสุด
(Classification Name : Fee Rate Unit)",
	max_fee_rate            	string       comment "Def(En): Maximum Fee Rate   
Def(Th): อัตราค่าธรรมเนียมสูงสุด (ยกเว้นประเภทกลุ่มตราสารอนุพันธ์)",
	max_fee_rate_unit       	string       comment "Def(En): Maximum Fee Rate Unit Def(Th): หน่วยของอัตราค่าธรรมเนียมสูงสุด
(Classification Name : Fee Rate Unit)",
	grace_prin_day          	string       comment "Def(En): Grace for default of Principal 
Unit = Day
Note: Grace period start from DUE_DATE
Def(Th):",
	credit_app_id           	string       comment "Def(En): Credit Application ID
Def(Th): เลขที่คำอนุมัติจาก Under writer",
	outstnd_amt_ccy         	string       comment "Def(En): Outstanding Amount 
กรณีเป็นเงิน THB Field นี้มีค่าเท่ากันกับ OUTSTND_AMT_THB
Def(Th):",
	outstnd_amt_thb         	string       comment "Def(En): Outstanding Amount (Princ + Accrued + Late Charge) in CCY
Def(Th): กรณีเป็นเงิน THB Field นี้มีค่าเท่ากันกับ 
OUTSTND_AMT_CCY",
	percent_coverage        	string       comment "Def(En): Percent coverage 
Def(Th):",
	load_tms                	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id              	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                  	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                  	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_dgtl_fctrng/dgtl_fctrng_fact_acct' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);