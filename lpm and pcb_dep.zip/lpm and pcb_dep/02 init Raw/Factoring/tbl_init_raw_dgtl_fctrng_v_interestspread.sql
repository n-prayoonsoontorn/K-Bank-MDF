-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_dgtl_fctrng_v_interestspread.sql
# Area: dgtl_fctrng
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_DGTL_FCTRNG.DGTL_FCTRNG_V_INTERESTSPREAD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_dgtl_fctrng.dgtl_fctrng_v_interestspread (
	pos_dt      	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	orgcode     	string       comment "Def(En):
Def(Th): Organization Code : always KBANK",
	compcode    	string       comment "Def(En): Limit Number
Def(Th):",
	effdate     	string       comment "Def(En):
Def(Th): วันที่มีผล",
	srate       	string       comment "Def(En): Spread
Def(Th):",
	updateby    	string       comment "Def(En):
Def(Th): ผู้แก้ไขล่าสุด",
	updatedate  	string       comment "Def(En):
Def(Th): วันที่แก้ไขล่าสุด",
	updatetime  	string       comment "Def(En):
Def(Th): เวลาที่แก้ไขล่าสุด",
	version     	string       comment "Def(En):
Def(Th): ครั้งที่แก้ไข (Internal use)",
	interestcode	string       comment "Def(En):
Def(Th): Interest Index 
เช่น MOR, LIBOR, FIXED
refer to InterestMaster.Icode",
	effrate     	string       comment "Def(En):
Def(Th): Effective Rate",
	remarks     	string       comment "Def(En):
Def(Th): Remarks หน้า Interest",
	contractrate	string       comment "Def(En): Contract Rate
Def(Th):",
	createby    	string       comment "Def(En):
Def(Th): ผู้บันทึกครั้งแรก",
	createdate  	string       comment "Def(En):
Def(Th): วันที่บันทึกครั้งแรก",
	createtime  	string       comment "Def(En):
Def(Th): เวลาที่บันทึกครั้งแรก",
	intbytime   	string       comment "Def(En):
Def(Th): ดอกเบี้ยรายครั้ง ระดับ Schedule (Y/N)",
	load_tms    	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id  	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy    	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm      	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd      	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_dgtl_fctrng/dgtl_fctrng_v_interestspread' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);