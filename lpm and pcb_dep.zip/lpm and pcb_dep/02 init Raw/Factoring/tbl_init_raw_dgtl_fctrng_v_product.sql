-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_dgtl_fctrng_v_product.sql
# Area: dgtl_fctrng
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_DGTL_FCTRNG.DGTL_FCTRNG_V_PRODUCT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_dgtl_fctrng.dgtl_fctrng_v_product (
	pos_dt           	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	productcode      	string       comment "Def(En): Product Code 9 Digits
Def(Th):",
	productname      	string       comment "Def(En): Product Name
Def(Th):",
	productgroupcode 	string       comment "Def(En): DropDown  =  DO,IM,EX
Def(Th):",
	productgroup     	string       comment "Def(En): DropDown  =  Domestic, Import, Export
Def(Th):",
	recoursetypecode 	string       comment "Def(En): DropDown  =  WR,WO
Def(Th):",
	recoursetype     	string       comment "Def(En): DropDown  = With Recourse, Without Recourse
Def(Th):",
	insurancetypecode	string       comment "Def(En): DropDown  =  WI,WO
Def(Th):",
	insurancetype    	string       comment "Def(En): DropDown = With Insurance, Without Insurance
Def(Th):",
	fundtypecode     	string       comment "Def(En): DropDown  =  F,UF
Def(Th):",
	fundtype         	string       comment "Def(En): DropDown = Fund, Unfund
Def(Th):",
	fcicode          	string       comment "Def(En): DropDown  = F, NF
Def(Th):",
	fci              	string       comment "Def(En): DropDown = FCI , Non FCI
Def(Th):",
	pastdue          	string       comment "Def(En): Grace period for Collection
Def(Th):",
	daysdefault      	string       comment "Def(En): Grace Period for Default Rate
Def(Th):",
	defaultrate      	string       comment "Def(En): Max late  charge
Def(Th):",
	remarks          	string       comment "Def(En): Remarks
Def(Th):",
	status           	string       comment "Def(En): Status
1 = Request
2 = Active
3 = Inactive
Def(Th):",
	termcode         	string       comment "Def(En): DropDown  =  S/L
Def(Th):",
	term             	string       comment "Def(En): DropDown = Short Term, Long Term
Def(Th):",
	createby         	string       comment "Def(En):
Def(Th): ผู้บันทึกครั้งแรก",
	createdate       	string       comment "Def(En):
Def(Th): วันที่บันทึกครั้งแรก",
	createtime       	string       comment "Def(En):
Def(Th): เวลาที่บันทึกครั้งแรก",
	updateby         	string       comment "Def(En):
Def(Th): ผู้แก้ไขล่าสุด",
	updatedate       	string       comment "Def(En):
Def(Th): วันที่แก้ไขล่าสุด",
	updatetime       	string       comment "Def(En):
Def(Th): เวลาที่แก้ไขล่าสุด",
	load_tms         	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id       	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy         	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm           	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd           	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_dgtl_fctrng/dgtl_fctrng_v_product' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);