-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_kplus_jmobileactlog_log.sql
# Area: kplus
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_KPLUS.KPLUS_JMOBILEACTLOG_LOG
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_kplus.kplus_jmobileactlog_log (
	pos_dt               	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	logid                	string       comment "Def(En): Log ID
Def(Th):",
	trandatetime         	string       comment "Def(En): Transaction date 
Def(Th): วันทำรายการ
เช่น 2018-01-09 00:00:00",
	trandesc             	string       comment "Def(En): Transaction Description.
Def(Th):",
	mobileno             	string       comment "Def(En):
Def(Th): หมายเลขโทรศํพท์ทำรายการ",
	mobileoperator       	string       comment "Def(En):Mobile operator
Def(Th): Operation ของหมายเลขโทรศัพท์ที่ใช้ทำรายการ",
	currentaccountno     	string       comment "Def(En):Current account number
Def(Th): หมายเลขบัญชี CA ที่ใช้ทำรายการ",
	savingaccountno      	string       comment "Def(En):Saving account number
Def(Th): หมายเลขบัญชี SA ที่ใช้ทำรายการ",
	cardno               	string       comment "Def(En):Card number
Def(Th): หมายเลขบัตรที่ใช้ทำรายการ (encrypt)",
	cardtype             	string       comment "Def(En):
Def(Th): ประเภทบัตรที่ใช้ทำรายการ",
	language             	string       comment "Def(En):
Def(Th): ภาษาที่ใช้ในการทำรายการ",
	otp                  	string       comment "Def(En):
Def(Th): รหัสผ่านครั้งเดียว",
	pin                  	string       comment "Def(En):
Def(Th): รหัสการ Login",
	upgradeflag          	string       comment "Def(En):Upgrade Flag
Def(Th):",
	thirdfundtransferflag	string       comment "Def(En):Third Fund Transfer Flag
Def(Th):",
	productcode          	string       comment "Def(En):Product Code
Def(Th):",
	channel              	string       comment "Def(En):Channel that use to perform the transaction.
Def(Th):",
	location             	string       comment "Def(En): Location that use to perform the transaction.  ATM machine no., BranchCode.
Def(Th):",
	username             	string       comment "Def(En): Username that perform the transaction via BackOffice.
Def(Th):",
	responsecode         	string       comment "Def(En):
Def(Th): รหัสแสดงสถานะการทำงานทั้งกรณี Error และ Success",
	remark               	string       comment "Def(En): Remark or response message that related with ResponseCode.
Def(Th):",
	updatetype           	string       comment "Def(En):
Def(Th): ประเภทของการแก้ไข กรณีเป็น transaction เพื่อเข้ามาแก้ไข profile.",
	oldupdatevalue       	string       comment "Def(En):Old values before perform update.
Def(Th):",
	newupdatevalue       	string       comment "Def(En):New values after performed update.
Def(Th):",
	ipaddress            	string       comment "Def(En): IP Address that use to perform the transaction.
Def(Th):",
	latitude             	string       comment "Def(En): Latitude of Location when customers do 
Def(Th):",
	longitude            	string       comment "Def(En): Longitude of Location when customers do transaction
Def(Th):",
	load_tms             	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id           	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy             	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm               	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd               	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_kplus/kplus_jmobileactlog_log' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);