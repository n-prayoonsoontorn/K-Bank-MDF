-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_lpm_as400_ar_wrtof_rcv.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_AR_WRTOF_RCV
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_ar_wrtof_rcv (
	pos_dt                 	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	l01d070_acct_no        	string       comment "Def(En):
Def(Th): เลขที่บัญชี",
	l01d070_w_outs         	string       comment "Def(En):
Def(Th): ยอดรวมตัดสูญ เงินต้น + ดอกเบี้ย",
	l01d070_w_bot_principal	string       comment "Def(En):
Def(Th): เงินต้นตัดสูญ ตาม ธปท.",
	l01d070_w_bot_accru    	string       comment "Def(En):
Def(Th): ดอกเบี้ยตัดสูญ ตาม ธปท.",
	l01d070_w_tfb_principal	string       comment "Def(En):
Def(Th): เงินต้นตัดสูญ ตาม KBANK",
	l01d070_w_tfb_accru    	string       comment "Def(En):
Def(Th): ดอกเบี้ยตัดสูญ ตาม KBANK",
	l01d070_w_tfb_reverse  	string       comment "Def(En):
Def(Th): ยอด REVERSE ตัดสูญ ตาม KBANK",
	l01d070_w_enter_yyyymm 	string       comment "Def(En):
Def(Th): ปีเดือนที่ตัดสูญ",
	l01d070_w_update_yyyymm	string       comment "Def(En):
Def(Th): ปีเดือนที่ตัดสูญปรับปรุง",
	l01d070_r_outs         	string       comment "Def(En):
Def(Th): ยอดรวมรับคืน เงินต้น + ดอกเบี้ย",
	l01d070_r_bot_principal	string       comment "Def(En):
Def(Th): เงินต้นรับคืนตาม ธปท.",
	l01d070_r_bot_accru    	string       comment "Def(En):
Def(Th): ดอกเบี้ยรับคืนตาม ธปท.",
	l01d070_r_tfb_principal	string       comment "Def(En):
Def(Th): เงินต้นรับคืนตาม KBANK",
	l01d070_r_tfb_accru    	string       comment "Def(En):
Def(Th): ดอกเบี้ยรับคืนตาม KBANK",
	l01d070_r_tfb_reverse  	string       comment "Def(En):
Def(Th): ยอด REVERSE รับคืน ตาม KBANK",
	l01d070_r_enter_yyyymm 	string       comment "Def(En):
Def(Th): ปีเดือนที่รับคืน",
	l01d070_r_update_yyyymm	string       comment "Def(En):
Def(Th): ปีเดือนที่รับคืนปรับปรุง",
	load_tms               	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id             	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy               	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                 	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                 	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_ar_wrtof_rcv' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);