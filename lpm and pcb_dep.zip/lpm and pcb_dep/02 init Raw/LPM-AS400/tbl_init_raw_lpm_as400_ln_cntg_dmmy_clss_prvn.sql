-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_lpm_as400_ln_cntg_dmmy_clss_prvn.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_AS400.LPM_AS400_LN_CNTG_DMMY_CLSS_PRVN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_as400.lpm_as400_ln_cntg_dmmy_clss_prvn (
	pos_dt                       	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	l01w769_tm_id                	string       comment "Def(En):
Def(Th): เดือนที่ประมวลผล",
	l01w769_acct_no              	string       comment "Def(En):
Def(Th): เลขที่บัญชี",
	l01w769_acct_type            	string       comment "Def(En):
Def(Th): ประเภทบัญชี",
	l01w769_cr_type              	string       comment "Def(En):
Def(Th): ประเภทเครดิต",
	l01w769_cust_no              	string       comment "Def(En):
Def(Th): เลขที่ลูกหนี้",
	l01w769_title                	string       comment "Def(En):
Def(Th): คำนำหน้า",
	l01w769_name                 	string       comment "Def(En):
Def(Th): ชื่อลูกหนี้",
	l01w769_branch_no            	string       comment "Def(En):
Def(Th): รหัสสาขา",
	l01w769_dept_no              	string       comment "Def(En):
Def(Th): รหัสสังกัด",
	l01w769_acct_bus_code        	string       comment "Def(En):
Def(Th): รหัสประเภทธุรกิจ ระดับบัญชี",
	l01w769_cust_bus_code        	string       comment "Def(En):
Def(Th): รหัสประเภทธุรกิจ ระดับลูกหนี้",
	l01w769_fics_type            	string       comment "Def(En):
Def(Th): ประเภทหัวบัญชี",
	l01w769_prv_day_diff         	string       comment "Def(En):
Def(Th): จำนวนวันขาดผ่อน",
	l01w769_sign_prv_outs        	string       comment "Def(En):
Def(Th): เครื่องหมาย PRVOUTS",
	l01w769_prv_outs             	string       comment "Def(En):
Def(Th): ยอดหนี้รวมดอกเบี้ย",
	l01w769_sign_prv_accru       	string       comment "Def(En):
Def(Th): เครื่องหมาย PRVACCR",
	l01w769_prv_accru            	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยค้างรับ",
	l01w769_prv_int_fg           	string       comment "Def(En):
Def(Th): Flag ดอกเบี้ย, 0-คิดดอกเบี้ย, 1-งดคิดดอกเบี้ย",
	l01w769_acct_cust_type       	string       comment "Def(En):
Def(Th): ประเภทลูกค้า (ระดับบัญชี)",
	l01w769_limit                	string       comment "Def(En):
Def(Th): วงเงิน ระดับบัญชี",
	l01w769_dept_code            	string       comment "Def(En):
Def(Th): รหัสสังกัด",
	l01w769_bibf_in_out          	string       comment "Def(En): Flag BIBF, 1 - OUT-IN, 2 - OUT-OUT, 3 - PERSONAL OD
Def(Th):",
	l01w769_contract_date        	string       comment "Def(En):
Def(Th): วันที่ทำสัญญา",
	l01w769_rate_type            	string       comment "Def(En):
Def(Th): ประเภทอัตราดอกเบี้ย",
	l01w769_sign                 	string       comment "Def(En):
Def(Th): 0 =  + ,  1 =  -",
	l01w769_spread               	string       comment "Def(En):
Def(Th): ผลต่างของดอกเบี้ย",
	l01w769_center_branch        	string       comment "Def(En):
Def(Th): ศูนย์ธุรกิจต่างประเทศ",
	l01w769_acct_ofc_tdr         	string       comment "Def(En):
Def(Th): สังกัดผู้ดูแล",
	l01w769_due_date             	string       comment "Def(En):
Def(Th): วันครบกำหนด",
	l01w769_sign_bef_outs        	string       comment "Def(En):
Def(Th): เครื่องหมาย BEFOUTS",
	l01w769_bef_outs             	string       comment "Def(En):
Def(Th): ยอดหนี้ก่อนตัดสูญ",
	l01w769_sign_bef_accru       	string       comment "Def(En):
Def(Th): เครื่องหมาย BEFACCR",
	l01w769_bef_accru            	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยคงค้างก่อนตัดสูญ",
	l01w769_group2               	string       comment "Def(En):
Def(Th): จัดชั้นกลุ่ม 2",
	l01w769_asset_flag           	string       comment "Def(En):
Def(Th): FLAG สินทรัพย์",
	l01w769_sign_prv_ext_pay     	string       comment "Def(En):
Def(Th): เครื่องหมาย PRVEXTPAY",
	l01w769_prv_ext_pay          	string       comment "Def(En):
Def(Th): ยอดส่วนลดรับ",
	l01w769_cust_type            	string       comment "Def(En):
Def(Th): ประเภทลูกค้า (ระดับลูกหนี้)",
	l01w769_bot_acct_group       	string       comment "Def(En):
Def(Th): หนี้จัดชั้นตามธนาคารแห่งประเทศไทย",
	l01w769_class_from           	string       comment "Def(En):
Def(Th): รหัสการปรับโครงสร้างหนี้ 0, 1, 2, 3",
	l01w769_sign_date            	string       comment "Def(En):
Def(Th): ปีเดือนวันที่ปรับโครงสร้างหนี้",
	l01w769_class_reason         	string       comment "Def(En):
Def(Th): รหัสเหตุผลการปรับ เช่น 601, 901, 902",
	l01w769_asset_group          	string       comment "Def(En):
Def(Th): 01-CG, 02-RT, 03-DR, 04-RN, 05-OTHERS (ฝ่าย นค)",
	l01w769_product_name         	string       comment "Def(En):
Def(Th): ชื่อผลิตภัณฑ์ของธนาคาร (ฝ่าย นค)",
	l01w769_segment              	string       comment "Def(En):
Def(Th): กลุ่มผู้เป็นเจ้าของสินทรัพย์ หรือผู้ดูแล (ฝ่าย นค)",
	l01w769_segment_geo          	string       comment "Def(En):
Def(Th): กลุ่มผู้เป็นเจ้าของสินทรัพย์ หรือผู้ดูแล (ฝ่าย นค)",
	l01w769_indus_index_97       	string       comment "Def(En):
Def(Th): อุตสาหกรรม 97 อุตฯ  และผลิตภัณฑ์ (ฝ่าย นค)",
	l01w769_indus_index_100      	string       comment "Def(En):
Def(Th): อุตสาหกรรม 100 อุตฯ  และผลิตภัณฑ์ (ฝ่าย นค)",
	l01w769_loans_aging_group    	string       comment "Def(En):
Def(Th): จำแนกกลุ่มตามช่วงของวันค้าง แบบที่ 1",
	l01w769_loans_aging_group2   	string       comment "Def(En):
Def(Th): จำแนกกลุ่มตามช่วงของวันค้าง แบบที่ 2",
	l01w769_indus_index_con_97   	string       comment "Def(En):
Def(Th): การจำแนกอุตสาหกรรม 97 อย่างมีเงื่อนไข",
	l01w769_indus_index_con_100  	string       comment "Def(En):
Def(Th): การจำแนกอุตสาหกรรม 100 อย่างมีเงื่อนไข",
	l01w769_int_risk_ind97       	string       comment "Def(En):
Def(Th):  อัตราดอกเบี้ย ตามความเสี่ยงของอุตสาหกรรม 97",
	l01w769_int_risk_ind97_con   	string       comment "Def(En):
Def(Th): อัตราดอกเบี้ย ตามความเสี่ยงของอุตสาหกรรม 97",
	l01w769_limit_sub            	string       comment "Def(En):
Def(Th):  ยอด Principal ลดลง หรือ Account หายไป)",
	l01w769_due_date1            	string       comment "Def(En):
Def(Th): วันครบกำหนด",
	l01w769_cont_date            	string       comment "Def(En):
Def(Th): วันทำสัญญา",
	l01w769_cancel_flag          	string       comment "Def(En):
Def(Th): Flag การยกเลิกของ Credit card",
	l01w769_block_code           	string       comment "Def(En):
Def(Th): Block code ของ Credit card",
	l01w769_real_rec_flag        	string       comment "Def(En):
Def(Th):",
	l01w769_asset_type           	string       comment "Def(En):
Def(Th): ประเภทสินทรัพย์",
	l01w769_lec_status           	string       comment "Def(En):
Def(Th): รหัสการดำเนินการในการดำเนินคดีLEC",
	l01w769_coll_limit           	string       comment "Def(En):
Def(Th): วงเงินหลักประกัน",
	l01w769_coll_val             	string       comment "Def(En):
Def(Th): ราคาประเมินที่กระจายแล้ว",
	l01w769_acct_ofc_flag        	string       comment "Def(En):
Def(Th): Flag A/O รายบัญชี",
	l01w769_loan_purpose         	string       comment "Def(En):
Def(Th): จุดประสงค์การกู้เงิน",
	l01w769_pay_flag             	string       comment "Def(En):
Def(Th): Flag การจ่ายเงิน",
	l01w769_bad_center           	string       comment "Def(En): Bad Center
Def(Th):",
	l01w769_acct_res_outs        	string       comment "Def(En):
Def(Th): ยอดหนี้สำรองระดับบัญชี",
	l01w769_npl_outs             	string       comment "Def(En):
Def(Th): ยอดเงินต้น+ดอกเบี้ยค้างรับที่เป็น NPL",
	l01w769_npl_accru            	string       comment "Def(En):
Def(Th): ยอดดอกเบี้ยค้างรับที่เป็น NPL",
	l01w769_sign_int_receive     	string       comment "Def(En):
Def(Th): เครื่องหมาย INTREC",
	l01w769_int_receive          	string       comment "Def(En):
Def(Th): รายได้ดอกเบี้ย(เดือน)รายบัญชีที่ธนาคารรับรู้รายได้แล้ว",
	l01w769_pl_status            	string       comment "Def(En): 0=PL, 1=PRL
IF ACCT NPL GRP = 1,2 CLASS_FROM = 0,1  = PL
IF ACCT NPL GRP = 1,2 CLASS_FROM = 2  = PRL
Def(Th):",
	l01w769_acct_ofc_rev         	string       comment "Def(En):
Def(Th): ผู้ดูแลลูกค้าก่อนหน้า (ผู้ดูแลลูกค้าเดิม)",
	l01w769_eff_date             	string       comment "Def(En):
Def(Th): ปีเดือนวันที่เงื่อนไขการผ่อนชำระมีผลครั้งแรก",
	l01w769_pay_year             	string       comment "Def(En):
Def(Th): ระยะเวลาที่ต้องผ่อนชำระ (เดือน)",
	l01w769_npl_yyyymm           	string       comment "Def(En):
Def(Th): วันที่เริ่มเป็น NPL ล่าสุด",
	l01w769_pay_maturity         	string       comment "Def(En):
Def(Th):",
	l01w769_fg_draw_down         	string       comment "Def(En):
Def(Th): 0 = ใช้วงเงินไม่หมด
1 = ใช้วงเงินหมด",
	l01w769_cust_trade_status    	string       comment "Def(En):
Def(Th): สถานะการเป็นลูกค้า Trade",
	l01w769_s_act_tp_sub_lim_port	string       comment "Def(En):
Def(Th): เครื่องหมาย ACTPSLIMP",
	l01w769_acct_tp_sub_lim_port 	string       comment "Def(En):
Def(Th): วงเงินอนุมัติ (ระดับ ACCT-TYPE-SUB)
ที่หักยอดที่ซ้ำออกแล้ว
สามารถนำมารวมได้เป็นวงเงินภาระผูกพันทั้ง Port ของธนาคาร",
	l01w769_sign_exposure_amt    	string       comment "Def(En):
Def(Th): เครื่องหมาย EXPOSAMT",
	l01w769_exposure_amt         	string       comment "Def(En):
Def(Th): ยอด Exposure",
	l01w769_asset_owner          	string       comment "Def(En):
Def(Th):",
	l01w769_loan_size            	string       comment "Def(En):
Def(Th): จัดขนาดกลุ่มตามช่วงของ exposure",
	l01w769_sign_prin            	string       comment "Def(En):
Def(Th): เครื่องหมาย PRINCIPAL",
	l01w769_principal            	string       comment "Def(En):
Def(Th): ยอดเงินต้น",
	l01w769_segment_group        	string       comment "Def(En):
Def(Th): ประเภทกลุ่มผู้เป็นเจ้าของสินทรัพย์ หรือผู้ดูแล (ฝ่าย นค)",
	l01w769_asset_owner_group    	string       comment "Def(En):
Def(Th):",
	l01w769_legal_entity         	string       comment "Def(En):
Def(Th): รหัสบริษัท",
	l01w769_resp_center          	string       comment "Def(En):
Def(Th): รหัสสังกัด",
	l01w769_gl_account           	string       comment "Def(En):
Def(Th): รหัสบัญชีประเภทเครดิต",
	l01w769_function             	string       comment "Def(En):
Def(Th): รหัสฟังก์ชันงาน",
	l01w769_line_business        	string       comment "Def(En):
Def(Th): รหัสประเภทธุรกิจ",
	l01w769_gl_product_code      	string       comment "Def(En):
Def(Th): รหัสผลิตภัณฑ์สำหรับการบันทึกบัญชี",
	l01w769_inter_company        	string       comment "Def(En):
Def(Th): รหัสบริษัทในการหักค่าใช้จ่ายระหว่างบริษัทในเครือ",
	l01w769_intra_company        	string       comment "Def(En):
Def(Th): รหัสบริษัทในการหักค่าใช้จ่ายระหว่างฝ่ายงาน",
	l01w769_project              	string       comment "Def(En):
Def(Th): รหัสโครงการ",
	l01w769_gl_filler1           	string       comment "Def(En):
Def(Th): สำหรับใช้ในอนาคต",
	l01w769_gl_filler2           	string       comment "Def(En):
Def(Th): สำหรับใช้ในอนาคต",
	l01w769_product_code         	string       comment "Def(En):
Def(Th): รหัสผลิตภัณฑ์",
	load_tms                     	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                   	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                     	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                       	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                       	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_as400/lpm_as400_ln_cntg_dmmy_clss_prvn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);