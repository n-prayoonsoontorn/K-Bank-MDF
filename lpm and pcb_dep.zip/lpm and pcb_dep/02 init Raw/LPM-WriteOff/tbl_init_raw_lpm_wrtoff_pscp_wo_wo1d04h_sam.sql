-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_lpm_wrtoff_pscp_wo_wo1d04h_sam.sql
# Area: lpm_wrtoff
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_LPM_WRTOFF.LPM_WRTOFF_PSCP_WO_WO1D04H_SAM
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_lpm_wrtoff.lpm_wrtoff_pscp_wo_wo1d04h_sam (
	pos_dt                	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	wo04_cut_type         	string       comment "Def(En):
Def(Th):",
	wo04_cust_id          	string       comment "Def(En):
Def(Th):",
	wo04_account_no       	string       comment "Def(En):
Def(Th):",
	wo04_adjust_time      	string       comment "Def(En):
Def(Th):",
	wo04_type             	string       comment "Def(En):
Def(Th):",
	wo04_sign_date        	string       comment "Def(En):
Def(Th):",
	wo04_credit_type      	string       comment "Def(En):
Def(Th):",
	wo04_br_account       	string       comment "Def(En):
Def(Th):",
	wo04_drmemo_flag      	string       comment "Def(En):
Def(Th):",
	wo04_loss_deduct_prin 	string       comment "Def(En):
Def(Th):",
	wo04_loss_deduct_accru	string       comment "Def(En):
Def(Th):",
	wo04_bef_prin         	string       comment "Def(En):
Def(Th):",
	wo04_pay_incard_prin  	string       comment "Def(En):
Def(Th):",
	wo04_pay_incard_accru 	string       comment "Def(En):
Def(Th):",
	wo04_pay_out_card     	string       comment "Def(En):
Def(Th):",
	wo04_pay_reverse      	string       comment "Def(En):
Def(Th):",
	wo04_appr_prin        	string       comment "Def(En):
Def(Th):",
	wo04_appr_int         	string       comment "Def(En):
Def(Th):",
	wo04_deduct_account   	string       comment "Def(En):
Def(Th):",
	wo04_deduct_reverse   	string       comment "Def(En):
Def(Th):",
	wo04_deduct_hair_cut  	string       comment "Def(En):
Def(Th):",
	wo04_deduct_lpm       	string       comment "Def(En):
Def(Th):",
	wo04_deduct_npv       	string       comment "Def(En):
Def(Th):",
	wo04_profit_loss      	string       comment "Def(En):
Def(Th):",
	wo04_profit_loss_sign 	string       comment "Def(En):
Def(Th):",
	wo04_limit            	string       comment "Def(En):
Def(Th):",
	wo04_end_flag         	string       comment "Def(En):
Def(Th):",
	wo04_end_date         	string       comment "Def(En):
Def(Th):",
	wo04_apply_tax        	string       comment "Def(En):
Def(Th):",
	wo04_apply_tax_date   	string       comment "Def(En):
Def(Th):",
	wo04_memo_accru       	string       comment "Def(En):
Def(Th):",
	wo04_report_bot       	string       comment "Def(En):
Def(Th):",
	wo04_rate             	string       comment "Def(En):
Def(Th):",
	wo04_reverse_orig     	string       comment "Def(En):
Def(Th):",
	wo04_appr_from_tdr    	string       comment "Def(En):
Def(Th):",
	wo04_appr_auto_less   	string       comment "Def(En):
Def(Th):",
	wo04_follow           	string       comment "Def(En):
Def(Th):",
	wo04_cr_buro          	string       comment "Def(En):
Def(Th):",
	wo04_prin             	string       comment "Def(En):
Def(Th):",
	wo04_int              	string       comment "Def(En):
Def(Th):",
	wo04_w_flag           	string       comment "Def(En):
Def(Th):",
	wo04_wo_aging         	string       comment "Def(En):
Def(Th):",
	wo04_user_input       	string       comment "Def(En):
Def(Th):",
	wo04_user_input_date  	string       comment "Def(En):
Def(Th):",
	wo04_user_check       	string       comment "Def(En):
Def(Th):",
	wo04_user_check_date  	string       comment "Def(En):
Def(Th):",
	wo04_user_approve     	string       comment "Def(En):
Def(Th):",
	wo04_user_approve_date	string       comment "Def(En):
Def(Th):",
	wo04_approve_status   	string       comment "Def(En):
Def(Th):",
	wo04_user_confirm     	string       comment "Def(En):
Def(Th):",
	wo04_user_confirm_date	string       comment "Def(En):
Def(Th):",
	wo04_confirm_status   	string       comment "Def(En):
Def(Th):",
	wo04_user_report      	string       comment "Def(En):
Def(Th):",
	wo04_user_report_date 	string       comment "Def(En):
Def(Th):",
	wo04_status           	string       comment "Def(En):
Def(Th):",
	filler                	string       comment "Def(En):
Def(Th):",
	load_tms              	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id            	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy              	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_lpm_wrtoff/lpm_wrtoff_pscp_wo_wo1d04h_sam' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);