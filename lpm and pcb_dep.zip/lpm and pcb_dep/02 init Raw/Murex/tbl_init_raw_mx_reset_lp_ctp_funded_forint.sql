-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_mx_reset_lp_ctp_funded_forint.sql
# Area: mx
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_MX.MX_RESET_LP_CTP_FUNDED_FORINT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_mx.mx_reset_lp_ctp_funded_forint (
	pos_dt                 	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	key                    	string       comment "Def(En):Original customer ID
Def(Th):เลขที่บัญชี",
	fullname               	string       comment "Def(En):Original customer name
Def(Th):ชื่อเต็มของบัญชี",
	parent                 	string       comment "Def(En):Parent original customer ID for check share limit 
Def(Th):เลขที่บัญชีของ Parent สำหรับตรวจสอบการใช้วงเงินร่วมกัน",
	ib_corp                	string       comment "Def(En):Customer type code
Def(Th):บอกประเภทว่าเป็น Corporate หรือ InterBank",
	cis_id                 	string       comment "Def(En):Id of involved party
Def(Th):เลขที่ลูกค้า CIS",
	counterparty_staus     	string       comment "Def(En):Contract status
Def(Th):สถานะของสัญญา",
	bad_bank               	string       comment "Def(En):To identify bad customer 
Def(Th):เป็น field ที่บอกว่าเป็นลูกค้า BadBank หรือไม่",
	csa_active             	string       comment "Def(En):CSA Active flag
Def(Th):สถานะของ CSA",
	mlc_ratingfitch        	string       comment "Def(En):Counterparty rating from Fitch
Def(Th): การจัดอันดับของสัญญาจาก Fitch",
	mlc_ratingmoodys       	string       comment "Def(En):Counterparty rating from Moody's
Def(Th):การจัดอันดับของสัญญาจาก Moody's",
	mlc_ratingstandardpoors	string       comment "Def(En):Counterparty rating from Standard & Poor's
Def(Th):การจัดอันดับของสัญญาจาก Standard & Poor's",
	kbankrating            	string       comment "Def(En):Counterparty rating from Kbank
Def(Th):การจัดอันดับของสัญญาจาก Kbank",
	risk                   	string       comment "Def(En):Risk level
Def(Th):ระดับความเสี่ยง",
	group                  	string       comment "Def(En):Product group code
Def(Th):ประเภทผลิตภัณฑ์",
	pillar                 	string       comment "Def(En):Pillar
Def(Th):ระยะเวลาธุรกรรม",
	limit_parameter        	string       comment "Def(En):Limit Parameter
Def(Th):พารามิเตอร์ที่แสดงว่าอนุมัติวงเงินหรือไม่",
	limit_currency         	string       comment "Def(En):Limit currency code
Def(Th):สกุลของวงเงินที่อนุมัติ",
	limit_amount           	string       comment "Def(En):Limit Amount
Def(Th):วงเงิน",
	utilization            	string       comment "Def(En):Principal Amount
Def(Th):ยอดค้าง",
	utilization_           	string       comment "Def(En):Percentage of counterparty funded
Def(Th):เปอร์เซ็นต์ที่ใช้วงเงิน",
	available              	string       comment "Def(En):Available limit amount or over limit amount
Def(Th):วงเงินที่คงเหลือ",
	maxcomment             	string       comment "Def(En):Comment field
Def(Th):Remark field ที่เก็บข้อมูลผสม",
	enginedate             	string       comment "Def(En):Source system  date
Def(Th):วันที่ของระบบ source",
	load_tms               	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id             	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy               	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                 	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                 	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_mx/mx_reset_lp_ctp_funded_forint' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);