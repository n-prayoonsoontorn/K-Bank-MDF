-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_pcb_dep_deptxn_db.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_PCB_DEP.PCB_DEP_DEPTXN_DB
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_pcb_dep.pcb_dep_deptxn_db (
	pos_dt          	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	txn_id          	string       comment "Def(En):CBS Transaction Id
Def(Th):",
	txn_grp_id      	string       comment "Def(En):CBS Transaction GroupId
Def(Th):",
	rel_txn_id      	string       comment "Def(En):CBS Transaction Id to identify the reverse transaction  
Def(Th):",
	src_pos_dt      	string       comment "Def(En):Business Day the contents of this file relate to.
Def(Th):",
	orig_src_stm_id 	string       comment "Def(En):Application ID, from KBank Registry, of the application from which the information was sourced. (Application ID of from the originator of the transaction)
Def(Th):",
	orig_rquid      	string       comment "Def(En):Original Unique Request ID 
Def(Th):",
	ar_id           	string       comment "Def(En):Account Arrangement is the unique numeric identifier of the Account Arrangement. Examples for the Arrangement Id is the identifier of product : Deposit Arrangements, Loan Arrangements and Credit Card Arrangements.
Def(Th):เลขที่บัญชี",
	sub_ar_seq      	string       comment "Def(En):The unique identifier of the sub arrangement.  
Def(Th):เลขที่บัญชีระดับ Sub",
	sub_ar_id       	string       comment "Def(En):Internal Arrangement ID of CBS
Def(Th):",
	fm_to_ar_id     	string       comment "Def(En):From/To Account Arrangement is the unique numeric identifier of the Account Arrangement. 
Def(Th):เลขที่บัญชีต้นทาง/ปลายทาง",
	fm_to_sub_ar    	string       comment "Def(En):The unique identifier of the From/To sub arrangement.  
Def(Th):เลขที่บัญชีระดับ Sub",
	fm_to_inr_sub_ar	string       comment "Def(En):From/To Internal Arrangement ID of CBS",
	svc_br_no       	string       comment "Def(En):Service Branch No
Def(Th):สาขาที่ทำธุรกรรม",
	txn_dt          	string       comment "Def(En): Transaction Date
Def(Th):",
	txn_tm          	string       comment "Def(En): Transaction Time
Def(Th):",
	txn_eff_dt      	string       comment "Def(En): Effective Date
Def(Th):",
	db_cr_ind       	string       comment "Def(En): Debit/ Credit indicator
Def(Th):",
	ppn_tms         	string       comment "Def(En):The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	txn_cd          	string       comment "Def(En): Transaction Code
Def(Th):",
	inr_txn_cd      	string       comment "Def(En): CBS Interanl Transaction Code
Def(Th):",
	chk_no          	string       comment "Def(En): Cheque Number
Def(Th):",
	src_usr_id      	string       comment "Def(En): User ID per Kbank Security Guideline
Def(Th):",
	dvc_id          	string       comment "Def(En): TerminalID (sometimes with workstation id value) per Kbank Security Guidelines
Def(Th):",
	ahrzd_usr_id    	string       comment "Def(En): UserID as per KBank security guideline to determine whether the financial transaction is authorized.
Def(Th):",
	rmrk            	string       comment "Def(En): Data stored in CBS and depends on the legacy.
Def(Th):",
	refr_no1        	string       comment "Def(En): Reference no1 - 1st Reference Number on Bill Slip or QR Code
Def(Th):",
	refr_no2        	string       comment "Def(En): Reference no2 - 2nd Reference Number on Bill Slip or QR Code
Def(Th):",
	refr_no3        	string       comment "Def(En): Reference no3 - 3rd Reference Number on Bill Slip or QR Code
Def(Th):",
	txn_sk          	string       comment "Def(En): Transaction Surrogate Key
Def(Th):",
	txn_amt         	string       comment "Def(En): Transaction Amount
Def(Th):",
	acr_int_amt     	string       comment "Def(En): Accrued Interest Amount
Def(Th):",
	tax_amt         	string       comment "Def(En): Tax Amount
Def(Th):",
	pny_amt         	string       comment "Def(En): Penalty Amount
Def(Th):",
	crn_bal         	string       comment "Def(En): Current Balance
Def(Th):",
	load_tms        	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id      	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy        	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm          	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd          	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_pcb_dep/pcb_dep_deptxn_db' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);