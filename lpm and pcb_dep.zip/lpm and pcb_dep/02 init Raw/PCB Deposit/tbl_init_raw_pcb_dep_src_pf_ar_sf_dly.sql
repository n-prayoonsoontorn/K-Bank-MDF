-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_pcb_dep_src_pf_ar_sf_dly.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_PCB_DEP.PCB_DEP_SRC_PF_AR_SF_DLY
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_pcb_dep.pcb_dep_src_pf_ar_sf_dly (
	pos_dt            	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt        	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	ar_id             	string       comment "Def(En): Account Arrangement 
Def(Th): เลขที่บัญชี",
	ar_nm_th          	string       comment "Def(En): Arrangment Thai Name
Def(Th): ชื่อบัญชีภาษาไทย",
	ar_nm_eng         	string       comment "Def(En):Arrangment English Name
Def(Th): ชื่อบัญชีภาษาอังกฤษ",
	opn_dt            	string       comment "Def(En):Account open date
Def(Th): วันที่เปิดบัญชี",
	cls_dt            	string       comment "Def(En):Closed Date
Def(Th): วันที่ปิดบัญชี",
	eff_dt            	string       comment "Def(En):Effective Date of each sub arrangement
Def(Th): วันที่เริ่มมีการคิดดอกเบี้ย",
	mat_dt            	string       comment "Def(En):Maturity date is the due date of the account. 
For deposit, maturity date is due date for the term of fixed and special fixed account.
Def(Th): กรณีเงินฝาก คือ วันที่ครบเทอมของบัญชีฝากประจำและทวีทรัพย์",
	ar_lcs_tp_id      	string       comment "Def(En):Arrangement life cycle status type ID
Def(Th): สถานะของบัญชี",
	cst_tp_id         	string       comment "Def(En):Customer type classified align with KBANK standard customer type
Def(Th): รหัสประเภทลูกค้าตามมาตรฐานการจัดประเภทลูกค้าของธนาคาร",
	bsn_code_id       	string       comment "Def(En): Business code id is the business sector in which the arrangement/customer is belonged to. It should be align with KBANK stardard business code.
Def(Th): รหัสประเภทธุรกิจของลูกค้าหรือบัญชีของลูกค้า ตาม KBANK stardard business code",
	br_nbr            	string       comment "Def(En): Branch Number, Code to represent KBank Branch, Domicile Branch
Def(Th): รหัสสาขาเจ้าของบัญชี",
	ccy_id            	string       comment "Def(En):This is the original currency of which the account is belonged to. The code for this field is character code e.g. THB, USD, EUR etc
Def(Th): รหัสสกุลเงินตาม ISO ตัวอย่างเช่น 'THB', 'USD'",
	otsnd_bal_amt     	string       comment "Def(En):Outstanding balance amount
Def(Th): จำนวนเงินของหนี้คงค้างรวมดอกเบี้ย, ยอดเงินคงเหลือ",
	opn_bal_amt       	string       comment "Def(En):Opening Balance of the account. 
Def(Th): จำนวนเงินที่เปิดบัญชี",
	cls_bal_amt       	string       comment "Def(En):Amount of deposits account  that have already been closed in last period (Principal + Interest)
Def(Th): ยอดเงินสุดท้ายก่อนการปิดบัญชี",
	last_cst_avy_dt   	string       comment "Def(En):The most recent date on which any Customer initiated activity related to the Arrangement took place.
Def(Th): วันที่ลูกค้ามาทำรายการวันล่าสุด",
	drmt_dys          	string       comment "Def(En):Dormant Days (The total number of days that customer didn't have any transaction with Kbank since his last contact date)
Def(Th): จำนวนวันที่ลูกค้าไม่ได้มีการติดต่อกับธนาคาร (นับตั้งแต่วันที่มีการติดต่อครั้งสุดท้าย)",
	psbk_no           	string       comment "Def(En):Passbook Number
Def(Th): เลขที่สมุดบัญชี",
	acr_bss_code      	string       comment "Def(En):Accrual Basis Code is the basis on which the interest accrual on an account is calculated. The accrual basis code should be set according to account’s original currency. The code is expected to be used instead of actual description. 
Def(Th): วิธีการคำนวณดอกเบี้ย โดยพิจารณาจาก จำนวนวันที่คำนวณดอกเบี้ยต่อเดือน/จำนวนวันที่คำนวณดอกเบี้ยต่อปี
ตัวอย่างเช่น 
ปล่อยสินเชื่อ 90 วัน ระบบคิดอัตราดอกเบี้ย  = จำนวนเงินต้น * อัตราดอกเบี้ย / 365 
โดยจำนวนวันที่ระบบจะทำการคิดดอกเบี้ยตามจำนวนวันจริง ณ สิ้นเดือน อย่างเช่น เดือนมกราคม เป็น 31 วัน.,เดือนกุมภาพันธ์ เป็น 29 วัน 
และ จำนวนวันที่ระบบจะทำการคิดดอกเบี้ยต่อปีเป็น 360  วัน
ดังนั้น accrual basis cd =  6 (Actual/ 365)
หมายเหตุ   actual เป็นจำนวนวันจริงที่คำนวณดอกเบี้ยต่อเดือน/ปีตามปฎิทิน",
	int_pymt_frq      	string       comment "Def(En):
For lending, Interest Payment Frequency is the frequency in which the customer pays their interest. 
For deposit, Interest Payment Frequency is the frequency in which the bank pays interest to the customer.
Def(Th): 
กรณีเงินให้สินเชื่อ คือ ความถี่ในการจ่ายดอกเบี้ยของลูกค้าตามสัญญา 
กรณีเงินฝาก คือ ความถี่ในการจ่ายดอกเบี้ยของธนาคารให้กับลูกค้า",
	int_pymt_frq_unit 	string       comment "Def(En):For deposit, it is Unit of measurement of Interest Payment Frequency when the bank pays interest to the customer.
Def(Th): กรณีเงินฝาก คือ หน่วยของความถี่ของการจ่ายดอกเบี้ยของธนาคาร",
	last_int_pymt_dt  	string       comment "Def(En): For deposit, Last Interest Payment Date is the latest date in which the bank pays interest to the customer.
Def(Th): กรณีเงินฝาก คือ วันที่ธนาคารจ่ายดอกเบี้ยให้กับลูกค้าครั้งล่าสุด",
	nxt_int_pymt_dt   	string       comment "Def(En): For deposit, Next Interest Payment Date is the bank will pay interest next time.
Def(Th): กรณีเงินฝาก คือ วันที่ธนาคารจะชำระดอกเบี้ยครั้งถัดไป",
	cmpd_frq          	string       comment "Def(En):Frequency by which interest is compounded in which the bank has to pay the customer
Def(Th): ความถี่ของดอกเบี้ยที่ทบรวมเงินต้น ที่ทางแบงค์จะต้องจ่ายให้กับลูกค้า",
	cmpd_frq_unit     	string       comment "Def(En):Unit of frequency by which interest is compounded in which the bank has to pay the customer
Def(Th): หน่วยของความถี่ของดอกเบี้ยที่ทบรวมเงินต้น ที่ทางแบงค์จะต้องจ่ายให้กับลูกค้า",
	int_ctn_clc_bss_id	string       comment "Def(En):Interest computation calculation basis ID
Def(Th): รหัสวิธีการคำนวณดอกเบี้ย",
	int_ctn_clc_prd_id	string       comment "Def(En):Interest computation calculation period ID
Def(Th): รหัสช่วงเวลาที่ใช้ในการคำนวนดอกเบี้ย",
	eff_int_rate      	string       comment "Def(En):Effective interest rate is the current interest rate give to customer.
Def(Th): อัตราดอกเบี้ยที่แท้จริงที่ใช้ในการคำนวณดอกเบี้ย ณ ปัจจุบัน",
	int_eff_dt        	string       comment "Def(En):Interest Rate Effective Date
Def(Th): วันที่อัตราดอกเบี้ยที่แท้จริงที่ใช้ในการคำนวณดอกเบี้ยเริ่มมีผล",
	int_end_dt        	string       comment "Def(En):Interest Rate End Date
Def(Th): วันที่อัตราดอกเบี้ยที่แท้จริงที่ใช้ในการคำนวณดอกเบี้ยสิ้นสุด",
	eff_int_rate_tp_id	string       comment "Def(En):Effective Interest Rate Type Id
Def(Th): ประเภทของดอกเบี้ย",
	int_rate_ind      	string       comment "Def(En):Interest Rate Indicator
Def(Th): รหัสประเภทของดอกเบี้ย (ปกติ, พิเศษ)",
	eff_sprd_int_rate 	string       comment "Def(En):Effective Spread Interest Rate
Def(Th): สเปรด เรท",
	acr_int_pbl_amt   	string       comment "Def(En): Accrued Interest Payable Amount
Def(Th): ดอกเบี้ยสะสม",
	int_paid_amt      	string       comment "Def(En):Interest amount that already paid to customer on that business day. If no interest payment then 0.
Def(Th): ดอกเบี้ยที่จ่ายจริงให้กับลูกค้าในวันนั้น ถ้าในวันนั้นไม่มีการจ่ายดอกเบี้ยจะมีค่าเป็น 0",
	int_cal_st_id     	string       comment "Def(En): Interest Calculation Status
Def(Th): รหัสประเภทการคิดดอกเบี้ย เช่น 9 หยุดคิดดอกเบี้ย",
	coa_ac            	string       comment "Def(En):Chart of Accounts account code is KBANK New GL-account number in which the account is belonged to
The 1st Digit = nature of accounts, 
A leading 1 indicates Asset
A leading 2 indicates Liabilities
A leading 3 indicates Shareholder's equity
A leading 4 indicates Revenues
A leading 5 indicates Interest expenses
A leading 6 indicates Non interest expenses
A leading 7 indicates Off balance sheet items
A leading 8 indicates Memo accounts
The 2nd & 3rd Digit = group of nature of accounts
A “01” indicates Cash
A “02” indicates ….
The 4th Digit = sub-group of nature of accounts
5th - 7th digit = Block Range of Account Codes
Def(Th): รหัสบัญชีแยกประเภทตามผังการลงบัญชีใหม่ของธนาคาร (KBANK New GL-account number)",
	coa_pd            	string       comment "Def(En):Chart of Accounts product code is KBANK New GL-product number 
1st - 2nd digits = Product Group
3rd - 4th digits = Product Sub-Group 
5th - 6th digits = Product (or service)
7th - 9th digits = Product Feature (not in the new GL system)
Def(Th): รหัสผลิตภัณฑ์ตามระบบบํญชีใหม่ของธนาคาร (KBANK New Chart of Accounts)",
	coa_pd_ftr_code   	string       comment "Def(En):Chart of Accounts product feature code  is KBANK New GL-product number 
1st - 2nd digits = Product Group
3rd - 4th digits = Product Sub-Group 
5th - 6th digits = Product (or service)
7th - 9th digits = Product Feature (not in the new GL system)
Def(Th): รหัสผลิตภัณฑ์ตามระบบบํญชีใหม่ของธนาคาร (KBANK New Chart of Accounts)",
	hld_bal_amt       	string       comment "Def(En): Hold Balance Amount
Def(Th): จำนวนเงินที่ห้ามถอน ตัวอย่างเช่นเพื่อกันไว้เป็นหลักประกัน",
	ar_term_prd       	string       comment "Def(En): Arrangemen Term Period
Def(Th): Term ของบัญชีฝากประจำ",
	ar_term_unit_id   	string       comment "Def(En): Arrangemen Term Period Unit
Def(Th): หน่วยของ Term ของบัญชีฝากประจำ",
	bonus_eff_int_rate	string       comment "Def(En): Effective interest rate of bonus rate
Def(Th): อัตราดอกเบี้ยที่ใช้ในการคำนวณโบนัส",
	bonus_int_amt     	string       comment "Def(En): Bonus interest amount
Def(Th): จำนวนดอกเบี้ยโบนัส",
	pcb_int_idnx      	string       comment "Def(En): Profile Interest Index only Deposit
Def(Th): INT INDEX ที่ชื่อขึ้นต้นด้วย S / T และ C
S = Saving
T = ทวีทรัพย์
C = Current",
	int_paid_life     	string       comment "Def(En): Int/Div Paid – Life
Def(Th): ดอกเบี้ยที่มีการจ่ายตั้งแต่มีการเปิดบัญชี",
	int_paid_pr_year  	string       comment "Def(En): Int/Div Paid Prior Financial Year
Def(Th): ดอกเบี้ยจ่ายปีก่อนหน้า",
	int_ytd           	string       comment "Def(En): Int/Div Paid Financial Year-to-Date
Def(Th): ดอกเบี้ยจ่ายภายในปี",
	back_wht_flg      	string       comment "Def(En): Backup Withholding 
Def(Th): ภาษีที่มีการจ่าย",
	back_wht_pr_year  	string       comment "Def(En): Backup Withholding Prior Year
Def(Th): ภาษี(WHT)ที่มีการจ่ายปีก่อนน้า",
	back_wht_ytd      	string       comment "Def(En): Backup Withholding Tax Year-to-date
Def(Th): ภาษีที่มีการจ่ายภายในปี",
	tax_owner         	string       comment "Def(En): Tax Owner
Def(Th): ผู้เสียภาษีอากร",
	intwcalc          	string       comment "Def(En): Int/Div Withholding Calculation Method
Def(Th):วิธีการคำนวณ",
	tax_key           	string       comment "Def(En): Tax Key
Def(Th):",
	cid_deduct        	string       comment "Def(En):Decuct accout ID
Def(Th): เลขบัญชีเพื่อหักเงิน",
	block_ind         	string       comment "Def(En): Indicates if the arrangement is blocked or not for Active and Closed Accounts.
Def(Th):",
	allow_flag        	string       comment "Def(En): Identify the account is allow to debit, credit or allow both
Def(Th):",
	tax_id            	string       comment "Def(En): Tax identification number
Def(Th):",
	citizen_id        	string       comment "Def(En): Citizen identification number
Def(Th):",
	load_tms          	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id        	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy          	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm            	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd            	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_pcb_dep/pcb_dep_src_pf_ar_sf_dly' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);