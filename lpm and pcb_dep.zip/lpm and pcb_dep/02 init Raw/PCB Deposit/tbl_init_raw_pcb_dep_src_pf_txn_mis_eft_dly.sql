-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_pcb_dep_src_pf_txn_mis_eft_dly.sql
# Area: pcb_dep
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_PCB_DEP.PCB_DEP_SRC_PF_TXN_MIS_EFT_DLY
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_pcb_dep.pcb_dep_src_pf_txn_mis_eft_dly (
	pos_dt            	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	orig_txn_id       	string       comment "Def(En): Profile unique running number
Def(Th):",
	txn_dt            	string       comment "Def(En): Transaction Date
Def(Th): วันที่ทำรายการ",
	txn_val_dt        	string       comment "Def(En): The date that the transaction takes effect. For example, for check deposits, this will differ from the book date by the time it takes to clear the check; for Trades, this will be the settled date; etc.
Def(Th): วันที่รายการมีผล",
	txn_code          	string       comment "Def(En):
Def(Th):",
	txn_tm            	string       comment "Def(En): Time of entry of the trasaction.This is the time assocoated with the Entry Date
Def(Th): เวลาที่ทำรายการ",
	cnl_id            	string       comment "Def(En): Channel identifies the different delivery and communications mechanisms through which products and services are made available to a customer and by which the Financial Institution and customers communicate with each other. Application Id
Def(Th): ระบบที่ทำรายการ",
	fm_ar_id          	string       comment "Def(En): From Arrangement Id
Def(Th): บัญชีของผู้ทำรายการ",
	to_ar_id          	string       comment "Def(En): To Arrangement Id
Def(Th): บัญชีผู้รับ",
	intzon_id         	string       comment "Def(En):
Def(Th):",
	txn_amt           	string       comment "Def(En): Transaction Amount
Def(Th): จำนวนเงินที่ทำรายการ",
	txn_cmsn          	string       comment "Def(En):
Def(Th):",
	txn_tel_fee       	string       comment "Def(En):
Def(Th):",
	act_txn_amt       	string       comment "Def(En):
Def(Th):",
	wv_fee_amt        	string       comment "Def(En): Waive Fee 
Def(Th): จำนวนเงินลดหย่อน",
	fm_br_no          	string       comment "Def(En):
Def(Th):",
	to_br_no          	string       comment "Def(En):
Def(Th):",
	fm_ar_domc_br_no  	string       comment "Def(En):
Def(Th):",
	fm_ar_pd_tp_id    	string       comment "Def(En):
Def(Th):",
	to_ar_pd_tp_id    	string       comment "Def(En):
Def(Th):",
	fm_coa_pd_ftr_code	string       comment "Def(En):
Def(Th):",
	to_coa_pd_ftr_code	string       comment "Def(En):
Def(Th):",
	eft_co_th_nm      	string       comment "Def(En):
Def(Th):",
	eft_co_en_nm      	string       comment "Def(En):
Def(Th):",
	eft_cst_nm        	string       comment "Def(En):
Def(Th):",
	eft_usr_id        	string       comment "Def(En):
Def(Th):",
	eft_txn_tp        	string       comment "Def(En):
Def(Th):",
	eft_chk_nbr       	string       comment "Def(En):
Def(Th):",
	eft_chk_bnk_code  	string       comment "Def(En):
Def(Th):",
	load_tms          	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id        	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy          	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm            	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd            	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_pcb_dep/pcb_dep_src_pf_txn_mis_eft_dly' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);