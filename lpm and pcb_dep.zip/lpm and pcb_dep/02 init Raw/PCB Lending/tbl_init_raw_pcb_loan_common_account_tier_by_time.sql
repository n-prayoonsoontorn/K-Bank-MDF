-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_pcb_loan_common_account_tier_by_time.sql
# Area: pcb_loan
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_PCB_LOAN.PCB_LOAN_COMMON_ACCOUNT_TIER_BY_TIME
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_pcb_loan.pcb_loan_common_account_tier_by_time (
	pos_dt               	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	ac_ar_id             	string       comment "Def(En): Account Number
Def(Th):",
	prfl_ac_ar_id        	string       comment "Def(En): Profile Account Number
Def(Th):",
	eff_dt               	string       comment "Def(En): Effective Date
Def(Th):",
	end_dt               	string       comment "Def(En): End Date 
Def(Th):",
	int_idnx             	string       comment "Def(En): Interest Rate Index 
Def(Th):",
	int_rate_sign        	string       comment "Def(En): Interest Sign
Def(Th):",
	int_rate_sprd        	string       comment "Def(En): Interest Spread
Def(Th):",
	eff_int_rate_typ_prfl	string       comment "Def(En): Effective Interest rate type ID Profile
Def(Th):",
	load_tms             	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id           	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy             	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm               	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd               	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_pcb_loan/pcb_loan_common_account_tier_by_time' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);