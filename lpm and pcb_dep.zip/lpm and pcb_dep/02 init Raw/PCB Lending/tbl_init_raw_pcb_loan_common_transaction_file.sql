-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_pcb_loan_common_transaction_file.sql
# Area: pcb_loan
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_PCB_LOAN.PCB_LOAN_COMMON_TRANSACTION_FILE
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_pcb_loan.pcb_loan_common_transaction_file (
	pos_dt           	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	ac_ar_id         	string       comment "Def(En):
Def(Th):",
	txn_seq          	string       comment "Def(En):
Def(Th):",
	txn_dt           	string       comment "Def(En):
Def(Th):",
	txn_tm           	string       comment "Def(En):
Def(Th):",
	prfl_ac_ar_id    	string       comment "Def(En):
Def(Th):",
	txn_val_dt       	string       comment "Def(En):
Def(Th):",
	txn_code         	string       comment "Def(En):
Def(Th):",
	rev_txn_seq      	string       comment "Def(En):
Def(Th):",
	net_cash_flow_amt	string       comment "Def(En):
Def(Th):",
	ar_bal_amt       	string       comment "Def(En):
Def(Th):",
	eff_int_rate     	string       comment "Def(En):
Def(Th):",
	prin_amt         	string       comment "Def(En):
Def(Th):",
	act_int          	string       comment "Def(En):
Def(Th):",
	int_late_charge  	string       comment "Def(En):
Def(Th):",
	fee_code         	string       comment "Def(En):
Def(Th):",
	fee_amt          	string       comment "Def(En):
Def(Th):",
	pymt_id          	string       comment "Def(En):
Def(Th):",
	usr_id           	string       comment "Def(En):
Def(Th):",
	ahr_usr_id       	string       comment "Def(En):
Def(Th):",
	ahr_lvl_id       	string       comment "Def(En):
Def(Th):",
	dvc_id           	string       comment "Def(En):
Def(Th):",
	channel_id       	string       comment "Def(En):
Def(Th):",
	svc_br_nbr       	string       comment "Def(En):
Def(Th):",
	coa_rspl_cntr_ar 	string       comment "Def(En):
Def(Th):",
	coa_fnc_ar       	string       comment "Def(En):
Def(Th):",
	coa_prj_ar       	string       comment "Def(En):
Def(Th):",
	coa_ac_fee       	string       comment "Def(En):
Def(Th):",
	load_tms         	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id       	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy         	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm           	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd           	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_pcb_loan/pcb_loan_common_transaction_file' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);