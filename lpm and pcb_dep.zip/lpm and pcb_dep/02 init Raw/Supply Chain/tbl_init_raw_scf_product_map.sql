-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_scf_product_map.sql
# Area: scf
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_SCF.SCF_PRODUCT_MAP
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_scf.scf_product_map (
	pos_dt         	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	strfacility    	string       comment "Def(En): Supply Chain Product Code
Def(Th): รหัสผลิตภัณฑ์",
	strproduct_code	string       comment "Def(En): Chart of Account Product Feature Code
Def(Th): รหัสผลิตภัณฑ์ตามระบบบํญชีใหม่ของธนาคาร (KBANK New Chart of Accounts)",
	strproduct_name	string       comment "Def(En): Supply Chain Product Name
Def(Th): ชื่อผลิตภัณฑ์",
	load_tms       	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id     	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy       	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm         	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd         	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_scf/scf_product_map' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);