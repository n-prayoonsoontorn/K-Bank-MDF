-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_scf_trading.sql
# Area: scf
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_SCF.SCF_TRADING
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_scf.scf_trading (
	pos_dt              	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	strsponsorid        	string       comment "Def(En): Sponsor Customer ID
Def(Th):",
	strbuysellid        	string       comment "Def(En): Buyer/Seller Customer ID
Def(Th):",
	strprodtype         	string       comment "Def(En): Product Type
Def(Th):",
	inttradingno        	string       comment "Def(En): Trading No
Def(Th):",
	declimitamt         	string       comment "Def(En): Limit Amount
Def(Th):",
	decoutlimitamt      	string       comment "Def(En): Outstanding Limit Amount
Def(Th):",
	decpenddirectdramt  	string       comment "Def(En): Pending Direct Debit Amount
Def(Th):",
	decpenddrawdwamt    	string       comment "Def(En): Pending Drawdown Amount
Def(Th):",
	decavltopupamt      	string       comment "Def(En): Available Top up Amount
Def(Th):",
	decremainlimitamt   	string       comment "Def(En): Remaining Limit Amount
Def(Th):",
	strsendremainchgflag	string       comment "Def(En):
Def(Th):",
	strremainupdatedflag	string       comment "Def(En):
Def(Th):",
	strapprdate         	string       comment "Def(En):
Def(Th):",
	strefftdate         	string       comment "Def(En): Effective Date
Def(Th):",
	strduedate          	string       comment "Def(En): Due Date
Def(Th):",
	strreviewdate       	string       comment "Def(En):
Def(Th):",
	strdesc             	string       comment "Def(En):
Def(Th):",
	strchargeintfor     	string       comment "Def(En): Charge Interest For
Def(Th):",
	strpayinttype       	string       comment "Def(En): Payment Interest Type
Def(Th):",
	strintflag          	string       comment "Def(En): Interest Flag
Def(Th):",
	strintcode          	string       comment "Def(En): Interest Code
Def(Th):",
	decintbasis         	string       comment "Def(En): Interest Basis
Def(Th):",
	decintspread        	string       comment "Def(En): Interest Basis
Def(Th):",
	decallinrate        	string       comment "Def(En): All In Rate
Def(Th):",
	decprepayperc       	string       comment "Def(En): Pre Payment Percentage
Def(Th):",
	inttenor            	string       comment "Def(En): Tenor Days
Def(Th):",
	strchargefeefor     	string       comment "Def(En): Charge Fee For (SP = Sponsor, BS = Buyer / Seller)
Def(Th):",
	strchargefeetype    	string       comment "Def(En): OD= On due, MN = Monthly, TD = Transaction Date
Def(Th):",
	strchargedcfeefor   	string       comment "Def(En): Charge DC Fee For (SP = Sponsor, BS = Buyer / Seller)
Def(Th):",
	strchargedcfeetype  	string       comment "Def(En):
Def(Th):",
	strcrtype           	string       comment "Def(En):
Def(Th):",
	strcrmethod         	string       comment "Def(En):
Def(Th):",
	decfeeamt           	string       comment "Def(En):
Def(Th):",
	decbalfeeamt        	string       comment "Def(En):
Def(Th):",
	decdcfeeamt         	string       comment "Def(En): DC FEE Amount
Def(Th):",
	strlastfeedate      	string       comment "Def(En):
Def(Th):",
	stractiveflag       	string       comment "Def(En): Active Flag
Def(Th):",
	strprocessflag      	string       comment "Def(En): Process Flag
Def(Th):",
	strverifyflag       	string       comment "Def(En): Verify Flag
Def(Th):",
	strverifyby         	string       comment "Def(En): Verify By
Def(Th):",
	strverifydate       	string       comment "Def(En): Verify Date
Def(Th):",
	strreturnflag       	string       comment "Def(En):
Def(Th):",
	strreturnrem        	string       comment "Def(En): Return Remark
Def(Th):",
	strdelverifyflag    	string       comment "Def(En): Delete Verify Flag
Def(Th):",
	strdelverifyby      	string       comment "Def(En): Delete Verify By
Def(Th):",
	strdelverifydate    	string       comment "Def(En): Delete Verify Date
Def(Th):",
	strsdintflag        	string       comment "Def(En): Special Direct Debit Interest Flag (1 = Fix, 2 = Float)
Def(Th):",
	decsdintrate        	string       comment "Def(En): Interest Rate
Def(Th):",
	strsdintcode        	string       comment "Def(En): Special Direct Debit Interest Code
Def(Th):",
	decsdintspread      	string       comment "Def(En): Special Direct Debit Interest Spread
Def(Th):",
	decsdintbasis       	string       comment "Def(En): Special Direct Debit Interest Basis
Def(Th):",
	decsdallinrate      	string       comment "Def(En): Special Direct Debit All in Rate
Def(Th):",
	stramendby          	string       comment "Def(En): Amend By
Def(Th):",
	stramenddate        	string       comment "Def(En): Amend Date
Def(Th):",
	stramendverifyby    	string       comment "Def(En): Amend Verify By
Def(Th):",
	stramendverifydate  	string       comment "Def(En): Amend Verify Date
Def(Th):",
	stramendverifyflag  	string       comment "Def(En): Amend Verify Flag
Def(Th):",
	decintrate          	string       comment "Def(En):
Def(Th):",
	strcreateuser       	string       comment "Def(En): Create User
Def(Th):",
	dtecreatedate       	string       comment "Def(En): Create Date
Def(Th):",
	strupduser          	string       comment "Def(En): Update User
Def(Th):",
	dteupddate          	string       comment "Def(En): Update Date
Def(Th):",
	stronlineflag       	string       comment "Def(En): Online Flag
Def(Th):",
	strshareflag        	string       comment "Def(En): Share Flag Y=share,N=No Share
Def(Th):",
	strsharegrp         	string       comment "Def(En): Share Group
Def(Th):",
	strchgshare         	string       comment "Def(En):
Def(Th):",
	load_tms            	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id          	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy            	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm              	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd              	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_scf/scf_trading' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);