-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_trade_na_src_eximar.sql
# Area: trade_na
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_TRADE_NA.TRADE_NA_SRC_EXIMAR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_trade_na.trade_na_src_eximar (
	pos_dt               	string       comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt           	string       comment "Def(En): Customer ID
Def(Th):",
	ar_id                	string       comment "Def(En): Arrangement id
Def(Th):",
	acr_bss_code         	string       comment "Def(En): Accrual Basis Code
Def(Th):",
	amrz_term_dys        	string       comment "Def(En): Amortization Term in Days
Def(Th):",
	amrz_term_mo         	string       comment "Def(En): Amortization Term in Months
Def(Th):",
	amrz_tp              	string       comment "Def(En): Amortization Type
Def(Th):",
	posn_dt              	string       comment "Def(En): Position Date
Def(Th):",
	av_book_bal          	string       comment "Def(En): Average Book Balance
Def(Th):",
	av_par_bal           	string       comment "Def(En): Average Par Balance
Def(Th):",
	bill_cyc_id          	string       comment "Def(En): Billing Cycle Id
Def(Th):",
	blc_code_id          	string       comment "Def(En): Block Code Id
Def(Th):",
	br_nbr               	string       comment "Def(En): Branch Number
Def(Th):",
	call_dt              	string       comment "Def(En): Call Date
Def(Th):",
	put_dt               	string       comment "Def(En): Put Date
Def(Th):",
	call_prc             	string       comment "Def(En): Call Price
Def(Th):",
	put_prc              	string       comment "Def(En): Put Price
Def(Th):",
	cc_tp_id             	string       comment "Def(En): Credit Card Type Id
Def(Th):",
	cls_bal_amt          	string       comment "Def(En): Closed Balance Amount
Def(Th):",
	clt_amt              	string       comment "Def(En): Collateral Amount
Def(Th):",
	clt_tp               	string       comment "Def(En): Collateral Type
Def(Th):",
	lmt_amt              	string       comment "Def(En): Limit Amount
Def(Th):",
	cmpd_frq             	string       comment "Def(En): Compounding Frequency
Def(Th):",
	ctr_sign_dt          	string       comment "Def(En): Contract Sign Date
Def(Th):",
	cost_cntr            	string       comment "Def(En): Cost Center
Def(Th):",
	cntpr_nm             	string       comment "Def(En): Counter Party Name
Def(Th):",
	rman_term_dys        	string       comment "Def(En): Remaining Term in Days
Def(Th):",
	rman_term_mo         	string       comment "Def(En): Remaining Term in Months
Def(Th):",
	ccy_id               	string       comment "Def(En): Currency Id
Def(Th):",
	crn_book_bal         	string       comment "Def(En): Current Book Balance
Def(Th):",
	eff_int_rate         	string       comment "Def(En): Effective Interest Rate
Def(Th):",
	crn_par_bal          	string       comment "Def(En): Current Par Balance
Def(Th):",
	nxt_pnp_pymt_amt     	string       comment "Def(En): Next Principal Payment Amount
Def(Th):",
	nxt_int_pymt_amt     	string       comment "Def(En): Next Interest Payment Amount
Def(Th):",
	crn_prem_dcn         	string       comment "Def(En): Current Premium/Discount
Def(Th):",
	sprd_int_rate        	string       comment "Def(En): Spread Interest Rate
Def(Th):",
	crn_stmt_bal         	string       comment "Def(En): Current Statement Balance
Def(Th):",
	bsn_code_id          	string       comment "Def(En): Business Code Id
Def(Th):",
	ip_id                	string       comment "Def(En): Involved Party ID
Def(Th):",
	cst_tp_id            	string       comment "Def(En): Customer Type Id
Def(Th):",
	dept_no              	string       comment "Def(En): Department Number
Def(Th):",
	exn_dep_amt          	string       comment "Def(En): Extended Deposit Amount
Def(Th):",
	rvrs_acr_int_f       	string       comment "Def(En): Reverse Accrued Interest Flag
Def(Th):",
	clc_int_f            	string       comment "Def(En): Calculated Interest Flag
Def(Th):",
	dcn_tp               	string       comment "Def(En): Discount Type
Def(Th):",
	au_id                	string       comment "Def(En): Accounting Unit Id
Def(Th):",
	grc_prd              	string       comment "Def(En): Grace Period
Def(Th):",
	hld_ac               	string       comment "Def(En): Hold Account
Def(Th):",
	hld_bal_amt          	string       comment "Def(En): Hold Balance Amount
Def(Th):",
	ar_hld_tp_id         	string       comment "Def(En): Arrangement Hold Type Id
Def(Th):",
	mprm_amt             	string       comment "Def(En): Impairment Amount
Def(Th):",
	prch_sale_ind        	string       comment "Def(En): Indicator show Purchase/Sale (For Fixed Income
Def(Th):",
	rcv_pay_ind          	string       comment "Def(En): Indicator show Receive/Pay (For SWAP)
Def(Th):",
	issu_dt              	string       comment "Def(En): Issue Date
Def(Th):",
	pnp_pymt_frq         	string       comment "Def(En): Principal Payment Frequency
Def(Th):",
	int_pymt_frq         	string       comment "Def(En): Interest Payment Frequency
Def(Th):",
	int_tp               	string       comment "Def(En): Interest Type
Def(Th):",
	int_rate_tp_id       	string       comment "Def(En): Interest Rate Type Id
Def(Th):",
	ivsm_tp              	string       comment "Def(En): Investment Type
Def(Th):",
	issur_nm             	string       comment "Def(En): Issuer Name
Def(Th):",
	lrd_bal_amt          	string       comment "Def(En): LRD Balance Amount
Def(Th):",
	last_int_pymt_dt     	string       comment "Def(En): Last Interest Payment Date
Def(Th):",
	last_pnp_pymt_dt     	string       comment "Def(En): Last Principal Payment Date
Def(Th):",
	last_rprc_dt         	string       comment "Def(En): Last Reprice Date
Def(Th):",
	ar_pps_tp_id         	string       comment "Def(En): Arrangement Purpose Type Id
Def(Th):",
	mtm_val              	string       comment "Def(En): Mark to Market Value
Def(Th):",
	mat_dt               	string       comment "Def(En): Maturity date
Def(Th):",
	mftp_qtn_dt          	string       comment "Def(En): MFTP Quotation Date
Def(Th):",
	nxt_pnp_pymt_dt      	string       comment "Def(En): Next Principal Payment Date
Def(Th):",
	nxt_int_pymt_dt      	string       comment "Def(En): Next Interest Payment Date
Def(Th):",
	orig_pymt_amt        	string       comment "Def(En): Original Payment Amount
Def(Th):",
	orig_int_rate        	string       comment "Def(En): Original Interest Rate
Def(Th):",
	orig_term_dys        	string       comment "Def(En): Original Term in Days
Def(Th):",
	orig_term_mo         	string       comment "Def(En): Original Term in Months
Def(Th):",
	ou_id                	string       comment "Def(En): Organization Unit Id
Def(Th):",
	nxt_rprc_dt          	string       comment "Def(En): Next Reprice Date
Def(Th):",
	opn_bal_amt          	string       comment "Def(En): Opened Balance Amount
Def(Th):",
	orig_book_bal        	string       comment "Def(En): Original Book Balance
Def(Th):",
	orig_par_bal         	string       comment "Def(En): Original Par Balance
Def(Th):",
	orig_prem_dcn        	string       comment "Def(En): Original Premium/Discount
Def(Th):",
	orig_dt              	string       comment "Def(En): Origination Date
Def(Th):",
	clc_int_stop_dt      	string       comment "Def(En): Calculated Interest Stop Date
Def(Th):",
	prd_flr_rate         	string       comment "Def(En): Period Floor Rate
Def(Th):",
	prd_cap_rate         	string       comment "Def(En): Period Cap Rate
Def(Th):",
	prev_stmt_bal        	string       comment "Def(En): Previous Statement Balance
Def(Th):",
	pd_tp_id             	string       comment "Def(En): Product Type Id
Def(Th):",
	rate_cap             	string       comment "Def(En): Rate Cap
Def(Th):",
	rate_flr             	string       comment "Def(En): Rate Floor
Def(Th):",
	rprc_frq             	string       comment "Def(En): Repricing Frequency
Def(Th):",
	rprc_sprd_rate       	string       comment "Def(En): Repricing Spread Rate
Def(Th):",
	rvrs_acr_int_amt     	string       comment "Def(En): Reverse Accrued Interest Amount
Def(Th):",
	rvrs_acr_int_dt      	string       comment "Def(En): Reverse Accrued Interest Date
Def(Th):",
	sp_itnl_rtg          	string       comment "Def(En): SP International Rating
Def(Th):",
	tris_itnl_rtg        	string       comment "Def(En): TRIS International Rating
Def(Th):",
	fitch_itnl_rtg       	string       comment "Def(En): FITCH International Rating
Def(Th):",
	moodys_itnl_rtg      	string       comment "Def(En): MOODYS International Rating
Def(Th):",
	scr_nm               	string       comment "Def(En): Security Name
Def(Th):",
	ln_clsfd_bot         	string       comment "Def(En): Loan Classified BOT
Def(Th):",
	tsr_rate_end_dt      	string       comment "Def(En): Teaser Rate End Date
Def(Th):",
	tsr_rate             	string       comment "Def(En): Teaser Rate Rate
Def(Th):",
	tsr_rate_tp_id       	string       comment "Def(En): Teaser Rate Type Id
Def(Th):",
	ppymt_bal_amt        	string       comment "Def(En): Prepayment Balance Amount
Def(Th):",
	ppymt_dt             	string       comment "Def(En): Prepayment Date
Def(Th):",
	ppymt_f              	string       comment "Def(En): Prepayment Flag
Def(Th):",
	lmt_amt_rng          	string       comment "Def(En): Limit Amount Range
Def(Th):",
	pct_non_rvl          	string       comment "Def(En): Percentage of Non-Revolve
Def(Th):",
	ac_ofcr              	string       comment "Def(En): Account Officer
Def(Th):",
	cl_mo_f              	string       comment "Def(En): Closed Month Flag
Def(Th):",
	crn_idnx_rate        	string       comment "Def(En): Current Index Rate
Def(Th):",
	crn_rate_fix         	string       comment "Def(En): Current Rate Fixed
Def(Th):",
	intprd               	string       comment "Def(En): Interest Period
Def(Th):",
	exn_mo_f             	string       comment "Def(En): Extension Month Flag
Def(Th):",
	fwd_tp_code          	string       comment "Def(En): Forward Type Code
Def(Th):",
	int_chg_f            	string       comment "Def(En): Interest Change Flag
Def(Th):",
	opn_mo_f             	string       comment "Def(En): Open Month Flag
Def(Th):",
	npl_dt               	string       comment "Def(En): NPL Date
Def(Th):",
	npl_f                	string       comment "Def(En): NPL Flag
Def(Th):",
	orig_admn_rate       	string       comment "Def(En): Original Admin Rate
Def(Th):",
	setl_dt              	string       comment "Def(En): Settlement Date
Def(Th):",
	val_dt               	string       comment "Def(En): Value Date
Def(Th):",
	yld_to_mat           	string       comment "Def(En): Yield To Maturity
Def(Th):",
	intprd_av_pnp_amt    	string       comment "Def(En): Interest Period Average Principle Amount
Def(Th):",
	pnp_amt              	string       comment "Def(En): Principle Amount
Def(Th):",
	pymt_due_dt          	string       comment "Def(En): Payment Due Date
Def(Th):",
	ln_clsfd             	string       comment "Def(En): Loan Classified
Def(Th):",
	ac_ofcr_pd_f         	string       comment "Def(En): Account Officer Product Flag
Def(Th):",
	ar_tp_id             	string       comment "Def(En): Arrangement Type Id
Def(Th):",
	cst_seg_id           	string       comment "Def(En): Customer Segment Id
Def(Th):",
	ppn_dt               	string       comment "Def(En): Population Date
Def(Th):",
	ppn_tm               	string       comment "Def(En): Population Time
Def(Th):",
	src_stm_id           	string       comment "Def(En): Source System Id
Def(Th):",
	overdue_flag         	string       comment "Def(En): Overdue Flag
Def(Th):",
	weighted_avg_ind_rate	string       comment "Def(En): Weighted Average Index Rate
Def(Th):",
	legl_entity          	string       comment "Def(En): Legal entity
Def(Th):",
	responsibility_center	string       comment "Def(En): Responsibility Center
Def(Th):",
	account_no           	string       comment "Def(En): Account No
Def(Th):",
	function_on          	string       comment "Def(En): Function On
Def(Th):",
	line_of_business     	string       comment "Def(En): Line of Business
Def(Th):",
	product_code         	string       comment "Def(En): Product Code
Def(Th):",
	inter_company        	string       comment "Def(En): Inter Company
Def(Th):",
	intra_company        	string       comment "Def(En): Intra Company
Def(Th):",
	project              	string       comment "Def(En): Project Code
Def(Th):",
	future_use1          	string       comment "Def(En): Future Use1
Def(Th):",
	future_use2          	string       comment "Def(En): Future Use1
Def(Th):",
	sub_product          	string       comment "Def(En): Sub Product
Def(Th):",
	load_tms             	string       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id           	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy             	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm               	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd               	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_trade_na/trade_na_src_eximar' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);