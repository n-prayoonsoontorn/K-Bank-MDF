-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_raw_ud_vw_flt_rl_sub_bal_enq.sql
# Area: ud
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.RAW_UD.UD_VW_FLT_RL_SUB_BAL_ENQ
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.raw_ud.ud_vw_flt_rl_sub_bal_enq (
	pos_dt                  	string        comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	cif_number              	string        comment "Def(En): CIF Number
Def(Th):",
	card_no                 	string        comment "Def(En): Identification No.
Def(Th):",
	card_type               	string        comment "Def(En): Identification Type 
Def(Th):",
	uh_acc_number           	string        comment "Def(En): Investor account, unit holder ID 
Def(Th):",
	agency_id               	string        comment "Def(En): Agency Id
Def(Th):",
	consent_flag            	string        comment "Def(En): Consent option of UH Account Level
Def(Th):",
	apply_kinvest_flag      	string        comment "Def(En): Apply K-Cyber option of UH Account Level
Def(Th):",
	sub_acc_number          	string        comment "Def(En): Sub account of investor
Def(Th):",
	fund_id                 	string        comment "Def(En): Fund Id
Def(Th):",
	fund_type_code          	string        comment "Def(En): Fund Type Code for RMF/LTF/SSF/SSFX/RMF-PVD
Def(Th):",
	fund_short_name         	string        comment "Def(En): Fund Short name
Def(Th):",
	unit_balance_provisional	string        comment "Def(En): Unit which is waiting for cheque clearing
Def(Th):",
	unit_balance_confirmed  	string        comment "Def(En): Confirmed Unit Balance
Def(Th):",
	salable_unit1           	string        comment "Def(En): Applicable for RMF/ LTF/SSF/SSFX/RMF-PVD
for RMF type -->summary of unit before 1 March 08 
for LTF/SSF/SSFX/RMF-PVD type -->summary of unit that have completed minimum holding period of 5 or 7 years based on parameter setup
Def(Th):",
	salable_unit2           	string        comment "Def(En): Applicable for RMF only
for RMF type -->summary of unit since 1 March 08
, invested 5 consecutive years and customer age >= 55 years old
Def(Th):",
	load_tms                	string        comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id              	string        comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                	string        comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                  	string        comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                  	string        comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_raw}/${catalog}/raw_ud/ud_vw_flt_rl_sub_bal_enq' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);