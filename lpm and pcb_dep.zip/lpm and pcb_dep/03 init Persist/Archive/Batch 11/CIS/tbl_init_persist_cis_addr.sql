-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cis_addr.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-08    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CIS.CIS_ADDR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cis.cis_addr (
	pos_dt           	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	method           	string       comment "Def(En): Ingestion Method
Def(Th): วิธีการนำเข้า",
	addr_id          	bigint       comment "Def(En): Address id
Def(Th): เลขที่ที่อยู่",
	addr_ip_id       	integer      comment "Def(En): Customer id
Def(Th): เลขที่ลูกค้า",
	addr_src_stm     	string       comment "Def(En): Address source system
Def(Th): ระบบที่สร้างที่อยู่",
	addr_wkplc_nm    	string       comment "Def(En): Work Place name
Def(Th): ชื่อสถานที่ทำงาน",
	addr_po          	string       comment "Def(En): PO. Box
Def(Th): ตู้ป.ณ.",
	addr_no          	string       comment "Def(En): Address no.
Def(Th): บ้านเลขที่",
	addr_moo         	string       comment "Def(En): Moo
Def(Th): หมู่ที่",
	addr_mooban      	string       comment "Def(En): Village
Def(Th): หมู่บ้าน",
	addr_bld         	string       comment "Def(En): Building
Def(Th): อาคาร",
	addr_fl          	string       comment "Def(En): Floor no.
Def(Th): ชั้น",
	addr_room        	string       comment "Def(En): Room no.
Def(Th): ห้อง",
	addr_soi         	string       comment "Def(En): Soi
Def(Th): ซอย",
	addr_rd          	string       comment "Def(En): Road
Def(Th): ถนน",
	addr_tumbol      	string       comment "Def(En): Tumbol
Def(Th): ตำบล, แขวง",
	addr_amp         	string       comment "Def(En): Amphur
Def(Th): อำเภอ, เขต",
	addr_prov        	string       comment "Def(En): Province
Def(Th): จังหวัด",
	addr_post_cd     	string       comment "Def(En): Post code
Def(Th): รหัสไปรษณีย์",
	addr_country_cd  	string       comment "Def(En): Country code
Def(Th): รหัสประเทศของที่อยู่",
	addr_1           	string       comment "Def(En): Address 2 Line Line#1
Def(Th): ที่อยู่ 2 บรรทัด บรรทัดที่ 1",
	addr_2           	string       comment "Def(En): Address 2 Line Line#2
Def(Th): ที่อยู่ 2 บรรทัด บรรทัดที่ 2",
	addr_stat        	string       comment "Def(En): Address Status code
Def(Th): รหัสสถานะของที่อยู่",
	addr_eft_dt      	date         comment "Def(En): Address Effective date
Def(Th): วันที่สร้างที่อยู่",
	addr_exp_dt      	date         comment "Def(En): Address Expire date
Def(Th): วันที่ยกเลิกที่อยู่",
	addr_uncnt_flg   	string       comment "Def(En): Address Uncontact Mark flag
Def(Th): ระบุสถานะที่อยู่ที่ไม่สามารถติดต่อได้",
	addr_uncnt_dt    	date         comment "Def(En): Address Uncontact Mark date
Def(Th): วันที่บันทึกที่อยู่ที่ไม่สามารถติดต่อได้",
	addr_uncnt_user  	string       comment "Def(En): User id
Def(Th): รหัสผู้บันทึกที่อยู่ที่ไม่สามารถติดต่อได้",
	addr_uncnt_cen_cd	string       comment "Def(En): User Center code
Def(Th): รหัสสังกัดของผู้บันทึกที่อยู่ที่ไม่สามารถติดต่อได้",
	addr_uncnt_br_no 	string       comment "Def(En): User Branch no.
Def(Th): รหัสสาขาของผู้บันทึกที่อยู่ที่ไม่สามารถติดต่อได้",
	addr_cre_user    	string       comment "Def(En): User id
Def(Th): รหัสผู้สร้างที่อยู่",
	addr_user_id     	string       comment "Def(En): User id
Def(Th): รหัสผู้ทำรายการ",
	addr_upd_dt      	timestamp    comment "Def(En): Update date time
Def(Th): วันและเวลาที่ทำรายการ",
	load_tms         	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id       	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy         	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm           	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd           	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cis/cis_addr' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);