-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cis_dntcnt.sql
# Area: cis
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-08    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CIS.CIS_DNTCNT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cis.cis_dntcnt (
	pos_dt           	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	method           	string       comment "Def(En): Ingestion Method
Def(Th): วิธีการนำเข้า",
	dntcnt_ip_id     	integer      comment "Def(En): Customer id
Def(Th): เลขที่ลูกค้า",
	dntcnt_cnt_chnnl 	string       comment "Def(En): Contact Channel
Def(Th): ช่องทางสำหรับติดต่อลูกค้า",
	dntcnt_prd_domain	string       comment "Def(En): Product Domain
Def(Th): Domain ของผลิตภัณฑ์",
	dntcnt_purpose   	string       comment "Def(En): Contact Purpose
Def(Th): วัตถุประสงค์ในการติดต่อ",
	dntcnt_mark_user 	string       comment "Def(En): User id
Def(Th): รหัสผู้ทำรายการ do not contact",
	dntcnt_mark_dt   	timestamp    comment "Def(En): Update date time
Def(Th): วันและเวลาที่ทำรายการ do not contact",
	dntcnt_user_id   	string       comment "Def(En): User id
Def(Th): รหัสผู้ทำรายการ",
	dntcnt_upd_dt    	timestamp    comment "Def(En): Update date time
Def(Th): วันและเวลาที่ทำรายการ",
	load_tms         	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id       	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy         	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm           	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd           	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cis/cis_dntcnt' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);