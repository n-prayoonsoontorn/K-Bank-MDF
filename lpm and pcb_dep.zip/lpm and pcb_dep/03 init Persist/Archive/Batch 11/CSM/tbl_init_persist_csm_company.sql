-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_csm_company.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-08    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CSM.CSM_COMPANY
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_csm.csm_company (
	pos_dt                  	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	company_cd              	smallint     comment "Def(En): Company Code
Def(Th): รหัสของ Company",
	company_th_full_name    	string       comment "Def(En):Company Thai fullname
Def(Th):ชื่อบริษัทภาษาไทยแบบเต็ม",
	company_th_abbr_name    	string       comment "Def(En):Company Thai abreviate
Def(Th):ชื่อบริษัทภาษาไทยแบบย่อ",
	company_en_full_name    	string       comment "Def(En):Company English fullname
Def(Th):ชื่อบริษัทภาษาอังกฤษแบบเต็ม",
	company_en_abbr_name    	string       comment "Def(En):Company English abreviate
Def(Th):ชื่อบริษัทภาษาอังกฤษแบบย่อ",
	company_display_priority	smallint     comment "Def(En):Company display prioryty
Def(Th):ลำดับการแสดงผลเพื่อขอ consent",
	company_controller_flag 	string       comment "Def(En):Controller flag
Def(Th):สถานะของของบริษัทว่าสามารถเก็บค่า consent ของลูกค้าได้หรือไม่",
	company_status          	string       comment "Def(En):Company status
Def(Th):สถานะของ company",
	company_upd_user        	string       comment "Def(En):Update by UserID
Def(Th):user ที่แก้ไขข้อมูล",
	company_upd_dt          	timestamp    comment "Def(En):Update date
Def(Th):วันที่อัพเดทข้อมูล",
	load_tms                	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id              	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                  	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                  	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_csm/csm_company' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);