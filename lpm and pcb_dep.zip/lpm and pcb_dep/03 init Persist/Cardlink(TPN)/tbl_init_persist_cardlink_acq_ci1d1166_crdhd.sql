-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_acq_ci1d1166_crdhd.sql
# Area: cardlink_acq
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK_ACQ.CARDLINK_ACQ_CI1D1166_CRDHD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink_acq.cardlink_acq_ci1d1166_crdhd (
	pos_dt                   	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	cardrandom               	string       comment "Def(En): CardRandom
Def(Th):",
	cardmasking              	string       comment "Def(En): Card Masking
Def(Th):",
	cardservicetype          	string       comment "Def(En): Type of Card
Def(Th):",
	cardholdername           	string       comment "Def(En): Card owner Name
Def(Th):",
	branchorder              	string       comment "Def(En): สาขาที่สั่งบัตร
Def(Th):",
	buildcarddate            	date         comment "Def(En): วันที่สั่งบัตร gen emboss file
Def(Th):",
	cardtype                 	string       comment "Def(En): Card type for set fee
Def(Th):",
	cardstyle                	string       comment "Def(En): Card style
Def(Th):",
	pinmailer                	string       comment "Def(En): flag ที่บอกว่าบัตรนี้ต้องทำการพิมพ์ซอง PIN ไหม
Def(Th):",
	mbrnum                   	string       comment "Def(En): The member number, or card seq number, for the card. [สามารถใช้บอกได้ว่า มีบัตรเสริมหรือไม่]
Def(Th):",
	cardstatus               	string       comment "Def(En): Status Card
Def(Th):",
	issuedate                	date         comment "Def(En): Virtual - วันที่ทำการออกบัตร
Physical - วันที่ทำการผูกบัญชี หรือ activate card (change status from Inactive to Need PIN Change) 
Def(Th):",
	activedate               	date         comment "Def(En): วันที่ลูกค้าทำการ Active Card 
Virtual = issue date
Physical = ลูกค้าเปลี่ยน PIN (Need PIN Change ==> Active status)
Def(Th):",
	expireddate              	string       comment "Def(En): ExpiredDate
Def(Th):",
	canceldate               	date         comment "Def(En): วันที่ทำการอายัดบัตร
Def(Th):",
	canceltime               	string       comment "Def(En): เวลาที่ทำการอายัดบัตร
Def(Th):",
	cancelbyuserid           	string       comment "Def(En): User ID ทีทำการอายัดบัตร
Def(Th):",
	badpincount              	integer      comment "Def(En): จำนวนครั้งที่ใส่ PIN ผิด รวมทุก channel (ATM/EDC/VDO-IVR)
Def(Th):",
	badpinchannel            	string       comment "Def(En): Channel ที่ใส่ PIN ผิด
Def(Th):",
	resetpincount            	integer      comment "Def(En): จำนวนครั้งที่ Reset PIN 
Def(Th):",
	pinoffset                	string       comment "Def(En): ใช้ veriry PIN
Def(Th):",
	tranind                  	string       comment "Def(En): Terminal ID ที่ลุกค้าทำล่าสุด เพื่อ check ว่า ลูกค้าไม่ได้ทำมาซ้ำ 
Def(Th):",
	transeqnum               	string       comment "Def(En): Sequence Number ของ Terminal ID  ที่ลุกค้าทำล่าสุด เพื่อ check ว่า ลูกค้าไม่ได้ทำมาซ้ำ
Def(Th):",
	lastmadate               	date         comment "Def(En): Identifies the last file maintenance action on this record
Def(Th):",
	lastmatime               	string       comment "Def(En): Identifies the last file maintenance action on this record
Def(Th):",
	lastmabyusergroup        	string       comment "Def(En): Identifies the last file maintenance action on this record
Def(Th):",
	lastmabyuserid           	string       comment "Def(En): Identifies the last file maintenance action on this record
Def(Th):",
	updatetype               	string       comment "Def(En): UpdateType
Def(Th):",
	totalusecount            	integer      comment "Def(En): TotalUseCount
Def(Th):",
	lasttrandate             	date         comment "Def(En): Last transaction date
Def(Th):",
	purchaseregisflag        	string       comment "Def(En): Flag allow purchase goods and service 
Def(Th):",
	purchaselimit            	integer      comment "Def(En): วงเงินซื้อต่อวัน
Def(Th):",
	setpurchaselimitdate     	date         comment "Def(En): วันที่ทำการ set วงเงินซื้อ
Def(Th):",
	setpurchaselimittime     	string       comment "Def(En): เวลาที่ทำการ set วงเงินซื้อ
Def(Th):",
	setpurchaselimituserid   	string       comment "Def(En): User ID ที่ทำการ set วงเงินซื้อ
Def(Th):",
	cashwithdrawlimit        	integer      comment "Def(En): วงเงินถอนด้วยบัญชีต่อวัน
Def(Th):",
	cashadvancelimit         	integer      comment "Def(En): วงเงินถอนด้วยบัตรเครดิตต่อวัน
Def(Th):",
	setwithdrawlimitdate     	date         comment "Def(En): วันที่ทำการ set วงเงินถอนด้วยบัญชี
Def(Th):",
	setwithdrawlimittime     	string       comment "Def(En): เวลาที่ทำการ set วงเงินถอนด้วยบัญชี
Def(Th):",
	setwithdrawlimituserid   	string       comment "Def(En): User ID ที่ทำการ set วงเงินถอนด้วยบัญชี
Def(Th):",
	transferlimit            	integer      comment "Def(En): วงเงินโอนต่อวัน (ไม่นับรวมการโอนเงินภายในบัตร-Linkage Transfer)
Def(Th):",
	settransferlimitdate     	date         comment "Def(En): วันที่ทำการ set วงเงินโอน
Def(Th):",
	settransferlimittime     	string       comment "Def(En): เวลาที่ทำการ set วงเงินโอน
Def(Th):",
	settransferlimituserid   	string       comment "Def(En): User ID ที่ทำการ set วงเงินโอน
Def(Th):",
	purchaseusage            	decimal(13,0) comment "Def(En): ยอดใช้จ่ายที่ซื้อสินค้าผ่านเว็บ หรือ เครื่อง EDC ต่อวัน
Def(Th):",
	purchasecount            	integer      comment "Def(En): จำนวนครั้งที่ใช้ซื้อสินค้าผ่านผ่านเว็บ หรือ เครื่อง EDC ต่อวัน
Def(Th):",
	purchaselastdate         	date         comment "Def(En): วันที่ใช้ซื้อสินค้าผ่านเว็บ หรือ เครื่อง EDC ล่าสุด
Def(Th):",
	cashwithdrawusage        	decimal(13,0) comment "Def(En): ยอดเงินที่ใช้ถอนเงินด้วยบัญชีต่อวัน
Def(Th):",
	cashadvanceusage         	decimal(13,0) comment "Def(En): ยอดเงินที่ใช้ถอนเงินด้วยวงเงินบัตรเครดิตต่อวัน
Def(Th):",
	cashwithdrawcount        	integer      comment "Def(En): จำนวนครั้งที่ใช้ถอนเงินด้วยบัญชี
Def(Th):",
	cashwithdrawlastdate     	date         comment "Def(En): วันที่ใช้ถอนเงินด้วยบัญชีล่าสุด
Def(Th):",
	linkagetransferusage     	decimal(13,0) comment "Def(En): ยอดจำนวนเงินการโอนเงินภายในบัตรต่อวัน
Def(Th):",
	linkagetransfercount     	integer      comment "Def(En): จำนวนเครั้งการโอนเงินภายในบัตรต่อวัน
Def(Th):",
	thirdtransferusage       	decimal(13,0) comment "Def(En): ยอดจำนวนเงินการโอนเงินบุคคลที่สามต่อวัน
Def(Th):",
	thirdtransfercount       	integer      comment "Def(En): จำนวนเครั้งการโอนเงินบุคคลที่สามต่อวัน
Def(Th):",
	orftusage                	decimal(13,0) comment "Def(En): ยอดจำนวนเงินการโอนเงินต่างธนาคารต่อวัน
Def(Th):",
	orftcount                	integer      comment "Def(En): จำนวนเครั้งการโอนเงินต่างธนาคารต่อวัน
Def(Th):",
	transferlastdate         	date         comment "Def(En): วันที่ทำการโอนเงินต่างธนาคาร หรือ โอนเงินบุคคลที่สาม
Def(Th):",
	transferusage            	decimal(13,0) comment "Def(En): ยอดจำนวนเงินที่ทำการโอนเงินเงินต่างธนาคาร (ORFTUsage) รวมกับยอดจำนวนเงินที่ทำการโอนเงินบุคคลที่สาม (ThirdTransferUsage)
Def(Th):",
	balanceinqcount          	integer      comment "Def(En): ทำรายการถามยอดต่อวัน
Def(Th):",
	pinchangecount           	integer      comment "Def(En): จำนวนการเปลี่ยน PIN
Def(Th):",
	interbankfeedate         	date         comment "Def(En): InterbankFeeDate
Def(Th):",
	interbankfeemonthlycount 	integer      comment "Def(En): InterbankFeeMonthlyCount
Def(Th):",
	withdrawalfeedate        	date         comment "Def(En): WithdrawalFeeDate
Def(Th):",
	withdrawalfeecount       	integer      comment "Def(En): WithdrawalFeeCount
Def(Th):",
	thirdpartyfeedate        	date         comment "Def(En): ThirdPartyFeeDate
Def(Th):",
	thirdpartyfeecount       	integer      comment "Def(En): ThirdPartyCount
Def(Th):",
	paymentfeedate           	date         comment "Def(En): PaymentFeeDate
Def(Th):",
	paymentfeecount          	integer      comment "Def(En): PaymentFeeCount
Def(Th):",
	atcforchip1              	string       comment "Def(En): Application Transaction Counter for CHIP-CARD 1 (VISA)
Def(Th):",
	atcforchip2              	string       comment "Def(En): Application Transaction Counter for CHIP-CARD 2 (TH-STD)
Def(Th):",
	fallbackallowflag        	string       comment "Def(En): บัตรนี้อนุญาติให้ทำ Fall Back หรือไม่
Def(Th):",
	savingaccount            	string       comment "Def(En): Account number
Def(Th):",
	savingaccountbranch      	string       comment "Def(En): Account owner branch
Def(Th):",
	savingaccounttype        	string       comment "Def(En): Account type
Def(Th):",
	currentaccount           	string       comment "Def(En): Account number
Def(Th):",
	currentaccountbranch     	string       comment "Def(En): Account owner branch
Def(Th):",
	currentaccounttype       	string       comment "Def(En): Account type
Def(Th):",
	creditnum                	string       comment "Def(En): Account number
Def(Th):",
	creditbranch             	string       comment "Def(En): Account owner branch
Def(Th):",
	credittype               	string       comment "Def(En): Account type
Def(Th):",
	pendinganuualfeedate     	date         comment "Def(En): วันที่ทำการติด Pending Annual Fee
Def(Th):",
	pendingannualfeeflag     	string       comment "Def(En): Annual fee flag
Def(Th):",
	pendingannualfeecount    	integer      comment "Def(En): จำนวนครั้งที่ติด Annual Fee
Def(Th):",
	pendingannualfeeamt      	decimal(19,0) comment "Def(En): จำนวนเงินที่ติด Annual Fee
Def(Th):",
	entryfee                 	decimal(19,0) comment "Def(En): ค่าธรรมเนียมบัตรแรกเข้า
Def(Th):",
	firstyearfee             	decimal(19,0) comment "Def(En): ค่าธรรมเนียมบัตรปีแรก
Def(Th):",
	annualfee                	decimal(19,0) comment "Def(En): ค่าธรรมเนียมรายปีของบัตร
Def(Th):",
	duedate                  	string       comment "Def(En): เดือนปีที่ครบกำหนดการเก็บค่าธรรมเนียมรายปี
Def(Th):",
	lastyearfee              	decimal(19,0) comment "Def(En): ค่าธรรมเนียมบัตรปีล่าสุด ที่เกิดจากงาน batch ทั้งกรณีหักได้ & หักไม่ได้ (mark pending)
Def(Th):",
	lastyearfeedeductdate    	date         comment "Def(En): วันที่ตัดค่าธรรมเนียมบัตรปีล่าสุด ที่เกิดจากงาน Batch
Def(Th):",
	refundflag               	string       comment "Def(En): Refund flag
Def(Th):",
	refundamount             	decimal(19,0) comment "Def(En): เงินที่จะทำการ refund
Def(Th):",
	refunddate               	date         comment "Def(En): วันที่ทำการ refund สำเร็จ
Def(Th):",
	refundbyuserid           	string       comment "Def(En): User ที่ทำการคืนเงิน
Def(Th):",
	staffflag                	string       comment "Def(En): บัตรนี้เป็นพนักงานกสิกรไทยหรือไม่
Def(Th):",
	useairportloungedate     	date         comment "Def(En): วันที่ใข้บริการ Miracle Lounge
Def(Th):",
	previousairportloungedate	date         comment "Def(En): วันที่ใข้บริการ Miracle Lounge ครั้งที่แล้ว
Def(Th):",
	airportloungecount       	integer      comment "Def(En): จำนวนที่ใช้บริการ Miracle Lounge
Def(Th):",
	cardencryptedpb          	string       comment "Def(En): เบอร์บัตรที่ทำการ encrypted ด้วย Random Key 
Def(Th):",
	eban_card_masking        	string       comment "Def(En): 
Def(Th):",
	customernumber           	string       comment "Def(En): เลข Customer
Def(Th):",
	filler                   	string       comment "Def(En): 
Def(Th):",
	load_tms                 	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id               	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                 	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                   	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                   	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink_acq/cardlink_acq_ci1d1166_crdhd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);