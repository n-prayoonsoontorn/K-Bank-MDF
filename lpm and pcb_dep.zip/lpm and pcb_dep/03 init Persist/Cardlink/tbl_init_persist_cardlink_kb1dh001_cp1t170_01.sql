-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_kb1dh001_cp1t170_01.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_KB1DH001_CP1T170_01
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_kb1dh001_cp1t170_01 (
	pos_dt                               	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh001_pm_record_seq_m                	integer      comment "Def(En): Record sequence
Def(Th):",
	dh001_pm_cust_nmbr                   	bigint       comment "Def(En): Customer number
Def(Th):",
	dh001_pm_card_type                   	string       comment "Def(En): Card type
Def(Th):",
	dh001_pm_basic_or_supp               	string       comment "Def(En): Basic card or supplementary card
Def(Th):",
	dh001_pm_card_nmbr                   	bigint       comment "Def(En): Card number
Def(Th):",
	dh001_pm_branch_nmbr                 	smallint     comment "Def(En): Branch number
Def(Th):",
	dh001_pm_cr_zip_code                 	string       comment "Def(En): Zip code
Def(Th):",
	dh001_pm_principle_staff_flag        	string       comment "Def(En): Staff flag
Def(Th):",
	dh001_pm_org                         	smallint     comment "Def(En): Organization
Def(Th):",
	dh001_pm_type                        	smallint     comment "Def(En): Type 
Def(Th):",
	dh001_pm_trans_count                 	smallint     comment "Def(En): Transaction count 
(for this account)
Def(Th):",
	dh001_pm_1st_trans_addr              	integer      comment "Def(En): Transaction address ( Value for start on CPSTRN)
Def(Th):",
	dh001_pm_r_beg_balance               	decimal(11,2) comment "Def(En): Retail begin balance
Def(Th):",
	dh001_pm_r_svc_chrg                  	decimal(8,2) comment "Def(En): Retail service charge 
Def(Th):",
	dh001_pm_r_interest                  	decimal(11,2) comment "Def(En): Retail interest
Def(Th):",
	dh001_pm_r_curr_balance              	decimal(11,2) comment "Def(En): Retail current balance
Def(Th):",
	dh001_pm_r_misc                      	decimal(11,2) comment "Def(En): Retail miscellaneous Fee
Def(Th):",
	dh001_pm_c_beg_balance               	decimal(11,2) comment "Def(En): Cash begin balance
Def(Th):",
	dh001_pm_c_svc_chrg                  	decimal(11,2) comment "Def(En): Cash service charge
Def(Th):",
	dh001_pm_c_interest                  	decimal(11,2) comment "Def(En): Cash interest
Def(Th):",
	dh001_pm_c_curr_balance              	decimal(11,2) comment "Def(En): Cash current balance
Def(Th):",
	dh001_pm_amnt_past_due               	decimal(11,2) comment "Def(En): Amount past due
Def(Th):",
	dh001_pm_curr_pymt_due               	decimal(11,2) comment "Def(En): Current payment due
Def(Th):",
	dh001_pm_credit_limit                	bigint       comment "Def(En): Credit Limit
Def(Th):",
	dh001_pm_stmt_dte                    	date         comment "Def(En): Statement date
Def(Th):",
	dh001_pm_pymt_due_dte                	date         comment "Def(En): Payment due date
Def(Th):",
	dh001_pm_ytd_interest                	decimal(11,2) comment "Def(En): Interest year to date
Def(Th):",
	dh001_pm_prior_ytd_interest          	decimal(11,2) comment "Def(En): Year to date interest receive
Def(Th):",
	dh001_pm_ach_flag                    	smallint     comment "Def(En): Autopayment flag
Def(Th):",
	dh001_pm_ach_db_nmbr                 	bigint       comment "Def(En): Account for autopayment
Def(Th):",
	dh001_pm_avail_credit                	bigint       comment "Def(En): Avail credit
Def(Th):",
	dh001_pm_memo_nbr_1                  	smallint     comment "Def(En): Memo number-1
Def(Th):",
	dh001_pm_memo_nbr_2                  	smallint     comment "Def(En): Memo number-2
Def(Th):",
	dh001_pm_memo_nbr_3                  	smallint     comment "Def(En): Memo number-3
Def(Th):",
	dh001_pm_memo_nbr_4                  	smallint     comment "Def(En): Memo number-4
Def(Th):",
	dh001_pm_memo_nbr_5                  	smallint     comment "Def(En): Memo number-5
Def(Th):",
	dh001_pm_status                      	smallint     comment "Def(En): Status of cardholder
Def(Th):",
	dh001_pm_annual_fee                  	decimal(7,2) comment "Def(En): Annual Fee amount
Def(Th):",
	dh001_pm_fee_amount                  	decimal(11,2) comment "Def(En): Other Fee amount
Def(Th):",
	dh001_pm_vat_amount                  	decimal(9,2) comment "Def(En): VAT amount
Def(Th):",
	dh001_pm_mbosser_name_1_info         	string       comment "Def(En): Embosser name information
Def(Th):",
	dh001_pm_basic_or_supp_card_info     	string       comment "Def(En): Basic card or supplementary card information
Def(Th):",
	dh001_pm_cr_thai_name                	string       comment "Def(En): Customer thai name
Def(Th):",
	dh001_pm_cr_addr_1                   	string       comment "Def(En): Customer address line-1
Def(Th):",
	dh001_pm_cr_addr_2                   	string       comment "Def(En): Customer address line-2
Def(Th):",
	dh001_pm_cr_crlimit                  	integer      comment "Def(En): Customer credit Line
Def(Th):",
	dh001_pm_statemenr_reference         	bigint       comment "Def(En): Statement number 
Def(Th):",
	dh001_pm_princ_card_nmbr             	bigint       comment "Def(En): Principle card number
Def(Th):",
	dh001_pm_bb_earned_spec              	integer      comment "Def(En): Special point for this month
Def(Th):",
	dh001_pm_bb_exp_mnt1                 	integer      comment "Def(En): Point expire in 1 month
Def(Th):",
	dh001_pm_bb_exp_mnt2                 	integer      comment "Def(En): Point expire in 2 month
Def(Th):",
	dh001_pm_bb_billing_cyc              	smallint     comment "Def(En): Billing cycle 
Def(Th):",
	dh001_pm_bb_beg_balance              	integer      comment "Def(En): Point last month 
Def(Th):",
	dh001_pm_bb_earned_ctd               	integer      comment "Def(En): Point for this month
Def(Th):",
	dh001_pm_bb_used_ctd                 	integer      comment "Def(En): Point redeem for this month
Def(Th):",
	dh001_pm_sec_cust_nbr                	bigint       comment "Def(En): Customer number (use for produce statement file)
Def(Th):",
	dh001_pm_t_payment                   	decimal(11,2) comment "Def(En): Summary amount payment
Def(Th):",
	dh001_pm_t_purch_cash                	decimal(11,2) comment "Def(En): Summary amount retail and cash
Def(Th):",
	dh001_pm_c_curr_base_rate            	decimal(8,7) comment "Def(En): Interest rate
Def(Th):",
	dh001_pm_aff_code                    	smallint     comment "Def(En): Affinity code 
Def(Th):",
	dh001_pm_sort_stmt_dte_m             	date         comment "Def(En): Sort Statement date
Def(Th):",
	dh001_pm_sort_flag_m                 	string       comment "Def(En): sort flag 
Def(Th):",
	dh001_pm_line_count_cust             	smallint     comment "Def(En): Number of line per customer
Def(Th):",
	dh001_pm_page_count_card             	smallint     comment "Def(En): Number of page per cardholder
Def(Th):",
	dh001_pm_page_count_cust             	smallint     comment "Def(En): Number of page per customer
Def(Th):",
	filler                               	string       comment "Def(En): 
Def(Th):",
	load_tms                             	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                           	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                             	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                               	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                               	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_kb1dh001_cp1t170_01' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);