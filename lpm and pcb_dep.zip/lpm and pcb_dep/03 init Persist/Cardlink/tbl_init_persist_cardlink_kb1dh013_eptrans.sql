-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_kb1dh013_eptrans.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_KB1DH013_EPTRANS
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_kb1dh013_eptrans (
	pos_dt                      	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh013_acct_org              	smallint     comment "Def(En): ORG Of Card 
001- Credit Card 
200 - KEC
Def(Th):",
	dh013_acct_type             	smallint     comment "Def(En): TYPE Of Card  
Def(Th):",
	dh013_card_nmbr             	bigint       comment "Def(En): Card Number
Def(Th):",
	dh013_tran_date             	date         comment "Def(En): Transaction Date
Def(Th): วันที่ทำรายการ",
	dh013_tran_time             	integer      comment "Def(En): Transaction Time
Def(Th): เวลา HHMMSS เช่น  231805",
	dh013_merch_org             	smallint     comment "Def(En): ORG Of Merchant 
Def(Th): รูดจากร้านค้าไหน ประเภทไหน",
	dh013_merch_nmbr            	integer      comment "Def(En): Merchant Number
Def(Th): รหัสร้านค้า",
	dh013_exp_date              	smallint     comment "Def(En): Expire Date 
Def(Th):",
	dh013_item_price            	decimal(9,2) comment "Def(En):
Def(Th): ยอดรวมทั้งหมดที่รูด ยอดราคาเต็มสินค้าที่รูด เช่น วันที่  26   3 รายการ  จะแสดง  3  บรรทัด เป็นรายการ วันต่อวัน",
	dh013_pay_term              	smallint     comment "Def(En): 
Def(Th): จำนวนงวดที่ชำระ (เดือน)",
	dh013_intr_rate             	decimal(7,6) comment "Def(En): Interest Rate
Def(Th): ดอกเบี้ยที่คิด",
	dh013_intr_free_mos         	smallint     comment "Def(En): 
Def(Th):จำนวนงวดที่ไม่มีดอกเบี้ย",
	dh013_first_pay_date        	date         comment "Def(En): First Payment Date 
Def(Th): วันแรกที่ให้ลูกค้าชำระ",
	dh013_first_pay_amt         	decimal(9,2) comment "Def(En): First Payment Amount 
Def(Th): ยอดผ่อนชำระงวดแรก",
	dh013_last_pay_date         	date         comment "Def(En): Last Payment Date
Def(Th):",
	dh013_last_pay_amt          	decimal(9,2) comment "Def(En): Last Payment Amount
Def(Th): ยอดผ่อนชำระงวดสุดท้าย",
	dh013_mon_instl_amt         	decimal(9,2) comment "Def(En): 
Def(Th): ยอดผ่อนชำระต่องวด  เป็นยอดผ่อนชำระ ที่รวมดอกเบี้ย
Ex1: 0%   2 เดือน ต่อมา ดอก  6% 8  เดือน   
เดือน  1, 2  ดูจาก DH013-FIRST-PAY-AMT
เดือน  3 - 7 ดูจาก DH013-MON-INSTL-AMT 
เดือน  8 ดูจาก DH013-LAST-PAY-AMT 

Ex2:    0 %  10  เดือน  ดูจาก 
DH013-MON-INSTL-AMT ได้เลย",
	dh013_outs_principal        	decimal(9,2) comment "Def(En): 
Def(Th): ยอดเงินต้นคงค้าง ไม่รวมดอกเบี้ย 
filed  นี้จะ  update  ยอดเงินต้นจากลูกค้าชำระ
เช่น ถ้าลูกค้า มีหนี้อยู่  5,000 จ่าย  1,000  บาท ดังนั้น DH013-OUTS-PRINCIPAL  = 4,000 
ถ้าลูกค้าจ่าย  5,000   ดังนั้น DH013-OUTS-PRINCIPAL  = 0 แล้ว  purge  ออกจาก file นี้",
	dh013_curr_cycle_intr       	decimal(9,2) comment "Def(En): Current Cycle Interest 
Def(Th):  อัตราดอกเบี้ยของ  รอบล่าสุด  (Unused field",
	dh013_paid_terms            	smallint     comment "Def(En): 
Def(Th): จำนวนงวดที่ชำระเข้ามาในระบบแล้ว 
จำนวนงวดที่ลูกค้าชำระมา field  นี้ update  ค่า",
	dh013_status                	smallint     comment "Def(En): Status
Def(Th): Status ที่บอกว่าการผ่อนชำระสิ้นสุดหรือยัง",
	dh013_instl_plan            	smallint     comment "Def(En): Install Plan 
Def(Th): รูปแบบการผ่อน  default   999   (Unused field)",
	dh013_purge_date            	date         comment "Def(En): Purge Date 
Def(Th): วันที่จะ purge record ออกจากระบบ
ถ้า  เป็น  spaces  แสดงว่า ยังผ่อนชำระไม่หมด",
	dh013_auth_code             	string       comment "Def(En): 
Def(Th): Authorize code  ตอนรูด",
	dh013_merch_name            	string       comment "Def(En): Merchant Name
Def(Th):",
	dh013_outs_int              	decimal(9,2) comment "Def(En): 
Def(Th): ยอดอัตราดอกเบี้ยคงค้าง ถ้าลูกค้าชำระดอกเบี้ยเข้ามา จะลดลงเรื่อยๆๆ",
	dh013_sss_nbr               	bigint       comment "Def(En): (Unused field)
Def(Th):",
	dh013_intr_compute_method   	smallint     comment "Def(En): 
Def(Th): วิธีการคำนวณดอกเบี้ย แบบ คงที่ หรือ Tier หรือ ลดต้นลดอก 
meaning",
	dh013_handling_fee          	decimal(9,2) comment "Def(En): Handing Fee (Unused field)
Def(Th):",
	dh013_iplan_mode            	smallint     comment "Def(En): (Unused field)
Def(Th):",
	dh013_supp_nbr              	smallint     comment "Def(En): Support Number (Unused field)
Def(Th):",
	dh013_prod_typ              	smallint     comment "Def(En): Production Type (Unused field)
Def(Th):",
	dh013_model_nbr             	integer      comment "Def(En): Model Number (Unused field)
Def(Th):",
	dh013_term_id               	string       comment "Def(En): Terminal ID 
Def(Th):",
	dh013_txn_identifier        	bigint       comment "Def(En): Transaction Idendifier (Unused field)
Def(Th):",
	dh013_interest_rate_1       	decimal(6,5) comment "Def(En): 
Def(Th): Interest Rate 1  อัตราดอกเบี้ยของงวดที่  1 (Unused field)",
	dh013_interest_rate_2       	decimal(6,5) comment "Def(En): 
Def(Th): Interest Rate 2 อัตราดอกเบี้ยของงวดที่  2 (Unused field)",
	dh013_interest_rate_3       	decimal(6,5) comment "Def(En): 
Def(Th): Interest Rate 3 อัตราดอกเบี้ยของงวดที่  3 (Unused field)",
	dh013_interest_rate_4       	decimal(6,5) comment "Def(En): 
Def(Th): Interest Rate 4 อัตราดอกเบี้ยของงวดที่  4 (Unused field)",
	dh013_interest_rate_5       	decimal(6,5) comment "Def(En): Interest Rate 5 (Unused field)
Def(Th):",
	dh013_interest_rate_6       	decimal(6,5) comment "Def(En): Interest Rate 6 (Unused field)
Def(Th):",
	dh013_interest_rate_7       	decimal(6,5) comment "Def(En): Interest Rate 7 (Unused field)
Def(Th):",
	dh013_interest_rate_8       	decimal(6,5) comment "Def(En): Interest Rate 8 (Unused field)
Def(Th):",
	dh013_interest_rate_9       	decimal(6,5) comment "Def(En): Interest Rate 9 (Unused field)
Def(Th):",
	dh013_interest_rate_10      	decimal(6,5) comment "Def(En): Interest Rate 10 (Unused field)
Def(Th):",
	dh013_interest_rate_11      	decimal(6,5) comment "Def(En): Interest Rate 11 (Unused field)
Def(Th):",
	dh013_interest_rate_12      	decimal(6,5) comment "Def(En): Interest Rate 12 (Unused field)
Def(Th):",
	dh013_installment_amt_1     	decimal(9,2) comment "Def(En): Installment Amount 1 (Unused field)
Def(Th):",
	dh013_installment_amt_2     	decimal(9,2) comment "Def(En): Installment Amount 2 (Unused field)
Def(Th):",
	dh013_installment_amt_3     	decimal(9,2) comment "Def(En): Installment Amount 3 (Unused field)
Def(Th):",
	dh013_installment_amt_4     	decimal(9,2) comment "Def(En): Installment Amount 4 (Unused field)
Def(Th):",
	dh013_installment_amt_5     	decimal(9,2) comment "Def(En): Installment Amount 5 (Unused field)
Def(Th):",
	dh013_installment_amt_6     	decimal(9,2) comment "Def(En): Installment Amount 6 (Unused field)
Def(Th):",
	dh013_installment_amt_7     	decimal(9,2) comment "Def(En): Installment Amount 7 (Unused field)
Def(Th):",
	dh013_installment_amt_8     	decimal(9,2) comment "Def(En): Installment Amount 8 (Unused field)
Def(Th):",
	dh013_installment_amt_9     	decimal(9,2) comment "Def(En): Installment Amount 9 (Unused field)
Def(Th):",
	dh013_installment_amt_10    	decimal(9,2) comment "Def(En): Installment Amount 10 (Unused field)
Def(Th):",
	dh013_installment_amt_11    	decimal(9,2) comment "Def(En): Installment Amount 11 (Unused field)
Def(Th):",
	dh013_installment_amt_12    	decimal(9,2) comment "Def(En): Installment Amount 12 (Unused field)
Def(Th):",
	dh013_serial_nbr            	string       comment "Def(En): Serial Number (Unused field)
Def(Th):",
	dh013_xfr_new_card_nbr      	bigint       comment "Def(En): (Unused field)
Def(Th):",
	dh013_signon_name           	string       comment "Def(En): Maintenance User (Unused field)
Def(Th):",
	dh013_mcc_code              	smallint     comment "Def(En): Merchant category
Def(Th):",
	dh013_maint_date            	string       comment "Def(En): Maintenance Date วันล่าสุดที่มีการ update   
Def(Th):",
	dh013_smartcash_to_acct_no  	string       comment "Def(En): Smart cash transfer account number
Def(Th):",
	dh013_smartcash_to_acct_name	string       comment "Def(En): Smart cash transfer account name
Def(Th):",
	dh013_smartcash_bank_code   	string       comment "Def(En): Smart Cash transfer bank code
Def(Th):",
	filler                      	string       comment "Def(En): Filler
Def(Th):",
	load_tms                    	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                  	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                    	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                      	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                      	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_kb1dh013_eptrans' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);