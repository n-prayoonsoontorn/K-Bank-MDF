-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_kb1dh018_cpsrptt.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_KB1DH018_CPSRPTT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_kb1dh018_cpsrptt (
	pos_dt                            	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh018_trr_form_nmbr               	smallint     comment "Def(En): Report Form Number
Def(Th):",
	dh018_trr_orgn_nmbr               	smallint     comment "Def(En): Org Number
Def(Th):",
	dh018_trr_group_nmbr              	smallint     comment "Def(En): Group Number
Def(Th):",
	dh018_trr_rpt_nmbr                	smallint     comment "Def(En): Report Number
Def(Th):",
	dh018_trr_type_nmbr               	smallint     comment "Def(En): Type Number 
Def(Th):",
	dh018_wst1_acct_nmbr              	bigint       comment "Def(En): Credit card number
Def(Th): หมายเลขบัตรเครดิต",
	dh018_wst_trnsfer_dte             	date         comment "Def(En): 
Def(Th): วันที่Transfer รายการ",
	dh018_wst_posting_dte             	string       comment "Def(En): 
Def(Th): วันที่ Post รายการนี้เข้าระบบ Cardlink",
	dh018_wst_purchase_dte, dh018_time	string       comment "Def(En): 
Def(Th): วันที่ลูกค้าทำรายการซื้อสินค้า",
	dh018_wst_date_last_delq          	string       comment "Def(En): 
Def(Th): วันที่ค้างชำระล่าสุด",
	dh018_wst_amount                  	decimal(11,2) comment "Def(En): 
Def(Th): จำนวนเงิน",
	dh018_wst_curr_balance            	decimal(13,2) comment "Def(En): 
Def(Th): ยอด Current Balance ของบัตร",
	dh018_wst_amt_past_due            	decimal(13,2) comment "Def(En): 
Def(Th): ยอด Past Due Amount",
	dh018_wst_short_name              	string       comment "Def(En): 
Def(Th): ชื่อลูกค้า",
	dh018_wst_status                  	string       comment "Def(En): Status ของบัตร
Def(Th):",
	dh018_wst_block_code              	string       comment "Def(En): Block Code ของบัตร
Def(Th):",
	dh018_wst_alt_block_code          	string       comment "Def(En): Alt Block Code ของบัตร
Def(Th):",
	dh018_wst_cycle                   	smallint     comment "Def(En): Cycle ของบัตร
Def(Th):",
	dh018_wst_user_code               	string       comment "Def(En): User Code ของบัตร
Def(Th):",
	dh018_wst_user_code_2             	string       comment "Def(En): User Code-2 ของบัตร
Def(Th):",
	dh018_wst_user_code_3             	string       comment "Def(En): User Code-3 ของบัตร
Def(Th):",
	dh018_wst_tfb_card_type           	string       comment "Def(En): 
Def(Th): ประเภทของบัตร เช่น Visa , Mastercard",
	dh018_wst_auth_flag               	string       comment "Def(En): Authorize Flag
Def(Th):",
	dh018_wst_rt_nmbr                 	integer      comment "Def(En): 
Def(Th): ค่าCM-ACH-RT-NMBR ของบัตร",
	dh018_wst_dda_acct                	bigint       comment "Def(En): Deduct account
Def(Th): ค่าCM-ACH-DB-NMBR ของบัตร
เลขที่บัญขีที่ผูกกับบัตรไว้ตัดชำระเงินอัตโนมัติ (Auto Payment)",
	dh018_wst_ref_nmbr                	bigint       comment "Def(En): Reference Number ที่เข้า Post ในCardlink
Def(Th):",
	dh018_wst_posting_flag            	smallint     comment "Def(En): Posting Flag 
Def(Th): บอกว่ารายการสำเร็จหรือไม่",
	dh018_wst_source                  	smallint     comment "Def(En): 
Def(Th): แหล่งที่มาของรายการนี้
WS-LOCAL-INPUT              VALUE +0.       
WS-USER-IPT                 VALUE +1.       
WS-GENERATED                VALUE +2.       
WS-TRANSFERED-HISTORY       VALUE +3.       
WS-INCLEARING               VALUE +4, +5.   
WS-VISA-INCLEARING          VALUE +4.       
WS-INET-INCLEARING          VALUE +5.       
WS-TRANSFERRED-DETAIL           VALUE +6 +7.
WS-TRANSFER-DET-ORIG-INCLR      VALUE +6.   
WS-TRANSFER-DET-NOT-ORIG-INCLR  VALUE +7.   
WS-VISA-DATA-CAPTURE            VALUE +8.   
WS-LOCAL-BANK-INCOM             VALUE +98.",
	dh018_wst_trans_code              	smallint     comment "Def(En): Transaction Code
Def(Th):",
	dh018_wst_collector               	string       comment "Def(En): 
Def(Th): ค่าCM-CURR-COLLECTOR ของบัตร",
	dh018_wst_desc                    	string       comment "Def(En): 
Def(Th): ชื่อรายการ หรือชื่อร้านค้า",
	dh018_wst_ins_flag                	string       comment "Def(En): Installment Flag
Def(Th):",
	dh018_wst_br_code                 	smallint     comment "Def(En): 
Def(Th): รหัสสาขา  
(ฟิลด์นี้จะมีค่า เมื่อเป็นรายการ Trans-Code = 40,30 เท่านั้น)
เอาค่ามาจาก DH018-WST-DESC
Pending List Value 
- ถ้า 20 ผ่านสาขาจะมี BR-CODE ??
มีค่า Branch Code",
	dh018_wst_orig_ref_nbr            	string       comment "Def(En): Acquire Reference Number
Def(Th): รหัสอ้างอิงกับร้านค้าต่างธนาคาร",
	dh018_wst_trnsfer_acct_nmbr       	bigint       comment "Def(En): 
Def(Th): ค่าCM-XFR-ACCT-NMBR ของบัตร 
(เบอร์บัตรใหม่ ถ้ามีการ Transferไปบัตรใหม่)",
	dh018_wst_reimb_att               	string       comment "Def(En): 
Def(Th): ค่า CMTV-REIMB-ATT",
	dh018_wst_auto_chgbk_flag         	smallint     comment "Def(En): Flag Auto Chargeback (ลค.ปฏิเสธการจ่าย)
Def(Th):",
	dh018_trr_chgoff_status           	string       comment "Def(En): Charge-Off Status
Def(Th):",
	dh018_trr_stop_int_income_flag    	string       comment "Def(En): Flag Stop Int Income flag
Def(Th):",
	dh018_time                        	string       comment "Def(En): Time transaction เวลาที่ทำรายการ ;
 Time  ของ  purchase-date
Def(Th):",
	load_tms                          	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                        	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                          	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                            	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                            	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_kb1dh018_cpsrptt' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);