-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_kb1dh021_cc1d582s.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_KB1DH021_CC1D582S
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_kb1dh021_cc1d582s (
	pos_dt                           	date          comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh021_d582_batch_proc_date_ymd   	date          comment "Def(En):
Def(Th): วันที่ของข้อมูล",
	dh021_d582_create_date_ymd       	date          comment "Def(En):
Def(Th): วันที่สร้างไฟล์",
	dh021_d582_merchant_file_date_ymd	date          comment "Def(En):
Def(Th): วันที่ทำรายการที่ร้านค้า",
	dh021_d582_merchant_id           	bigint        comment "Def(En):
Def(Th): รหัสร้านค้า",
	dh021_d582_merchant_name         	string        comment "Def(En):
Def(Th): ชื่อร้านค้า",
	dh021_d582_owner_ind             	smallint      comment "Def(En): Owner ID
Def(Th):",
	dh021_d582_terminal_no           	smallint      comment "Def(En): Terminal no.
Def(Th):",
	dh021_d582_batch_no              	smallint      comment "Def(En): Batch no.
Def(Th):",
	dh021_d582_trans_seq_no          	integer       comment "Def(En): Transaction Seq No.
Def(Th):",
	dh021_d582_trans_code            	smallint      comment "Def(En): Transaction Code
Def(Th):",
	dh021_d582_trans_date            	date          comment "Def(En):
Def(Th): วันที่ทำรายการ",
	dh021_d582_trans_time            	smallint      comment "Def(En):
Def(Th): เวลาที่ทำรายการ HH:MM",
	dh021_d582_vs_mc_acct_no         	bigint        comment "Def(En): Visa Mastercard account no.
Def(Th):",
	dh021_d582_cd_acct_no            	bigint        comment "Def(En): Credit card account no.
Def(Th):",
	dh021_d582_vs_comm_rate          	decimal(4,2)  comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Visa",
	dh021_d582_mc_comm_rate          	decimal(4,2)  comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Mastercard",
	dh021_d582_cd_comm_rate          	decimal(4,2)  comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Credit card",
	dh021_d582_card_no               	bigint        comment "Def(En): Card Number
Def(Th):",
	dh021_d582_trans_amount          	decimal(12,2) comment "Def(En): Transaction amount
Def(Th):",
	dh021_d582_card_id_method        	string        comment "Def(En): Card ID Method
Def(Th):",
	dh021_d582_acct_data_source_code 	string        comment "Def(En):
Def(Th): แหล่งที่มาของข้อมูล",
	dh021_d582_auth_source_code      	string        comment "Def(En):
Def(Th): รหัสของแหล่งข้อมูลที่ขอ Authorize",
	dh021_d582_auth_no               	string        comment "Def(En): Authorize no.
Def(Th):",
	dh021_d582_system_code           	smallint      comment "Def(En): System code
Def(Th):",
	dh021_d582_user_code_3           	string        comment "Def(En): User code3
Def(Th):",
	dh021_d582_branch                	smallint      comment "Def(En):
Def(Th): รหัสสาขา",
	dh021_d582_cc1p554_flag          	string        comment "Def(En):
Def(Th): Flag แสดงสถานะของรายงาน CC1P554",
	dh021_d582_cc1p584_flag          	string        comment "Def(En):
Def(Th): Flag แสดงสถานะของรายงาน CC1P584",
	dh021_d582_ve_comm_rate          	decimal(4,2)  comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Visa Electron",
	dh021_d582_orig_amount           	decimal(12,2) comment "Def(En): Original amount
Def(Th):",
	dh021_d582_curr_code             	smallint      comment "Def(En): Currency code
Def(Th):",
	dh021_d582_curr_rate             	decimal(4,2)  comment "Def(En): Currency Rate
Def(Th):",
	dh021_d582_ec_comm_rate          	decimal(4,2)  comment "Def(En):
Def(Th): Committion Rate ของบัตร Electronic card",
	dh021_d582_ecom_transfer_flag    	string        comment "Def(En): E-Commerce transfer flag
Def(Th):",
	dh021_d582_ecom_mall_comm_rate   	decimal(4,2)  comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Electronic card",
	dh021_d582_ec_card_user_code     	string        comment "Def(En): User code of Electronic card
Def(Th):",
	dh021_d582_ec_card_per_trans     	decimal(7,5)  comment "Def(En): Charge commision Fee Per transaction of Electronic card
Def(Th):",
	dh021_d582_ec_card_bull_cost     	decimal(7,2)  comment "Def(En): Bull cost of Electronic card
Def(Th):",
	dh021_d582_user_code_1           	string        comment "Def(En): User code1
Def(Th):",
	dh021_d582_merch_cepp            	string        comment "Def(En): Merchant Cepp
Def(Th):",
	dh021_d582_mmd_merch_type        	smallint      comment "Def(En): Merchant Type
Def(Th):",
	dh021_d582_mmd_pos_mode          	string        comment "Def(En): Pos mode
Def(Th):",
	dh021_d582_mmd_mail_phone_ind    	string        comment "Def(En): MAIL Telephone INDICATOR TO BE USED INTERCHANGEABLY BETWEEN VISA 
AND MASTERCARD                  
Def(Th):",
	dh021_d582_purcase_card_flag     	string        comment "Def(En): Purchase card flag
Def(Th):",
	dh021_d582_vs_on_comm_rate       	decimal(4,2)  comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Visa onus",
	dh021_d582_vs_lo_comm_rate       	decimal(4,2)  comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Visa local",
	dh021_d582_vs_in_comm_rate       	decimal(4,2)  comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Visa inter",
	dh021_d582_vs_plt_comm_rate      	decimal(4,2)  comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Visa platinium",
	dh021_d582_vs_cop_comm_rate      	decimal(4,2)  comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Visa cooperate",
	dh021_d582_mc_on_comm_rate       	decimal(4,2)  comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Mastercard onus",
	dh021_d582_mc_lo_comm_rate       	decimal(4,2)  comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Mastercard local",
	dh021_d582_mc_in_comm_rate       	decimal(4,2)  comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Mastercard inter",
	dh021_d582_mc_plt_comm_rate      	decimal(4,2)  comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Mastercard platinium",
	dh021_d582_mc_cop_comm_rate      	decimal(4,2)  comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของบัตร Mastercard cooperate",
	dh021_d582_purc_comm_rate        	decimal(4,2)  comment "Def(En):
Def(Th): อัตราค่าธรรมเนียมของ Purchase",
	dh021_d582_smartpay_flag         	smallint      comment "Def(En): Smartpay flag
Def(Th):",
	dh021_d582_iplan_mode            	string        comment "Def(En):
Def(Th): Iplan mode คือรหัสโครงการผ่อนชำระ",
	dh021_d582_supp_nbr              	smallint      comment "Def(En): Supplier number
Def(Th):",
	dh021_d582_prod_typ              	smallint      comment "Def(En):
Def(Th): Product Type ประเภทของสินค้า",
	dh021_d582_model_nbr             	integer       comment "Def(En): Model number
Def(Th):",
	dh021_d582_serial_nbr            	string        comment "Def(En): Serial number
Def(Th):",
	dh021_d582_supp_name             	string        comment "Def(En): Supplier name
Def(Th):",
	dh021_d582_prod_name             	string        comment "Def(En): Product name
Def(Th):",
	dh021_d582_model_name            	string        comment "Def(En): Model name
Def(Th):",
	dh021_d582_promotion_name        	string        comment "Def(En): Promotion name
Def(Th):",
	dh021_d582_threshold_from        	decimal(9,2)  comment "Def(En):
Def(Th): Min Amount สามารถผ่อนได้",
	dh021_d582_threshold_to          	decimal(9,2)  comment "Def(En):
Def(Th): Max Amountที่สามารถผ่อนได้",
	dh021_d582_handling_fee          	decimal(9,2)  comment "Def(En):
Def(Th): Handling fee ค่าธรรมเนียมการจัดการ",
	dh021_d582_min_inst_per_month    	decimal(9,2)  comment "Def(En):
Def(Th): Min installment
ยอดขั้นต่ำที่จะต้องผ่อนแต่ละเดือน",
	dh021_d582_term                  	smallint      comment "Def(En):
Def(Th): Term จำนวนงวดที่ผ่อน",
	dh021_d582_nbr_of_free_mon       	smallint      comment "Def(En):
Def(Th): จำนวนเดือนยังไม่ต้องชำระเงิน",
	dh021_d582_nbr_of_waive_fr       	smallint      comment "Def(En):
Def(Th): เริ่มต้น เดือนที่ Waive ดอกเบี้ย",
	dh021_d582_nbr_of_waive_to       	smallint      comment "Def(En):
Def(Th): สิ้นสุด เดือนที่ Waive ดอกเบี้ย",
	dh021_d582_merchant_disc         	decimal(6,5)  comment "Def(En): Merchant discount
Def(Th):",
	dh021_d582_interest              	decimal(6,5)  comment "Def(En): Interest
Def(Th):",
	dh021_d582_merchant_fee          	decimal(6,5)  comment "Def(En): Merchant fee
Def(Th):",
	dh021_d582_supplier_fee          	decimal(6,5)  comment "Def(En): Supplier fee
Def(Th):",
	dh021_d582_customer_fee          	decimal(6,5)  comment "Def(En): Customer fee
Def(Th):",
	dh021_d582_start_date_jul        	date          comment "Def(En):
Def(Th): วันที่เริ่มต้นโครงการผ่อนชำระ",
	dh021_d582_end_date_jul          	date          comment "Def(En):
Def(Th): วันที่สิ้นสุดโครงการผ่อนชำระ",
	dh021_d582_maint_date_dmy        	date          comment "Def(En):
Def(Th): วันที่ดำเนินการ Maintenance ข้อมูลร้านค้า",
	dh021_d582_maint_user            	string        comment "Def(En):
Def(Th): User ที่ดำเนินการ Maintananceข้อมูลร้านค้า",
	dh021_d582_status_flag           	string        comment "Def(En):
Def(Th): Status flag ของ ร้านค้า
MMD-STATUS-FLAG",
	dh021_d582_brand_name            	string        comment "Def(En): Brand name
Def(Th):",
	dh021_d582_rec_of_charge         	integer       comment "Def(En): Record of Charge 
Def(Th):",
	dh021_d582_serial_nbr_emie       	string        comment "Def(En):
Def(Th): Serial number/EMIE ของรายการสินค้าที่ผ่อน",
	dh021_d_filler                   	string        ,
	load_tms                         	timestamp     comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                       	string        comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                         	string        comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                           	string        comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                           	string        comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_kb1dh021_cc1d582s' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);