-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_kb1dh029_ccatabla.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_KB1DH029_CCATABLA
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_kb1dh029_ccatabla (
	pos_dt                       	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh029_arda_tbl_type          	string       comment "Def(En): TABLE TYPE
Def(Th):",
	dh029_arda_tbl_mneu          	string       comment "Def(En): TABLE BIN NAME
Def(Th):",
	dh029_arda_rec_typ           	string       comment "Def(En): Record Type of bin visa
Def(Th):",
	dh029_arda_tbl_key           	string       comment "Def(En): TBL Key
Def(Th):",
	dh029_arda_tbl_eff_dt        	string       comment "Def(En): Effective date
Def(Th):",
	dh029_arda_del_indicator     	string       comment "Def(En): Delete INDICATOR
Def(Th):",
	dh029_arda_low_range_acct    	string       comment "Def(En): Low range account
Def(Th):",
	dh029_arda_issuer_bin        	integer      comment "Def(En): Issuer BIN
Def(Th):",
	dh029_arda_chk_digit         	smallint     comment "Def(En): Check Digit
Def(Th):",
	dh029_arda_acct_length       	smallint     comment "Def(En): Account Length
Def(Th):",
	dh029_arda_card_type         	string       comment "Def(En): Card type
Def(Th):",
	dh029_arda_usage             	string       comment "Def(En): Usage
Def(Th):",
	dh029_arda_process_bin       	integer      comment "Def(En): Process BIN
Def(Th):",
	dh029_arda_domain            	string       comment "Def(En): Domain
Def(Th):",
	dh029_arda_region            	smallint     comment "Def(En): Region
Def(Th):",
	dh029_arda_country           	string       comment "Def(En): Country of issuer BIN (ARDA-ISSUER-BIN)
Def(Th):",
	dh029_arda_commerc_card_ind  	string       comment "Def(En): Commercial Cards Ind
Def(Th):",
	dh029_arda_techno_ind        	string       comment "Def(En): Technology
Indicator
Def(Th):",
	dh029_arda_ardef_region      	string       comment "Def(En): Region เมือง
Def(Th):",
	dh029_arda_ardef_country     	string       comment "Def(En): Account range (ARDEF) country of issue
Def(Th):",
	dh029_arda_commerc_card_l2   	string       comment "Def(En): Commercial Card Level 2 Data Indicator
Def(Th):",
	dh029_arda_commerc_card_l3   	string       comment "Def(En): Commercial Card Level 3 Enhanced Data Indicator
Def(Th):",
	dh029_arda_pos_prompt        	string       comment "Def(En): Commercial Card POS Prompting Indicator
Def(Th):",
	dh029_arda_vat_evidence      	string       comment "Def(En): Commercial Card
Electronic VATEvidence Indicator
Def(Th):",
	dh029_arda_original_credit   	string       comment "Def(En): Original Credit
Def(Th):",
	dh029_arda_product_type_ext  	string       comment "Def(En): Product Type
Def(Th):",
	dh029_arda_oc_money_transfer 	string       comment "Def(En): Money Transfer
Def(Th):",
	dh029_arda_oc_online_gambling	string       comment "Def(En): Online Gambling
Def(Th):",
	dh029_arda_product_id        	string       comment "Def(En): Product id
Def(Th):",
	load_tms                     	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                   	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                     	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                       	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                       	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_kb1dh029_ccatabla' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);