-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_kb1dh037_cptcpf_p.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_KB1DH037_CPTCPF_P
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_kb1dh037_cptcpf_p (
	pos_dt                  	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh037_p_record_nbr      	bigint       comment "Def(En): Record number in maintenance file
Def(Th):",
	dh037_p_org             	smallint     comment "Def(En): Organization 
001 : Credit Card
200 : KEC
Def(Th):",
	dh037_p_type            	smallint     comment "Def(En): Card Type
000 :- detail record of Customer 
Not equal 000 :- detail record of CardHolder
Def(Th):",
	dh037_p_carriage_control	smallint     comment "Def(En): Carriage control
0 :- CPCCPF-TOP-OF-PAGE  
1 , 4 THRU 9 :- SKIP-1-LINE
2 :- SKIP-2-LINES
3 :- SKIP-3-LINES
Def(Th): เว้นกี่บรรทัด จัดหน้าเอกสารใน  cobol",
	dh037_p_data            	string       comment "Def(En): Data of Header report / Data of Total record
Def(Th):",
	load_tms                	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id              	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                  	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                  	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_kb1dh037_cptcpf_p' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);