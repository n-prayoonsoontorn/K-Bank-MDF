-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_la10s_oatkn.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_LA10S_OATKN
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_la10s_oatkn (
	pos_dt                    	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	oatkn_org                 	string       comment "Def(En): Organization
Def(Th):",
	oatkn_type                	string       comment "Def(En): Type 
Def(Th):",
	oatkn_acct                	string       comment "Def(En): Account number
Def(Th):",
	oatkn_token_number        	string       comment "Def(En): Token number
Def(Th):",
	oatkn_assurance_lvl       	string       comment "Def(En): Token Assurance Level
Def(Th):",
	oatkn_requestor_id        	string       comment "Def(En): Token Requestor ID
Def(Th):",
	oatkn_status              	string       comment "Def(En): Token Status
Def(Th):",
	oatkn_action_date         	date         comment "Def(En): Token Action Date
Def(Th):",
	oatkn_date_change         	date         comment "Def(En): The Last Date Change
Def(Th):",
	oatkn_time_change         	string       comment "Def(En): The Last Time Change
Def(Th):",
	oatkn_acct_exp_date       	string       comment "Def(En): Card expiry date
Def(Th):",
	oatkn_visa_token_type     	string       comment "Def(En): Visa Token Type
Def(Th):",
	oatkn_visa_device_id      	string       comment "Def(En): Visa Device ID
Def(Th):",
	oatkn_visa_device_nbr     	string       comment "Def(En): Visa Device Number
Def(Th):",
	oatkn_visa_device_loc     	string       comment "Def(En): Visa Device Locate
Def(Th):",
	oatkn_visa_wallet_acct_id 	string       comment "Def(En): Visa Wallet Account ID
Def(Th):",
	oatkn_visa_wallet_email   	string       comment "Def(En): Visa Wallet Email Account
Def(Th):",
	oatkn_visa_wallet_rsn_code	string       comment "Def(En): Visa Wallet Reason Code
Def(Th):",
	filler                    	string       comment "Def(En):
Def(Th):",
	oatkn_pymt_acct_ref       	string       comment "Def(En): Payment Account Reference Data
Def(Th):",
	load_tms                  	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_la10s_oatkn' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);