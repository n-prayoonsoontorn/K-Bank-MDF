-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_cardlink_lb1dh002_lbcrd.sql
# Area: cardlink
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CARDLINK.CARDLINK_LB1DH002_LBCRD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_cardlink.cardlink_lb1dh002_lbcrd (
	pos_dt                    	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dh002_cp_org_nbr          	smallint     comment "Def(En): Account org
Def(Th):",
	dh002_cp_type             	smallint     comment "Def(En): Account type
Def(Th):",
	dh002_cp_card_nbr         	bigint       comment "Def(En): Card no.
Def(Th):",
	dh002_cp_program_id       	smallint     comment "Def(En): Program id  
Def(Th):",
	dh002_cp_status           	string       comment "Def(En): Cardholder program status
Def(Th):",
	dh002_cp_waive_fee_ind    	string       comment "Def(En): wave annual fee indicator
Def(Th):",
	dh002_cp_nxt_fee_dte      	date         comment "Def(En): next annual fee date
Def(Th):",
	dh002_cp_dte_joined       	date         comment "Def(En): joing date of this program
Def(Th):",
	dh002_cp_dte_close        	string       comment "Def(En): close date of this program
Def(Th):",
	dh002_cp_accum_shr_opt    	smallint     comment "Def(En): accumulate share option
Def(Th):",
	dh002_cp_red_shr_opt      	smallint     comment "Def(En): redemption  share option
Def(Th):",
	dh002_cp_accum_start_dte  	date         comment "Def(En): date for start accumulate
Def(Th):",
	dh002_cp_yest_cur_bal     	decimal(11,2) comment "Def(En): current point of last batch
Def(Th):",
	dh002_cp_yest_av1         	decimal(11,2) comment "Def(En): AV1 point of last batch
Def(Th):",
	dh002_cp_yest_av2         	decimal(11,2) comment "Def(En): AV2 point of last batch
Def(Th):",
	dh002_cp_pas_accum_1      	decimal(11,2) comment "Def(En): accumulate point (CTD)
Def(Th):",
	dh002_cp_pas_cr_adj_1     	decimal(11,2) comment "Def(En): credit adjust point (CTD)
Def(Th):",
	dh002_cp_pas_dr_adj_1     	decimal(11,2) comment "Def(En): debit adjust point (CTD)
Def(Th):",
	dh002_cp_pas_cur_bal_1    	decimal(11,2) comment "Def(En): current balance point (CTD)
Def(Th):",
	dh002_cp_pas_net_sales_1  	decimal(11,2) comment "Def(En): net sale amount (CTD)
Def(Th):",
	dh002_cp_pas_accum_2      	decimal(11,2) comment "Def(En): accumulate point (last 1 month)
Def(Th):",
	dh002_cp_pas_cr_adj_2     	decimal(11,2) comment "Def(En): credit adjust point (last 1 month)
Def(Th):",
	dh002_cp_pas_dr_adj_2     	decimal(11,2) comment "Def(En): debit adjust point (last 1 month)
Def(Th):",
	dh002_cp_pas_cur_bal_2    	decimal(11,2) comment "Def(En): current balance point (last 1 month)
Def(Th):",
	dh002_cp_pas_net_sales_2  	decimal(11,2) comment "Def(En): net sale amount (last 1 month)
Def(Th):",
	dh002_cp_ra_red_cur_1     	decimal(11,2) comment "Def(En): point redeem from current bucket (CTD)
Def(Th):",
	dh002_cp_ra_red_av1_1     	decimal(11,2) comment "Def(En): point redeem from AV1 bucket (CTD)
Def(Th):",
	dh002_cp_ra_red_av2_1     	decimal(11,2) comment "Def(En): point redeem from AV2 bucket (CTD)
Def(Th):",
	dh002_cp_ra_red_cur_2     	decimal(11,2) comment "Def(En): point redeem from current bucket (last 1 month)
Def(Th):",
	dh002_cp_ra_red_av1_2     	decimal(11,2) comment "Def(En): point redeem from AV1 bucket (last 1 month)
Def(Th):",
	dh002_cp_ra_red_av2_2     	decimal(11,2) comment "Def(En): point redeem from AV2 bucket (last 1 month)
Def(Th):",
	dh002_cp_av1              	decimal(11,2) comment "Def(En): point expire in AV1
Def(Th):",
	dh002_cp_av1_exp_dte      	date         comment "Def(En): date of point expire in AV1
Def(Th):",
	dh002_cp_av2              	decimal(11,2) comment "Def(En): point expire in AV2
Def(Th):",
	dh002_cp_av2_exp_dte      	date         comment "Def(En): date of point expire in AV2
Def(Th):",
	dh002_cp_last_seq_no      	integer      comment "Def(En): last sequence number of transaction
Def(Th):",
	dh002_cp_lst_end_accum_dte	date         comment "Def(En): laste accumulate date
Def(Th):",
	dh002_cp_atd_net_sales    	decimal(11,2) comment "Def(En): the accum period sale volumn
Def(Th):",
	dh002_cp_lst_trxn_dte     	date         comment "Def(En): last transaction date
Def(Th):",
	dh002_cp_lst_maint_dte    	date         comment "Def(En): last maintenace date
Def(Th):",
	dh002_cp_xfr_prev_bal     	decimal(11,2) comment "Def(En): previos balace  transfer(point transfer from old card)
Def(Th):",
	dh002_cp_prev_bal         	decimal(11,2) comment "Def(En): previos balance point
Def(Th):",
	dh002_cp_cbal_exp_dte     	date         comment "Def(En): current balance expire  date (End of this cycle)
Def(Th):",
	dh002_cp_cycle_date       	date         comment "Def(En): Cycle date (end of this cycle)
Def(Th):",
	dh002_cp_kiv_points       	decimal(11,2) comment "Def(En): KBANK keep in view point ( This point not post to current point balance until cycle due equal 0)
Def(Th):",
	dh002_cp_fifo_bucket_1    	decimal(11,2) comment "Def(En): FIFO bucket point  1st month 
Def(Th):",
	dh002_cp_fifo_bucket_2    	decimal(11,2) comment "Def(En): FIFO bucket point  2nd month 
Def(Th):",
	dh002_cp_fifo_bucket_3    	decimal(11,2) comment "Def(En): FIFO bucket point  3rd month 
Def(Th):",
	dh002_cp_fifo_bucket_4    	decimal(11,2) comment "Def(En): FIFO bucket point  4th month 
Def(Th):",
	dh002_cp_fifo_bucket_5    	decimal(11,2) comment "Def(En): FIFO bucket point  5th month 
Def(Th):",
	dh002_cp_fifo_bucket_6    	decimal(11,2) comment "Def(En): FIFO bucket point  6th month 
Def(Th):",
	dh002_cp_fifo_bucket_7    	decimal(11,2) comment "Def(En): FIFO bucket point  7th month 
Def(Th):",
	dh002_cp_fifo_bucket_8    	decimal(11,2) comment "Def(En): FIFO bucket point  8th month 
Def(Th):",
	dh002_cp_fifo_bucket_9    	decimal(11,2) comment "Def(En): FIFO bucket point  9th month 
Def(Th):",
	dh002_cp_fifo_bucket_10   	decimal(11,2) comment "Def(En): FIFO bucket point  10th month 
Def(Th):",
	dh002_cp_fifo_bucket_11   	decimal(11,2) comment "Def(En): FIFO bucket point  11th month 
Def(Th):",
	dh002_cp_fifo_bucket_12   	decimal(11,2) comment "Def(En): FIFO bucket point  12th month 
Def(Th):",
	dh002_cp_fifo_bucket_13   	decimal(11,2) comment "Def(En): FIFO bucket point  13th month 
Def(Th):",
	dh002_cp_fifo_bucket_14   	decimal(11,2) comment "Def(En): FIFO bucket point  14th month 
Def(Th):",
	dh002_cp_fifo_bucket_15   	decimal(11,2) comment "Def(En): FIFO bucket point  15th month 
Def(Th):",
	dh002_cp_fifo_bucket_16   	decimal(11,2) comment "Def(En): FIFO bucket point  16th month 
Def(Th):",
	dh002_cp_fifo_bucket_17   	decimal(11,2) comment "Def(En): FIFO bucket point  17th month 
Def(Th):",
	dh002_cp_fifo_bucket_18   	decimal(11,2) comment "Def(En): FIFO bucket point  18th month 
Def(Th):",
	dh002_cp_fifo_bucket_19   	decimal(11,2) comment "Def(En): FIFO bucket point  19th month 
Def(Th):",
	dh002_cp_fifo_bucket_20   	decimal(11,2) comment "Def(En): FIFO bucket point  20th month 
Def(Th):",
	dh002_cp_fifo_bucket_21   	decimal(11,2) comment "Def(En): FIFO bucket point  21st month 
Def(Th):",
	dh002_cp_fifo_bucket_22   	decimal(11,2) comment "Def(En): FIFO bucket point  22nd month 
Def(Th):",
	dh002_cp_fifo_bucket_23   	decimal(11,2) comment "Def(En): FIFO bucket point  23rd month 
Def(Th):",
	dh002_cp_fifo_bucket_24   	decimal(11,2) comment "Def(En): FIFO bucket point  24th month 
Def(Th):",
	dh002_cp_fifo_bucket_25   	decimal(11,2) comment "Def(En): FIFO bucket point  25th month 
Def(Th):",
	dh002_cp_fifo_bucket_26   	decimal(11,2) comment "Def(En): FIFO bucket point  26th month 
Def(Th):",
	dh002_cp_fifo_bucket_27   	decimal(11,2) comment "Def(En): FIFO bucket point  27th month 
Def(Th):",
	dh002_cp_fifo_bucket_28   	decimal(11,2) comment "Def(En): FIFO bucket point  28th month 
Def(Th):",
	dh002_cp_fifo_bucket_29   	decimal(11,2) comment "Def(En): FIFO bucket point  29th month 
Def(Th):",
	dh002_cp_fifo_bucket_30   	decimal(11,2) comment "Def(En): FIFO bucket point  30th month 
Def(Th):",
	dh002_cp_fifo_bucket_31   	decimal(11,2) comment "Def(En): FIFO bucket point  31st month 
Def(Th):",
	dh002_cp_fifo_bucket_32   	decimal(11,2) comment "Def(En): FIFO bucket point  32nd month 
Def(Th):",
	dh002_cp_fifo_bucket_33   	decimal(11,2) comment "Def(En): FIFO bucket point  33th month 
Def(Th):",
	dh002_cp_fifo_bucket_34   	decimal(11,2) comment "Def(En): FIFO bucket point  34th month 
Def(Th):",
	dh002_cp_fifo_bucket_35   	decimal(11,2) comment "Def(En): FIFO bucket point  35th month 
Def(Th):",
	dh002_cp_fifo_bucket_36   	decimal(11,2) comment "Def(En): FIFO bucket point  36th month 
Def(Th):",
	dh002_cp_fifo_bucket_37   	decimal(11,2) comment "Def(En): FIFO bucket point  37th month 
Def(Th):",
	dh002_cp_fifo_bucket_38   	decimal(11,2) comment "Def(En): FIFO bucket point  38th month 
Def(Th):",
	dh002_cp_fifo_bucket_39   	decimal(11,2) comment "Def(En): FIFO bucket point  39th month 
Def(Th):",
	dh002_cp_fifo_bucket_40   	decimal(11,2) comment "Def(En): FIFO bucket point  40th month 
Def(Th):",
	dh002_cp_fifo_bucket_41   	decimal(11,2) comment "Def(En): FIFO bucket point  41st month 
Def(Th):",
	dh002_cp_fifo_bucket_42   	decimal(11,2) comment "Def(En): FIFO bucket point  42nd month 
Def(Th):",
	dh002_cp_fifo_bucket_43   	decimal(11,2) comment "Def(En): FIFO bucket point  43th month 
Def(Th):",
	dh002_cp_fifo_bucket_44   	decimal(11,2) comment "Def(En): FIFO bucket point  44th month 
Def(Th):",
	dh002_cp_fifo_bucket_45   	decimal(11,2) comment "Def(En): FIFO bucket point  45th month 
Def(Th):",
	dh002_cp_fifo_bucket_46   	decimal(11,2) comment "Def(En): FIFO bucket point  46th month 
Def(Th):",
	dh002_cp_fifo_bucket_47   	decimal(11,2) comment "Def(En): FIFO bucket point  47th month 
Def(Th):",
	dh002_cp_fifo_bucket_48   	decimal(11,2) comment "Def(En): FIFO bucket point  48th month 
Def(Th):",
	dh002_cp_cycle_month_1    	smallint     comment "Def(En): FIFO bucket 1st  month
Def(Th):",
	dh002_cp_cycle_month_2    	smallint     comment "Def(En): FIFO bucket 2nd  month
Def(Th):",
	dh002_cp_cycle_month_3    	smallint     comment "Def(En): FIFO bucket 3rd  month
Def(Th):",
	dh002_cp_cycle_month_4    	smallint     comment "Def(En): FIFO bucket 4th  month
Def(Th):",
	dh002_cp_cycle_month_5    	smallint     comment "Def(En): FIFO bucket 5th  month
Def(Th):",
	dh002_cp_cycle_month_6    	smallint     comment "Def(En): FIFO bucket  6th  month
Def(Th):",
	dh002_cp_cycle_month_7    	smallint     comment "Def(En): FIFO bucket 7th  month
Def(Th):",
	dh002_cp_cycle_month_8    	smallint     comment "Def(En): FIFO bucket  8th  month
Def(Th):",
	dh002_cp_cycle_month_9    	smallint     comment "Def(En): FIFO bucket  9th  month
Def(Th):",
	dh002_cp_cycle_month_10   	smallint     comment "Def(En): FIFO bucket 10th  month
Def(Th):",
	dh002_cp_cycle_month_11   	smallint     comment "Def(En): FIFO bucket 11th  month
Def(Th):",
	dh002_cp_cycle_month_12   	smallint     comment "Def(En): FIFO bucket 12th  month
Def(Th):",
	dh002_cp_cycle_month_13   	smallint     comment "Def(En): FIFO bucket 13th  month
Def(Th):",
	dh002_cp_cycle_month_14   	smallint     comment "Def(En): FIFO bucket  14th  month
Def(Th):",
	dh002_cp_cycle_month_15   	smallint     comment "Def(En): FIFO bucket 15th  month
Def(Th):",
	dh002_cp_cycle_month_16   	smallint     comment "Def(En): FIFO bucket 16th  month
Def(Th):",
	dh002_cp_cycle_month_17   	smallint     comment "Def(En): FIFO bucket  17th  month
Def(Th):",
	dh002_cp_cycle_month_18   	smallint     comment "Def(En): FIFO bucket  18th  month
Def(Th):",
	dh002_cp_cycle_month_19   	smallint     comment "Def(En): FIFO bucket  19th  month
Def(Th):",
	dh002_cp_cycle_month_20   	smallint     comment "Def(En): FIFO bucket  20th  month
Def(Th):",
	dh002_cp_cycle_month_21   	smallint     comment "Def(En): FIFO bucket  21st  month
Def(Th):",
	dh002_cp_cycle_month_22   	smallint     comment "Def(En): FIFO bucket  22nd  month
Def(Th):",
	dh002_cp_cycle_month_23   	smallint     comment "Def(En): FIFO bucket  23rd  month
Def(Th):",
	dh002_cp_cycle_month_24   	smallint     comment "Def(En): FIFO bucket  24th  month
Def(Th):",
	dh002_cp_cycle_month_25   	smallint     comment "Def(En): FIFO bucket  25th  month
Def(Th):",
	dh002_cp_cycle_month_26   	smallint     comment "Def(En): FIFO bucket  26th  month
Def(Th):",
	dh002_cp_cycle_month_27   	smallint     comment "Def(En): FIFO bucket  27th  month
Def(Th):",
	dh002_cp_cycle_month_28   	smallint     comment "Def(En): FIFO bucket  28th  month
Def(Th):",
	dh002_cp_cycle_month_29   	smallint     comment "Def(En): FIFO bucket  29th  month
Def(Th):",
	dh002_cp_cycle_month_30   	smallint     comment "Def(En): FIFO bucket  30th  month
Def(Th):",
	dh002_cp_cycle_month_31   	smallint     comment "Def(En): FIFO bucket  31st  month
Def(Th):",
	dh002_cp_cycle_month_32   	smallint     comment "Def(En): FIFO bucket  32nd  month
Def(Th):",
	dh002_cp_cycle_month_33   	smallint     comment "Def(En): FIFO bucket  33rd  month
Def(Th):",
	dh002_cp_cycle_month_34   	smallint     comment "Def(En): FIFO bucket  34th  month
Def(Th):",
	dh002_cp_cycle_month_35   	smallint     comment "Def(En): FIFO bucket  35th  month
Def(Th):",
	dh002_cp_cycle_month_36   	smallint     comment "Def(En): FIFO bucket  36th  month
Def(Th):",
	dh002_cp_cycle_month_37   	smallint     comment "Def(En): FIFO bucket  37th  month
Def(Th):",
	dh002_cp_cycle_month_38   	smallint     comment "Def(En): FIFO bucket  38th  month
Def(Th):",
	dh002_cp_cycle_month_39   	smallint     comment "Def(En): FIFO bucket  39th  month
Def(Th):",
	dh002_cp_cycle_month_40   	smallint     comment "Def(En): FIFO bucket  40th  month
Def(Th):",
	dh002_cp_cycle_month_41   	smallint     comment "Def(En): FIFO bucket  41st  month
Def(Th):",
	dh002_cp_cycle_month_42   	smallint     comment "Def(En): FIFO bucket  42nd  month
Def(Th):",
	dh002_cp_cycle_month_43   	smallint     comment "Def(En): FIFO bucket  43rd  month
Def(Th):",
	dh002_cp_cycle_month_44   	smallint     comment "Def(En): FIFO bucket  44th  month
Def(Th):",
	dh002_cp_cycle_month_45   	smallint     comment "Def(En): FIFO bucket  45th  month
Def(Th):",
	dh002_cp_cycle_month_46   	smallint     comment "Def(En): FIFO bucket  46th  month
Def(Th):",
	dh002_cp_cycle_month_47   	smallint     comment "Def(En): FIFO bucket  47th  month
Def(Th):",
	dh002_cp_cycle_month_48   	smallint     comment "Def(En): FIFO bucket  48th  month
Def(Th):",
	dh002_cm_customer_nmbr    	bigint       comment "Def(En): Customer no.
Def(Th):",
	filler                    	string       comment "Def(En): Space
Def(Th):",
	load_tms                  	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                  	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                    	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                    	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_cardlink/cardlink_lb1dh002_lbcrd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);