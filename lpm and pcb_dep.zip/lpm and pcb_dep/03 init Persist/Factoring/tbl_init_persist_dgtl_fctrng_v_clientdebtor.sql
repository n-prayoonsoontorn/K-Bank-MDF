-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_dgtl_fctrng_v_clientdebtor.sql
# Area: dgtl_fctrng
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_DGTL_FCTRNG.DGTL_FCTRNG_V_CLIENTDEBTOR
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_dgtl_fctrng.dgtl_fctrng_v_clientdebtor (
	pos_dt            	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	clientcode        	string       comment "Def(En): Limit Number
Def(Th):",
	debtorcode        	string       comment "Def(En): Customer Factor ID
Def(Th):",
	clientkbankid     	string       comment "Def(En):
Def(Th):",
	debtorkbankid     	string       comment "Def(En): Customer CIS Number
Def(Th):",
	crterm            	bigint       comment "Def(En): Credit Term
Def(Th):",
	limited           	decimal(18,2) comment "Def(En): Sub Limit
Def(Th):",
	advratio          	decimal(18,2) comment "Def(En): %I/P
Def(Th):",
	totamt            	decimal(18,2) comment "Def(En): Total A/R
Def(Th):",
	holdlimit         	decimal(18,2) comment "Def(En):
Def(Th): จำนวนเงินที่ถูกระงับวงเงินชั่วคราว (Hold Limit)",
	facfeetype        	string       comment "Def(En):
Def(Th): ประเภท Fac Fee
1=Reserved
2=% By AR
3=Fix ตามลูกหนี้
4=Fix ตามจำนวนใบแจ้งหนี้",
	facfee            	decimal(20,5) comment "Def(En):
Def(Th): ค่า Fac Fee
% Fee for FacFeeType=2
Amt Fee for FacFeeType=3 & 4",
	colltype          	string       comment "Def(En):
Def(Th): Collection Type ประเภทการเก็บเงิน
for Fund Product
1=Reserved
2=Transfer 
3=Cheque 
4=Posted Date Cheque 
5=Inter-Office Account 
for Unfund Product =  (ไม่ระบุ)",
	collcontact       	string       comment "Def(En):
Def(Th): ชื่อผู้ติดต่อ : Collection",
	collphone         	string       comment "Def(En):
Def(Th): โทรศัพท์ผู้ติดต่อ : Collection",
	colldetail        	string       comment "Def(En):
Def(Th): รายละเอียดผู้ติดต่อ : Collection",
	colladdr1         	string       comment "Def(En): Collection Address1
Def(Th):",
	colladdr2         	string       comment "Def(En): Collection Address2
Def(Th):",
	collremarks       	string       comment "Def(En): Collection Remarks
Def(Th):",
	purdoc            	string       comment "Def(En):
Def(Th): เงื่อนไขการรับซื้อ",
	notifytype        	string       comment "Def(En):
Def(Th): ประเภทหนังสือโอนสิทธิ
001 = Notify Form 1
002 = Notify Form 2
003 = Notify Form 3
004 = Notify Form 4",
	baseintdays       	string       comment "Def(En):
Def(Th): ฐานปีการคิดดอกเบี้ย
1=360
2=365
3=366
9=actual",
	notifycondcode    	string       comment "Def(En):
Def(Th): เงื่อนไขการ Notify
N=Notify 
NN=Non-Notify 
S=Silent",
	zoneid            	string       comment "Def(En):
Def(Th): รหัสโซน
refer to Zone.ZoneId",
	buyerprob         	string       comment "Def(En):
Def(Th): Buyer Problem Flag ของคู๋ค้า",
	buyerprobdes      	string       comment "Def(En):
Def(Th): คำอธิบาย BuyerProb",
	limitstatus       	integer      comment "Def(En):
Def(Th): สถานะของคู้ค้า
1- Active, 0 - Inactive",
	lockstatus        	integer      comment "Def(En):
Def(Th): Flag เพื่อบอกการแก้ไข
0 - Not Lock,1 - Lock",
	documentterm      	bigint       comment "Def(En):
Def(Th): Document Term (ใช้เป็นข้อมูลในการยืน claim ประกัน)",
	commissionrate    	decimal(18,5) comment "Def(En):
Def(Th): Commission Rate (ใช้เป็นข้อมูลคำนวณเพื่อออกรายงานเท่านั้น)",
	createby          	string       comment "Def(En):
Def(Th):",
	createdate        	string       comment "Def(En):
Def(Th):",
	createtime        	string       comment "Def(En):
Def(Th):",
	facfeecondition   	string       comment "Def(En):
Def(Th):",
	specialreqcustomer	string       comment "Def(En):
Def(Th):",
	updateby          	string       comment "Def(En):
Def(Th):",
	updatedate        	string       comment "Def(En):
Def(Th):",
	updatetime        	string       comment "Def(En):
Def(Th):",
	load_tms          	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id        	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy          	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm            	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd            	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_dgtl_fctrng/dgtl_fctrng_v_clientdebtor' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);