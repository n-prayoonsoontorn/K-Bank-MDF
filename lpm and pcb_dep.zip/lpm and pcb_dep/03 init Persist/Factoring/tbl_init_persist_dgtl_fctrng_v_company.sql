-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_dgtl_fctrng_v_company.sql
# Area: dgtl_fctrng
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_DGTL_FCTRNG.DGTL_FCTRNG_V_COMPANY
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_dgtl_fctrng.dgtl_fctrng_v_company (
	pos_dt           	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	compcode         	string       comment "Def(En): Limit Number
Def(Th):",
	cisno            	string       comment "Def(En): Factor ID
Def(Th):",
	insurercode      	string       comment "Def(En): Insurer Code (Correspondence ID)
refer to Insurer.CisNo
Def(Th):",
	clientkbankid    	string       comment "Def(En):  Client CIS Number
Def(Th):",
	custtype         	string       comment "Def(Th): ประเภทลูกค้า เช่น นิติบุคคล, บุคคบธรรมดา
from Cis.CisCustType
Def(Th):",
	sellerno         	string       comment "Def(En): Seller Number
Def(Th):",
	sellername       	string       comment "Def(En): Seller Name
Def(Th):",
	selleraddr       	string       comment "Def(En): Seller Address
Def(Th):",
	limitstatus      	integer      comment "Def(En): สถานะของวงเงิน
1-New, 2- Open, 3 - Close
Def(Th):",
	productcode      	string       comment "Def(En): Product Code
Def(Th):",
	riskrate         	string       comment "Def(En):
Def(Th):",
	riskratebot      	string       comment "Def(En):
Def(Th):",
	comptype         	string       comment "Def(En):
Def(Th):",
	limittype        	string       comment "Def(En): Limit Type
Def(Th):
1 = ทบทวน
2 = ชั่วคราว
3 = เฉพาะราย",
	bcode            	string       comment "Def(En): Business Code
refer to BType.Bcode
Def(Th):",
	clientlimit      	decimal(18,2) comment "Def(En):
Def(Th):",
	advratio         	decimal(18,2) comment "Def(En): %IP
Def(Th):",
	limitused        	decimal(18,2) comment "Def(En):
Def(Th): Limit ที่ใช้ไป",
	totamt           	decimal(18,2) comment "Def(En): Outstandin AR
Def(Th):",
	advamt           	decimal(18,2) comment "Def(En):
Def(Th):",
	fiu              	decimal(18,2) comment "Def(En): Outstanding IP
Def(Th):",
	currency         	string       comment "Def(En):
Def(Th): สกุลเงิน",
	facfeetype       	string       comment "Def(En):
Def(Th): ประเภท Fac Fee
1=Reserved
2=% By AR
3=Fix ตามลูกหนี้
4=Fix ตามจำนวนใบแจ้งหนี้",
	facfee           	decimal(18,5) comment "Def(En):
Def(Th): ค่า Fac Fee
% Fee for FacFeeType=2 
(Type = numeric 7,5)
Amt Fee for FacFeeType=3 & 4 
(Type = numeric 17,2)",
	guaranteetype    	string       comment "Def(En):
Def(Th): ประเภท Guarantee
1=None
2=% of AR (at disburse)
3=Reserved
4=% of Refund (A/R at collection)",
	guaranteededuct  	decimal(18,5) comment "Def(En): Deduction Value (%)
Def(Th):",
	guaranteeamt     	decimal(18,2) comment "Def(En): Guarantee Target
Def(Th):",
	guaranteepaid    	decimal(18,2) comment "Def(En): Guarantee Balance
Def(Th):",
	discounttype     	string       comment "Def(En):
Def(Th): วิธีการคิดดอกเบี้ย
1=Monthly
2=Discount Normal
3=Discount Present Value
4=Maturity",
	inttype          	string       comment "Def(En): Interest Cal Type
Def(Th): Fix หรือ Float",
	defaultintrate   	decimal(9,5) comment "Def(En): Default Rate
Def(Th):",
	pastdue          	integer      comment "Def(En): Grace for Collection
Def(Th):",
	daysdefault      	integer      comment "Def(En): Grace for Default Rate
Def(Th):",
	whtbybank        	string       comment "Def(En):
Def(Th): ให้ธนาคารนำส่ง WHT
Y=Yes
N=No",
	feewhtrate       	decimal(18,2) comment "Def(En):
Def(Th): % Fee WHT Rate
1 (รัฐบาล รัฐวิสาหกิจ)
3 (นิติบุคคล)",
	residence        	string       comment "Def(En):
Def(Th): เป็น Residence
from Cis.Residence
Y=Resident
N=Non-Resident",
	baseintdays      	string       comment "Def(En):
Def(Th):",
	doctype          	string       comment "Def(En):
Def(Th):",
	businessdesc     	string       comment "Def(En):
Def(Th): รายละเอียดประเภทกิจการ",
	policyholder     	string       comment "Def(En): Policy Holder
1 = Client Hold
2 = Bank Hold
Def(Th):",
	percentcoverage  	decimal(18,2) comment "Def(En): %Coverage
Def(Th):",
	policyno         	string       comment "Def(En): Policy Number
Def(Th):",
	insuranceexpire  	date         comment "Def(En): Insurance Expire Date
Def(Th):",
	maxtransferperiod	integer      comment "Def(En): Max Transfer Period
Def(Th):",
	contractsigndate 	date         comment "Def(En):
Def(Th): วันเซ็นสัญญา",
	contractlimit    	decimal(18,2) comment "Def(En):
Def(Th): วงเงินเซ็นสัญญา",
	regact           	string       comment "Def(En):
Def(Th): พรบ.จดทะเบียน ระบุค่า
1 = AR แบบไม่เจาะจง
2 = AR แบบเจาะจงลูกหนี้
3 = AR แบบเจาะจงสัญญา
4 = AR แบบราย Invoice
5 =ไม่จด AR",
	claimperiod      	string       comment "Def(En): Claim Period
Def(Th):",
	program          	string       comment "Def(En): Program ID
refer to ProductProgram.ProgramCode
Def(Th):",
	guaranteepercent 	decimal(18,2) comment "Def(En): %Guarantee to Client
Def(Th):",
	feeremarks       	string       comment "Def(En):
Def(Th): เงื่อนไขการเก็บ Other Charge",
	mainlimit        	string       comment "Def(En):
Def(Th): Flag เพื่อระบุว่าเป็น limit หลัก กรณี GroupLimit หรือไม่",
	status           	string       comment "Def(En):
Def(Th): สถานะตาม Workflow",
	committedtype    	integer      comment "Def(En): Committed Type
1=Uncommitted
2=Committed
Def(Th):",
	commissionrate   	decimal(18,5) comment "Def(En):
Def(Th): Commission Rate (ใช้เป็นข้อมูลคำนวณเพื่อออกรายงานเท่านั้น)",
	approveby        	string       comment "Def(En): Limit Approver User ID
Def(Th):",
	approvedate      	date         comment "Def(En): Limit Approve Date
Def(Th):",
	approvetime      	string       comment "Def(En): Limit Approve Time
Def(Th):",
	createby         	string       comment "Def(En):
Def(Th):",
	createdate       	date         comment "Def(En):
Def(Th):",
	createtime       	string       comment "Def(En):
Def(Th):",
	updateby         	string       comment "Def(En):
Def(Th):",
	updatedate       	date         comment "Def(En):
Def(Th):",
	updatetime       	string       comment "Def(En):
Def(Th):",
	spreadlatecharge 	decimal(9,5) comment "Def(En):
Def(Th):",
	load_tms         	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id       	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy         	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm           	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd           	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_dgtl_fctrng/dgtl_fctrng_v_company' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);