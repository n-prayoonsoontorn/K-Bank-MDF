-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_hrcrc_vc_rc_cd.sql
# Area: hrcrc
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_HRCRC.HRCRC_VC_RC_CD
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_hrcrc.hrcrc_vc_rc_cd (
	pos_dt                 	date            comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	rc_cd                  	integer         comment "Def(En):New Center Code of OGL
Def(Th):หมายเลขหน่วยงาน",
	eff_dt                 	timestamp       comment "Def(En):Center Open Date/Effective Date
Def(Th):วันที่เริ่มต้น/วันที่เปิดหน่วยงาน",
	rc_tp_cd               	string          comment "Def(En):The Code to identify Type of Responsibility Center
Def(Th):รหัสประเภทของหน่วยงาน",
	rc_tp_nm               	string          comment "Def(En):Responsibility Center Type name
Def(Th):ประเภทของหน่วยงาน",
	kbnk_br_no             	string          comment "Def(En):The code to identify the branch of KBANK
Def(Th):รหัสหมายเลขสาขาของ KBANK",
	fcn_cd                 	smallint        comment "Def(En):The Code to identify Function of Center code
Def(Th):รหัสระบุประเภทหน้าที่งานของหน่วยงาน",
	fcn_nm                 	string          comment "Def(En):Function of Center code name
Def(Th):ประเภทหน้าที่งานของหน่วยงาน",
	cntr_tp_cd             	string          comment "Def(En):Type of Center Code
Def(Th):รหัสประเภทของ Center",
	cntr_tp_nm             	string          comment "Def(En):Center Code type name
Def(Th):ประเภทของ Center",
	cntr_lvl_cd            	smallint        comment "Def(En):The Code to identify Level of Center code
Def(Th):รหัสระบุประเภทของลำดับของหน่วยงาน",
	cntr_lvl_nm            	string          comment "Def(En):Level of Center code name
Def(Th):ประเภทของลำดับของหน่วยงาน",
	co_tp_cd               	string          comment "Def(En):The code to identify Type of Company
Def(Th):รหัสประเภทของกลุ่มบริษัท",
	co_tp_nm               	string          comment "Def(En):Company Type name
Def(Th):ประเภทของกลุ่มบริษัท",
	kbnk_area_tp_cd        	smallint        comment "Def(En):The code to identify the Area
Def(Th):รหัสพื้นที่",
	kbnk_area_tp_nm        	string          comment "Def(En):Kbank Area Type name
Def(Th):ชื่อพื้นที่",
	kbnk_area_rc_no        	integer         comment "Def(En):Kbank area resposibility number 
Def(Th):รหัสพื้นที่ของหน่วยงาน Kbank",
	zon_tp_cd              	smallint        comment "Def(En):The code to identify Clearing Zone
Def(Th):รหัสเขต",
	zon_tp_nm              	string          comment "Def(En):Clearing Zone name
Def(Th):ชื่อเขต",
	rgon_tp_cd             	smallint        comment "Def(En):The code to identify the Region
Def(Th):รหัสภาคในประเทศไทย",
	rgon_tp_nm             	string          comment "Def(En):Region name
Def(Th):ชื่อภาค",
	sub_urban_tp_cd        	smallint        comment "Def(En):Sub Urban Type Code
Def(Th):รหัสเขต/เมือง",
	sub_urban_tp_nm        	string          comment "Def(En):Sub Urban Type name
Def(Th):เขต/เมือง",
	en_cntr_nm             	string          comment "Def(En):Center Name in English
Def(Th):ชื่อหน่วยงานภาษาอังกฤษ",
	en_cntr_nm_abr         	string          comment "Def(En):Center Abbreviation Name in English
Def(Th):ชื่อย่อหน่วยงานภาษาอังกฤษ",
	th_cntr_nm             	string          comment "Def(En):Center Name in Thai
Def(Th):ชื่อหน่วยงานภาษาไทย",
	th_cntr_nm_abr         	string          comment "Def(En):Center Abbreviation Name in Thai
Def(Th):ชื่อย่อหน่วยงานภาษาไทย",
	cntr_abr_rpt           	string          comment "Def(En):Center short name for reporting in FICS
Def(Th):",
	en_hs_no               	string          comment "Def(En):House number in English
Def(Th):บ้านเลขที่ภาษาอังกฤษ",
	en_vill_no             	string          comment "Def(En):Village number in English
Def(Th):หมู่ที่ภาษาอังกฤษ",
	en_bld_nm              	string          comment "Def(En):Building Name in English
Def(Th):ชื่ออาคารภาษาอังกฤษ",
	en_aly                 	string          comment "Def(En):Alley Name in English
Def(Th):ชื่อซอยอังกฤษ",
	en_str_nm              	string          comment "Def(En):Street name in English
Def(Th):ชื่อถนนภาษาอังกฤษ",
	en_subdstc             	string          comment "Def(En):Sub-district in English
Def(Th):แขวง/ตำบลภาษาอังกฤษ",
	en_dstc                	string          comment "Def(En):District in English
Def(Th):เขต/อำเภอภาษาอังกฤษ",
	en_prov                	string          comment "Def(En):Province in English
Def(Th):จังหวัดภาษาอังกฤษ",
	en_cty_cd              	string          comment "Def(En):Country code in English
Def(Th):รหัสประเทศภาษาอังกฤษ",
	en_shrt_adr            	string          comment "Def(En):Short Address in English
Def(Th):ที่อยู่แบบย่อภาษาอังกฤษ",
	th_hs_no               	string          comment "Def(En):House number in Thai
Def(Th):บ้านเลขที่ภาษาไทย",
	th_vill_no             	string          comment "Def(En):Village number in Thai
Def(Th):หมู่ที่ภาษาไทย",
	th_bld_nm              	string          comment "Def(En):Building Name in Thai
Def(Th):ชื่ออาคารภาษาไทย",
	th_aly                 	string          comment "Def(En):Alley Name in Thai
Def(Th):ชื่อซอยภาษาไทย",
	th_str_nm              	string          comment "Def(En):Street name in Thai
Def(Th):ชื่อถนนภาษาไทย",
	th_subdstc             	string          comment "Def(En):Sub-district in Thai
Def(Th):แขวง/ตำบลภาษาไทย",
	th_dstc                	string          comment "Def(En):District in Thai
Def(Th):เขต/อำเภอภาษาไทย",
	th_prov                	string          comment "Def(En):Province in Thai
Def(Th):จังหวัดภาษาไทย",
	pstcd_area_cd          	integer         comment "Def(En):Postcode area code
Def(Th):รหัสไปรษณีย์",
	th_shrt_adr            	string          comment "Def(En):Short Address in Thai
Def(Th):ที่อยู่แบบย่อภาษาไทย",
	div_cntr_cd            	integer         comment "Def(En):Level 1- Center Code of HR Line Business (Division)
Def(Th):รหัสสายงาน",
	en_div_nm              	string          comment "Def(En):HR Line Business (Division) Name in English
Def(Th):ชื่อสายงานภาษาอังกฤษ",
	en_div_nm_abr          	string          comment "Def(En):HR Line Business (Division) Abbreviation Name in English
Def(Th):ชื่อย่อสายงานภาษาอังกฤษ",
	th_div_nm              	string          comment "Def(En):HR Line Business (Division) Name in Thai
Def(Th):ชื่อสายงานภาษาไทย",
	th_div_nm_abr          	string          comment "Def(En):HR Line Business (Division) Abbreviation Name in Thai
Def(Th):ชื่อย่อสายงานภาษาไทย",
	ntw_cntr_cd            	integer         comment "Def(En):Level 2- Center Code of Network
Def(Th):รหัสเครือข่าย",
	en_ntw_cntr_nm         	string          comment "Def(En):Network Center Name in English
Def(Th):ชื่อเครือข่ายภาษาอังกฤษ",
	en_ntw_cntr_nm_abr     	string          comment "Def(En):Network Center Abbreviation Name in English
Def(Th):ชื่อย่อเครือข่ายภาษาอังกฤษ",
	th_ntw_cntr_nm         	string          comment "Def(En):Network Center Name in Thai
Def(Th):ชื่อเครือข่ายภาษาไทย",
	th_ntw_cntr_nm_abr     	string          comment "Def(En):Network Center Abbreviation Name in Thai
Def(Th):ชื่อย่อเครือข่ายภาษาไทย",
	dept_id                	integer         comment "Def(En):Level 3- Center Code of Department/Region
Def(Th):รหัสสังกัดของสาขา ส่วนงาน หรือภาค (KBNK_RGON_CD)",
	en_dept_nm             	string          comment "Def(En):Department Name in English
Def(Th):ชื่อสาขาหรือส่วนงานภาษาอังกฤษ",
	en_dept_nm_abr         	string          comment "Def(En):Department Abbreviation Name in English
Def(Th):ชื่อย่อสาขาหรือส่วนงานภาษาอังกฤษ",
	th_dept_nm             	string          comment "Def(En):Department Name in Thai
Def(Th):ชื่อสาขาหรือส่วนงานภาษาไทย",
	th_dept_nm_abr         	string          comment "Def(En):Department Abbreviation Name in Thai
Def(Th):ชื่อย่อสาขาหรือส่วนงานภาษาไทย",
	unit_cntr_cd           	integer         comment "Def(En):Level 4- Center Code of Unit/Zone, Network of IN. Dept.
Def(Th):รหัสสังกัดของ Unit,Zone,Network (KBNK_ZONE_NO)",
	en_unit_cntr_nm        	string          comment "Def(En):Unit Name in English
Def(Th):ชื่อ Unit,Zone,Network ภาษาอังกฤษ",
	en_unit_cntr_nm_abr    	string          comment "Def(En):Unit Abbreviation Name in English
Def(Th):ชื่อย่อ Unit,Zone,Network ภาษาอังกฤษ",
	th_unit_cntr_nm        	string          comment "Def(En):Unit Name in Thai
Def(Th):ชื่อ Unit,Zone,Network ภาษาไทย",
	th_unit_cntr_nm_abr    	string          comment "Def(En):Unit Abbreviation Name in Thai
Def(Th):ชื่อย่อ Unit,Zone,Network ภาษาไทย",
	sub_unit_cntr_cd       	integer         comment "Def(En):Level 5- Center Code of Sub-unit.
Def(Th):รหัส Sub-Unit (กลุ่มงาน)",
	en_sub_unit_cntr_nm    	string          comment "Def(En):Sub-Unit Name in English
Def(Th):ชื่อ Sub-Unitภาษาอังกฤษ",
	en_sub_unit_cntr_nm_abr	string          comment "Def(En):Sub-Unit Abbreviation Name in English
Def(Th):ชื่อย่อ Sub-Unitภาษาอังกฤษ",
	th_sub_unit_cntr_nm    	string          comment "Def(En):Sub-Unit Name in Thai
Def(Th):ชื่อ Sub-Unit ภาษาไทย",
	th_sub_unit_cntr_nm_abr	string          comment "Def(En):Sub-Unit Abbreviation Name in Thai
Def(Th):ชื่อย่อ Sub-Unit ภาษาไทย",
	sale_team_cd           	integer         comment "Def(En):Sale Team code
Def(Th):ทีมขายที่ดูแลสาขา",
	en_sale_team_nm        	string          comment "Def(En):Sale Team name in English
Def(Th):ชื่อทีมขายภาษาอังกฤษ",
	en_sale_team_nm_abr    	string          comment "Def(En):Sale Team Abbreviation Name in English
Def(Th):ชื่อย่อทีมขายภาษาอังกฤษ",
	th_sale_team_nm        	string          comment "Def(En):Sale Team name in Thai
Def(Th):ชื่อทีมขายภาษาไทย",
	th_sale_team_nm_abr    	string          comment "Def(En):Sale Team Abbreviation Name in Thai
Def(Th):ชื่อย่อทีมขายภาษาไทย",
	kbnk_zon_no            	smallint        comment "Def(En):Kbank Zone number
Def(Th):หมายเลขรหัสระบุภาคที่ KBank ตั้งอยู่ รหัสเขตของ KBank",
	kbnk_rgon_cd           	smallint        comment "Def(En):The code to identify Region of KBank
Def(Th):เขต รหัสภาคของ KBank",
	oprn_br_no             	string          comment "Def(En):Operation Branch Number Parent Hub No. (CT Dept.)
Def(Th):รหัสตัวแทนของหน่วยงานที่บริการ  หมายเลข Hub ผู้ดูแลในมุมของฝ่าย กค.",
	kbnk_hub_no            	string          comment "Def(En):Kbank Hub Number
Def(Th):หมายเลข Hub",
	br_rgst_no             	string          comment "Def(En):Branch Registration Number
Def(Th):ทะเบียนการค้า",
	tax_zon                	string          comment "Def(En):Tax Zone
Def(Th):",
	intco                  	integer         comment "Def(En):Intra Company Number
Def(Th):หมายเลขกลุ่มบริษัท Intra Company",
	rcrd_st_cd             	string          comment "Def(En):Record Status Code
Def(Th):รหัสระบุสถานะของข้อมูล",
	fisc_cntr_cd_6         	integer         comment "Def(En):GL ENTRY SLIP FOR Head Office
Def(Th):",
	fisc_cntr_cd_10        	string          comment "Def(En):Old Center Code of FICS 10 Digit
Def(Th):",
	cnl_tp_cd              	string          comment "Def(En):The Code to identify Type of Channel 
Def(Th):รหัสระบุประเภทของช่องทาง",
	rje_f                  	smallint        comment "Def(En):RJE Flag
Def(Th):",
	lo_cd                  	string          comment "Def(En):Location code of Branch
Def(Th):รหัสพื้นที่ของสาขา",
	mgr_id                 	string          comment "Def(En):Manager ID
Def(Th):รหัสผู้อำนวยการ",
	mncp_tax               	decimal(5,2)    comment "Def(En):Tax Rate for Municipal
Def(Th):อัตราภาษีเทศบาล",
	eff_st_cd              	string          comment "Def(En):Status Effective/Not Effective
Def(Th):รหัสสถานะของหน่วยงาน",
	crt_dt                 	timestamp       comment "Def(En):Creation Date of Center Code
Def(Th):วันที่เปิดสังกัด",
	usr_udt                	string          comment "Def(En):User that updated
Def(Th):รหัสผู้ใช้ที่อัพเดตข้อมูล",
	end_dt                 	timestamp       comment "Def(En):Cancel Date of Center Code
Def(Th):วันที่ปิดสังกัด/ยกเลิกสังกัด",
	last_udt_dt            	timestamp       comment "Def(En):Last update date
Def(Th):วันที่มีการอัพเดตข้อมูลล่าสุด",
	main_br_no             	string(4)       comment "Def(En):The code to identify the (Main-Merge BR/Main-Dummy BR) branch of KBANK
Def(Th):รหัสหมายเลขสาขาแม่ (Main-Merge BR/Main-Dummy BR)  ของ KBANK",
	clrg_hub_no            	string(4)       comment "Def(En):Kbank CBO Clearing Hub Number
Def(Th):หมายเลข CBO Clearing Hub",
	clrg_hub_nm            	string(100)     comment "Def(En): CBO Clearing Hub name
Def(Th): ชื่อ CBO Clearing Hub",
	clrg_hub_strt_dt       	timestamp       comment "Def(En): CBO Clearing Hub Relationship Start Date
Def(Th):วันที่ผูกความสัมพันธ์กับ CBO Clearing Hub",
	lnd_hub_no             	string(4)       comment "Def(En): Kbank CLS Lending Hub Number
Def(Th): หมายเลข CLS Lending Hub",
	lnd_hub_nm             	string(100)     comment "Def(En): CLS Lending Hub name
Def(Th): ชื่อ CLS Lending Hub",
	lnd_hub_strt_dt        	timestamp       comment "Def(En): CLS Lending Hub Relationship Start Date
Def(Th): วันที่ผูกความสัมพันธ์กับ CLS Clearing Hub",
	intr_rgon_zon_cd       	string          comment "Def(En):Inter Region Zone Code
Def(Th): รหัสเขตสำนักหักบัญชี สำหรับดูค่าธรรมเนียมในการโอนข้ามโซน",
	en_cntr_nm_prt         	string          comment "Def(En):Center Name in English for statement printing
Def(Th):ชื่อหน่วยงานภาษาอังกฤษสำหรับพิมพ์ statement ยาวไม่เกิน 50 ตัวอักษร",
	th_cntr_nm_prt         	string          comment "Def(En):Center Name in Thai for statement printing
Def(Th):ชื่อหน่วยงานภาษาไทยสำหรับพิมพ์ statement ยาวไม่เกิน 50 ตัวอักษร",
	load_tms               	timestamp       comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id             	string          comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy               	string          comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                 	string          comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                 	string          comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_hrcrc/hrcrc_vc_rc_cd' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);