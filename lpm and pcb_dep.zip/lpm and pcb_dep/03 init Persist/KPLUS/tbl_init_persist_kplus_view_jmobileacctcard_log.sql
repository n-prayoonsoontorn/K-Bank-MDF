-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_kplus_view_jmobileacctcard_log.sql
# Area: kplus
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_KPLUS.KPLUS_VIEW_JMOBILEACCTCARD_LOG
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_kplus.kplus_view_jmobileacctcard_log (
	pos_dt          	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	relateacctcard  	string       comment "Def(En):
Def(Th): หมายเลขบัญชี หรือหมายเลขบัตร
e.g. 6732277925
4062301001539286",
	mobileno        	string       comment "Def(En):
Def(Th): หมายเลขโทรศํพท์
e.g. 0910269379",
	accounttype     	string       comment "Def(En):
Def(Th): ประเภท source 
01,11: บัญชี
31: บัตรเครดิต",
	aliasname       	string       comment "Def(En):
Def(Th): ชื่อย่อบัญชี",
	acctcardstatus  	string       comment "Def(En):
Def(Th): สถานะบัญชีหรือบัตร
e.g. NULL, A",
	accountstate    	string       comment "Def(En):
Def(Th): ประเภทบัญชีหรือบัตร
NULL,R: บัญชีหรือบัตรที่สมัคร
A: บัญชีหรือบัตรที่ทำการเพิ่ม",
	createdate      	timestamp    comment "Def(En):
Def(Th): วันที่สมัครหรือเพิ่มบัญชี
e.g. 2016-02-05 00:00:00.010",
	defaultacct     	string       comment "Def(En):
Def(Th): เป็นบัญชี Default หรือไม่
1: Default Account",
	flag1           	string       comment "Def(En): Mark Account
Def(Th): Mark บัญชีกับบัตรเวลาแสดงผลที่หน้าจอ Mobile
1: Mark
0: Unmark",
	flag2           	string       comment "Def(En): Show balance
1: Show balance
0: Not show balance
Def(Th):",
	flag3           	string       comment "Def(En): Card Type
M: Main
S: Supplyment
Def(Th):",
	flag4           	string       comment "Def(En): Card Holder Flag
Def(Th): Card Holder Flag
Y: เจ้าของบัตร
N: ไม่ใช่เจ้าของบัตร",
	flag5           	string       comment "Def(En): Main Customer Flag
Def(Th): Main Customer Flag
Y: เจ้าของบัตรหลัก
N: ไม่ใช่เจ้าของบัตรหลัก",
	flag6           	string       comment "Def(En):
Def(Th): Temp Field ไว้เก็บ Flag",
	flag7           	string       comment "Def(En):
Def(Th): Temp Field ไว้เก็บ Flag",
	flag8           	string       comment "Def(En):
Def(Th): Temp Field ไว้เก็บ Flag",
	flag9           	string       comment "Def(En):
Def(Th): Temp Field ไว้เก็บ Flag",
	flag10          	string       comment "Def(En):
Def(Th): Temp Field ไว้เก็บ Flag",
	accountsubtype  	string       comment "Def(En):
Def(Th): ประเภทของบัญชี
01: บัญชีประเภท Mobile Saving(ไม่มีสมุดบัญชีที่เปิดผ่าน K-Mobile Banking PLUS)
NULL: บัญชีประเภทอื่นๆ",
	limitamount     	decimal(18,2) comment "Def(En):
Def(Th): จำนวนเงินสูงสุดสำหรับการทำรายการของบัญชีประเภท Mobile Saving
e.g. NULL
20000",
	usedamount      	decimal(18,2) comment "Def(En):
Def(Th): จำนวนเงินใช้ไปสำหรับการทำรายการของบัญชีประเภท Mobile Saving
e.g. NULL
20000",
	kbankproductcode	string       comment "Def(En): Kbank Product Code
Def(Th):",
	load_tms        	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id      	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy        	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm          	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd          	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_kplus/kplus_view_jmobileacctcard_log' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);