-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_ks_fundportfolio.sql
# Area: ks
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_KS.KS_FUNDPORTFOLIO
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_ks.ks_fundportfolio (
	pos_dt       	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	src_pos_dt   	date         comment "Def(En): Date of data generated file by KS
Def(Th): วันที่สร้างไฟล์ข้อมูลโดย KS",
	card_id      	string       comment "Def(En): Customer identification number
Def(Th): ​เลขบัตรประชาชน/หนังสือเดินทาง",
	cust_cd      	string       comment "Def(En): Customer reference number
Def(Th): ​รหัสลูกค้าตามประเภทการเปิดบัญชี",
	acct         	string       comment "Def(En): Account number
Def(Th): ​หมายเลขบัญชีหลักทรัพย์
first digit
3- Omnibus
2- Segegrate",
	product_type 	string       comment "Def(En): Product type
Def(Th): ประเภทของผลิตภัณฑ์",
	product_name 	string       comment "Def(En): Product name
Def(Th): ชื่อของผลิตภัณฑ์",
	fundid       	integer      comment "Def(En): Fund ID
Def(Th): รหัสกองทุนที่ Ksec สร้างเอง",
	fundcode     	string       comment "Def(En): Fund code
Def(Th): ชื่อย่อกองทุน",
	fundname     	string       comment "Def(En): Fund name (Eng)
Def(Th): ชื่อกองทุนภาษาอังกฤษ",
	vol          	decimal(24,6) comment "Def(En): Unit volume
Def(Th): ปริมาณหน่วยลงทุนคงเหลือ",
	price_cost   	decimal(24,6) comment "Def(En): Average price cost per unit
Def(Th): ราคาเฉลี่ยต้นทุนต่อหน่วย",
	cost_amt     	decimal(24,6) comment "Def(En): Cost amount
Def(Th): มูลค่าต้นทุน",
	price_mkt    	decimal(24,6) comment "Def(En): Market price amount (per unit)
Def(Th): ราคาปิดตลาดต่อหน่วย",
	mkt_value    	decimal(38,6) comment "Def(En): Market value amount
Def(Th): มูลค่าตลาด",
	unrealize    	decimal(38,6) comment "Def(En): Unrealized gain loss amount
Def(Th): มูลค่ากำไร (ขาดทุน) ที่ยังไม่เกิดขึ้น",
	unrealize_pct	decimal(38,6) comment "Def(En): Unrealized gain loss percentage
Def(Th): %มูลค่ากำไร (ขาดทุน) ที่ยังไม่เกิดขึ้น [ทางบัญชี]",
	amc_id       	integer      comment "Def(En): AMC ID
Def(Th): รหัสบริษัทหลักทรัพย์

ใช้เป็นเงื่อนไขเลือกรายการ OA โดยเลือก AMC ที่ไม่ใช่ KAsset",
	amc_name     	string       comment "Def(En): AMC Name (Eng)
Def(Th): ชื่อบริษัทหลักทรัพย์ภาษาอังกฤษ",
	unitholder_id	string       comment "Def(En): Unit holder ID
Def(Th): เลขที่บัญชีกองทุนที่ใช้ติดต่อบล.",
	fund_type    	string       comment "Def(En): Fund type 
Def(Th): ประเภทของกองทุน",
	price_mkt_dt 	date         comment "Def(En): Market price date
Def(Th): วันที่ของข้อมูลราคาตลาดต่อหน่วย",
	load_tms     	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id   	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy     	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm       	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd       	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_ks/ks_fundportfolio' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);