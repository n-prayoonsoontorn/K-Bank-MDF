-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_lpm_as400_lmt_ar_inf_bfr_wrtof.sql
# Area: lpm_as400
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_LPM_AS400.LPM_AS400_LMT_AR_INF_BFR_WRTOF
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_lpm_as400.lpm_as400_lmt_ar_inf_bfr_wrtof (
	pos_dt                  	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	lmd23400_cust_no        	bigint       comment "Def(En):
Def(Th): เลขที่ลูกหนี้ LPM",
	lmd23400_acct_type      	smallint     comment "Def(En):
Def(Th): ประเภทเครดิต",
	lmd23400_acct_no        	string       comment "Def(En):
Def(Th): หมายเลขบัญชี",
	lmd23400_acct_type_sub  	string       comment "Def(En):
Def(Th): ประเภท Product ระดับ SUB หรือ เลขที่บัญชีระดับ SUB",
	lmd23400_cust_no_tr     	string       comment "Def(En):
Def(Th): เลขที่ลูกค้า Trade",
	lmd23400_sub_tr         	string       comment "Def(En):
Def(Th): ลำดับวงเงินของ Trade",
	lmd23400_fics_acct_no   	string       comment "Def(En):
Def(Th): ประเภทหัวบัญชี",
	lmd23400_br_no          	smallint     comment "Def(En):
Def(Th): สาขา",
	lmd23400_acct_flag      	string       comment "Def(En):
Def(Th): 0 = บัญชีปิดแล้ว
1 = บัญชียังไม่ปิด",
	lmd23400_fg_pod         	string       comment "Def(En):
Def(Th): Flag POD เพื่อใช้แยกกรณีมี Acct-type = 2
0 = ไม่เป็น POD
1 = เป็น POD",
	lmd23400_limit_sub      	decimal(13,2) comment "Def(En):
Def(Th): วงเงินอนุมัติ (ระดับ ACCT-TYPE-SUB)",
	lmd23400_limit_port     	decimal(13,2) comment "Def(En):
Def(Th): วงเงินอนุมัติ (ระดับ ACCT-TYPE-SUB)
ที่หักยอดที่ซ้ำออกแล้ว
สามารถนำมารวมได้เป็นวงเงินภาระผูกพันทั้ง Port ของธนาคาร",
	lmd23400_used_limit     	decimal(13,2) comment "Def(En):
Def(Th): วงเงินที่ใช้ไปแล้ว",
	lmd23400_principle      	decimal(13,2) comment "Def(En):
Def(Th): เงินต้น",
	lmd23400_accru          	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ย",
	lmd23400_memo           	decimal(13,2) comment "Def(En):
Def(Th): ดอกเบี้ยนอกการ์ด",
	lmd23400_due_date1      	integer      comment "Def(En):
Def(Th): วันที่เริ่มสัญญา  1",
	lmd23400_cont_date1     	integer      comment "Def(En):
Def(Th): วันที่ครบกำหนดสัญญา  1",
	lmd23400_due_date2      	integer      comment "Def(En):
Def(Th): วันที่เริ่มสัญญา  2",
	lmd23400_cont_date2     	integer      comment "Def(En):
Def(Th): วันที่ครบกำหนดสัญญา  2",
	lmd23400_due_date3      	integer      comment "Def(En):
Def(Th): วันที่เริ่มสัญญา  3",
	lmd23400_cont_date3     	integer      comment "Def(En):
Def(Th): วันที่ครบกำหนดสัญญา  3",
	lmd23400_due_date4      	integer      comment "Def(En):
Def(Th): วันที่เริ่มสัญญา  4",
	lmd23400_cont_date4     	integer      comment "Def(En):
Def(Th): วันที่ครบกำหนดสัญญา  4",
	lmd23400_due_date5      	integer      comment "Def(En):
Def(Th): วันที่เริ่มสัญญา  5",
	lmd23400_cont_date5     	integer      comment "Def(En):
Def(Th): วันที่ครบกำหนดสัญญา  5",
	lmd23400_due_date6      	integer      comment "Def(En):
Def(Th): วันที่เริ่มสัญญา  6",
	lmd23400_cont_date6     	integer      comment "Def(En):
Def(Th): วันที่ครบกำหนดสัญญา  6",
	lmd23400_due_date7      	integer      comment "Def(En):
Def(Th): วันที่เริ่มสัญญา  7",
	lmd23400_cont_date7     	integer      comment "Def(En):
Def(Th): วันที่ครบกำหนดสัญญา  7",
	lmd23400_block_code     	string       comment "Def(En):
Def(Th): รหัสการติด Code",
	lmd23400_cancel_flag    	string       comment "Def(En):
Def(Th): รหัสการ Cancel",
	lmd23400_fg_limit_used3 	smallint     comment "Def(En):
Def(Th): Flag ของ Aval/Acceptance",
	lmd23400_limit_no       	integer      comment "Def(En):
Def(Th): ลำดับที่ของวงเงิน",
	lmd23400_jl_id          	bigint       comment "Def(En):
Def(Th): เลขที่ของ Joint limit",
	lmd23400_dummy_acct_fg  	string       comment "Def(En):
Def(Th): Flag ว่าเป็น Dummy",
	lmd23400_debit_amt      	decimal(13,2) comment "Def(En):
Def(Th): ยอดที่เบิกใช้ เฉพาะ Loan",
	lmd23400_product_type   	string       comment "Def(En):
Def(Th): ประเภท Product ของวงเงิน",
	lmd23400_product_limit  	decimal(17,2) comment "Def(En):
Def(Th): วงเงินระดับ Product
วงเงินระดับ Product ที่ระบบ Trade ใช้ควบคุมการใช้ (ซึ่งรวมกันหลาย Product อาจจะเกินวงเงินระดับลูกค้า)",
	lmd23400_unuse_limit    	decimal(17,2) comment "Def(En):
Def(Th): วงเงินที่ใช้คำนวณวงเงินคงเหลือ Unuse Limit (ระดับ ACCT-TYPE-SUB)",
	lmd23400_group_id       	string       comment "Def(En):
Def(Th): เลขที่กลุ่มลูกค้า Trade",
	lmd23400_group_cust_no  	bigint       comment "Def(En):
Def(Th): เลขที่กลุ่มลูกค้า LPM",
	lmd23400_group_limit    	decimal(17,2) comment "Def(En):
Def(Th): วงเงินระดับกลุ่มลูกค้า ที่ได้รับอนุมัติ",
	lmd23400_limit_flag     	smallint     comment "Def(En):
Def(Th): การนับวงเงินว่าอนุญาตให้ใช้หรือไม่ให้ใช้วงเงิน
0 = NAL (Disabled)
1 = Normal customer (Enabled)
(เพราะมีบางกรณี หยุดคิดดอกเบี้ย แต่ยังอนุญาตให้ใช้วงเงินเป็นกรณีพิเศษ)",
	lmd23400_legal_entity   	smallint     comment "Def(En):
Def(Th): รหัสบริษัท",
	lmd23400_resp_center    	smallint     comment "Def(En):
Def(Th): รหัสสังกัด",
	lmd23400_gl_account     	integer      comment "Def(En):
Def(Th): รหัสบัญชีประเภทเครดิต",
	lmd23400_function       	smallint     comment "Def(En):
Def(Th): รหัสฟังก์ชันงาน",
	lmd23400_line_business  	smallint     comment "Def(En):
Def(Th): รหัสประเภทธุรกิจ",
	lmd23400_gl_product_code	integer      comment "Def(En):
Def(Th): รหัสผลิตภัณฑ์สำหรับการบันทึกบัญชี",
	lmd23400_inter_company  	smallint     comment "Def(En):
Def(Th): รหัสบริษัทในการหักค่าใช้จ่ายระหว่างบริษัทในเครือ",
	lmd23400_intra_company  	smallint     comment "Def(En):
Def(Th): รหัสบริษัทในการหักค่าใช้จ่ายระหว่างฝ่ายงาน",
	lmd23400_project        	smallint     comment "Def(En):
Def(Th): รหัสโครงการ",
	lmd23400_gl_filler1     	integer      comment "Def(En):
Def(Th): สำหรับใช้ในอนาคต",
	lmd23400_gl_filler2     	smallint     comment "Def(En):
Def(Th): สำหรับใช้ในอนาคต",
	lmd23400_product_code   	integer      comment "Def(En):
Def(Th): รหัสผลิตภัณฑ์",
	load_tms                	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id              	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                  	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                  	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_lpm_as400/lpm_as400_lmt_ar_inf_bfr_wrtof' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);