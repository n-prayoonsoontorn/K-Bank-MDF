-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_lpm_wrtoff_pscp_wo_wo1d04h_sam.sql
# Area: lpm_wrtoff
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_LPM_WRTOFF.LPM_WRTOFF_PSCP_WO_WO1D04H_SAM
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_lpm_wrtoff.lpm_wrtoff_pscp_wo_wo1d04h_sam (
	pos_dt                	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	wo04_cut_type         	smallint     comment "Def(En):
Def(Th):",
	wo04_cust_id          	bigint       comment "Def(En):
Def(Th):",
	wo04_account_no       	string       comment "Def(En):
Def(Th):",
	wo04_adjust_time      	smallint     comment "Def(En):
Def(Th):",
	wo04_type             	smallint     comment "Def(En):
Def(Th):",
	wo04_sign_date        	integer      comment "Def(En):
Def(Th):",
	wo04_credit_type      	smallint     comment "Def(En):
Def(Th):",
	wo04_br_account       	smallint     comment "Def(En):
Def(Th):",
	wo04_drmemo_flag      	smallint     comment "Def(En):
Def(Th):",
	wo04_loss_deduct_prin 	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_loss_deduct_accru	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_bef_prin         	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_pay_incard_prin  	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_pay_incard_accru 	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_pay_out_card     	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_pay_reverse      	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_appr_prin        	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_appr_int         	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_deduct_account   	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_deduct_reverse   	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_deduct_hair_cut  	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_deduct_lpm       	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_deduct_npv       	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_profit_loss      	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_profit_loss_sign 	string       comment "Def(En):
Def(Th):",
	wo04_limit            	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_end_flag         	string       comment "Def(En):
Def(Th):",
	wo04_end_date         	integer      comment "Def(En):
Def(Th):",
	wo04_apply_tax        	smallint     comment "Def(En):
Def(Th):",
	wo04_apply_tax_date   	integer      comment "Def(En):
Def(Th):",
	wo04_memo_accru       	decimal(13,2) comment "Def(En):
Def(Th):",
	wo04_report_bot       	integer      comment "Def(En):
Def(Th):",
	wo04_rate             	decimal(6,3) comment "Def(En):
Def(Th):",
	wo04_reverse_orig     	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_appr_from_tdr    	string       comment "Def(En):
Def(Th):",
	wo04_appr_auto_less   	string       comment "Def(En):
Def(Th):",
	wo04_follow           	string       comment "Def(En):
Def(Th):",
	wo04_cr_buro          	string       comment "Def(En):
Def(Th):",
	wo04_prin             	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_int              	decimal(15,2) comment "Def(En):
Def(Th):",
	wo04_w_flag           	string       comment "Def(En):
Def(Th):",
	wo04_wo_aging         	smallint     comment "Def(En):
Def(Th):",
	wo04_user_input       	integer      comment "Def(En):
Def(Th):",
	wo04_user_input_date  	integer      comment "Def(En):
Def(Th):",
	wo04_user_check       	integer      comment "Def(En):
Def(Th):",
	wo04_user_check_date  	integer      comment "Def(En):
Def(Th):",
	wo04_user_approve     	integer      comment "Def(En):
Def(Th):",
	wo04_user_approve_date	integer      comment "Def(En):
Def(Th):",
	wo04_approve_status   	smallint     comment "Def(En):
Def(Th):",
	wo04_user_confirm     	integer      comment "Def(En):
Def(Th):",
	wo04_user_confirm_date	integer      comment "Def(En):
Def(Th):",
	wo04_confirm_status   	smallint     comment "Def(En):
Def(Th):",
	wo04_user_report      	integer      comment "Def(En):
Def(Th):",
	wo04_user_report_date 	integer      comment "Def(En):
Def(Th):",
	wo04_status           	smallint     comment "Def(En):
Def(Th):",
	filler                	string       comment "Def(En):
Def(Th):",
	load_tms              	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id            	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy              	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_lpm_wrtoff/lpm_wrtoff_pscp_wo_wo1d04h_sam' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);