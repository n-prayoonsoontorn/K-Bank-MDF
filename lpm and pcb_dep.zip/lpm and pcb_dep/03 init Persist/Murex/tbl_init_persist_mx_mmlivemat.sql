-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_mx_mmlivemat.sql
# Area: mx
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_MX.MX_MMLIVEMAT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_mx.mx_mmlivemat (
	pos_dt         	date          comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	dealref        	string        comment "Def(En): Deal reference
Def(Th):",
	package_id     	string        comment "Def(En): MX package number
Def(Th):",
	contract       	decimal(10,0) comment "Def(En): MX contract number
Def(Th):",
	nb             	decimal(10,0) comment "Def(En): MX component number
Def(Th):",
	trn_fmly       	string        comment "Def(En): Product family
Def(Th):",
	trn_grp        	string        comment "Def(En): Product group
Def(Th):",
	trn_type       	string        comment "Def(En): Product Type
Def(Th):",
	trn_typology   	string        comment "Def(En): Product typology
Def(Th):",
	portfolio      	string        comment "Def(En): Portfolio
Def(Th):",
	cisid          	string        comment "Def(En): CIS ID
Def(Th):",
	ctpy_short_name	string        comment "Def(En): Counterparty short name
Def(Th):",
	prinamt        	decimal(19,2) comment "Def(En): Principle amount
Def(Th):",
	princcy        	string        comment "Def(En): Principle currency
Def(Th):",
	tradedate      	date          comment "Def(En): Trade date
Def(Th):",
	valuedate      	date          comment "Def(En): Value date
Def(Th):",
	matdate        	date          comment "Def(En): Maturity date
Def(Th):",
	sbtthb         	decimal(19,2) comment "Def(En): Special business tax (SBT) amount in THB equivalent
Def(Th):",
	intrate        	decimal(19,6) comment "Def(En): Interest rate
Def(Th):",
	intbasis       	string        comment "Def(En): Interest basis
Def(Th):",
	ai_tdy_day     	decimal(5,0)  comment "Def(En): Accrued & Interest Today : Day
Def(Th):",
	ai_tdy_amt     	decimal(16,2) comment "Def(En): Accrued & Interest Today : Amount
Def(Th):",
	ai_mat_day     	decimal(5,0)  comment "Def(En): Accrued & Interest Maturity : Day
Def(Th):",
	ai_mat_amt     	decimal(16,2) comment "Def(En): Accrued & Interest Maturity : Amount
Def(Th):",
	intamt_ytd     	decimal(19,2) comment "Def(En): Interest amount : Year to date
Def(Th):",
	intamt_mtd     	decimal(19,2) comment "Def(En): Interest amount : Month to date
Def(Th):",
	si_method      	string        comment "Def(En): Settlement instruction method
Def(Th):",
	trader         	string        comment "Def(En): Trader Name
Def(Th):",
	dealstatus     	string        comment "Def(En): Deal status
Def(Th):",
	dealtype       	string        comment "Def(En): Deal type
Def(Th):",
	buysell        	string        comment "Def(En): Buy/Sell
Def(Th):",
	prem_disc      	decimal(19,2) comment "Def(En): Premium/ Discount amount
Def(Th):",
	ogl_acc        	string        comment "Def(En): OGL Account code
Def(Th):",
	interest_index 	string        comment "Def(En): Interest rate code
Def(Th):",
	spread         	decimal(24,11) comment "Def(En): Spread rate
Def(Th):",
	notional       	decimal(25,8) comment "Def(En): Notional Amount
Def(Th):",
	int_pay_freq   	string        comment "Def(En): Interest payment frequency
Def(Th):",
	notional_move  	decimal(25,0) comment "Def(En): Notional movement
Def(Th):",
	interest_move  	decimal(25,0) comment "Def(En): Interest movement
Def(Th):",
	mop_status     	string        comment "Def(En): Market operation status
Def(Th):",
	related_deal   	bigint        comment "Def(En): Related Deal Number
Def(Th):",
	load_tms       	timestamp     comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id     	string        comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy       	string        comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm         	string        comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd         	string        comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_mx/mx_mmlivemat' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);