-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_gts_kbgt_cont_outstanding.sql
# Area: gts
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_GTS.GTS_KBGT_CONT_OUTSTANDING
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_gts.gts_kbgt_cont_outstanding (
	pos_dt                  	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	trade_ref               	string       comment "Def(En): Trade transaction reference number15 digit of Contingent/Loan issuance
Only case Import LC Term at acceptance step (Nego) this Trade Txn reference is 15 digit of ACCEPTANCE event
Def(Th):",
	old_traderef            	string       comment "Def(En): Old Trade transaction reference number incase changing trade transaction reference from restructure loan
Def(Th): Note : แต่เนื่องจาก Bank Trade ตาม business process จะไม่เกิดการ restructure loan แล้วเปิดเป็นตั๋วใหม่ใน Bank Trade จะต้องไปเปิดใหม่ในระบบ TP-NAL ดังนั้น field นี้ BT จะไม่ส่งค่า",
	cis_id                  	string       comment "Def(En): CIS ID of customer who is owner of Trade transaction
Def(Th):",
	facility_id             	string       comment "Def(En): Facility ID of Limit which Trade transaction apply to.
Def(Th): กรณี Advance Loan ตั๋วจะไม่มีเลขที่วงเงิน (Facility ID) ถ้าลูกค้าไม่มีวงเงิน Loan",
	limit_id                	string       comment "Def(En): Credit Limit ID by Facility_ID+Customer Acronym/Abbreviation in Bank Trade
Def(Th): กรณี Advance Loan ตั๋วจะไม่มีเลขที่วงเงิน (Facility ID) ถ้าลูกค้าไม่มีวงเงิน Loan",
	facility_level          	string       comment "Def(En): Limit level of Current facility 
Def(Th): กรณี Advance Loan ตั๋วจะไม่มีเลขที่วงเงิน (Facility ID) ถ้าลูกค้าไม่มีวงเงิน Loan",
	l6_limit_id             	string       comment "Def(En): Limit ID of Limit level 6
(by Facility_ID+Customer Acronym/Abbreviation in Bank Trade)
Def(Th): กรณี Advance Loan ตั๋วจะไม่มีเลขที่วงเงิน (Facility ID) ถ้าลูกค้าไม่มีวงเงิน Loan",
	issue_date              	date         comment "Def(En): Issue date of contingent/loan
- Loan (Finance) : Start date of loan
- Contingent : Issue date
Def(Th): วันที่ออกตั๋ว",
	eff_date                	date         comment "Def(En): Effective date of contingent /loan  (start calculate interest)
Def(Th):",
	maturity_date           	date         comment "Def(En): Maturity date
Maturity date and Due date will be same for all product except for Discount product that have different date (refer to functional requirment)
Def(Th):",
	due_date                	date         comment "Def(En): Due date of Transaction
Maturity date and Due date will be same for all product except for Discount product that have different date  (refer to functional requirment)
Def(Th):",
	close_date              	date         comment "Def(En): Transaction Close date
Def(Th):
- Loan : ส่ง close date ในวันที่ตั๋ว outstanding = 0 (principle, interet, fee)
- Contingent :  ส่ง close date ในวันที่ตั๋ว outstanding = 0 (principle, interet, fee)",
	status                  	string       comment "Def(En): Loan/Contingent Transaction status

Status relate with Close date 
Status = Close --> Close date have value
Else status = Active
Def(Th):",
	term                    	decimal(5,0) comment "Def(En): TENOR for transaction
Def(Th):",
	term_unit               	string       comment "Def(En): Unit of Term
Def(Th):",
	ccy_code                	string       comment "Def(En): Original Currency Code of transaction
Def(Th):",
	prin_org_amount_ccy     	decimal(18,2) comment "Def(En): Original Principle Amount as CCY_CODE
Def(Th):",
	prin_org_amount_thb     	decimal(18,2) comment "Def(En): Original Principle Amount in THB
Def(Th):",
	prin_cur_amount_ccy     	decimal(18,2) comment "Def(En): Current Loan/Contingent Principle Amount as CCY_CODE
Def(Th):",
	prin_cur_amount_thb     	decimal(18,2) comment "Def(En): Current Loan/Contingent Principle Amount in THB
Def(Th):",
	int_daily_accru_ccy     	decimal(18,2) comment "Def(En): Daily Accrued Interest amount as CCY Code
For both Normal and NAL transaction
Def(Th):",
	int_daily_accru_thb     	decimal(18,2) comment "Def(En): Daily Accrued Interest amount in THB
For both Normal and NAL transaction
Def(Th):",
	int_remain_amount_ccy   	decimal(18,2) comment "Def(En): Outstanding Interest amount or Remain Accrued Interest as CCY_CODE but
in case Discount product this field = 0
Def(Th):",
	int_remain_amount_thb   	decimal(18,2) comment "Def(En): Outstanding Interest amount or Remain Accrued Interest in THB but
in case Discount product this field = 0
Def(Th):",
	disc_amount_ccy         	decimal(18,2) comment "Def(En): Discount amount in CCY
Def(Th):จะมีค่าก็ต่อเมื่อเป็น Discount product",
	disc_amount_thb         	decimal(18,2) comment "Def(En): Discount amount in THB
Def(Th): จะมีค่าก็ต่อเมื่อเป็น Discount product",
	amrz_amount_ccy         	decimal(18,2) comment "Def(En): Amortize amount in CCY
Def(Th): จะมีค่าก็ต่อเมื่อเป็น Discount product",
	amrz_amount_thb         	decimal(18,2) comment "Def(En): Amortize amount in THB
Def(Th): จะมีค่าก็ต่อเมื่อเป็น Discount product",
	int_receive_ccy         	decimal(18,2) comment "Def(En): Interest Receive in CCY
- Accural basis : Accumulate Accured Interest but it is amount month to date only
- Cash basis : Payment amount incase NAL transaction 
- Reverse Accured Interest : send Reverse amount with minus sign
- Discount product : send accumulate amotize amount month to date
Def(Th):",
	int_receive_thb         	decimal(18,2) comment "Def(En): Interest Receive in THB
- Accural basis : Accumulate Accured Interest but it is amount month to date only
- Cash basis : Payment amount incase NAL transaction 
- Reverse Accured Interest : send Reverse amount with minus sign
- Discount product : send accumulate amotize amount month to date
Def(Th): Note: ถ้า original Interest receive เป็น CCY การส่ง Interest receive THB ต้องเป็นการ convert โดยใช้ daily Mid rate * daily Interest receive เช่น 
Day#1 : Daily Int receive = 1 , mid rate = 35 ---> Int receive THB = 35
Day#2 : Daily Int receive = 1 , mid rate = 34 ---> Int receive THB = 35 + 34
Day#3 : Daily Int receive = 1 , mid rate = 35 ---> Int receive THB = 35 + 34 + 35",
	int_daily_late_chrg_ccy 	decimal(18,2) comment "Def(En): Daily Interest Late Charge amount as CCY_CODE
Def(Th): จะมีค่าเมื่อ transaction ถูกคิด Interest Late Charge",
	int_daily_late_chrg_thb 	decimal(18,2) comment "Def(En): Daily Interest Late Charge amount in THB
Def(Th): จะมีค่าเมื่อ transaction ถูกคิด Interest Late Charge",
	int_late_chrg_remain_ccy	decimal(18,2) comment "Def(En): Remain Interest Late Charge amount as CCY_CODE
Def(Th): จะมีค่าเมื่อ transaction ถูกคิด Interest Late Charge",
	int_late_chrg_remain_thb	decimal(18,2) comment "Def(En): Remain Interest Late Charge amount in THB
Def(Th): จะมีค่าเมื่อ transaction ถูกคิด Interest Late Charge",
	reverse_accru_ccy       	decimal(18,2) comment "Def(En): Reverse Accrued Interest Amount as CCY_CODE
Def(Th):",
	reverse_accru_thb       	decimal(18,2) comment "Def(En): Reverse Accrued Interest Amount in THB
Def(Th): กรณีภาระผูกพัน จะต้องมีค่าเป็น 0 เสมอ",
	memo_accru_ccy          	decimal(18,2) comment "Def(En): Memo Accrual Interest Amount as CCY_CODE
Def(Th):",
	memo_accru_thb          	decimal(18,2) comment "Def(En): Memo Accrual Interest Amount in THB
Def(Th):",
	unpaid_fee_thb          	decimal(18,2) comment "Def(En): Total unpaid Fee amount in THB
Def(Th):",
	date_of_last_payment    	date         comment "Def(En): Last Payment Date of any payment event (Principle , Interest , Fee )

If the last payment date does not exist (first payment) then this field should send blank
Def(Th):",
	amt_last_payment_ccy    	decimal(18,2) comment "Def(En): Payment amount of Last payment in CCY
Def(Th):",
	amt_last_payment_thb    	decimal(18,2) comment "Def(En): Payment amount of Last payment in THB
Def(Th):",
	amt_accum_payment_ccy   	bigint       comment "Def(En): Accumulate all payment amount in CCY (Interest , Principle, Fee , Expense)
Def(Th):",
	amt_accum_payment_thb   	bigint       comment "Def(En): Accumulate all payment amount in THB (Interest , Principle, Fee , Expense)
Def(Th):",
	mid_rate                	decimal(11,7) comment "Def(En): KBank Mid Rate (at Today EOD)
Note: Use this rate incase require to convert CCY amount to THB 
Def(Th):",
	eff_rate                	decimal(9,7) comment "Def(En): Effective interest rate (all in rate for normal transaction)
Def(Th): กรณีภาระผูกพัน จะต้องมีค่าเป็น 0 เสมอ",
	rate_type               	string       comment "Def(En): Rate type
Incase 
- Overdue Transaction : send rate type = 20
- Fix rate : send rate type = 11
- Foating rate : ดูตาม base rate ของ txn ตาม RATE TYPE ID
Def(Th):",
	sign                    	string       comment "Def(En): SPREAD SIGN
Def(Th): มีค่าต่อเมื่อ Rate is Floating rate",
	spread_rate             	decimal(9,7) comment "Def(En): SPREAD_RATE
Def(Th): มีค่าต่อเมื่อ Rate is Floating rate
Spread rate no value send
DIH format : 0.0000000
LPM format : 000000000",
	int_late_chg_rate       	decimal(9,7) comment "Def(En): Late charge rate which charge to customer 

Def(Th): จะมีค่าเมื่อ transaction ถูกคิด Interest Late Charge",
	max_rate                	decimal(9,7) comment "Def(En): Default Interet rate (Maximum interest rate to charge customer)
Def(Th):",
	int_pay_type            	smallint     comment "Def(En): Interest Payment Frequency is the frequency in which the customer pays their interest.
Def(Th):",
	kbank_product_code      	integer      comment "Def(En): Kbank Product Code of Loan or Contingent transaction
Def(Th):",
	type_of_loan            	string       comment "Def(En): To define Contigent or loan
Def(Th):",
	reverse_flag            	smallint     comment "Def(En): Reverse Accrued Interest flag (Stop Interest accrued calculation)
Def(Th):",
	reverse_date            	date         comment "Def(En): Reverse accrue interest date.
Def(Th): มีค่าเมื่อ Reverse flag <> 0 
incase no value send null",
	dpd_prin                	smallint     comment "Def(En): Day Pass Due (Aging) of Principle
Def(Th): มีค่าเมื่อตั๋ว overdue",
	dpd_int                 	smallint     comment "Def(En): Day Pass Due (Aging) of Interest
Def(Th): มีค่าเมื่อตั๋วผิดนัดชำระดอกเบี้ย",
	dpd_bot                 	smallint     comment "Def(En): Day Pass Due (Aging) of BOT
Def(Th): มีค่าเมื่อตั๋ว overdue หรือ ผิดนัดชำระดอกเบี้ย",
	dpd_start_date          	date         comment "Def(En): Start date of Day pass due for aging BOT
Def(Th): มีค่าเมื่อตั๋ว overdue หรือ ผิดนัดชำระดอกเบี้ย",
	overdue_amount_ccy      	decimal(18,2) comment "Def(En): Overdue amount in CCY of Interest or Priciple or Interest + Principle depend on overdue type
Def(Th): มีค่าต่อเมือลูกค้าผิดนัดชำระเงินต้นและหรือดอกเบี้ย

LPM : 
สำหรับ INT-PAY-TYPE = 1
   - ถ้าครบกำหนดตาม maturity date แล้วไม่ชำระ ให้ส่งค่าค้างชำระเงินต้น + ดอกเบี้ยผิดนัดชำระของเงินต้น

สำหรับ INT-PAY-TYPE = 2
   - ถ้ายังไม่ครบกำหนดชำระตาม maturity date ให้ส่งค่ายอดค้างชำระของดอกเบี้ย
   - ถ้าครบกำหนดตาม maturity date แล้วให้ส่งค่าค้างชำระดอกเบี้ย + ค่าค้างชำระเงินต้น + ดอกเบี้ยผิดนัดชำระของเงินต้น

สำหรับ INT-PAY-TYPE = 3 
   - ถ้าครบกำหนดตาม maturity date แล้วไม่ชำระ ให้ส่งค่าค้างชำระดอกเบี้ย + ค่าค้างชำระเงินต้น + ดอกเบี้ยผิดนัดชำระของเงินต้น",
	overdue_amount_thb      	decimal(18,2) comment "Def(En): Overdue amount in THB of Interest or Priciple or Interest + Principle depend on overdue type
Def(Th): มีค่าต่อเมือลูกค้าผิดนัดชำระเงินต้นและหรือดอกเบี้ย

LPM : 
สำหรับ INT-PAY-TYPE = 1
   - ถ้าครบกำหนดตาม maturity date แล้วไม่ชำระ ให้ส่งค่าค้างชำระเงินต้น + ดอกเบี้ยผิดนัดชำระของเงินต้น

สำหรับ INT-PAY-TYPE = 2
   - ถ้ายังไม่ครบกำหนดชำระตาม maturity date ให้ส่งค่ายอดค้างชำระของดอกเบี้ย
   - ถ้าครบกำหนดตาม maturity date แล้วให้ส่งค่าค้างชำระดอกเบี้ย + ค่าค้างชำระเงินต้น + ดอกเบี้ยผิดนัดชำระของเงินต้น

สำหรับ INT-PAY-TYPE = 3 
   - ถ้าครบกำหนดตาม maturity date แล้วไม่ชำระ ให้ส่งค่าค้างชำระดอกเบี้ย + ค่าค้างชำระเงินต้น + ดอกเบี้ยผิดนัดชำระของเงินต้น

สำหรับภาระผูกพัน ให้มีค่าเป็น 0",
	regis_repay_dda         	bigint       comment "Def(En): one of DDA account that register in Account master (DDA splite)
Def(Th):",
	borrower_type           	string       comment "Def(En): Type of borrower
Def(Th):",
	grace_flag              	string       comment "Def(En): Grace period flag for Purchase/Discount L/C and B/C product
Def(Th):",
	grace_start_date        	date         comment "Def(En): Grace period Start date for Purchase/Discount L/C and B/C product
Def(Th): จะมีค่าต่อเมื่อ GRACE_FLAG = Y",
	grace_end_date          	date         comment "Def(En): Grace period End date for Purchase/Discount L/C and B/C product
Def(Th): จะมีค่าต่อเมื่อ GRACE_FLAG = Y",
	center_code             	string       comment "Def(En): RC Code of SPOKE which register customer.

Incase Customer is registered at HUB or doesn't have SPOKE ID, put value as '14550'
Def(Th):",
	prin_coa_lgl_ent        	smallint     comment "Def(En): LEGAL ENTITY (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_rspl_cntr      	smallint     comment "Def(En): RESPONSIBILITY CENTER (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_ac             	integer      comment "Def(En): OGL ACCOUNT (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_fnc            	smallint     comment "Def(En): FUNCTION (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_line_of_bsn    	smallint     comment "Def(En): LINE OF BUSINESS (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_pd             	integer      comment "Def(En): PRODUCT CODE (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_intco          	smallint     comment "Def(En): INTER COMPANY (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_inrco          	smallint     comment "Def(En): INTRA COMPANY (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_prj            	smallint     comment "Def(En): PROJECT (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_futr_used1     	integer      comment "Def(En): FUTURE USED1 (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_futr_used2     	smallint     comment "Def(En): FUTURE USED2 (as Master setup for Chart of Account)
Def(Th):",
	prin_coa_pd_ftr_code    	integer      comment "Def(En): SUB PRODUCT - Kbank Product Code 9 digit (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_lgl_ent    	smallint     comment "Def(En): LEGAL ENTITY (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_rspl_cntr  	smallint     comment "Def(En): RESPONSIBILITY CENTER (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_ac         	integer      comment "Def(En): OGL ACCOUNT (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_fnc        	smallint     comment "Def(En): FUNCTION (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_line_of_bsn	smallint     comment "Def(En): LINE OF BUSINESS (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_pd         	integer      comment "Def(En): PRODUCT CODE (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_intco      	smallint     comment "Def(En): INTER COMPANY (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_inrco      	smallint     comment "Def(En): INTRA COMPANY (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_prj        	smallint     comment "Def(En): PROJECT (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_futr_used1 	integer      comment "Def(En): FUTURE USED1 (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_futr_used2 	smallint     comment "Def(En): FUTURE USED2 (as Master setup for Chart of Account)
Def(Th):",
	accu_int_coa_pd_ftr_code	integer      comment "Def(En): SUB PRODUCT - Kbank Product Code 9 digit (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_lgl_ent     	smallint     comment "Def(En): LEGAL ENTITY (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_rspl_cntr   	smallint     comment "Def(En): RESPONSIBILITY CENTER (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_ac          	integer      comment "Def(En): OGL ACCOUNT (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_fnc         	smallint     comment "Def(En): FUNCTION (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_line_of_bsn 	smallint     comment "Def(En): LINE OF BUSINESS (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_pd          	integer      comment "Def(En): PRODUCT CODE (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_intco       	smallint     comment "Def(En): INTER COMPANY (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_inrco       	smallint     comment "Def(En): INTRA COMPANY (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_prj         	smallint     comment "Def(En): PROJECT (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_futr_used1  	integer      comment "Def(En): FUTURE USED1 (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_futr_used2  	smallint     comment "Def(En): FUTURE USED2 (as Master setup for Chart of Account)
Def(Th):",
	rev_int_coa_pd_ftr_code 	integer      comment "Def(En): SUB PRODUCT - Kbank Product Code 9 digit (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_lgl_ent        	smallint     comment "Def(En): LEGAL ENTITY (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_rspl_cntr      	smallint     comment "Def(En): RESPONSIBILITY CENTER (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_ac             	integer      comment "Def(En): OGL ACCOUNT (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_fnc            	smallint     comment "Def(En): FUNCTION (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_line_of_bsn    	smallint     comment "Def(En): LINE OF BUSINESS (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_pd             	integer      comment "Def(En): PRODUCT CODE (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_intco          	smallint     comment "Def(En): INTER COMPANY (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_inrco          	smallint     comment "Def(En): INTRA COMPANY (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_prj            	smallint     comment "Def(En): PROJECT (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_futr_used1     	integer      comment "Def(En): FUTURE USED1 (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_futr_used2     	smallint     comment "Def(En): FUTURE USED2 (as Master setup for Chart of Account)
Def(Th):",
	memo_coa_pd_ftr_code    	integer      comment "Def(En): SUB PRODUCT - Kbank Product Code 9 digit (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_lgl_ent    	smallint     comment "Def(En): LEGAL ENTITY (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_rspl_cntr  	smallint     comment "Def(En): RESPONSIBILITY CENTER (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_ac         	integer      comment "Def(En): OGL ACCOUNT (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_fnc        	smallint     comment "Def(En): FUNCTION (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_line_of_bsn	smallint     comment "Def(En): LINE OF BUSINESS (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_pd         	integer      comment "Def(En): PRODUCT CODE (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_intco      	smallint     comment "Def(En): INTER COMPANY (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_inrco      	smallint     comment "Def(En): INTRA COMPANY (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_prj        	smallint     comment "Def(En): PROJECT (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_futr_used1 	integer      comment "Def(En): FUTURE USED1 (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_futr_used2 	smallint     comment "Def(En): FUTURE USED2 (as Master setup for Chart of Account)
Def(Th):",
	int_late_coa_pd_ftr_code	integer      comment "Def(En): SUB PRODUCT - Kbank Product Code 9 digit (as Master setup for Chart of Account)
Def(Th):",
	acr_bss_code            	smallint     comment "Def(En): Accrual Basis Code is the basis on which the interest accrual on an account is calculated. 

Def(Th):",
	amrz_tp                 	string       comment "Def(En): Amortization Type

Trade : Principle is paid at Maturity date only : Send '2'
Def(Th):",
	orig_book_bal_ccy       	decimal(18,2) comment "Def(En): The original book balance (CCY) is the starting book balance. This field should always remain the same until the account is closed. The balance should be set according to its currency. 

Original book balance will be differed from original par balance in case of product with discount only. Original Book Balance = Original Par Balance - Original Discount.
Def(Th):",
	orig_book_bal_thb       	decimal(18,2) comment "Def(En): The original book balance (THB) is the starting book balance. This field should always remain the same until the account is closed. 

Original book balance will be differed from original par balance in case of product with discount only. Original Book Balance = Original Par Balance - Original Discount.
Def(Th):",
	orig_prem_dcn_ccy       	decimal(18,2) comment "Def(En): The Original Premium/Discount (CCY) is the starting premium/discount amount. This field should always remain the same until the account is closed and it should be equal to total discount amount. The amount should be according to its currency. 
The value should be send as minus value
Def(Th):",
	orig_prem_dcn_thb       	decimal(18,2) comment "Def(En): The Original Premium/Discount (THB) is the starting premium/discount amount. This field should always remain the same until the account is closed and it should be equal to total discount amount. 
The value should be send as minus value
Def(Th):",
	crn_book_bal_ccy        	decimal(18,2) comment "Def(En): Current Book Balance (CCY) should be equal to current par balance in case of non discount loan otherwise field current book balance = Current Par Balance - Current Premium/Discount

Def(Th):",
	crn_book_bal_thb        	decimal(18,2) comment "Def(En): Current Book Balance (THB) should be equal to current par balance in case of non discount loan otherwise field current book balance = Current Par Balance - Current Premium/Discount

Def(Th):",
	crn_prem_dcn_ccy        	decimal(18,2) comment "Def(En): [Use by TFRS9]

The current premium/discount (CCY) is the income or expense that bank has not yet recognized at the position date.

This field will be used for product with discount thus it will relate to field discount type. The expected value for this field must have minus sign (for discount). This field will be calculated 7 days

If monthend is non-working day : at last working day before monthend, current premium/discount value has to be value at monthend date (same data as Monthly file)

note:  Purchase product will be '0'

Def(Th):",
	crn_prem_dcn_thb        	decimal(18,2) comment "Def(En): The current premium/discount(THB) is the income or expense that bank has not yet recognized at the position date.

This field will be used for product with discount thus it will relate to field discount type. The expected value for this field must have minus sign (for discount). This field will be calculated 7 days

If monthend is non-working day : at last working day before monthend, current premium/discount value has to be value at monthend date (same data as Monthly file)

note:  Purchase product will be '0'

Def(Th):",
	av_book_bal_ccy         	decimal(18,2) comment "Def(En): Average Book Balance(CCY): ACCUMULATE Month to date of Daily Average Book Balance 

Daily Average Book balance is calculated from current book balance divide by number of days in that month. Daily Average Book balance is calculated 7 days.

ACCUMULATE amount start from loan effective date until day before Loan outstanding is 0.

For last working day of the week , ACCUMULATE amount has to include non-working day.
If monthend is non-working day : at last working day before monthend, ACCUMULATE amount has to include non-working day.

Case#1  : Loan transaction start and mature in same month of Position date
Accumulate amount start from start loan effective date until the day before Loan outstanding is 0.
Example : Effective Date = 1-Feb , Maturity = 8-Feb, Cur Book Bal = 1M
Position date = 5 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28);
Position date = 8 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28) +  (1M/28) +  (1M/28);


Case#2  : Loan transaction start in same month of Position date but mature on later month
Accumulate amount start from start loan effective date until monthend date.
Example : Effective Date = 1-Feb , Maturity = 2-Mar, Cur Book Bal = 1M
Position date = 5 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28);
Position date = 28 Feb 
<AV_BOOK_BAL> = 28 * (1M/28);

Case#3  : Loan transaction start in previous month but mature in same month of Position date
Accumulate amount start from 1st day of the month until the day before Loan outstanding is 0.
Example : Effective Date = 1-Jan , Maturity = 8-Feb, Cur Book Bal = 1M
Position date = 5 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28);
Position date = 8 Feb 
<AV_BOOK_BAL>  =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28) +  (1M/28) +  (1M/28);

Case#4  : Loan transaction start in previous month and mature on later month
Accumulate amount start from 1st day of the month until monthend date.
Example : Effective Date = 1-Jan , Maturity = 2-Mar, Cur Book Bal = 1M
Position date = 5 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28);
Position date = 28 Feb 
<AV_BOOK_BAL> = 28 * (1M/28);
Def(Th):",
	av_book_bal_thb         	decimal(18,2) comment "Def(En): Average Book Balance(THB): ACCUMULATE Month to date of Daily Average Book Balance 

Daily Average Book balance is calculated from current book balance divide by number of days in that month. Daily Average Book balance is calculated 7 days.

ACCUMULATE amount start from loan effective date until day before Loan outstanding is 0.

For last working day of the week , ACCUMULATE amount has to include non-working day.
If monthend is non-working day : at last working day before monthend, ACCUMULATE amount has to include non-working day.

Case#1  : Loan transaction start and mature in same month of Position date
Accumulate amount start from start loan effective date until the day before Loan outstanding is 0.
Example : Effective Date = 1-Feb , Maturity = 8-Feb, Cur Book Bal = 1M
Position date = 5 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28);
Position date = 8 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28) +  (1M/28) +  (1M/28);


Case#2  : Loan transaction start in same month of Position date but mature on later month
Accumulate amount start from start loan effective date until monthend date.
Example : Effective Date = 1-Feb , Maturity = 2-Mar, Cur Book Bal = 1M
Position date = 5 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28);
Position date = 28 Feb 
<AV_BOOK_BAL> = 28 * (1M/28);

Case#3  : Loan transaction start in previous month but mature in same month of Position date
Accumulate amount start from 1st day of the month until the day before Loan outstanding is 0.
Example : Effective Date = 1-Jan , Maturity = 8-Feb, Cur Book Bal = 1M
Position date = 5 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28);
Position date = 8 Feb 
<AV_BOOK_BAL>  =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28) +  (1M/28) +  (1M/28);

Case#4  : Loan transaction start in previous month and mature on later month
Accumulate amount start from 1st day of the month until monthend date.
Example : Effective Date = 1-Jan , Maturity = 2-Mar, Cur Book Bal = 1M
Position date = 5 Feb 
<AV_BOOK_BAL> =  (1M/28) +  (1M/28) +  (1M/28) +  (1M/28) + (1M/28);
Position date = 28 Feb 
<AV_BOOK_BAL> = 28 * (1M/28);
Def(Th):",
	av_par_bal_ccy          	decimal(18,2) comment "Def(En): Average Par Balance (CCY): ACCUMULATE Month to date of Daily Average Par Balance 

Daily Average Par Balance is calculated from Current PAR Balance divide by number of days in that month. Daily Average Par balance is calculated 7 days.

ACCUMULATE amount start from loan effective date until day before Loan outstanding is 0.

For last working day of the week , ACCUMULATE amount has to include non-working day.
If monthend is non-working day : at last working day before monthend, ACCUMULATE amount has to include non-working day.

Case#1  : Loan transaction start and mature in same month of Position date
Accumulate amount start from start loan effective date until the day before Loan outstanding is 0.

Case#2  : Loan transaction start in same month of Position date but mature on later month
Accumulate amount start from start loan effective date until monthend date.

Case#3  : Loan transaction start in previous month but mature in same month of Position date
Accumulate amount start from 1st day of the month until the day before Loan outstanding is 0.

Case#4  : Loan transaction start in previous month and mature on later month
Accumulate amount start from 1st day of the month until monthend date.

note: refer example of each case from Average Book Balance
Def(Th):",
	av_par_bal_thb          	decimal(18,2) comment "Def(En): Average Par Balance(THB) : ACCUMULATE Month to date of Daily Average Par Balance 

Daily Average Par Balance is calculated from Current PAR Balance divide by number of days in that month. Daily Average Par balance is calculated 7 days.

ACCUMULATE amount start from loan effective date until day before Loan outstanding is 0.

For last working day of the week , ACCUMULATE amount has to include non-working day.
If monthend is non-working day : at last working day before monthend, ACCUMULATE amount has to include non-working day.

Case#1  : Loan transaction start and mature in same month of Position date
Accumulate amount start from start loan effective date until the day before Loan outstanding is 0.

Case#2  : Loan transaction start in same month of Position date but mature on later month
Accumulate amount start from start loan effective date until monthend date.

Case#3  : Loan transaction start in previous month but mature in same month of Position date
Accumulate amount start from 1st day of the month until the day before Loan outstanding is 0.

Case#4  : Loan transaction start in previous month and mature on later month
Accumulate amount start from 1st day of the month until monthend date.

note: refer example of each case from Average Book Balance
Def(Th):",
	crn_idnx_rate           	decimal(9,7) comment "Def(En): Current index rate is the index rate of the account interest rate type at the position date.
Current index rate will send 
- 0 : when current Interest rate type (INT_CHG_F) is Fixed rate
- Base rate (at current date) : when current Interest rate type (INT_CHG_F)  is Float rate
Def(Th):",
	orig_int_rate           	decimal(9,7) comment "Def(En): Original Interest Rate is Effective Interest rate (all in rate) at loan effective date
Def(Th):",
	int_chg_f               	smallint     comment "Def(En): Interest Change Flag (current interest rate type)
Def(Th):",
	last_int_pymt_dt        	date         comment "Def(En): Last Interest Payment Date is the date in which the interest payment is last scheduled before position date. If last interest payment date does not exist then this field should be set to origination date/Effective date. 
Def(Th):",
	last_pnp_pymt_dt        	date         comment "Def(En): Last Principal Payment Date is the date in which the principal payment is last schedule before position date.
If the last principal payment date does not exist (first payment) then the last principal payment date is the origination date/Effective date.
Def(Th):",
	last_rprc_dt            	date         comment "Def(En): Last Reprice Date
If Interest rate is 
- Fix rate : send Effective date
- Float rate : send Batch date
Def(Th):",
	nxt_int_pymt_dt         	date         comment "Def(En): Next Interest Payment Date

If interest schedule is
Monthly = send next billing date
Maturity = send Maturity date
Def(Th):",
	overdue_flag            	string       comment "Def(En): Identifier Transaction Overdue product
(Overdue for Principle)
Def(Th):",
	value_dt                	date         comment "Def(En): Value date of transaction
Def(Th):",
	ppymt_bal_amt_ccy       	decimal(18,2) comment "Def(En): Prepayment Balance amount (CCY) is the total prepayment amount that exclude amount pay on maturity date
Def(Th):",
	ppymt_bal_amt_thb       	decimal(18,2) comment "Def(En): Prepayment Balance amount(THB) is the total prepayment amount that exclude amount pay on maturity date
Def(Th):",
	ppymt_dt                	date         comment "Def(En): Prepayment date is the latest date of prepayment (before maturity date)
Def(Th):",
	ppymt_f                 	string       comment "Def(En): Prepayment Flag
Def(Th):",
	weighted_avg_ind_rate   	decimal(9,5) comment "Def(En): Weighted Average Index Rate (Month to date) = sum (Daily Weight Index Rate) / sum (Loan Outstanding)

Daily Weight Index Rate = Loan Outstanding * CRN_IDNX_RATE 
Daily Weight Index Rate is calculated everyday (7 days). The value of fields (Loan Outstanding and CRN_IDNX_RATE) for non-working day use same value from last working day.

If monthend is non-working day : at last working day before monthend, Weighted Average Index Rate has to include amount of non-working day (same data as Monthly file)

Ex. Position date is 4/5/07 : Weighted Average Index Rate = 5.41


Def(Th):",
	orig_admn_rate          	decimal(9,7) comment "Def(En): Original Admin Rate
Def(Th):",
	src_system              	string       comment "Def(En): SYSTEM that generate data
Def(Th):",
	latest_amd_mat_date     	date         comment "Def(En): Lastest Amend Maturity Date
Def(Th):",
	latest_amd_ccy_date     	date         comment "Def(En): Lastest Amend Maturity Date
Def(Th):",
	latest_amd_int_date     	date         comment "Def(En): Lastest Amend Maturity Date
Def(Th):",
	overdue_date            	date         comment "Def(En): Overdue Date
Def(Th):",
	misc_info               	string       comment "Def(En): Miscellaneous Information
Def(Th):",
	load_tms                	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id              	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                  	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                  	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_gts/gts_kbgt_cont_outstanding' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);