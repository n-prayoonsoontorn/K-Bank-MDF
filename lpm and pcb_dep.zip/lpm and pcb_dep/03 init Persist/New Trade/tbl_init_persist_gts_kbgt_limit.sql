-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_gts_kbgt_limit.sql
# Area: gts
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_GTS.GTS_KBGT_LIMIT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_gts.gts_kbgt_limit (
	pos_dt              	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	custid              	string       comment "Def(En): CIS ID of Trade Customer 
Def(Th):",
	parent_custid       	string       comment "Def(En): CIS ID of parent 
ถ้าไม่มีบริษัทแม่ให้ส่ง Blank
Def(Th):",
	limit_id            	string       comment "Def(En): Limit ID (Concat FACILITY ID and Customer Acronym/abbreviation in BankTrade)
Def(Th):",
	limit_level         	string       comment "Def(En): Level of limit (key in at BankTrade screen)
Def(Th): เลขที่ level ของวงเงิน",
	facility_id         	string       comment "Def(En): Facility ID of Limit 
Def(Th):",
	facility_description	string       comment "Def(En): Description of  Facility id
Def(Th):",
	type_of_loan        	string       comment "Def(En): To define Contigent or loan
Def(Th):",
	upper_limitid       	string       comment "Def(En): Uppper Limit ID (Concat FACILITY ID and Customer Acronym/abbreviation in BankTrade)
Incase Limit ID is Root Facility , this field put Limit ID. 
Def(Th):",
	upper_facilityid    	string       comment "Def(En): Facility ID in upper level of Faciltiy ID 
Incase Facility ID is Root Facility , this field put Facility ID. 
Def(Th):",
	root_limitid        	string       comment "Def(En): Limit ID of customer level (CL/OV)
Def(Th):",
	root_facilityid     	string       comment "Def(En): Facility ID of Customer level (CL/OV)
Def(Th):",
	second_facilitypid  	string       comment "Def(En): Secenod Facility ID in BankTrade
Def(Th):",
	kbank_pd_code       	string       comment "Def(En): Kbank Product Code of Facility (as Facility product mapping with Kbank product code) 
Def(Th):",
	limit_ccy           	decimal(18,2) comment "Def(En): Limit amount of this Facility in CCY
Def(Th):",
	used_amount_ccy     	decimal(18,2) comment "Def(En): Used amount of this Facility in CCY

Def(Th):",
	avaiable_amount_ccy 	decimal(18,2) comment "Def(En): Available amount of this Facility in CCY
Def(Th):",
	pending_amount_ccy  	decimal(18,2) comment "Def(En): Amount earmark during create/update transaction pending for approval 
Def(Th): กรณีสร้างรายการแต่ยังไม่ได้ approve วงเงินจะถูก earmark",
	lccy                	string       comment "Def(En): LIMIT currency e.g. THB, USD 
Def(Th):",
	block_flag          	string       comment "Def(En): Block flag
Y = Block
N = not block
Def(Th): ใช้ในกรณีคำสั่งให้ block เช่น ประเทศที่มีความเสี่ยง หรือ RM แจ้งไม่ให้ใช้วงเงิน แต่ amount ทุกอย่างในระบบยังเท่าเดิม",
	limit_thb           	decimal(18,2) comment "Def(En): Limit amount of this Facility in THB
Def(Th):",
	used_amount_thb     	decimal(18,2) comment "Def(En): Used amount of this Facility in THB
Def(Th):",
	avaiable_amount_thb 	decimal(18,2) comment "Def(En): Available amount of this Facility
Def(Th):",
	pending_amount_thb  	decimal(18,2) comment "Def(En): Amount earmark during create/update transaction pending for approval 
Def(Th):",
	kbank_midrate       	decimal(11,7) comment "Def(En): KBank Mid Rate that use to convert TXN_AMT_CCY to TXN_AMT
Def(Th):",
	borrower_type       	string       comment "Def(En): Type of borrower
Def(Th):",
	andor_limit_flag    	string       comment "Def(En): Type of limit at product level
And/or product flag
Def(Th): ระดับ Product User สามารถเลือกได้ว่าเป็นวงเงิน And/or หรือไม่",
	issue_date          	date         comment "Def(En): Create transaction date
Def(Th): ไม่มีการเปลี่ยนแปลงถึงแม้จะมีการ update",
	update_date         	date         comment "Def(En): Last update date (Approve date in BankTrade)
Def(Th): Note : 
1. Approved date :วันที่วงเงินเริ่มใช้งานได้
2. การแก้ไขข้อมูลวงเงินและยังไม่ได้ Approve : ในกรณีมีการ update วงเงิน วงเงินจะมีการเปลี่ยนค่าตามวันที่มีการ update  BankTrade จะส่งinformation ของ limit ค่าที่ update แล้วไปให้ถึงจะยังไม่ได้รับการ approve ก็ตาม",
	expiry_date         	date         comment "Def(En): Expire date of this Facilty 
Def(Th):",
	revision_date       	date         comment "Def(En): Review date ของวงเงิน
Def(Th):",
	closed_date         	date         comment "Def(En): Closed dated
Def(Th):",
	limit_status        	string       comment "Def(En): Limit status
If closed date is null , limit status is active
else Inactive
1=Active
2= Inactive
Def(Th):",
	approve_flag        	string       comment "Def(En): Approve flag
Def(Th):",
	uncommitted_type    	string       comment "Def(En): Committed type 
Def(Th):",
	revolving_type      	string       comment "Def(En): Revolving type
Def(Th):",
	approverid          	string       comment "Def(En): Approver ID (KBANK USER ID)  
Def(Th):",
	makerid             	string       comment "Def(En): Create / Issue User :Maker ID (KBANK USER ID)
Def(Th):",
	tenor               	smallint     comment "Def(En): Tenor day of limit
Def(Th): ใน BankTrade ใช้สำหรับ validate ระดับตั๋ว ว่าตั๋วภายใต้ วงเงินนั้นจะต้องมี Tenor ไม่เกิน Tenor ของ limit
ถ้ามีค่าเป็น 0 คือ open-end",
	prod_trade          	string       comment "Def(En): Internal Trade product : liability code in BankTrade
Def(Th):",
	exposure            	decimal(18,2) comment "Def(En):
Def(Th): ยอดความเสี่ยงที่ธนาคารต้องแบกรับภาระ   (ยอดวงเงินที่ยังไม่เบิกใช้ +  ยอดเงินต้นคงค้าง)

#1. กรณี Limit ที่ยังไม่ expired
Exposure =  Limit amount

#2.กรณี Limit ที่ถึง Expired แล้ว
    Exposure = Used amount",
	business_code       	string       comment "Def(En):
Def(Th): ประเภทธุรกิจ ระดับ Facility",
	load_tms            	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id          	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy            	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm              	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd              	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_gts/gts_kbgt_limit' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);