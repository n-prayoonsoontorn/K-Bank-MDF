-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_pcb_loan_common_rate_type.sql
# Area: pcb_loan
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_PCB_LOAN.PCB_LOAN_COMMON_RATE_TYPE
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_pcb_loan.pcb_loan_common_rate_type (
	pos_dt         	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	int_idnx       	string       comment "Def(En): Interest Index 
Def(Th):",
	pcb_int_idnx   	string       comment "Def(En): Profile Interest Index 
Def(Th):",
	int_dsc        	string       comment "Def(En): Rate description
Def(Th):",
	int_idnx_tp    	string       comment "Def(En): Interest Index Type 
0: Basis
1: BalanceTier
Def(Th):",
	eff_int_rate   	decimal(8,5) comment "Def(En): Effective Rate 
Def(Th):",
	ctr_sprd_flg   	string       comment "Def(En): Flag Contract Spread
0: OFF
1: ON
Def(Th):",
	start_dt       	date         comment "Def(En): Start Date of Effective Rate
Def(Th):",
	end_dt         	date         comment "Def(En): End Date of Effective Rate
Def(Th):",
	rate_type      	smallint     comment "Def(En): Rate Type
Def(Th):",
	ccy_code       	string       comment "Def(En): Currency Code
Def(Th):",
	sub_category   	string       comment "Def(En): Sub Category
Def(Th):",
	tenor          	string       comment "Def(En): Tenor -Number Of Days To Average Rate 
Def(Th):",
	cal_back_period	smallint     comment "Def(En): Calculation Back Period
Def(Th):",
	load_tms       	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id     	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy       	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm         	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd         	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_pcb_loan/pcb_loan_common_rate_type' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);