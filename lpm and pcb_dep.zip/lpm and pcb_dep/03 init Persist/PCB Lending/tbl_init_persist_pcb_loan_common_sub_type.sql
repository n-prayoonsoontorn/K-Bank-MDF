-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_pcb_loan_common_sub_type.sql
# Area: pcb_loan
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_PCB_LOAN.PCB_LOAN_COMMON_SUB_TYPE
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_pcb_loan.pcb_loan_common_sub_type (
	pos_dt      	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	pd_grp      	string       comment "Def(En):Product Group 
Def(Th): กลุ่มผลิตภัณฑ์
LN : Consumer
COM : Commercial",
	sub_typ_code	string       comment "Def(En): Sub type code
Def(Th): รหัสประเภทย่อย",
	sub_typ_dsc 	string       comment "Def(En): Sub type description
Def(Th): คำอธิบายประเภทย่อย",
	load_tms    	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id  	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy    	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm      	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd      	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_pcb_loan/pcb_loan_common_sub_type' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);