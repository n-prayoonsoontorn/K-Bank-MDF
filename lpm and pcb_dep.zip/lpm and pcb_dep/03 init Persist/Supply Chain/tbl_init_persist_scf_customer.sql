-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_scf_customer.sql
# Area: scf
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_SCF.SCF_CUSTOMER
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_scf.scf_customer (
	pos_dt             	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	strcustid          	string       comment "Def(En): TN Customer ID
Def(Th):",
	strcustcode        	string       comment "Def(En): Customer Code from GEC
Def(Th):",
	strcustnametha     	string       comment "Def(En): Thai Customer Name
Def(Th):",
	strcustnameeng     	string       comment "Def(En): English Customer Name
Def(Th):",
	strcustaddr1       	string       comment "Def(En): Customer Address1
Def(Th):",
	strcustaddr2       	string       comment "Def(En): Customer Address2
Def(Th):",
	strcustaddr3       	string       comment "Def(En): Customer Address3
Def(Th):",
	strcustaddrreg1    	string       comment "Def(En): Register Customer Address1
Def(Th):",
	strcustaddrreg2    	string       comment "Def(En): Register Customer Address2
Def(Th):",
	strcustaddrreg3    	string       comment "Def(En): Register Customer Address3
Def(Th):",
	strbuysellflag     	string       comment "Def(En): Buyer/Seller Flag
Def(Th):",
	strsponsorflag     	string       comment "Def(En): Sponsor Flag 
Def(Th):",
	strkfactflag       	string       comment "Def(En): K-Factoring Flag
Def(Th):",
	strtelno           	string       comment "Def(En): Telephone No
Def(Th):",
	strfax             	string       comment "Def(En): Fax No
Def(Th):",
	stremail           	string       comment "Def(En): E-mail Address
Def(Th):",
	decfeeamt          	decimal(15,2) comment "Def(En):
Def(Th):",
	decbalfeeamt       	decimal(15,2) comment "Def(En):
Def(Th):",
	strlastfeedate     	date         comment "Def(En):
Def(Th):",
	strpersoncont      	string       comment "Def(En):
Def(Th):",
	strdwflag          	string       comment "Def(En): Drawdown Flag
Def(Th):",
	strfwflag          	string       comment "Def(En): Future Drawdown
Def(Th):",
	strddflag          	string       comment "Def(En): Direct Debit Flag
Def(Th):",
	strfdflag          	string       comment "Def(En): Future Direct Debit Flag
Def(Th):",
	strsdflag          	string       comment "Def(En): Special Direct Debit Flag 
Def(Th):",
	strdcflag          	string       comment "Def(En): Direct Credit Flag
Def(Th):",
	strdctype          	string       comment "Def(En): Direct Credit Type
Def(Th):",
	strvendorcode      	string       comment "Def(En): Vendor Code
Def(Th):",
	strvostrocode      	string       comment "Def(En):
Def(Th):",
	strmappingglno     	string       comment "Def(En):
Def(Th):",
	strkbankacctno     	string       comment "Def(En): Kbank Account No
Def(Th):",
	strpaysupplier     	string       comment "Def(En): Repayment Method to Supplier 
Def(Th):",
	stramendverifyflag 	string       comment "Def(En): Amend Verify Flag
Def(Th):",
	stramendby         	string       comment "Def(En): Amend By
Def(Th):",
	stramenddate       	date         comment "Def(En): Amend Date
Def(Th):",
	stramendverifyby   	string       comment "Def(En): Amend Verify By
Def(Th):",
	stramendverifydate 	date         comment "Def(En): Amend Verify Date
Def(Th):",
	strrmcode          	string       comment "Def(En):
Def(Th):",
	strrmname          	string       comment "Def(En):
Def(Th):",
	strsegment         	string       comment "Def(En):
Def(Th):",
	strspokeid         	string       comment "Def(En):
Def(Th):",
	stractiveflag      	string       comment "Def(En): Active Flag
Def(Th):",
	strprocessflag     	string       comment "Def(En): Process Flag
Def(Th):",
	strverifyflag      	string       comment "Def(En): Verify Flag
Def(Th):",
	strverifyby        	string       comment "Def(En): Verify By
Def(Th):",
	strverifydate      	date         comment "Def(En): Verify Date
Def(Th):",
	strreturnflag      	string       comment "Def(En): Return Flag
Def(Th):",
	strreturnrem       	string       comment "Def(En): Return Remark
Def(Th):",
	strdelverifyflag   	string       comment "Def(En): Delete Verify Flag 
Def(Th):",
	strdelverifyby     	string       comment "Def(En): Delete Verify By
Def(Th):",
	strdelverifydate   	date         comment "Def(En): Delete Verify Date
Def(Th):",
	strcreateuser      	string       comment "Def(En): Create User
Def(Th):",
	dtecreatedate      	timestamp    comment "Def(En): Create Date
Def(Th):",
	strupduser         	string       comment "Def(En): Update User
Def(Th):",
	dteupddate         	timestamp    comment "Def(En): Update Date
Def(Th):",
	stronlineflag      	string       comment "Def(En): Online Flag
Def(Th):",
	strrequiretopupflag	string       comment "Def(En): Require Topup Flag
Def(Th):",
	strdocid           	string       comment "Def(Th): เลขที่เอกสารสำคัญ
Def(Th):",
	strdocid           	string       comment "Def(Th): เลขที่เอกสารสำคัญ
Def(Th):",
	strcisno           	string       comment "Def(Th): หมายเลข CIS
Def(Th):",
	strdoctype         	string       comment "Def(Th): ประเภทเอกสารสำคัญที่ระบุใน STRDOCID
Def(Th):",
	load_tms           	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id         	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy           	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm             	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd             	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_scf/scf_customer' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);