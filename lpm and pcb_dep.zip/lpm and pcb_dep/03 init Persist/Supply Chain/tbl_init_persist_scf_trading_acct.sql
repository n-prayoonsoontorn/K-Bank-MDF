-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_scf_trading_acct.sql
# Area: scf
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 2024-03-10    Tanatchporn S.         Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_SCF.SCF_TRADING_ACCT
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_scf.scf_trading_acct (
	pos_dt      	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	strsponsorid	string       comment "Def(En): Sponsor ID
Def(Th):",
	strbuysellid	string       comment "Def(En): Buyer / Seller ID
Def(Th):",
	strprodtype 	string       comment "Def(En): Product Type 
Def(Th):",
	inttradingno	integer      comment "Def(En): Trading No
Def(Th):",
	intacctseq  	integer      comment "Def(En): Account Sequence
Def(Th):",
	strownerflag	string       comment "Def(En): Owner Flag
Def(Th):",
	strdcflag   	string       comment "Def(En): Debit/Credit Flag
Def(Th):",
	stracctno   	string       comment "Def(En): Account No
Def(Th):",
	intacctseq  	string       comment "Def(En): Default Flag
Def(Th):",
	strownerflag	string       comment "Def(En): Active Flag 
Def(Th):",
	strdcflag   	string       comment "Def(En): Create User
Def(Th):",
	stracctno   	timestamp    comment "Def(En): Create Date
Def(Th):",
	intacctseq  	string       comment "Def(En): Update User
Def(Th):",
	strownerflag	timestamp    comment "Def(En): Update Date
Def(Th):",
	strdcflag   	string       comment "Def(En): Account Type
Def(Th):",
	load_tms    	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id  	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy    	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm      	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd      	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_scf/scf_trading_acct' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);