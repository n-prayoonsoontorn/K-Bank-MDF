from collections import Counter
import json
import os
import openpyxl
import response
import utility




def load_workbook(excel_file, sheet_name):
    try:
        workbook = openpyxl.load_workbook(excel_file,data_only=True)
        if sheet_name in workbook.sheetnames:
            selected_sheet = workbook[sheet_name]
            print(f"Loaded worksheet '{sheet_name}' from Excel file '{excel_file}' successfully.")
            print(f"Number of rows: {selected_sheet.max_row}, Number of columns: {selected_sheet.max_column}")

            utility.replace_stars(selected_sheet)
            return selected_sheet
        else:
            print(f"Worksheet '{sheet_name}' not found in the Excel file.")
            return None
    except Exception as e:
        print(f"Error loading the Excel file: {e}")
        return None   


def search_keywords(worksheet):
    keywords_right = {
        "Area Name": None,
        "File Format": None,
        "File Extension": None,
        "Source Schema Name": None,
        "Source Table Name": None,
        "Target Schema Name": None,
        "Target Table Name": None,
        "Partition Key": None,
        "Header Flag": None,
        "File Delimiter": None,
        "Column Name Flag": None,
        "Control File Flag" : None,
        "Label Header Flag" : None,
        "Label Tailor Flag" : None,
        "Header Total Records Position": None,
        "Tailor Total Records Position": None,
        # "Data Frequency" : None,
    }
    keywords_below = {
        "Source System Name": None,
    }
    keywords_left = {
    }
    ##-------------CUSTOM SEARCH--------- ##
    keyword_source_filename = {
        "Source File Name/ File Path": None,
    }
  
    keywords_encryped_field = {
        "cardencryptedpb" : None,
    }
    keywords_get_datatype = {
        "find_datatype_partition": None,
    }
    keywords_sys_id = {
        "src_sys_id": None
    }
    keywords_ingestion_method = {
        "Ingestion Method": None
    }
    keywords_job_name = {
        "Job Name": None,
    }

    results_source_filename  = utility.search_keywords_source_filename(worksheet,keyword_source_filename)
    results_ingestion_method = utility.search_keywords_ingestion_method(worksheet,keywords_ingestion_method)
    results_job_name = utility.search_keywords_job_name(worksheet,keywords_job_name)
    results_sys_id = utility.search_keywords_sys_id(worksheet,keywords_sys_id)
    results_right = utility.search_keywords_right(worksheet,keywords_right)
    results_left = utility.search_keywords_left(worksheet,keywords_left)
    results_below = utility.search_keywords_below(worksheet,keywords_below)
    # results_datatype = utility.get_datatype_as_string(worksheet,results_right["Extraction Logic"],keywords_get_datatype)


    results = {**results_right, **results_below , **results_left,**results_sys_id, **results_ingestion_method, **results_source_filename,**results_job_name}
    return results

if __name__ == "__main__":
    


    
    path_in = "/Users/n.prayoonsoontorn/Downloads/script-foundation-config-for-inbound/input/"
    path_out = "/Users/n.prayoonsoontorn/Downloads/script-foundation-config-for-inbound/output/"

    sheet_name = "mdp_request_field"
    
    count = 0
    failed = []
    #---------  for investigation ---------
    parquet_file = []
    uniq_job_name = []
    text_file = []

    base_dir = []
    #--------------------------------------
    for dir_name in os.listdir(path_in):
        if dir_name != ".DS_Store":
            dir_path = os.path.join(path_in, dir_name)
            if os.path.isdir(dir_path):
                for filename in os.listdir(dir_path):
                    if filename != ".DS_Store":
                        count += 1
                        file_path = os.path.join(dir_path, filename)
                        worksheet = load_workbook(file_path, sheet_name)
                        results = search_keywords(worksheet)

                        results["Partition Key"] =  results["Partition Key"].replace(" ", "")
                        results["Extraction Logic"] = results.get("Partition Key", "")
                        results["File Delimiter"] = results.get("File Delimiter", "").split(' ')[0].lower()
                        results["File Format"] = results.get("File Format", "").split(' ')[0].lower()
                        results["src_sys_id"] = str(utility.extract_number_with_regex(results["src_sys_id"][1]))
                        

                        
                        ##Columns
                        columnsTargetName =results["ColumnsNameM"] = utility.get_all_value_from_column(worksheet,"M")
                        columnsIsMandat =results["ColumnsNameN"] = utility.get_all_value_from_column(worksheet,"N")
                        
                        columnsMain =results["ColumnsNameB"] = utility.get_all_value_from_column(worksheet,"B")
                        columnsSourceName =results["ColumnsNameX"] = utility.get_all_value_from_column(worksheet,"X")

                        results["MainColumnns"] = columnsMain
                        results["SourceNameColumns"] =  columnsSourceName



                        ##get primaryKey to list for delta
                        pk_list = []
                        for pair1, pair2 in zip(columnsTargetName, columnsIsMandat):
                            if pair1[1] is None:
                                continue  # Skip to next index if value is None
                            if pair2[1] is None:
                                continue
                            if "(pk)" in pair2[1].lower():
                                pk_list.append(pair1[1])
                        results["PK List"] = pk_list


                    

                        json_config = response.build_json(worksheet, results)
                        job_name = results["Job Name"]
                        output_file = "job_config_"+job_name+".json"
                        
                        # path_out = path_out+"/"+output_file
                        output_path = os.path.join(path_out, dir_name, output_file)
                        os.makedirs(os.path.dirname(output_path), exist_ok=True)

                        #---------  for investigation ---------
                        if results.get("File Extension") == 'parquet':
                            parquet_file.append(filename)
                        elif results.get("File Extension") == 'txt':
                            text_file.append(filename)
                        if job_name not in uniq_job_name:
                            uniq_job_name.append(job_name)
                        base_dir.append([json_config["job_info"]["persist_table_name"], json_config["tasks"]["search_source_file_task"]["parameters"]["base_directory"]])
                        #--------------------------------------

                        try:
                            with open(output_path, "w") as json_file:
                                print(output_path)
                                json.dump(json_config, json_file, indent=4, ensure_ascii=False)
                            print(f"\nJSON data has been written to {output_file}\n")   
                        except:
                            failed.append(filename)
                        
            
    
    print("Done writing", count, "files to", path_out)
    print(failed)

    print("Totak parquet file:", len(parquet_file))
    print("-"*50)
    print("Totak text file:", len(text_file))
    print("-"*50)
    print("Total unique job name:",len(uniq_job_name))
 