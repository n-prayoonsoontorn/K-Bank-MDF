import utility
import json
#mook add
import os
# import pandas as pd

env = "{{env}}"
catalog_name = "mdp"+env
pipeline_name = "IngestionPipeline"

# def filter_cond_selecter is for 'filter_cond' in "read_source_file_task" of Parquet file
def filter_cond_selecter(extraction_logic):
    
    keyword_to_value = {
        "ptn_dd": "ptn_dd = '{{ptn_dd}}'",
        "ptn_mm": "ptn_mm = '{{ptn_mm}}'",
        "ptn_qtr": "ptn_qtr = '{{ptn_dd}}'",
        "ptn_yyyy": "ptn_yyyy = '{{ptn_yyyy}}'"
    }

    keywords = extraction_logic.split(',')

    values = [keyword_to_value[keyword] for keyword in keywords if keyword in keyword_to_value]

    result = ' AND '.join(values)

    return result

# def partition_selecter is for 'partition' in 'base_directory' of Text and CSV file
def partition_selecter(extraction_logic):
    keyword_to_value = {
        "ptn_dd": "ptn_dd={{ptn_dd}}",
        "ptn_mm": "ptn_mm={{ptn_mm}}",
        "ptn_qtr": "ptn_qtr={{ptn_qtr}}",
        "ptn_yyyy": "ptn_yyyy={{ptn_yyyy}}"
    }

    # Split the extr string into individual keywords
    keywords = extraction_logic.split(',')

    # Use a list comprehension to extract the corresponding values
    values = [keyword_to_value[keyword] for keyword in keywords if keyword in keyword_to_value]

    # Join the values into a comma-separated string
    result = '/'.join(values)
    
    if result != "":
        return result+'/'
    else:
        return result
 

def build_task(worksheet, results):

    target_database = results["Source System Name"]
    raw_target_database = "raw_"+target_database
    table_name = results["Target Table Name"]
    persist_target_database = "persist_"+target_database
    target_table_name = results["Target Table Name"]
    task_file_extension = "parquet"
    database_table = '.'.join([catalog_name, raw_target_database, target_table_name])
            
    delimiter = results["File Delimiter"]
    delimiter = utility.remove_quotes(delimiter)

    columnsMain = {inner_list[1]: inner_list[0] for inner_list in results["MainColumnns"]}
    columnsSourceName =  {inner_list[0]: inner_list[1] for inner_list in results["SourceNameColumns"]}
    value_to_search_main = "" #for find index columnsMain
    indexColumns = 0 #for get idex columnsMain
    nameOfTotalRecord = ""

    # results["SourceNameColumns"] =  columnsSourceName

    if results["Header Total Records Position"] and int(results["Header Total Records Position"]) > 0:
        value_to_search_main = 'Header Label'
        indexColumns = columnsMain.get(value_to_search_main)
        indexColumns += int(results["Header Total Records Position"])
        nameOfTotalRecord = columnsSourceName.get(indexColumns)

    elif results["Tailor Total Records Position"] and int(results["Tailor Total Records Position"]) > 0:
        value_to_search_main = 'Tailor Label'
        indexColumns = columnsMain.get(value_to_search_main)
        indexColumns += int(results["Tailor Total Records Position"])
        nameOfTotalRecord = columnsSourceName.get(indexColumns)


    if delimiter == "\\u0001":
        delimiter = "\u0001"

    header = results["Column Name Flag"]
    #header = "y"
    if header.lower() == "y":
        header = "True"
        parameter = {
                "reader_options": {
                                   "delimiter": delimiter,
                                   "header": header
                                   }
            }
    else:   
        header = "False"
        parameter = {
                "reader_options": {
                                   "delimiter": delimiter,
                                   "header": header
                                   },
                "ref_schema": {
                    "database_table": database_table
                    
                }
            }
        if results['File Extension'] in ['txt','csv']: 
            parameter["ref_schema"]["exclude_columns"] = ["pos_dt", "load_tms","src_sys_id","ptn_yyyy","ptn_mm","ptn_dd"]

    values_to_check = ["cis"]
    source_system_names = results["Source System Name"]

    if source_system_names in values_to_check:
        parameter["reader_options"]["quote"] = "\uFFFF"        


    
    base_directory_template_txt = "/Volumes/mdp{{{{env}}}}/inbound/source_file/mdp/{}/"
        


        
    
    fileName = utility.convert_format_date(results["Source File Name/ File Path"].split("\n")[0])
    if '.zip' in fileName : 
        fileName = results["Source File Name/ File Path"].split("\n")[1].replace("(","").replace(")","")
        fileName = utility.convert_format_date(fileName)



    fileFormatText = ""
    base_directory = ""
    fileNameTobeUse= ""

    if results["Source File Name/ File Path"].endswith(".txt"):
        fileFormatText = utility.transform_file_extension(fileName,"txt")
        
        base_directory = base_directory_template_txt.format(results["Source System Name"])
        fileNameTobeUse = fileFormatText

    else:
        base_directory = base_directory_template_txt.format(results["Source System Name"])
        fileNameTobeUse = fileName
        

    
    filter_cond = filter_cond_selecter(results["Extraction Logic"])
    partition = partition_selecter(results["Extraction Logic"])

    result_map = utility.get_column_params(worksheet ,results["Extraction Logic"])
    column_params = utility.column_params(results["Extraction Logic"], result_map)
    if "ptn_qtr" in column_params:
        if "int" in column_params["ptn_qtr"]:
            partition = partition.replace("{{ptn_qtr}}","{{ptn_qtr|int}}")
    if "ptn_mm" in column_params:
        if "int" in column_params["ptn_mm"]:
            partition = partition.replace("{{ptn_mm}}","{{ptn_mm|int}}")
    if "ptn_dd" in column_params:
        if "int" in column_params["ptn_dd"]:
            partition = partition.replace("{{ptn_dd}}","{{ptn_dd|int}}")
    

    # ingestion_spec_path
    ingestion_spec_file_name = "ingest_spec_"+table_name
    
    ingestion_spec_path = "/Volumes/mdp"+env+"/artifact/mapping/mdp/ingest/"+target_database+"/"+ingestion_spec_file_name+".json"
    
   
     
    system_columns_type = "StandardSystemColumns"
    if results["Ingestion Method"] == "delta":
        system_columns_type = "IncrementalSystemColumns"
        
    
    csv_task = {
        #same as txt task
    }

    xml_task = {
        "xml_task": "mock"
    }

    json_task = {
        "json_task": "mock"
    }

    dat_task = {
        "dat_task": "mock"
    }
    
    json_task = {
        "json_task": "mock"
    }

    dat_task = {
        "dat_task": "mock"
    }
    
    parquet_task = {
    }

    txt_task = {
        "search_source_file_task": {
            "module_name": "GlobSearchSourcePathTask",
            "bypass_flag": "False",
            "parameters": {
                "base_directory": base_directory+fileNameTobeUse,
                "allow_empty_flag": "False"
            }
        },
          "read_source_file_task": {
         ##wait to pick what format
        },
        "transform_to_raw_task": {
            "module_name": "AddColumnsDataTnfmTask",
            "bypass_flag": "False",
            "parameters": {
                "system_column_type": "StandardSystemColumns",
            }
        },
        "load_to_raw_task": {
            "module_name": "FullDumpDataLoaderTask",
            "bypass_flag": "False",
            "parameters": {
                "target_catalog_name": catalog_name,
                "target_database_name": raw_target_database,
                "target_table_name": table_name,
                "format": task_file_extension
            }
        },
        "read_raw_from_table_task": {
            "module_name": "TableSourceReaderTask",
            "bypass_flag": "False",
            "parameters": {
                "target_catalog_name": catalog_name,
                "target_database_name": raw_target_database,
                "target_table_name": table_name,
                "filter_cond": filter_cond
            }
    },
        "transform_to_persist_task": {
            "module_name": "IngtSpecDataTnfmTask",
            "bypass_flag": "False",
            "parameters": {
                "system_column_type": system_columns_type,
                "ingestion_spec_path": ingestion_spec_path
            }
        },
        "load_to_persist_task": {
          ##wait to pick what format
        },
        "record_count_check_task": { 
            "module_name": "IngestionRecordCountCheckTask",
            "bypass_flag": "False", 
            "parameters": {
                "raw_database_table": catalog_name+"."+raw_target_database+"."+table_name,
                "raw_filter_cond": filter_cond,
                "persist_database_table": catalog_name+"."+persist_target_database+"."+table_name,
                "persist_filter_cond": filter_cond
            }  
        },
        "control_file_record_count_check_task": {
          ##wait to pick what format
        },
        "audit_data_task":{
            "module_name":"DataAuditingTask",
            "bypass_flag":False,
            "parameters":{
                "config_path":"/Volumes/mdp{{env}}/artifact/config/mdp/audit/ingest/" + source_system_names + "/audit_config_" + persist_target_database + "_" + table_name + ".json",
                "target_database_table":"mdp{{env}}." + persist_target_database + "." + table_name,
                "filter_cond": filter_cond,
                "exit_when_validation_error":True
            }
        }
    }
   
    json_task = {
        "json_task": "mock"
    }

    dat_task = {
        "dat_task": "mock"
    }
    

 
    #check Addition what type of ingestion method 
    ingest_method = results["Ingestion Method"]
    ingestion_method_map = {
       
        "fulldump" : {
          "module_name": "FullDumpDataLoaderTask",
            "bypass_flag": "False",
            "parameters": {
                "target_catalog_name": catalog_name,
                "target_database_name": persist_target_database,
                "target_table_name": table_name
            }
        },
        #getbackdone
        "delta" : {
            "module_name": "IncrementalDataLoaderTask",
            "bypass_flag": "False",
            "parameters": {
                "target_catalog_name": catalog_name,
                "target_database_name": persist_target_database,
                "target_table_name": table_name,
                "primary_keys": results["PK List"],
                "previous_data_filter_cond" : "int(ptn_yyyy) = year(cast('{{pos_dt}}' as date) - interval 1 day) and int(ptn_mm) = month(cast('{{pos_dt}}' as date) - interval 1 day) and int(ptn_dd) = day(cast('{{pos_dt}}' as date) - interval 1 day)"
            }
        }
    }

    
    if ingest_method in ingestion_method_map:
        txt_task["load_to_persist_task"] = ingestion_method_map[ingest_method]
        
    else:
        print("No action defined for ingestion_method =", ingest_method)
    
    
    
    
    #check Addition what type that retrieve from source (Ex.delimited ,fixlength)   
    
    file_format = results["File Format"] 
    action_map = {
        "f": {
            "module_name": "FixedLengthSourceFileReaderTask",
            "bypass_flag": False,
            "parameters": {
                "length_mapping_config_path": "/Volumes/mdp"+env+"/artifact/mapping/mdp/ingest/"+target_database+"/ingest_spec_"+table_name+ "_fixed_length.json"
            }                
        },
        "d": {
            "module_name": "DelimitedSourceFileReaderTask",
            "bypass_flag": "False",
            "parameters": parameter

        }
    }
    
    # Perform the action based on the value of 
    
    if file_format in action_map:
        txt_task["read_source_file_task"] = action_map[file_format]
        if file_format == "d":  
            if results["Label Header Flag"] == "y":
                txt_task["read_source_file_task"]["parameters"]["number_of_row_header"] = 1
            if results["Label Tailor Flag"] == "y":
                txt_task["read_source_file_task"]["parameters"]["number_of_row_footer"] = 1
        elif file_format == "f":  
            if results["Label Header Flag"] == "y":
                txt_task["read_source_file_task"]["parameters"]["number_of_row_header"] = 1
            if results["Label Tailor Flag"] == "y":
                txt_task["read_source_file_task"]["parameters"]["number_of_row_footer"] = 1

    else:
        print("No action defined for format =", file_format)


     #check Addition on config file flag 
    if results["Control File Flag"] == 'y':
        
        fileNameCtl  = utility.transform_file_extension(fileName,"ctl")
        txt_task["control_file_record_count_check_task"] = {
            "module_name": "PairedControlFileCheckerTask",
            "bypass_flag": "False",
            "parameters": {
                "control_file_path": base_directory + fileNameCtl,
                "file_type": "delimited",
                "reader_options": {
                                   "delimiter": "|",
                                   "header": "True"
                                   },
                "record_count_column": "number_of_records"
            }
        }

    else:
        if results["File Format"] == "f":  
            txt_task["control_file_record_count_check_task"] = {
                    "module_name": "FixedLengthControlFileCheckerTask",
                    "parameters": {
                        "control_file_path": base_directory + fileNameTobeUse,
                        "length_mapping_config_path": "/Volumes/mdp"+env+"/artifact/mapping/mdp/ingest/"+target_database+"/ingest_spec_"+table_name+ "_fixed_length.json",
                        "record_count_column": nameOfTotalRecord,                   
                    }
                } 

        elif results["File Format"] == "d":  
        # fileNameText = utility.transform_file_extension(fileName,"txt")
            txt_task["control_file_record_count_check_task"] = {
                        "module_name": "DelimitedControlFileCheckerTask",
                        "bypass_flag": "False",
                        "parameters": {
                            "control_file_path": base_directory + fileNameTobeUse,
                        }
                    } 
            
            header = results["Column Name Flag"]
            # header = "y"
            if header.lower() == "y":
                header = "True"
                paraForConReadDataFile = {
                        "reader_options": {
                                        "delimiter": delimiter,
                                        "header": header
                                        }
                    }
            else:
                header = "False"
                paraForConReadDataFile =  {
                            "reader_options": {
                                            "delimiter": delimiter,
                                            "header": header
                                            },
                            "ref_schema": {
                                "database_table": database_table
                            }
                        }
                if results['File Extension'] == 'txt': 
                    paraForConReadDataFile["ref_schema"]["exclude_columns"] = ["pos_dt","load_tms","src_sys_id","ptn_yyyy","ptn_mm","ptn_dd"]

            ingestion_spec_path = "/Volumes/mdp"+env+"/artifact/mapping/mdp/ingest/"+target_database+"/"+ingestion_spec_file_name+".json"
            txt_task["control_file_record_count_check_task"]["parameters"].update(paraForConReadDataFile)
        
        
        #check for control that read datafile
        if results["Label Header Flag"] == "y":
                txt_task["control_file_record_count_check_task"]["parameters"]["number_of_row_header"] = 1
        if results["Label Tailor Flag"] == "y":
                txt_task["control_file_record_count_check_task"]["parameters"]["number_of_row_footer"] = 1   

        target_position = None
        target_name = None

        if "Header Total Records Position" in results and isinstance(results["Header Total Records Position"], str) and results["Header Total Records Position"].isdigit() and int(results["Header Total Records Position"]) > 0:
            target_position = "header"
            target_name = "header"
        
        elif "Tailor Total Records Position" in results and isinstance(results["Tailor Total Records Position"], str) and results["Tailor Total Records Position"].isdigit() and int(results["Tailor Total Records Position"]) > 0:
            target_position = "footer"
            target_name = "tailor"

        if target_position:
            txt_task["control_file_record_count_check_task"]["parameters"]["record_count_index"] = {
                target_position: {
                    "column_index": int(results[target_name.capitalize() + " Total Records Position"]) - 1,
                    "row_index": 0
                }
            }


    ##If = delta
    if results["Ingestion Method"] == "delta" :
        check_dependency_task = {
            "module_name": "DependencyCheckingTask",
            "bypass_flag": "False",
            "parameters": {
                "dpnd_config_path": "/Volumes/mdp{{env}}/artifact/config/mdp/dpnd/ingest/"+source_system_names+"/persist/dpnd_"+results.get("Job Name")+".json"
            }
        }
        # Add the new module to the beginning of the txt_task dictionary
        txt_task = {**{"check_dependency_task": check_dependency_task}, **txt_task}   
        txt_task["record_count_check_task"]["module_name"] = "IncrementalRecordCountCheckTask"
    
    ##SRC SYS HAVE MULTILINE
    if results["Source System Name"] in ["scf","dgtl_fctrng","ud"]:
        txt_task["read_source_file_task"]["parameters"]["reader_options"]["multiLine"] = "True"

        
    #CHECK IF NOT HAVE CONTROL FILE AND IN DATA FILE NOT HAVE HEADER NAD TAILER
    if (results["Control File Flag"] == 'n' and
    results["Label Header Flag"] == "n" and
    results["Label Tailor Flag"] == "n"):
        txt_task.pop("control_file_record_count_check_task", None)


    if filter_cond == "":
        parquet_task.pop("transform_to_raw_task")
        txt_task.pop("transform_to_raw_task")

    
    


    #foundation
    file_extension = results.get("File Extension")
    switcher = {

        "parquet": parquet_task,
        "txt": txt_task,
        "csv": txt_task  ##same with text_task except file format
    }


    task = switcher.get(file_extension, "file_extension_not_found")
    
    return task

def build_json(worksheet, results):
    
    tasks = build_task(worksheet, results)
    
    #change pipeline name later
    

    job_info = {
        "source_name": results.get("Source System Name"),
        "source_system_id": results.get("src_sys_id"),
        "area_name": results.get("Area Name"),
        "raw_catalog_name": catalog_name,
        "raw_database_name": "raw_"+results.get("Source System Name"),
        "raw_table_name": results.get("Target Table Name"),
        "persist_catalog_name": catalog_name,
        "persist_database_name": results.get("Target Schema Name"),
        "persist_table_name": results.get("Target Table Name")
    }

    json_data = {
        "job_name": results.get("Job Name"),
        "pipeline_name": pipeline_name,
        "job_info": job_info,
        "tasks": tasks
    }
    
    return json_data
