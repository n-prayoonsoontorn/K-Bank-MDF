-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: tbl_init_persist_csm_custxformxconsentnonkblog.sql
# Area: csm
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....             Description....
#----------------------------------------------------------------------------------------------------
# 2024-08-21   Tanatchporn S.       Initial Version
#
# Target table(s)/view(s): ${catalog}.PERSIST_CSM.CSM_CUSTXFORMXCONSENTNONKBLOG
#--------------------------------------------------------------------------------------------------*/

-- COMMAND --

create table if not exists ${catalog}.persist_csm.csm_custxformxconsentnonkblog (
	pos_dt                      	date         comment "Def(En): Position Date
Def(Th): วันที่ของข้อมูล",
	lcustfcnkb_id_card          	string       comment "Def(En): Document ID
Def(Th): เลขที่เอกสารสำคัญ",
	lcustfcnkb_birth_date       	date         comment "Def(En): Birthdate
Def(Th): วันที่เกิด",
	lcustfcnkb_doc_type         	string       comment "Def(En): Document type
Def(Th): ประเภทเอกสารสำคัญ",
	lcustfcnkb_form_id          	integer      comment "Def(En): Form ID
Def(Th): เลขที่ฟอร์มสำหรับกรอก consent",
	lcustfcnkb_consent_eff_date 	timestamp    comment "Def(En): Effective date
Def(Th): วันที่ให้ consent",
	lcustfcnkb_consent_exp_date 	timestamp    comment "Def(En): Expire date
Def(Th): วันที่สิ้นสุดค่า consent",
	lcustfcnkb_re_consent_date  	date         comment "Def(En): Reconsent date
Def(Th): วันที่ต้องถาม consent ใหม่",
	lcustfcnkb_channel_cd       	string       comment "Def(En): Channel code
Def(Th): ช่องทางที่ให้ consent",
	lcustfcnkb_originate_product	string       comment "Def(En): Originate product
Def(Th): product ที่ทำรายการที่ให้ consent",
	lcustfcnkb_evidence_url     	string       comment "Def(En): Evidence URL
Def(Th): URL รูปภาพหลักฐานการให้ consent",
	lcustfcnkb_consent_flag     	string       comment "Def(En): Consent flag
Def(Th): ค่า consent ที่ลูกค้าให้",
	lcustfcnkb_upd_user         	string       comment "Def(En): Update by UserID
Def(Th): user ที่แก้ไขข้อมูล",
	lcustfcnkb_upd_user_name    	string       comment "Def(En): Update by User name
Def(Th): ชื่อ-นามสกุล ของ user
(No value in phase1)",
	lcustfcnkb_upd_user_deptcd  	string       comment "Def(En): Department code of user
Def(Th): รหัสหน่วยงานของ user ที่ทำรายการ
(No value in phase1)",
	lcustfcnkb_upd_user_deptnm  	string       comment "Def(En): Department name of user
Def(Th): ชื่อหน่วยงานของ user ที่ทำรายการ
(No value in phase1)",
	lcustfcnkb_upd_dt           	timestamp    comment "Def(En): Update date
Def(Th): วันที่อัพเดทข้อมูล",
	lcustfcnkb_upd_dt_group     	timestamp    comment "Def(En): Update date group
Def(Th): วันที่ใช้สำหรับ group ข้อมูลที่ update เป็นชุดเดียวกัน",
	lcustfcnkb_upd_user_l       	string       comment "Def(En): Update by UserID
Def(Th): User ที่แก้ไขข้อมูล",
	lcustfcnkb_upd_dt_l         	timestamp    comment "Def(En): Update log date
Def(Th): วันที่ log ข้อมูล",
	load_tms                    	timestamp    comment "Def(En): The timestamp on which the instance of the entity was last updated.
Def(Th): วันที่ที่ระบบได้รับข้อมูลล่าสุด",
	src_sys_id                  	string       comment "Def(En): Source system ID
Def(Th):เลขที่แสดงระบบงาน",
	ptn_yyyy                    	string       comment "Def(En): Partition Year (YYYY)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับปี",
	ptn_mm                      	string       comment "Def(En): Partition Month (MM)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับเดือน",
	ptn_dd                      	string       comment "Def(En): Partition Date (DD)
Def(Th): พาทิชั่นฟิลด์แบ่งข้อมูลระดับวัน",
	upd_tms                     	timestamp    comment "Def(En): Partition field - Record update timestamp
Def(Th):"
) using delta partitioned by (ptn_yyyy, ptn_mm, ptn_dd) location 'abfss://${storage_persist}/${catalog}/persist_csm/csm_custxformxconsentnonkblog' tblproperties (
	'delta.minreaderversion' = '2',
	'delta.minwriterversion' = '5',
	'delta.columnmapping.mode' = 'name'
);