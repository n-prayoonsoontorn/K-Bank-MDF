import os
import pandas as pd
from datetime import datetime
import re

# CBR input path
excel_files_directory = "/Users/n.prayoonsoontorn/Downloads/script_create_gen_ddl_physical/CBR Input/"



# init raw output path
raw_output_directory = "/Users/n.prayoonsoontorn/Downloads/script_create_gen_ddl_physical/Raw Output/"

# init persist output path
persist_output_directory = "/Users/n.prayoonsoontorn/Downloads/script_create_gen_ddl_physical/Persist Output/"

# initial string
catalog_name = '${catalog}'
environment = '${env}'
raw_table_init_location_storage = f'abfss://raw@stmdpsea{environment}raw001.dfs.core.windows.net/{catalog_name}/'
persist_table_init_location_storage = f'abfss://persist@stmdpsea{environment}per001.dfs.core.windows.net/{catalog_name}/'
CREATE_TABLE_IF_NOT_EXISTS = "CREATE TABLE IF NOT EXISTS"
CREATE_OR_REPLACE = "CREATE OR REPLACE TABLE"

# Change Revision detail -> Change create by name, and version message
create_dt = datetime.now().strftime('%Y-%m-%d')
create_by = 'Tanatchporn S.'
version = 'Initial Version'

x = datetime.now().strftime('%Y-%m-%d_%H_%M_%S')

success_count = 0
failure_count = 0

def generate_ddl(excel_file, raw_path, persist_path, cbr):
    global success_count, failure_count

    df = pd.read_excel(excel_file, sheet_name=None, header=None)
    for sheet_name, data in df.items():
        if 'mdp_request_field' in sheet_name.lower() and not any(keyword in sheet_name.lower() for keyword in ['Revision History', 'LOV', 'old request', 'Standard Naming']):
            try:
                read_cbr_file = pd.ExcelFile(excel_file).parse("mdp_request_field", skiprows=28, index_col=None, na_values=['NA'])
                v_seq = read_cbr_file["V Seq."].to_list()

                # Get table name from CBR
                table_name = data.iloc[10, 8].lower().replace("\n", "").replace(" ", "")

                # Set raw output file name
                raw_output_file_name = f"tbl_init_raw_{table_name.lower()}.sql"

                # Get area from CBR
                area = data.iloc[3, 1].lower()

                # Get schema from CBR
                schema_name = "raw_" + str(data.iloc[3, 1].lower())
                partition_key = data.iloc[19, 2].lower()

                # Set schema persist
                schema_name_persist = "persist_" + str(data.iloc[3, 1].lower())

                # Initial start row
                start_row = 29
                end_row = len(data)
                end_row_find_columns = end_row

                # Initial start column
                column_no = 11
                
                #End row value
                end_row_columns_persist_value=""
                while end_row_find_columns-1 > 0:
                    end_row_columns_persist_value = str(data.iloc[end_row_find_columns - 1, column_no+1])
                    
                    if end_row_columns_persist_value != "upd_tms":
                        break
                    end_row_find_columns -= 1

                print(end_row_columns_persist_value)
                
                # Check header label and move start row to another
                if "Header Label" in v_seq:
                    start_row = start_row + (v_seq.index("Body")) + 1
                    end_row = 29 + (v_seq.index("Tailor Label"))
                    end_row_find_columns = end_row

                    while end_row > 0:
                        end_row_columns_persist_value = str(data.iloc[end_row_find_columns, column_no+1])
                    
                        if end_row_columns_persist_value != "upd_tms":
                             break
                        end_row_find_columns -= 1
                        print(end_row_columns_persist_value)

                # Check partition
                if partition_key.lower() == 'no partition':
                    partition_clause = ""
                else:
                    partitions = [p.strip() for p in partition_key.split(',')]
                    partition_clause = f"partitioned by (" + \
                                       ', '.join([f'{p.lower()}' for p in partitions]) + \
                                       ")"
                    partition_clause = partition_clause.lstrip(',')
                #startt at index 0 
                # Find column name column position
                if str(data.iloc[28, column_no]).lower() != "column name":
                    if str(data.iloc[28, column_no + 1]).lower() == "column name":
                        column_no = column_no + 1

            
                # Calculate maximum column name length
                max_col_length = 0
                for row in range(start_row, end_row):
                    if pd.notna(data.iloc[row, column_no]):
                        size = len(str(data.iloc[row, column_no]))
                        if size > max_col_length:
                            max_col_length = size

                # Calculate maximum data type + data size length
                max_type_size_length = max(
                    data.iloc[start_row:, [column_no + 2, column_no + 3]].astype(str).apply(lambda x: ' '.join(x),
                                                                                                axis=1).apply(len))
                column_strings_raw = []
                column_strings_persist = []
                i = start_row
                pos_dt_found = False
                while i < end_row:
                    # Skip empty cell
                    if not pd.notna(data.iloc[i, column_no]):
                        col = data.iloc[i, column_no+11].lower().strip().replace("\n", "").replace("-","_").replace(".","_").replace("__","_")
                        type_size_raw = "string"

                        comment = str(data.iloc[i, column_no + 18]).strip().replace('"', '\\"').replace('\\"', '').replace(
                            "_x000D_", "").strip()
                        if pd.notna(data.iloc[i, column_no + 18]) and comment != '':
                            comment = 'comment "{}"'.format(comment)
                        else:
                            comment = ''

                            # Include other columns in both raw and persist tables
                        column_string_raw = "\t{col:<{col_length}}\t{type_size_raw:<{type_size_length}} {comment}{comma}".format(
                            col=col,
                            type_size_raw=type_size_raw,
                            comment=comment,
                            col_length=max_col_length,
                            type_size_length=max_type_size_length,
                            comma="," if i < end_row - 1 else ""
                        )
                        column_strings_raw.append(column_string_raw)
                    
                        i += 1
                        continue

                    col = data.iloc[i, column_no].lower().strip().replace("\n", "")
                    type_size_raw = "string"
                    type_size_persist = data.iloc[i, column_no + 2].lower().strip().replace("\n", "").replace('\\"', '')

                    if pd.notna(data.iloc[i, column_no + 3]) and (data.iloc[i, column_no + 2].lower().strip().replace("\n", "") == "decimal"):
                        type_size_persist = '{}({})'.format(type_size_persist, data.iloc[i, column_no + 3])
                    type_size_persist = type_size_persist.replace("\\", "")

                    comment = str(data.iloc[i, column_no + 7]).strip().replace('"', '\\"').replace('\\"', '').replace(
                        "_x000D_", "").strip()
                    if pd.notna(data.iloc[i, column_no + 7]) and comment != '':
                        comment = 'comment "{}"'.format(comment)
                    else:
                        comment = ''

                    # Check conditions for record and filler columns
                    if 'record' in col and (i == start_row or i == start_row + 1 or i == start_row + 2 or i == start_row + 3):
                        if col == 'pos_dt':
                            if 'record' in data.iloc[start_row, column_no:column_no + 10].to_string(index=False).lower():
                                col_index = data.iloc[start_row, column_no:column_no + 10].to_list().index('pos_dt') + column_no
                                column_strings_raw.append(column_strings_raw.pop(column_strings_raw.index(f"\t{col_index}")))  # Move pos_dt to the end
                                pos_dt_found = True
                        column_string_raw = "\t{col:<{col_length}}\t{type_size_raw:<{type_size_length}} {comment}{comma}".format(
                            col=col,
                            type_size_raw=type_size_raw,
                            comment=comment,
                            col_length=max_col_length,
                            type_size_length=max_type_size_length,
                            comma="," if i < end_row - 1 else ""
                        )
                        column_strings_raw.append(column_string_raw)
                    elif 'filler' in col:
                        # Exclude columns containing 'filler' from persist table but keep them in raw table
                        column_string_raw = "\t{col:<{col_length}}\t{type_size_raw:<{type_size_length}} {comment}{comma}".format(
                            col=col,
                            type_size_raw=type_size_raw,
                            comment=comment,
                            col_length=max_col_length,
                            type_size_length=max_type_size_length,
                            comma="," if i < end_row - 1 else ""
                        )
                        column_strings_raw.append(column_string_raw)
                        
                    else:
                        # Include other columns in both raw and persist tables
                        if col != "upd_tms":
                            column_string_raw = "\t{col:<{col_length}}\t{type_size_raw:<{type_size_length}} {comment}{comma}".format(
                                col=col,
                                type_size_raw=type_size_raw,
                                comment=comment,
                                col_length=max_col_length,
                                type_size_length=max_type_size_length,
                                comma = "" if (i >= end_row - 1) or (col == end_row_columns_persist_value) else ","
                            )
                            column_strings_raw.append(column_string_raw)
                            
                      

                        column_string_persist = "\t{col:<{col_length}}\t{type_size_persist:<{type_size_length}} {comment}{comma}".format(
                            col=col,
                            type_size_persist=type_size_persist,
                            comment=comment,
                            col_length=max_col_length,
                            type_size_length=max_type_size_length,
                            comma="," if i < end_row - 1 else ""
                        )
                        column_strings_persist.append(column_string_persist)
                        
                    i += 1

                columns_raw = ',\n'.join(column_strings_raw)
                columns_persist = ',\n'.join(column_strings_persist)

                # Remove the comma at the beginning of the first line
                columns_raw = columns_raw.replace(",\n", "\n")
                columns_persist = columns_persist.replace(",\n", "\n")

                # Subfolder by schema name
                raw_schema_folder = os.path.join(raw_output_directory, schema_name)
                os.makedirs(raw_schema_folder, exist_ok=True)
                # set raw output file name
                raw_output_file_name = f"tbl_init_raw_{table_name.lower()}.sql"

                raw_ddl = f"-- Databricks notebook source\n" + \
                          f"/*---------------------------------------------------------------------------------------------------\n" + \
                          f"# Name: tbl_init_raw_{table_name.lower()}.sql\n" + \
                          f"# Area: {area.lower()}\n" + \
                          f"#----------------------------------------------------------------------------------------------------\n" + \
                          f"#\n" + \
                          f"# Change Revision\n" + \
                          f"#----------------------------------------------------------------------------------------------------\n" + \
                          f"# Date....      Who....             Description....\n" + \
                          f"#----------------------------------------------------------------------------------------------------\n" + \
                          f"# {create_dt}   {create_by}       {version}\n" + \
                          f"#\n" + \
                          f"# Target table(s)/view(s): {catalog_name}.{schema_name.upper()}.{table_name.upper()}\n" + \
                          f"#--------------------------------------------------------------------------------------------------*/\n" + \
                          f"\n-- COMMAND --\n" + \
                          f"\n{CREATE_TABLE_IF_NOT_EXISTS.lower()} {catalog_name}.{schema_name}.{table_name} (\n{columns_raw}\n) using delta {partition_clause} location 'abfss://${{storage_raw}}/${{catalog}}/{schema_name.lower()}/{table_name.lower()}' tblproperties (" + \
                          f"\n\t'delta.minreaderversion' = '2'," + \
                          f"\n\t'delta.minwriterversion' = '5'," + \
                          f"\n\t'delta.columnmapping.mode' = 'name'" + \
                          f"\n);"

                raw_output_file_path = os.path.join(raw_schema_folder, raw_output_file_name)
                with open(raw_output_file_path, 'w', encoding='utf-8') as f:
                    f.write(raw_ddl)

                # Subfolder by schema name
                persist_schema_folder = os.path.join(persist_output_directory, "persist_" + area)
                os.makedirs(persist_schema_folder, exist_ok=True)
                # set persist output file name
                persist_output_file_name = f"tbl_init_persist_{table_name.lower()}.sql"

                persist_ddl = f"-- Databricks notebook source\n" + \
                              f"/*---------------------------------------------------------------------------------------------------\n" + \
                              f"# Name: tbl_init_persist_{table_name.lower()}.sql\n" + \
                              f"# Area: {area.lower()}\n" + \
                              f"#----------------------------------------------------------------------------------------------------\n" + \
                              f"#\n" + \
                              f"# Change Revision\n" + \
                              f"#----------------------------------------------------------------------------------------------------\n" + \
                              f"# Date....      Who....             Description....\n" + \
                              f"#----------------------------------------------------------------------------------------------------\n" + \
                              f"# {create_dt}   {create_by}       {version}\n" + \
                              f"#\n" + \
                              f"# Target table(s)/view(s): {catalog_name}.{schema_name_persist.upper()}.{table_name.upper()}\n" + \
                              f"#--------------------------------------------------------------------------------------------------*/\n" + \
                              f"\n-- COMMAND --\n" + \
                              f"\n{CREATE_TABLE_IF_NOT_EXISTS.lower()} {catalog_name}.{schema_name_persist}.{table_name} (\n{columns_persist}\n) using delta {partition_clause} location 'abfss://${{storage_persist}}/${{catalog}}/{schema_name_persist}/{table_name}' tblproperties (" + \
                              f"\n\t'delta.minreaderversion' = '2'," + \
                              f"\n\t'delta.minwriterversion' = '5'," + \
                              f"\n\t'delta.columnmapping.mode' = 'name'" + \
                              f"\n);"

                persist_output_file_path = os.path.join(persist_schema_folder, persist_output_file_name)
                with open(persist_output_file_path, 'w', encoding='utf-8') as f:
                    f.write(persist_ddl)

                print(f"DDL generated successfully for {excel_file}")
                success_count += 1
            except Exception as e:
                print(f"Failed to generate DDL for {excel_file}. Error: {e}")
                failure_count += 1

# Iterate through Excel files in the specified directory
for (root, dirs, files) in os.walk(excel_files_directory):
    for f in files:
        # for ignore temp of opened file
        if "~" not in f and (f.endswith(".xlsx") or f.endswith(".xls")):
            generate_ddl(os.path.join(root, f), raw_output_directory, persist_output_directory, f)

print(f"Number of successful file generations: {success_count}")
print(f"Number of failed file generations: {failure_count}")