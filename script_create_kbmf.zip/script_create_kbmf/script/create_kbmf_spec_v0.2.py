import os
import openpyxl
import zipfile
import utility
from datetime import date
from openpyxl.styles import Border, Side , Alignment,Font

def collect_information(cbr_file, kbmf_template):
    cbr_processed_count = 0  # Initialize counter for successfully processed CBR files
    
    try:
        # Load CBR file
        cbr_wb = openpyxl.load_workbook(cbr_file)
        cbr_ws = cbr_wb["mdp_request_field"]
        
        # Print the name of the CBR file being processed
        print("Processing CBR file:", cbr_file)

        #SETTING FIXED FIELD
        kbmf_view_name = "KBMF - "+cbr_ws['I8'].value	 
        ##Set font colour(black)
        font = Font(color="000000")  # Hex color code for black


        
        name_of_cbr = cbr_file.split("/")[-1]    
        name_src_sys = cbr_ws['B4'].value
        directory = "/814-MDP/Foundation/Ingestion (Persist)/01 Analysis & Design/01 CBR Specification/"+name_src_sys
        # Load KBMF template
        kbmf_wb = openpyxl.load_workbook(kbmf_template)
        kbmf_ws = kbmf_wb["KBMF"]

        # Collect information

        source_table = f"{cbr_ws['I10'].value}.{cbr_ws['I11'].value}"
        service_id = f"{cbr_ws['I9'].value}.{cbr_ws['I8'].value}"
        data_frequency = cbr_ws['C12'].value
        character_encoding = cbr_ws['C16'].value
        partition_key = cbr_ws['C20'].value
        ingestion_method = cbr_ws['D4'].value



        # Write collected information to KBMF
        kbmf_ws['C4'] = service_id
        kbmf_ws['C6'] = 'Outbound View'
        kbmf_ws['C8'] = data_frequency
        kbmf_ws['D11'] = character_encoding
        kbmf_ws['D12'] = partition_key
        kbmf_ws['D13'] = ingestion_method
        kbmf_ws['D14'] = 'Persist View'


        ##Annouce and set variable
        data_for_kbmf = {}
        seq_number = 1
        align_upper_left= Alignment(horizontal="left", vertical="top",wrapText=True)
        align_upper_middle = Alignment(horizontal="center", vertical="top", textRotation=0, wrapText=True)

        border = Border(left=Side(style='thin'),
                    right=Side(style='thin'),
                    top=Side(style='thin'),
                    bottom=Side(style='thin'))
        



        ##Get Index for all 
        indexBody = utility.find_row_index_with_keywords_in_column_b_view_name(cbr_ws,"Body")
        indexTailerLabel = utility.find_row_index_with_keywords_in_column_b_view_name(cbr_ws,"Tailor Label")

        if indexBody is None or indexTailerLabel is None:
            indexBody = utility.find_row_index_with_keywords_in_column_b_view_name(cbr_ws, "V Seq.")
            indexTailerLabel = cbr_ws.max_row+1  


        
        ##Retrieve columns value here 
        confidential_data_value = utility.get_column_values_in_range_(cbr_ws,"Q",indexBody,indexTailerLabel)
        confidential_data_value = utility.replace_non_y_values_with_n(confidential_data_value)


        columns_name_value = utility.get_column_values_in_range_(cbr_ws,"D",indexBody,indexTailerLabel)
        columns_description_value =  utility.get_column_values_in_range_(cbr_ws,"E",indexBody,indexTailerLabel)
        columns_data_type_value =  utility.get_column_values_in_range_(cbr_ws,"G",indexBody,indexTailerLabel)
        columns_data_size_value =   utility.get_column_values_in_range_(cbr_ws,"H",indexBody,indexTailerLabel)
        columns_mandatory_value = utility.get_column_values_in_range_(cbr_ws,"F",indexBody,indexTailerLabel)
        columns_physical_name_value = utility.get_column_values_in_range_(cbr_ws,"M",indexBody,indexTailerLabel)

        RBAC_data_element = utility.get_column_values_in_range_(cbr_ws,"R",indexBody,indexTailerLabel)
        





        ##Set to data_for_kbmf
        data_for_kbmf['confidential_data_value'] = confidential_data_value
        data_for_kbmf['columns_data_size_value'] = columns_data_size_value
        data_for_kbmf['RBAC_data_element'] = RBAC_data_element
        data_for_kbmf['columns_name_value']  = columns_name_value
        data_for_kbmf['columns_description_value']  = columns_description_value
        data_for_kbmf['columns_data_type_value']  = columns_data_type_value
        data_for_kbmf['columns_mandatory_value']  = columns_mandatory_value
        data_for_kbmf['columns_physical_name_value']  = columns_physical_name_value




 
        
        # data_for_kbmf[columns_data_value].append(columns_data_value)




        ##Combine them for list 
        # combined_values = zip(data_for_kbmf['confidential_data_value'], data_for_kbmf['columns_data_value']) << for list that have to contains
        ##Loop our last time input to row 
        ##Check if some columns name = null we will not add that index into new KBMF
        skipped_rows = []

        for idx, (confidential_value, rbac_element, name_value, description_value, data_type_value,data_size_value, mandatory_value,physical_name_value) in enumerate(zip(data_for_kbmf["confidential_data_value"], data_for_kbmf["RBAC_data_element"], data_for_kbmf["columns_name_value"], data_for_kbmf["columns_description_value"], data_for_kbmf["columns_data_type_value"], data_for_kbmf["columns_data_size_value"],data_for_kbmf["columns_mandatory_value"],data_for_kbmf["columns_physical_name_value"] ), start=21):
            if name_value is None:
                skipped_rows.append(idx)
                continue
           
          
            kbmf_ws.row_dimensions[idx].height = 40


            kbmf_ws.cell(row=idx, column=13, value=confidential_value) 
            kbmf_ws.cell(row=idx, column=13).border = border 
            kbmf_ws.cell(row=idx, column=13).alignment = align_upper_middle  
          


            kbmf_ws.cell(row=idx, column=14, value=rbac_element) 
            kbmf_ws.cell(row=idx, column=14).border = border 
            kbmf_ws.cell(row=idx, column=14).alignment = align_upper_left 

            kbmf_ws.cell(row=idx, column=3, value=name_value) 
            kbmf_ws.cell(row=idx, column=3).border = border 
            kbmf_ws.cell(row=idx, column=3).alignment = align_upper_left 

            kbmf_ws.cell(row=idx, column=7, value=description_value) 
            kbmf_ws.cell(row=idx, column=7).border = border 
            kbmf_ws.cell(row=idx, column=7).alignment = align_upper_left 

            kbmf_ws.cell(row=idx, column=4, value=data_type_value) 
            kbmf_ws.cell(row=idx, column=4).border = border 
            kbmf_ws.cell(row=idx, column=4).alignment = align_upper_left 

            kbmf_ws.cell(row=idx, column=2, value=seq_number)
            kbmf_ws.cell(row=idx, column=2).border = border 
            kbmf_ws.cell(row=idx, column=2).alignment = align_upper_middle 


            kbmf_ws.cell(row=idx, column=5, value=data_size_value)
            kbmf_ws.cell(row=idx, column=5).border = border 
            kbmf_ws.cell(row=idx, column=5).alignment = align_upper_left 


            kbmf_ws.cell(row=idx, column=6, value=mandatory_value)
            kbmf_ws.cell(row=idx, column=6).border = border 
            kbmf_ws.cell(row=idx, column=6).alignment = align_upper_middle 


            source_table_value = "From Table : "+source_table+"\nFieldName :"+physical_name_value
            kbmf_ws.cell(row=idx, column=16, value=source_table_value)
            kbmf_ws.cell(row=idx, column=16).border = border 
            kbmf_ws.cell(row=idx, column=16).alignment = align_upper_left 
            kbmf_ws.cell(row=idx, column=16).font = font


            



            ##Keep blank columns 

            ##Comprehensive Sample Values
            kbmf_ws.cell(row=idx, column=9).border = border 
            kbmf_ws.cell(row=idx, column=9).alignment = align_upper_left 

            #Default Values Sample Values
            kbmf_ws.cell(row=idx, column=10).border = border 
            kbmf_ws.cell(row=idx, column=10).alignment = align_upper_left 


            ##Possible Values
            kbmf_ws.cell(row=idx, column=11).border = border 
            kbmf_ws.cell(row=idx, column=11).alignment = align_upper_left 


            
            ##Formula/Business Rule
            kbmf_ws.cell(row=idx, column=12).border = border 
            kbmf_ws.cell(row=idx, column=12).alignment = align_upper_left 

                   
            ##Remarks
            kbmf_ws.cell(row=idx, column=15).border = border 
            kbmf_ws.cell(row=idx, column=15).alignment = align_upper_left 


            if data_type_value == 'date':
                kbmf_ws.cell(row=idx, column=8, value='yyyy-MM-dd')
            elif data_type_value == 'timestamp':
                kbmf_ws.cell(row=idx, column=8, value='yyyy-MM-dd HH:mm:ss')
            kbmf_ws.cell(row=idx, column=8).border = border 
            kbmf_ws.cell(row=idx, column=8).alignment = align_upper_middle 


            # Increment sequential number
            seq_number += 1

        for row_idx in skipped_rows:
            kbmf_ws.delete_rows(row_idx)
  

        

        ##SET Appendix sheet
        kbmf_wa = kbmf_wb["Appendix"]
        kbmf_wa['A6'] = name_of_cbr
        kbmf_wa['A6'].alignment = align_upper_left     
        kbmf_wa['B6'] = directory 



         ##SET Cover sheet
        kbmf_wa = kbmf_wb["Cover Sheet"]
        kbmf_wa['B17'] = "Prayoonsoontorn N."
        kbmf_wa['B11'] =kbmf_view_name
        kbmf_wa['A1'] = kbmf_view_name
        today = date.today()
        kbmf_wa['E17'] =  today
    
        # Increment counter for successfully processed CBR files
        cbr_processed_count += 1

        
        # Save KBMF file
        output_filename = f"KBMF_814_{cbr_ws['I9'].value}_{cbr_ws['I8'].value}.xlsx"
        kbmf_wb.save(os.path.join("/Users/n.prayoonsoontorn/Downloads/script_create_kbmf/kbmf_output", output_filename))
        
    except zipfile.BadZipFile:
        print(f"Error: {cbr_file} is not a valid Excel file.")
    
    # Return the count of successfully processed CBR files
    return cbr_processed_count

if __name__ == "__main__":
    cbr_directory = "/Users/n.prayoonsoontorn/Downloads/script_create_kbmf/cbr_input"
    kbmf_template_file = "/Users/n.prayoonsoontorn/Downloads/script_create_kbmf/kbmf_tmp/KBMF_TMP.xlsx"
    
    total_cbr_processed = 0  # Initialize counter for total successfully processed CBR files
    
    for filename in os.listdir(cbr_directory):
        if filename.endswith(".xlsx"):
            cbr_file = os.path.join(cbr_directory, filename)
            # Increment total count by the number of CBR files processed
            total_cbr_processed += collect_information(cbr_file, kbmf_template_file)

    # Print the total number of successfully processed CBR files
    print("Total number of CBR files processed:", total_cbr_processed)


