
import openpyxl
import re
import os


def retrieve_column_values(cbr_file, column):
        # Load CBR file

        # Retrieve values from the specified column
        column_values = []
        for cell in cbr_file[column]:
            column_values.append(cell.value)

        return column_values



def find_row_index_with_keywords_in_column_b_view_name(cbr_file, keyword):

      # Find row index containing keyword
        row_index = None
        for idx, cell in enumerate(cbr_file['B'], start=1):
            if str(cell.value).lower() == keyword.lower():
                row_index = idx
                break

        return row_index


def get_column_values_in_range_(cbr_file, column_letter, start_row_index, end_row_index):

    ##-1 because start index with 0
    column_index = openpyxl.utils.column_index_from_string(column_letter) - 1  

        # Get cell values in the specified column for the given range of row indices
    column_values = []
    ##have to definition real row like 17 is Q
    for row in cbr_file.iter_rows(min_row=start_row_index+1, max_row=end_row_index-1, min_col=column_index+1, max_col=column_index+1, values_only=True):
        column_values.extend(row)

 
    return column_values


def replace_non_y_values_with_n(values):
    # Iterate over the values list and replace non-'Y' values with 'N'
    for idx, value in enumerate(values):
        if value != 'Y':
            values[idx] = 'N'
    return  values

