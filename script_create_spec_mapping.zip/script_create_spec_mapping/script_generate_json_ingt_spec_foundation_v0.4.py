import os
import pandas as pd
import json
from datetime import datetime

# CBR input path
excel_files_directory = "/Users/n.prayoonsoontorn/Downloads/script_create_spec_mapping/CBR Input/"

# Spec output path
output_base_directory = "/Users/n.prayoonsoontorn/Downloads/script_create_spec_mapping/CBR Output/"

success_count = 0
failure_count = 0

x = datetime.now().strftime('%Y-%m-%d_%H_%M_%S')

def generate_json(excel_file, output_path):
    global success_count, failure_count

    try:
        df = pd.read_excel(excel_file, sheet_name=None, header=None)
        for sheet_name, data in df.items():
            if 'mdp_request_field' in sheet_name.lower() and not any(keyword in sheet_name.lower() for keyword in ['Revision History', 'LOV', 'old request', 'Standard Naming']):

                # Read CBR file
                read_cbr_file = pd.ExcelFile(excel_file).parse("mdp_request_field", skiprows=28, index_col=None, na_values=['NA'])
                v_seq = read_cbr_file["V Seq."].to_list()

                # Get job name
                job_name = data.iloc[6, 11] if str(data.iloc[6, 11]) != "nan" else ""
                job_name = job_name.lower() if job_name else "job name is NaN"

                # Get source name
                source_name = data.iloc[3, 1] if str(data.iloc[3, 1]) != "nan" else ""
                source_name = source_name.lower() if source_name else "source name is NaN"

                # Get system name
                system_name = data.iloc[3, 1] if str(data.iloc[3, 1]) != "nan" else ""
                system_name = system_name.lower() if system_name else "raw schema is NaN"


                ##Flag value
                flag_value = str(data.iloc[20, 2]).strip().lower() if pd.notna(data.iloc[20, 2]) else ''


                raw_catalog_name = 'mdp{{env}}'
                persist_catalog_name = 'mdp{{env}}'

                raw_schema_name = f"raw_{system_name}"
                persist_schema_name = f"persist_{system_name}"

                persist_table_name = data.iloc[10, 8].replace("\n", "").replace(" ", "")
                raw_table_name = persist_table_name

                raw_table_name = raw_table_name.lower() if str(raw_table_name) != "nan" else "raw table name is NaN"
                persist_table_name = persist_table_name.lower() if str(persist_table_name) != "nan" else "persist table name is NaN"

                start_row_number = 29
                end_row = len(data)

                if "Header Label" in v_seq:
                    start_row_number += v_seq.index("Body") + 1
                    end_row = 29 + v_seq.index("Tailor Label")

                ingest_spec = {
                    "job_name": job_name,
                    "job_info": {
                        "source_name": source_name,
                        "raw_catalog_name": raw_catalog_name,
                        "raw_schema_name": raw_schema_name,
                        "raw_table_name": raw_table_name,
                        "persist_catalog_name": persist_catalog_name,
                        "persist_schema_name": persist_schema_name,
                        "persist_table_name": persist_table_name
                    },
                    "mapping": []
                }

                relevant_columns = data.iloc[:, 9:start_row_number]

                j = start_row_number
                i = start_row_number

                source_start_col = 22
                target_start_col = 11

                start_row = max(0, len(relevant_columns) - 10)

                for col_index, col_value in enumerate(relevant_columns.columns):
                    if str(col_value).lower() in ["upd_tms", "pos_dt", "load_tms", "src_system_id", "ptn_yyyy", "ptn_mm", "ptn_dd"]:
                        continue
                    if "filler" in str(col_value).lower():
                        continue
                    if any("filler" in str(data.iloc[i, target_start_col]).lower() or "record" in str(data.iloc[i, target_start_col]).lower() for i in range(start_row, len(data))):
                        continue

                for col_index, col_value in enumerate(relevant_columns.columns):
                    if str(data.iloc[28, target_start_col]).lower() != "column name":
                        if str(data.iloc[28, target_start_col+1]).lower() == "column name":
                            target_start_col += 1
                            col_index += 1
                    if str(data.iloc[28, source_start_col]).lower() != "column name":
                        if str(data.iloc[28, source_start_col+1]).lower() == "column name":
                            source_start_col += 1

                    #Annouce column logic check 
                    column_logic_check = ""

                    while i < end_row and j < end_row:
                        source_column_name = str(data.iloc[j, source_start_col]).lower().strip() if pd.notna(data.iloc[j, source_start_col]) else ""
                        target_column_name = str(data.iloc[i, target_start_col]).lower().strip() if pd.notna(data.iloc[i, target_start_col]) else ""
                        
                        
                        if (not pd.notna(source_column_name) and str(target_column_name).lower() == "pos_dt") or str(target_column_name).lower() == "rec_type":
                            j += 1
                            source_column_name = str(data.iloc[j, source_start_col]).lower().strip() if pd.notna(data.iloc[j, source_start_col]) else ""

                        if str(data.iloc[i, target_start_col+2]) != "nan":
                            data_type = f"{data.iloc[i, target_start_col+2].strip().lower()}"
                            data_type += f"({data.iloc[i, target_start_col+3]})" if pd.notna(data.iloc[i, target_start_col+3]) and data.iloc[i, target_start_col+2].strip().lower() == 'decimal' else ''
                            column_logic = ''
                            flag_tf = "False"

                            if str(data.iloc[i, target_start_col+6]) != "nan":
                                column_logic_check = f"{data.iloc[i, target_start_col+6].lower()}" if pd.notna(data.iloc[i, target_start_col+6]) else ''
                                if column_logic_check.lower() != "direct move":
                                    column_logic_check_source = f"{data.iloc[j, target_start_col+16]}" if pd.notna(data.iloc[j, target_start_col+16]) else ''
                                    year_format = f"{data.iloc[j, target_start_col+17]}" if pd.notna(data.iloc[j, target_start_col+17]) else ''
                                    if year_format == "B.E." and year_format != "" or year_format == "B.C.":
                                        flag_tf = "True"
                                    if pd.notna(column_logic_check_source):
                                        if data_type.strip().lower() == "date":
                                            column_logic = "mdp{{{{env}}}}.udf.convert_dt({}, '{}',{})".format(f'`{target_column_name}`', column_logic_check_source.replace("Y", "y").replace("m", "M").replace("s", "S").replace("D", "d").replace("h", "H").replace(":MM:", ":mm:").replace(":SS", ":ss").strip(), flag_tf)
                                        elif data_type.strip().lower() == "timestamp":
                                            column_logic = "mdp{{{{env}}}}.udf.convert_tms({}, '{}',{})".format(f'`{target_column_name}`', column_logic_check_source.replace("Y", "y").replace("m", "M").replace("s", "S").replace("D", "d").replace("h", "H").replace(":MM:", ":mm:").replace(":SS", ":ss").strip(), flag_tf)
                                        elif data_type.strip().lower() == 'string'  and  column_logic_check.lower() == "right trim and direct move":
                                            target_column_name = target_column_name.replace("'", "''")
                                            column_logic = "rtrim({})".format(f'`{target_column_name}`')
                                    else:
                                        column_logic = ""

                        if not source_column_name or not target_column_name:
                            i += 1
                            j += 1
                            continue

                        if not data_type or pd.isnull(data.iloc[i, col_index + 9]):
                            continue
                        
                        if data_type.strip().lower()  == 'string' and  column_logic_check.lower() == "right trim and direct move":
                            column_logic = "rtrim({})".format(target_column_name)


                        if flag_value == 'n':
                            source_column_name = target_column_name
                        elif flag_value == 'y':
                            source_column_name = target_column_name

                        if len(column_logic) > 0:
                            mapping_item = {
                                "source_column_name": source_column_name.replace("\n", ""),
                                "target_column_name": target_column_name.replace("\n", ""),
                                "data_type": data_type.replace("\n", ""),
                                "column_logic": column_logic
                            }
                        else:
                            mapping_item = {
                                "source_column_name": source_column_name.replace("\n", ""),
                                "target_column_name": target_column_name.replace("\n", ""),
                                "data_type": data_type.replace("\n", "")
                            }

                        ingest_spec["mapping"].append(mapping_item)

                        i += 1
                        j += 1

                schema_subfolder_path = os.path.join(output_path, system_name)
                os.makedirs(schema_subfolder_path, exist_ok=True)

                json_file_name = f"ingest_spec_{persist_table_name}.json"
                json_file_path = os.path.join(schema_subfolder_path, json_file_name)

                print(ingest_spec)
                
                print(json_file_name)

                # print(json.load(ingest_spec))
                with open(json_file_path, 'w',encoding='utf-8') as json_file:
                    json.dump(ingest_spec, json_file, indent=2 , ensure_ascii=False)

                print(f"JSON generated successfully for {excel_file}")
                success_count += 1

    except Exception as e:
        print(f"Failed to generate JSON for {excel_file}. Error: {e}")
        failure_count += 1

for root, _, files in os.walk(excel_files_directory):
    for file in files:
        if file.endswith(".xlsx") or file.endswith(".xls"):
            excel_file = os.path.join(root, file)
            relative_path = os.path.relpath(root, excel_files_directory)
            output_path = os.path.join(output_base_directory, relative_path)
            os.makedirs(output_path, exist_ok=True)
            generate_json(excel_file, output_path)

print(f"Number of successful file generations: {success_count}")
print(f"Number of failed file generations: {failure_count}")
