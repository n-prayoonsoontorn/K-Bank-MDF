from collections import Counter
import json
import os
import openpyxl

import utility



def load_workbook(excel_file, sheet_name):
    try:
        workbook = openpyxl.load_workbook(excel_file,data_only=True)
        if sheet_name in workbook.sheetnames:
            selected_sheet = workbook[sheet_name]
            print(f"Loaded worksheet '{sheet_name}' from Excel file '{excel_file}' successfully.")
            print(f"Number of rows: {selected_sheet.max_row}, Number of columns: {selected_sheet.max_column}")

            utility.replace_stars(selected_sheet)
            return selected_sheet
        else:
            print(f"Worksheet '{sheet_name}' not found in the Excel file.")
            return None
    except Exception as e:
        print(f"Error loading the Excel file: {e}")
        return None   
    

    

#mook add
def search_keywords(worksheet):

    keywords_right = {
        "Job Name": None,
        # "Source File Name/ File Path": None,
        "Target Table Name": None,
        "Extract from zipfile" : None


    }
    keywords_below = {
        "Source System Name": None
    }
  ##-------------CUSTOM SEARCH--------- ##
    keyword_source_filename = {
        "Source File Name/ File Path": None,
    
    }

    results_source_filename  = utility.search_keywords_source_filename(worksheet,keyword_source_filename)


    results_right = utility.search_keywords_right(worksheet,keywords_right)
    results_below = utility.search_keywords_below(worksheet,keywords_below)
    
    results = {**results_right, **results_below ,**results_source_filename}
    return results

if __name__ == "__main__":
    


    ##-------- Pull DB




    path_in = "/Users/n.prayoonsoontorn/Downloads/script_extraction_config/input/"
    path_out = "/Users/n.prayoonsoontorn/Downloads/script_extraction_config/output/"


   
    sheet_name = "mdp_request_field"
    
    count = 0
    failed = []
    #---------  for investigation ---------
    parquet_file = []
    uniq_job_name = []
    text_file = []

    base_dir = []
    #--------------------------------------
    for dir_name in os.listdir(path_in):
        if dir_name != ".DS_Store":
            dir_path = os.path.join(path_in, dir_name)
            if os.path.isdir(dir_path):
                for filename in os.listdir(dir_path):
                    if filename != ".DS_Store":
                        count += 1
                        file_path = os.path.join(dir_path, filename)
                        worksheet = load_workbook(file_path, sheet_name)
                        results = search_keywords(worksheet)

                        #---------  Correction Field (format,etc.) ---------
                        fileNameRaw = results["Source File Name/ File Path"].split("\n")[0]
                        fileNameNewFormat = utility.convert_format_date(fileNameRaw)
                        print(fileNameNewFormat)
                        print(fileNameNewFormat)

                        fileNameWithStar = utility.modify_last_filename_to_star(fileNameNewFormat)

                        print(results["Source System Name"])

                        
                        dataTargetfilePath = "{{mdp_inbnd.filepath}}/" + results["Source System Name"] + "/" + fileNameWithStar #fixed  -> "{{mdp_inbnd.filepath}}
                        locationfilePath = "{{local_storage.filepath}}/" + results["Source System Name"] + "/" + fileNameWithStar #fixed  -> "{{local_storage.filepath}
                        targetDirectoryPath = "{{mdp_inbnd.filepath}}/" + results["Source System Name"] + "/"    #fixed  -> "{{mdp_inbnd.filepath}}
                        locationDirectoryPath = "{{local_storage.filepath}}/" + results["Source System Name"] + "/"  #fixed  -> "{{local_storage.filepath}



                    
                        #---------  Fixed field , Setting Field ---------

                    
                        pipeline_name = "ExtractionPipeline" #fixed
                        job_seq = "1"  #fixed
                        bypass_flag = "false"  #fixed

                        date_suffix = "{{ptn_yyyy}}{{ptn_mm}}{{ptn_dd}}" #fixed
                        file_extension = "txt"  #fixed
                        job_name =   utility.extract_and_concatenate(results["Job Name"])
                        base_filename =   utility.extract_prefix_from_filename_new_date(fileNameNewFormat)

                        ##Zip job
                        if ".zip" in fileNameRaw  : 
                            fileNameNewFormat = utility.convert_format_date(fileNameRaw)
                            fileNameWithStar  = utility.modify_last_filename_to_star(fileNameNewFormat)
                     
                            dataTargetfilePath = "{{mdp_inbnd.filepath}}/" + results["Source System Name"] + "/" + fileNameWithStar #fixed  -> "{{mdp_inbnd.filepath}}
                            locationfilePath = "{{local_storage.filepath}}/" + results["Source System Name"] + "/" + fileNameWithStar #fixed  -> "{{local_storage.filepath}
                            source_file_location = "{{local_storage.filepath}}/" + results["Source System Name"] + "/" + fileNameNewFormat
                            module_name = "ZipFileExtractorTask"


                            job_info = {
                            "data_source_type": "LocalLocation",   #fixed 
                            "file_name": fileNameWithStar,
                            "data_target_type": "ADLSLocation",  #fixed
                            "data_target_filepath":  dataTargetfilePath
                            }

                            account_name = "{{mdp_inbnd.account_name}}"
                            container_name = "{{mdp_inbnd.container_name}}"
                            sss_token =  "{{mdp_inbnd.sas_token}}"
                            
                            json_config = {
                                "job_name": job_name,   
                                "pipeline_name": pipeline_name,  #fixed 
                                "area_name": results["Source System Name"],
                                "job_seq": job_seq, #fixed 
                                "job_info": job_info,  
                                "tasks": {
                                    "file_extractor_task": {
                                        "module_name": "ZipFileExtractorTask",
                                        "bypass_flag": bypass_flag,
                                        "parameters": {
                                            "source_file_location": source_file_location
                                        }
                                     },
                                    "azcopy_data_transfer_task": {
                                        "module_name": "AzCopyDataTransferTask", #fixed 
                                        "bypass_flag": bypass_flag,   #fixed 
                                        "parameters": {
                                            "azcopy_command": "cp", #fixed 
                                            "target": {
                                                "type": "ADLSLocation",  #fixed 
                                                "account_name": account_name,  #fixed 
                                                "container_name": container_name,  #fixed 
                                                "sas_token": sss_token,  #fixed 
                                                "filepath": targetDirectoryPath #target as folder cause will 1 times move any format file (ctl,txt)
                                            }
                                        }
                                    }
                                }
                            }
                        ##Normal job
                        else : 
                           
                            job_info = {
                            "data_source_type": "LocalLocation",   #fixed 
                            "file_name": fileNameWithStar,
                            "data_target_type": "ADLSLocation",  #fixed
                            "data_target_filepath":  dataTargetfilePath
                            }

                            account_name = "{{mdp_inbnd.account_name}}"
                            container_name = "{{mdp_inbnd.container_name}}"
                            sss_token =  "{{mdp_inbnd.sas_token}}"
                            
                            json_config = {
                                "job_name": job_name,   
                                "pipeline_name": pipeline_name,  #fixed 
                                "area_name": results["Source System Name"],
                                "job_seq": job_seq, #fixed 
                                "job_info": job_info,  
                                "tasks": {
                                    "azcopy_data_transfer_task": {
                                        "module_name": "AzCopyDataTransferTask", #fixed 
                                        "bypass_flag": bypass_flag,   #fixed 
                                        "parameters": {
                                            "azcopy_command": "cp", #fixed 
                                            "source": {
                                                "type": "LocalLocation",  #fixed 
                                                "filepath": locationfilePath
                                            },
                                            "target": {
                                                "type": "ADLSLocation",  #fixed 
                                                "account_name": account_name,  #fixed 
                                                "container_name": container_name,  #fixed 
                                                "sas_token": sss_token,  #fixed 
                                                "filepath": targetDirectoryPath #target as folder cause will 1 times move any format file (ctl,txt)
                                            }
                                        }
                                    }
                                }
                            }



                   

                        # # Print or use the JSON object
                        json_string = json.dumps(json_config, indent=4)

                    
                        output_file = job_name + ".json"
                        output_path = os.path.join(path_out, dir_name, output_file)
                        os.makedirs(os.path.dirname(output_path), exist_ok=True)


                        try:
                            with open(output_path, "w") as json_file:
                                print(output_path)
                                json.dump(json_config, json_file, indent=4, ensure_ascii=False)
                            print(f"\nJSON data has been written to {output_file}\n")
                        except Exception as e:
                            print(f"Failed to write JSON data to {output_file}: {e}")
                            failed.append(filename)
        
    print("Done writing", count, "files to", path_out)
    print("Failed files:", failed)






