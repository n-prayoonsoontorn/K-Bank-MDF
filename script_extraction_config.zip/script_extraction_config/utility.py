import re
import os


def search_keywords_right(worksheet, keywords):
    if worksheet is None:
        return
    

    result = {keyword: "" for keyword in keywords}  # Initialize all keywords with empty strings

    for row in worksheet.iter_rows(values_only=True):
        for cell_value in row:
            if isinstance(cell_value, str) and cell_value in keywords:
                keyword = cell_value
                # Get the index of the keyword
                keyword_index = row.index(cell_value)
                # Check if the keyword is not the last element in the row
                if keyword_index < len(row) - 1:
                    # Get the value to the right of the keyword
                    value = row[keyword_index + 1]
                    if value is None:
                        result[keyword] = ""
                    else:
                        print(f"Found '{keyword}' Value: {value}")
                        # Remove double quotes from the string value
                        result[keyword] = str(value).strip('"').replace(" ", "")  # Strip double quotes from the string
    return result


def search_keywords_source_filename(worksheet, keywords):
    if worksheet is None:
        return
    
    result = {}
    for row in worksheet.iter_rows(values_only=True):
        for cell_value in row:
            if isinstance(cell_value, str) and cell_value in keywords:
                keyword = cell_value
                # Get the index of the keyword
                keyword_index = row.index(cell_value)
                # Check if the keyword is not the last element in the row
                if keyword_index < len(row) - 1:
                    # Get the value to the right of the keyword
                    value = row[keyword_index + 1]
                    if value is None:
                        result[keyword] = ""
                    else:
                        print(f"Found '{keyword}' Value: {value}")
                        result[keyword] = str(value)
                        return result
    return result





def search_keywords_below(worksheet, keywords):
    if worksheet is None:
        return

    result = {}
    for row_index, row in enumerate(worksheet.iter_rows(values_only=True)):
        for cell_index, cell_value in enumerate(row):
            if cell_value in keywords:
                keyword = cell_value
                value = worksheet.cell(row=row_index + 2, column=cell_index + 1).value
                if value == None:
                    result[keyword] = ""
                else:
                    print(f"Found '{keyword}' Value: {value}")
                    result[keyword] = value.lower()

    return result

def search_keywords_left(worksheet, keywords):
    if worksheet is None:
        return
    
    result = {}
    for row in worksheet.iter_rows(values_only=True):
        for cell_value in row:
            if cell_value in keywords:
                keyword = cell_value
                value = row[row.index(cell_value) - 1]
                if value == None:
                    result[keyword] = ""
                else:
                    print(f"Found '{keyword}' Value: {value}")
                    result[keyword] = value.lower()
    return result



def remove_quotes(cell_value):
    return cell_value.replace("'", "").replace('"', '')

def get_column_params(worksheet, extraction_logic):
    # column M
    column_to_search = 13
    # column O
    column_to_get_value = 15
    
    keywords = extraction_logic.split(',')
    result_map = {}
    
    for keyword in keywords:
        try:
            for row in range(1, worksheet.max_row + 1):
                if worksheet.cell(row=row, column=column_to_search).value == keyword.strip():
                    value_in_column_O = worksheet.cell(row=row, column=column_to_get_value).value
                    result_map[keyword.strip()] = value_in_column_O
        except ValueError as e:
            result_map[keyword.strip()] = str(e)
                   
    return result_map

def column_params(extraction_logic, result_map):
    
    keywords = extraction_logic.split(',')
    
    p_dd = "{{ptn_dd}}" if 'ptn_dd' in extraction_logic else ""
    p_mm = "{{ptn_mm}}" if 'ptn_mm' in extraction_logic else ""
    p_qtr = "{{ptn_qtr}}" if 'ptn_qtr' in extraction_logic else ""
    p_yyyy = "{{ptn_yyyy}}" if 'ptn_yyyy' in extraction_logic else ""

    dd = result_map.get("ptn_dd", "").lower()
    mm = result_map.get("ptn_mm", "").lower()
    qtr = result_map.get("ptn_qtr", "").lower()
    yyyy = result_map.get("ptn_yyyy", "").lower()

    keyword_to_value = {
        "ptn_dd": f"cast('{p_dd}' as {dd})",
        "ptn_mm": f"cast('{p_mm}' as {mm})",
        "ptn_qtr": f"cast('{p_qtr}' as {qtr})",
        "ptn_yyyy": f"cast('{p_yyyy}' as {yyyy})"
    }

    # Use a list comprehension to extract the corresponding values
    result = {keyword:keyword_to_value[keyword] for keyword in keywords if keyword in keyword_to_value}

    # Join the values into a comma-separated string
    # result = ',\n'.join(values)
    # result = result.replace(", ", ",\n")
    # print('column param', result)

    return result

def replace_stars(worksheet):
    for row in worksheet.iter_rows(min_row=1, max_row=worksheet.max_row, min_col=1, max_col=worksheet.max_column):
        for cell in row:
            if cell.value is not None and isinstance(cell.value, str):
                cell.value = cell.value.replace('*', '')


            

# def convert_format_date(sourceFileName, combinedSourceAndTable):

#     print(sourceFileName)
#     print(sourceFileName)

#     # Split the path by '/'
#     path_parts = sourceFileName.split('/')
#     # Get the last part which contains the filename
#     filename = path_parts[-1]
#     # Split the filename by '_'
#     filename_parts = filename.split('_')
#     # Get the last part which contains the date
#     date_part = filename_parts[-1]
    
#     # Define regular expressions for different date patterns
#     patterns = {
#         r'YYYY': r'{{ptn_yyyy}}',
#         r'MM': r'{{ptn_mm}}',
#         r'DD': r'{{ptn_dd}}',
#         r'yyyy': r'{{ptn_yyyy}}',
#         r'mm': r'{{ptn_mm}}',
#         r'dd': r'{{ptn_dd}}'
#     }

#     # Replace date patterns in the date part of the filename
#     for pattern, replacement in patterns.items():
#         date_part = re.sub(pattern, replacement, date_part)
    
#     # Replace the original date part with the modified one
#     filename_parts[-1] = date_part
    
#     # Join the filename parts back together
#     filename = '_'.join(filename_parts)
    
#     # Replace the original filename with the modified one in the path
#     path_parts[-1] = filename
    
#     # Join the path parts back together
#     modified_sourceFileName = '/'.join(path_parts)


#     print(modified_sourceFileName)
#     print(modified_sourceFileName)
    
#     return modified_sourceFileName


# def convert_format_date(sourceFileName):
#     # Split sourceFileName into filename and extension
#     filename, extension = sourceFileName.rsplit('.', 1)
    
#     # Split filename into parts
#     parts = filename.split('_')
    
#     # Convert the last part to uppercase
#     if len(parts[-1]) == 8 :
#         parts[-1] = parts[-1].upper()

#     sourceFileName = '_'.join(parts) + '.' + extension

#     patterns = {
#         r'YYYY': r'{{ptn_yyyy}}',
#         r'MM': r'{{ptn_mm}}',
#         r'DD': r'{{ptn_dd}}',
      
#     }

#     # Replace patterns in the specified order
#     for pattern, replacement in patterns.items():
#         sourceFileName = re.sub(pattern, replacement, sourceFileName)

#     return sourceFileName
                


# def convert_format_date(sourceFileName):
#     # Split the path by '/'
#     path_parts = sourceFileName.split('/')
#     # Get the last part which contains the filename
#     filename = path_parts[-1]
#     # Split the filename by '_'
#     filename_parts = filename.split('_')
#     # Get the last part which contains the date
#     date_part = filename_parts[-1]

    
#     # Define regular expressions for different date patterns
#     patterns = {
#         r'YYYY': r'{{ptn_yyyy}}',
#         r'MM': r'{{ptn_mm}}',
#         r'DD': r'{{ptn_dd}}',
#         # r'yyyy': r'{{ptn_yyyy}}',
#         # r'mm': r'{{ptn_mm}}',
#         # r'dd': r'{{ptn_dd}}'
#     }

#     # Replace date patterns in the date part of the filename
#     for pattern, replacement in patterns.items():
#         date_part = re.sub(pattern, replacement, date_part)


   
    
#     # Replace the original date part with the modified one
#     filename_parts[-1] = date_part
    
#     # Join the filename parts back together
#     filename = '_'.join(filename_parts)
    
#     # Replace the original filename with the modified one in the path
#     path_parts[-1] = filename
    
#     # Join the path parts back together
#     modified_sourceFileName = '/'.join(path_parts)
    
#     return modified_sourceFileName
                

def convert_format_date(sourceFileName):
    # Split the path by '/'

    if 'ddmmyy' in sourceFileName:
        # Split the filename at the pattern
      # Split the filename at the pattern
        split_index = sourceFileName.index('ddmmyy')
        prefix = sourceFileName[:split_index]
        date_part = sourceFileName[split_index:]
           
        
        # Convert 'ddmmyy' to uppercase
        date_part = date_part.replace('ddmmyy', 'DDMMYY')
        print(date_part)

        # Define regular expressions for different date patterns
        patterns = {
            r'MM': r'{{ptn_mm}}',
            r'DD': r'{{ptn_dd}}',
            r'YY' :r'{{ptn_yyyy[2:]}}'     
           }  

        for pattern, replacement in patterns.items():
             date_part = re.sub(pattern, replacement, date_part)

            # If there was a prefix, join it back with the modified date part
        if prefix:
            modified_sourceFileName = prefix + date_part

            print(modified_sourceFileName)
            print(modified_sourceFileName)
            print(modified_sourceFileName)
        
        return modified_sourceFileName
    
    elif '%%TRANDATE' in sourceFileName:

        split_index = sourceFileName.index('%%TRANDATE')
        prefix = sourceFileName[:split_index]
        date_part = sourceFileName[split_index:]


         # Convert 'ddmmyy' to uppercase
        date_part = date_part.replace('%%TRANDATE', 'DDMMYY')
        print(date_part)

        # Define regular expressions for different date patterns
        patterns = {
            r'MM': r'{{ptn_mm}}',
            r'DD': r'{{ptn_dd}}',
            r'YY' :r'{{ptn_yyyy[2:]}}'      
     }  

        for pattern, replacement in patterns.items():
             date_part = re.sub(pattern, replacement, date_part)

            # If there was a prefix, join it back with the modified date part
        if prefix:
            modified_sourceFileName = prefix + date_part

            print(modified_sourceFileName)
            print(modified_sourceFileName)
            print(modified_sourceFileName)
        
        return modified_sourceFileName
    
    elif '%Y%m%d' in sourceFileName:

        split_index = sourceFileName.index('%Y%m%d')
        prefix = sourceFileName[:split_index]
        date_part = sourceFileName[split_index:]


         # Convert 'ddmmyy' to uppercase
        date_part = date_part.replace('%Y%m%d', 'YYYYMMDD')
        print(date_part)

        # Define regular expressions for different date patterns
          # Define regular expressions for different date patterns
        
        patterns = {
            r'YYYY': r'{{ptn_yyyy}}',
            r'MM': r'{{ptn_mm}}',
            r'DD': r'{{ptn_dd}}',
            # r'yyyy': r'{{ptn_yyyy}}',
            # r'mm': r'{{ptn_mm}}',
            # r'dd': r'{{ptn_dd}}'
        }

        for pattern, replacement in patterns.items():
             date_part = re.sub(pattern, replacement, date_part)

            # If there was a prefix, join it back with the modified date part
        if prefix:
            modified_sourceFileName = prefix + date_part

            print(modified_sourceFileName)
            print(modified_sourceFileName)
            print(modified_sourceFileName)
        
        return modified_sourceFileName
    
    else :
        path_parts = sourceFileName.split('/')
        # Get the last part which contains the filename
        filename = path_parts[-1]
        # Split the filename by '_'
        filename_parts = filename.split('_')
        # Get the last part which contains the date
        date_part = filename_parts[-1]


        if 'yyyymmdd' in date_part.lower():
            date_part = date_part.replace('yyyymmdd', 'YYYYMMDD')
        if 'yyyyMMdd' in date_part:
            date_part = date_part.replace('yyyyMMdd', 'YYYYMMDD')
        if 'yyyy-mm-dd' in date_part.lower():
            date_part = date_part.replace('yyyy-mm-dd', 'YYYY-MM-DD')


    

        # Define regular expressions for different date patterns
        patterns = {
            r'YYYY': r'{{ptn_yyyy}}',
            r'MM': r'{{ptn_mm}}',
            r'DD': r'{{ptn_dd}}',
            # r'yyyy': r'{{ptn_yyyy}}',
            # r'mm': r'{{ptn_mm}}',
            # r'dd': r'{{ptn_dd}}'
        }

        # Replace date patterns in the date part of the filename
        for pattern, replacement in patterns.items():
            date_part = re.sub(pattern, replacement, date_part)


        
        # Replace the original date part with the modified one
        filename_parts[-1] = date_part
        
        # Join the filename parts back together
        filename = '_'.join(filename_parts)
        
        # Replace the original filename with the modified one in the path
        path_parts[-1] = filename
        
        # Join the path parts back together
        modified_sourceFileName = '/'.join(path_parts)
    
    return modified_sourceFileName





def transform_file_extension(file_name, new_format):

   
    base_name,extension  = os.path.splitext(file_name)
    new_file_name = f"{base_name}.{new_format}"
    return new_file_name





def extract_number_with_regex(input_string):
    # Define a regex pattern to match numbers
    pattern = r"\d+"
    # Find all matches of the pattern in the input string
    matches = re.findall(pattern, input_string)
    # Get the first match (assuming there's only one number)
    number = int(matches[0]) if matches else None
    return number

    
def extract_and_concatenate(string):
    # Split the string using underscore
    parts = string.split('_')

    parts.pop(0)
    
    # Join the parts and concatenate with "extrct_"
    concatenated_word = "extrct_" + '_'.join(parts)
    
    return concatenated_word





def remove_dot_from_filename(string):
    # Split the string using underscore
    parts = string.split('.')
   
    
    # Join the parts and concatenate with "extrct_"
    concatenated_word = "extrct_" + '_'.join(parts)
    
    return concatenated_word

def modify_last_filename_to_star(filename):
    # Remove "txt" and add ".*"
    modified_filename = filename.replace(".txt", ".*").replace(".TXT", ".*").replace(".csv", ".*").replace(".xlsx", ".*").replace(".xlx", ".*").replace(".zip", ".*")
    return modified_filename
    




def extract_prefix_from_filename_new_date(filename):
    parts = filename.split('_{{', 1)
    if len(parts) > 1:
        return parts[0]
    else:
        return filename


def retrieve_data(fileNameRaw):
    dataToTbList = [
        ('dgtl_fctrng_v_purref_YYYYMMDD.txt', 'V_PurRef'),
        ('dgtl_fctrng_v_clientdebtor_YYYYMMDD.txt', 'V_ClientDebtor'),
        ('dgtl_fctrng_v_product_YYYYMMDD.txt', 'V_Product'),
        ('dgtl_fctrng_v_company_YYYYMMDD.txt', 'V_Company'),
        ('dgtl_fctrng_v_clientlimit_YYYYMMDD.txt', 'V_ClientLimit'),
        ('dgtl_fctrng_v_cis_YYYYMMDD.txt', 'V_CIS'),
        ('dgtl_fctrng_v_interestspread_YYYYMMDD.txt', 'V_InterestSpread'),
        ('scf_vw_sct_book_loan_YYYYMMDD.txt', 'VW_SCT_BOOK_LOAN'),
        ('scf_vw_rdt_scf_cl_YYYYMMDD.txt', 'VW_RDT_SCF_CL'),
        ('scf_vw_scm_fee_structure_YYYYMMDD.txt', 'VW_SCM_FEE_STRUCTURE'),
        ('scf_vw_scm_acct_YYYYMMDD.txt', 'VW_SCM_ACCT'),
        ('scf_trading_YYYYMMDD.txt', 'VW_SCM_TRADING'),
        ('scf_customer_YYYYMMDD.txt', 'VW_SCM_CUSTOMER'),
        ('scf_product_map_YYYYMMDD.txt', 'SCM_PRODUCT_MAP'),
        ('scf_vw_rdt_scf_cl_acct_YYYYMMDD.txt', 'VW_RDT_SCF_CL_ACCT'),
        ('scf_vw_trading_acct_YYYYMMDD.txt', 'VW_SCM_TRADING_ACCT'),
        ('ud_vw_t_su_sub_uh_ful_YYYYMMDD.txt', 'DTEADM.VW_T_SU_SUB_UH_FUL'),
        ('ud_vw_kgroup_sidetexttbl_YYYYMMDD.txt', 'DTEADM.VW_KGROUP_SIDETEXTTBL'),
        ('ud_vw_fi_fnd_inf_ful_YYYYMMDD.txt', 'DTEADM.VW_FI_FND_INF_FUL'),
        ('ud_vw_flt_rl_sub_bal_enq_YYYYMMDD.txt', 'DTEADM.VW_FLT_RL_SUB_BAL_ENQ'),
        ('ud_vw_t_uh_uh_ful_YYYYMMDD.txt', 'DTEADM.VW_T_UH_UH_FUL'),
        ('ud_vw_flt_div_pmt_inc_YYYYMMDD.txt', 'DTEADM.VW_FLT_DIV_PMT_INC'),
        ('ud_vw_std_ins_eod_inc_YYYYMMDD.txt', 'DTEADM.VW_STD_INS_EOD_INC'),
        ('ud_vw_transactionext_YYYYMMDD.txt', 'DTEADM.VW_TRANSACTIONEXT'),
        ('ud_vw_transactioneodext_YYYYMMDD.txt', 'DTEADM.VW_TRANSACTIONEODEXT'),
        ('ud_vw_flt_dp_div_cert_inc_YYYYMMDD.txt', 'DTEADM.VW_FLT_DP_DIV_CERT_INC')
    ]

    # Retrieve the corresponding data from the list of tuples
    for filename, data in dataToTbList:
        if fileNameRaw == filename:
            print(f"Found DB '{filename}' Value: {data}")
            return data
    
    # Return "Not found" if no match is found
    return "Not found"



def retrieve_data_for_eban(fileNameRaw):
    dataToTbList = [
        ('IN_LPM_LMT_AR_INF_BFR_WRTOF_yyyy-mm-dd.TXT', 'IN_LPM_LMT_AR_INF_BFR_WRTOF', 'DATALAKE', 'IN_LPM_LMT_AR_INF_BFR_WRTOF_YYYYMMDD.TXT'),
        ('IN_LPM_AR_WRTOF_RCV_yyyy-mm-dd.TXT', 'IN_LPM_AR_WRTOF_RCV', 'DATALAKE', 'IN_LPM_AR_WRTOF_RCV_YYYYMMDD.TXT'),
        ('IN_LPM_LN_CNTG_DMMY_CLSS_PRVN_yyyy-mm-dd.TXT', 'IN_LPM_LN_CNTG_DMMY_CLSS_PRVN', 'DATALAKE', 'IN_LPM_LN_CNTG_DMMY_CLSS_PRVN_YYYYMMDD.TXT'),
        ('IN_LPM_LN_CARD_CLSS_PRVN_yyyy-mm-dd_.TXT', 'IN_LPM_LN_CARD_CLSS_PRVN', 'DATALAKE', 'IN_LPM_LN_CARD_CLSS_PRVN_YYYYMMDD_*.TXT'),
        ('IN_LPM_LN_CNTG_CLSS_PRVN_yyyy-mm-dd.TXT', 'IN_LPM_LN_CNTG_CLSS_PRVN', 'DATALAKE', 'IN_LPM_LN_CNTG_CLSS_PRVN_YYYYMMDD.TXT'),
        ('IN_LPM_AR_CLSS_QLY_yyyy-mm-dd.txt', 'IN_LPM_AR_CLSS_QLY', 'DATALAKE', 'IN_LPM_AR_CLSS_QLY_YYYYMMDD.txt'),
        ('IN_LPM_LN_CNTG_CLSS_PRVN_BFR_WRTOF_yyyy-mm-dd.TXT', 'IN_LPM_LN_CNTG_CLSS_PRVN_BFR_WRTOF', 'DATALAKE', 'IN_LPM_LN_CNTG_CLSS_PRVN_BFR_WRTOF_YYYYMMDD.TXT'),
        ('IN_LPM_LMT_INF_BFR_WRTOF_yyyy-mm-dd.TXT', 'IN_LPM_LMT_INF_BFR_WRTOF', 'DATALAKE', 'IN_LPM_LMT_INF_BFR_WRTOF_YYYYMMDD.TXT'),
        ('CC_JCB_AHR_LOG_IN_yyyy-mm-dd.txt', 'CC_JCB_AHR_LOG_IN', 'DATALAKE', 'CC_JCB_AHR_LOG_IN_YYYYMMDD.txt'),
        ('RC_CD_TMP.TXT', 'RC_CD_TMP', 'DATALAKE', 'RC_CD_TMP.TXT')

    ]

    for file_name, tableIn, schema,fileNameNewFormateDate in dataToTbList:
        if fileNameRaw == file_name:
            print(f"tableIn: {tableIn}, schema: {schema}, fileNameNewFormateDate: {fileNameNewFormateDate}")
            return tableIn, schema, fileNameNewFormateDate
    # If no match is found, return None
    return None, None,None


def find_word_position_in_excel(sheet, word):
    # Iterate through each cell in the specified sheet
    for row in sheet.iter_rows():
        for cell in row:
            # Check if the cell contains the word
            if isinstance(cell.value, str) and word in cell.value:
                # Find the position of the word within the cell value
                position = cell.value.find(word)
                # Return the position and cell address
                return position, cell.coordinate

    # If the word is not found in any cell, return None
    return None




 
def retrieve_values_from_column_for_no_point_source(sheet, start_row):
    retrieved_values = []
    # Find the last row in the specified column (column B in this case)
    end_row = sheet.max_row
    
    # Iterate through each cell in the specified range (column W)
    for row in range(start_row, end_row + 1):
        cell_W = sheet[f'W{row}']
        retrieved_values.append(cell_W.value)
    
    return retrieved_values

 
def retrieve_type_values_from_column_for_no_point_source(sheet, start_row):
    retrieved_values = []
    # Find the last row in the specified column (column B in this case)
    end_row = sheet.max_row
    
    # Iterate through each cell in the specified range (column W)
    for row in range(start_row, end_row + 1):
        cell_Y= sheet[f'Y{row}']
        retrieved_values.append(cell_Y.value)
    
    return retrieved_values


def retrieve_size_values_from_column_for_no_point_source(sheet, start_row):
    retrieved_values = []
    # Find the last row in the specified column (column B in this case)
    end_row = sheet.max_row
    
    # Iterate through each cell in the specified range (column W)
    for row in range(start_row, end_row + 1):
        cell_Z= sheet[f'Z{row}']
        retrieved_values.append(cell_Z.value)
    
    return retrieved_values

def retrieve_format_type_values_from_column_for_no_point_source(sheet, start_row):
    retrieved_values = []
    # Find the last row in the specified column (column B in this case)
    end_row = sheet.max_row
    
    # Iterate through each cell in the specified range (column W)
    for row in range(start_row, end_row + 1):
        cell_AB = sheet[f'AB{row}']
        retrieved_values.append(cell_AB.value)
    
    return retrieved_values

def retrieve_values_from_column_for_no_point_target(sheet, start_row):
    retrieved_values = []
    # Find the last row in the specified column (column B in this case)
    end_row = sheet.max_row
    
    # Iterate through each cell in the specified range (column W)
    for row in range(start_row, end_row + 1):
        cell_M = sheet[f'M{row}']
        retrieved_values.append(cell_M.value)
    
    return retrieved_values





def extract_row_number(cell_reference):
    # Split the cell reference into column and row parts
    column, row = cell_reference[:1], cell_reference[1:]
    # Extract the row number and return it
    row_number = int(row)
    return row_number



def format_string_for_diff_field(value1, value2):
    return '"{}":"cast(`{}` as string)"'.format(value1, value2)



def compare_and_append_lists(source_list, target_list):
    appended_values = []

    for source_tuple in source_list:
        # Extract the value from the first element of the tuple
        source_value = source_tuple[0]
        # Check if the source value exists in target_list
        if source_value in target_list:
            # If it does, append the tuple to appended_values
            appended_values.append(source_tuple)

    return appended_values