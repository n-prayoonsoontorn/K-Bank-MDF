from collections import Counter
import json
import os
import openpyxl

import utility


    

def load_workbook(excel_file, sheet_name):
    try:
        workbook = openpyxl.load_workbook(excel_file,data_only=True)
        if sheet_name in workbook.sheetnames:
            selected_sheet = workbook[sheet_name]
            print(f"Loaded worksheet '{sheet_name}' from Excel file '{excel_file}' successfully.")
            print(f"Number of rows: {selected_sheet.max_row}, Number of columns: {selected_sheet.max_column}")

            utility.replace_stars(selected_sheet)
            return selected_sheet
        else:
            print(f"Worksheet '{sheet_name}' not found in the Excel file.")
            return None
    except Exception as e:
        print(f"Error loading the Excel file: {e}")
        return None   
    

    

#mook add
def search_keywords(worksheet):

    keywords_right = {
        "Job Name": None,
        # "Source File Name/ File Path": None,
        "Target Table Name": None,

    }
    keywords_below = {
        "Source System Name": None
    }

    keyword_fileName = {
        "Source File Name/ File Path": None,
    }

    results_filename = utility.search_keywords_source_filename(worksheet,keyword_fileName)


    results_right = utility.search_keywords_right(worksheet,keywords_right)
    results_below = utility.search_keywords_below(worksheet,keywords_below)
    
    results = {**results_right, **results_below,**results_filename }
    return results

if __name__ == "__main__":
    

    path_in = "/Users/n.prayoonsoontorn/Downloads/script_extraction_config_eban_in/input/"
    path_out = "/Users/n.prayoonsoontorn/Downloads/script_extraction_config_eban_in/output/"


   
    sheet_name = "mdp_request_field"
    
    count = 0
    failed = []
    #---------  for investigation ---------
    parquet_file = []
    uniq_job_name = []
    text_file = []

    base_dir = []
    #--------------------------------------
    for dir_name in os.listdir(path_in):
        if dir_name != ".DS_Store":
            dir_path = os.path.join(path_in, dir_name)
            if os.path.isdir(dir_path):
                for filename in os.listdir(dir_path):
                    if filename != ".DS_Store":
                        count += 1
                        file_path = os.path.join(dir_path, filename)
                        worksheet = load_workbook(file_path, sheet_name)
                        results = search_keywords(worksheet)


                        #---------  Correction Field (format,etc.) ---------
                        fileNameRaw = results["Source File Name/ File Path"]

                    
                        #---------  Fixed field , Setting Field ---------

                            
                        pipeline_name = "ExtractionPipeline" #fixed
                        job_seq = "1"  #fixed
                        bypass_flag = "false"  #fixed
                        header_columns = ["date_of_data", "date_of_generated_data", "number_of_records", "source_file_name"] #fixed
                        job_name =   utility.extract_and_concatenate(results["Job Name"])

                        tableIn, schema,fileNameNewFormateDate=  utility.retrieve_data_for_eban(fileNameRaw)

                        fileNameNewFormateDate = fileNameNewFormateDate.replace("YYYYMMDD", "{{ptn_yyyy}}{{ptn_mm}}{{ptn_dd}}")



                        job_info = {
                            "schema_in": schema,
                            "table_in":  tableIn,
                            "file_name": fileNameNewFormateDate,
                        }

                        json_config = {
                            "job_name": job_name,
                            "pipeline_name": pipeline_name,  # Fixed
                            "area_name": results["Source System Name"],
                            "job_seq": job_seq,  # Fixed
                            "job_info": job_info,
                            "tasks": {
                                "eban_in_extractor_task": {
                                    "module_name": "EBANInExtractorTask",
                                    "bypass_flag": "false",
                                    "parameters": {}
                                }
                            }
                        }

                    
                        # Print or use the JSON object
                        json_string = json.dumps(json_config, indent=4)

                    
                        output_file = job_name + ".json"
                        output_path = os.path.join(path_out, dir_name, output_file)
                        os.makedirs(os.path.dirname(output_path), exist_ok=True)


                        try:
                            with open(output_path, "w") as json_file:
                                print(output_path)
                                json.dump(json_config, json_file, indent=4, ensure_ascii=False)
                            print(f"\nJSON data has been written to {output_file}\n")
                        except Exception as e:
                            print(f"Failed to write JSON data to {output_file}: {e}")
                            failed.append(filename)


    
    print("Done writing", count, "files to", path_out)
    print("Failed files:", failed)



