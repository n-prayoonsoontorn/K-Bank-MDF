from collections import Counter
import json
import os
import openpyxl

import utility



def load_workbook(excel_file, sheet_name):
    try:
        workbook = openpyxl.load_workbook(excel_file,data_only=True)
        if sheet_name in workbook.sheetnames:
            selected_sheet = workbook[sheet_name]
            print(f"Loaded worksheet '{sheet_name}' from Excel file '{excel_file}' successfully.")
            print(f"Number of rows: {selected_sheet.max_row}, Number of columns: {selected_sheet.max_column}")

            utility.replace_stars(selected_sheet)
            return selected_sheet
        else:
            print(f"Worksheet '{sheet_name}' not found in the Excel file.")
            return None
    except Exception as e:
        print(f"Error loading the Excel file: {e}")
        return None   
    

    

#mook add
def search_keywords(worksheet):

    keywords_right = {
        "Job Name": None,
        "Source File Name/ File Path": None,
        "Target Table Name": None,

    }
    keywords_below = {
        "Source System Name": None
    }


   


    results_right = utility.search_keywords_right(worksheet,keywords_right)
    results_below = utility.search_keywords_below(worksheet,keywords_below)
    
    results = {**results_right, **results_below}
    return results

if __name__ == "__main__":
    


    ##-------- Pull DB




    # path_in = "/Users/n.prayoonsoontorn/Desktop/CBR/CBR from KBANK sharepoint/supply chain"
    # path_out = "/Users/n.prayoonsoontorn/Desktop/Config VM Result/supply chain/"
   
    # path_in = "/Users/n.prayoonsoontorn/Desktop/CBR/CBR from KBANK sharepoint/factoring/"
    # path_out = "/Users/n.prayoonsoontorn/Desktop/Config VM Result/factoring/"

    # path_in = "/Users/n.prayoonsoontorn/Desktop/CBR/CBR from KBANK sharepoint/lec"
    # path_out = "/Users/n.prayoonsoontorn/Desktop/Config VM Result/lec/"


    # path_in = "/Users/n.prayoonsoontorn/Desktop/CBR/CBR from KBANK sharepoint/trade navigator"
    # path_out = "/Users/n.prayoonsoontorn/Desktop/Config VM Result/trade navigator"

    path_in = "/Users/n.prayoonsoontorn/Downloads/script_extraction_config_pull_db/input/"
    path_out = "/Users/n.prayoonsoontorn/Downloads/script_extraction_config_pull_db/output/"


   
    sheet_name = "mdp_request_field"
    
    count = 0
    failed = []
    #---------  for investigation ---------
    parquet_file = []
    uniq_job_name = []
    text_file = []

    base_dir = []
    #--------------------------------------
    for dir_name in os.listdir(path_in):
        if dir_name != ".DS_Store":
            dir_path = os.path.join(path_in, dir_name)
            if os.path.isdir(dir_path):
                for filename in os.listdir(dir_path):
                    if filename != ".DS_Store":
                        count += 1
                        file_path = os.path.join(dir_path, filename)
                        worksheet = load_workbook(file_path, sheet_name)
                        results = search_keywords(worksheet)

                        #---------  Correction Field (format,etc.) ---------
                        fileNameRaw = results["Source File Name/ File Path"]
                        fileNameNewFormat = utility.convert_format_date(results["Source File Name/ File Path"])
                        print(fileNameNewFormat)
                        print(fileNameNewFormat)

                        fileNameWithStar = utility.modify_last_filename_to_star(fileNameNewFormat)

                        print(results["Source System Name"])

                        
                        dataTargetfilePath = "{{mdp_inbnd.filepath}}/" + results["Source System Name"] + "/" + fileNameWithStar #fixed  -> "{{mdp_inbnd.filepath}}
                        locationfilePath = "{{local_storage.filepath}}/" + results["Source System Name"] + "/" + fileNameWithStar #fixed  -> "{{local_storage.filepath}
                        targetDirectoryPath = "{{mdp_inbnd.filepath}}/" + results["Source System Name"] + "/"    #fixed  -> "{{mdp_inbnd.filepath}}
                        locationDirectoryPath = "{{local_storage.filepath}}/" + results["Source System Name"] + "/"  #fixed  -> "{{local_storage.filepath}


                        #---- VM on customer is comeform  dih path or not (rdm,lpm-as400 batch2 planA,fxb : midrate_kbank)
                        if results["Source System Name"] == "rdm" :
                            locationfilePath = "{{local_storage.filepath}}/dih/" + fileNameWithStar
                            locationDirectoryPath =  "{{local_storage.filepath}}/dih/"

                

                    
                        #---------  Fixed field , Setting Field ---------

                            
                        pipeline_name = "ExtractionPipeline" #fixed
                        job_seq = "1"  #fixed
                        bypass_flag = "false"  #fixed
                        header_columns = ["date_of_data", "date_of_generated_data", "number_of_records", "source_file_name"] #fixed

                        date_suffix = "{{ptn_yyyy}}{{ptn_mm}}{{ptn_dd}}" #fixed
                        file_extension = "txt"  #fixed
                        job_name =   utility.extract_and_concatenate(results["Job Name"])
                        base_filename =   utility.extract_prefix_from_filename_new_date(fileNameNewFormat)



                        job_info = {
                            "data_source_type": "LocalLocation",   #fixed 
                            "file_name": fileNameWithStar,
                            "data_target_type": "ADLSLocation",  #fixed
                            "data_target_filepath":  dataTargetfilePath
                        }

                        account_name = "{{mdp_inbnd.account_name}}"
                        container_name = "{{mdp_inbnd.container_name}}"
                        sss_token =  "{{mdp_inbnd.sas_token}}"
                        
                        json_config = {
                            "job_name": job_name,   
                            "pipeline_name": pipeline_name,  #fixed 
                            "area_name": results["Source System Name"],
                            "job_seq": job_seq, #fixed 
                            "job_info": job_info,  
                            "tasks": {
                                "azcopy_data_transfer_task": {
                                    "module_name": "AzCopyDataTransferTask", #fixed 
                                    "bypass_flag": bypass_flag,   #fixed 
                                    "parameters": {
                                        "azcopy_command": "cp", #fixed 
                                        "source": {
                                            "type": "LocalLocation",  #fixed 
                                            "filepath": locationfilePath
                                        },
                                        "target": {
                                            "type": "ADLSLocation",  #fixed 
                                            "account_name": account_name,  #fixed 
                                            "container_name": container_name,  #fixed 
                                            "sas_token": sss_token,  #fixed 
                                            "filepath": targetDirectoryPath #target as folder cause will 1 times move any format file (ctl,txt)
                                        }
                                    }
                                }
                            }
                        }

                        #Condition Pull DB (UD,SCF,DCT)

                        # extrct_ud_privatefund_balance_d -> this not pull db
                        # extrct_ud_ka_fundcode_d.json  -> this not pull db

                        ## UD  ->  1 tables not have db in EBAN
                            ## ('scf_product_map_YYYYMMDD.txt', 'Not in EBAN'),
                        # -> UD BATCH1 not have suffix only batch 2 
                            ##('KA_FundCode.txt', 'DATALAKE.FND'),
                            ##('PrivateFund_Balance.txt', 'DATALAKE.PRVT_FND')

                        ## SCF - > 1 tables not have db in EBAN
                        ## ('ud_vw_std_ins_eod_inc_YYYYMMDD.txt', 'Not in EBAN'),
                

                        #   SELECT COUNT(*), SYSDATETIME(),'{{pos_dt}}' FROM test_tbl2 WHERE dt = '{{ pos_dt }}'; #for scf, dgtl
                        #   SELECT COUNT(*), SYSTIMESTAMP, '{{pos_dt}}' FROM test_tbl2 WHERE dt = '{{ pos_dt }}'; #for ud
                        #   THIS STEP FOR PULL DATA FROM DB AND CREATE AS DATA_FILE , CTL 
                    
                        if results["Source System Name"] in ["scf","dgtl_fctrng","ud"]:
                            
                            db_name =  utility.retrieve_data(fileNameRaw)

                        #XXXXXXXXX-----------------------------------------------------------

                            a= utility.find_word_position_in_excel(worksheet,"V Seq.")
                   

                            # b= utility.find_word_position_in_excel(worksheet,"Body")
                            # c= utility.find_word_position_in_excel(worksheet,"Tailor Label")
                            
                            posVseq= utility.extract_row_number((a[1]))
                            # posBody = utility.extract_row_number((b[1]))
                            # posTailorLabel = utility.extract_row_number((c[1]))

                            sourceNameValue =  utility.retrieve_values_from_column_for_no_point_source(worksheet,posVseq)
                           


                            sourcetypeValue =  utility.retrieve_type_values_from_column_for_no_point_source(worksheet,posVseq)
                            
                            sourceFormatTypeValue =  utility.retrieve_format_type_values_from_column_for_no_point_source(worksheet,posVseq)

                            sourceSizeValue = utility.retrieve_size_values_from_column_for_no_point_source(worksheet,posVseq)

                            targetNameValue =  utility.retrieve_values_from_column_for_no_point_target(worksheet,posVseq)
                            SourceNameValueChangeFormat = [column.replace(' ', '_').replace('-', '_').replace('.', '_') if column is not None else None for column in sourceNameValue]

                            for i in range(len(SourceNameValueChangeFormat)):
                                if SourceNameValueChangeFormat[i] is not None:
                                    SourceNameValueChangeFormat[i] = SourceNameValueChangeFormat[i].replace('__', '_')
                            

                            combined_list_source = list(zip(sourceNameValue, sourcetypeValue,sourceFormatTypeValue,sourceSizeValue))
                            combined_list_source = combined_list_source[1:]

                            
                            filtered_data = [(col_name, data_type, format_type, size_value) for col_name, data_type, format_type, size_value in combined_list_source if col_name is not None and data_type is not None  and '/' not in data_type]

                            print(len(filtered_data))
                            select_query = ""
                            if results["Source System Name"] == "ud":
                                select_query = "SELECT "
                                for field_name, field_type ,format_type , size_value in filtered_data:
                                    if field_type.lower() in ('datetime','timestamp','date'):
                                        if 'HH' in format_type:
                                            format_type = format_type.replace('HH', 'HH24')
                                        if 'SSSSSS' in format_type:
                                            format_type = format_type.replace('SSSSSS', 'FF6') 
                                        if 'SSS' in format_type:
                                            format_type = format_type.replace('SSS', 'FF3') 
                                        if 'MMM' in format_type:
                                            format_type = format_type.replace('MMM', 'MON') 
                                        # select_query += f"TO_CHAR({field_name}, 'YYYY-MM-DD HH24:MI:SS.FF6') AS {field_name}, "
                                        select_query += f"TO_CHAR(CAST({field_name} AS TIMESTAMP(6)), '{format_type}') AS {field_name}, "  
                                    else:
                                        select_query += f"{field_name}, "
                                select_query = select_query.rstrip(', ')  # Remove the trailing comma
                                select_query += " FROM " +db_name

                            elif results["Source System Name"] in ["scf", "dgtl_fctrng"]:
                                select_query = "SELECT "
                                for field_name, field_type,format_type , size_value in filtered_data:
                                    if field_type.lower() in ('datetime','timestamp','date'):
                                        if 'SSSSSS' in format_type:
                                            format_type = format_type.replace('SSSSSS', 'ffffff') 
                                        if 'SSS' in format_type:
                                            format_type = format_type.replace('SSS', 'fff') 
                                        select_query += f"FORMAT({field_name}, '{format_type}') AS {field_name}, "
                                    elif field_type.lower() == "numeric":
                                        if isinstance(size_value, str):
                                            # Split only if size_value contains a comma
                                            precision = int(size_value.split(',')[0]) if ',' in size_value else int(size_value)
                                            precision += 2 
                                        else:
                                            # If size_value is already an integer, assign it directly
                                            precision  = size_value
                                            precision += 1
                                        select_query += f"CAST({field_name} AS VARCHAR({precision})) AS {field_name} ,"
                                    else: 
                                        
                                        select_query += f"{field_name}, "
                                select_query = select_query.rstrip(', ')  # Remove the trailing comma
                                select_query += " FROM " +db_name
                        
                        #XXXXXXXXX-----------------------------------------------------------
                        
                            # queryDatafile = "SELECT * FROM " +db_name+ " WHERE pos_dt = '{{pos_dt}}'"
                            queryDatafile = select_query


                            json_config["tasks"]["source_data_extractor_task"] = {
                                "module_name": "OdbcDataExtractorTask",
                                "bypass_flag": bypass_flag, #fixed
                                "parameters": {
                                    "connection_name": results["Source System Name"],
                                    "query": queryDatafile,
                                    "extract_file_location": locationDirectoryPath,
                                    "file_name_format": {
                                        "base_file_name": base_filename,
                                        "date_suffix": date_suffix #fixed
                                    },
                                    "full_file_name": base_filename +"_"+ date_suffix,
                                    "batch_size": 1000000,
                                    "allow_zero_record": True,
                                    "file_extension": file_extension,  #fixed
                                    "write_property": {
                                        "format": "csv",
                                        "header": True,
                                        "option": {
                                            "delimiter": "|",
                                            "quotechar": "\"",
                                            "doublequote": False,
                                            "quoting":"QUOTE_ALL",
                                            "escapechar":"\\"
                                            }
                                        }
                                    }
                                }

                            queryCtl = ""
                            if results["Source System Name"] == "ud":
                                # queryCtl = "SELECT '{{pos_dt}}' AS date_of_data, SYSTIMESTAMP AS date_of_generated_data, COUNT(*) AS number_of_records, '" +fileNameNewFormat + "' AS source_file_name FROM "+db_name+" WHERE dt = '{{pos_dt}}'"
                                queryCtl = "SELECT '{{pos_dt}}' AS date_of_data, TO_CHAR(SYSTIMESTAMP, 'YYYYMMDD') AS date_of_generated_data, COUNT(*) AS number_of_records, '" +fileNameNewFormat + "' AS source_file_name FROM "+db_name 



                            elif results["Source System Name"] in ["scf", "dgtl_fctrng"]:
                                # queryCtl = "SELECT '{{pos_dt}}' AS date_of_data, SYSDATETIME() AS date_of_generated_data, COUNT(*) AS number_of_records, '" + fileNameNewFormat + "' AS source_file_name FROM "+db_name+" WHERE dt = '{{pos_dt}}'"
                                queryCtl = "SELECT '{{pos_dt}}' AS date_of_data, FORMAT(SYSDATETIME(), 'yyyyMMdd') AS date_of_generated_data, COUNT(*) AS number_of_records, '" + fileNameNewFormat + "' AS source_file_name FROM "+db_name
                                        
                            json_config["tasks"]["generate_control_file_task"] = {
                                "module_name": "OdbcControlFileGeneratorTask",
                                "bypass_flag": bypass_flag, #fixed 
                                "parameters": {
                                    "connection_name": results["Source System Name"],
                                    "query": queryCtl,
                                    "extract_file_location": locationDirectoryPath,
                                    "header": True,
                                    "header_columns": header_columns,
                                    "file_name_format": {
                                        "base_file_name": base_filename,
                                        "date_suffix": date_suffix #fixed
                                    },
                                    "full_file_name": base_filename +"_"+ date_suffix,
                                    "file_extension": "ctl",  #fixed
                                    "write_property": {
                                        "format": "csv",
                                        "header": True,
                                        "option": {
                                            "delimiter": "|",
                                            "quotechar": "\"",
                                            "quoting":"QUOTE_ALL",
                                            "escapechar":"\\"
                                            }
                                        }
                                    }
                                }
                            


                        # Print or use the JSON object
                        json_string = json.dumps(json_config, indent=4)

                    
                        output_file = job_name + ".json"
                        output_path = os.path.join(path_out, dir_name, output_file)
                        os.makedirs(os.path.dirname(output_path), exist_ok=True)


                        try:
                            with open(output_path, "w") as json_file:
                                print(output_path)
                                json.dump(json_config, json_file, indent=4, ensure_ascii=False)
                            print(f"\nJSON data has been written to {output_file}\n")
                        except Exception as e:
                            print(f"Failed to write JSON data to {output_file}: {e}")
                            failed.append(filename)
        
    print("Done writing", count, "files to", path_out)
    print("Failed files:", failed)






