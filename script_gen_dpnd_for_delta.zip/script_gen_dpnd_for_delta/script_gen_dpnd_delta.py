from collections import Counter
import json
import os
import openpyxl
import utility




def load_workbook(excel_file, sheet_name):
    try:
        workbook = openpyxl.load_workbook(excel_file,data_only=True)
        if sheet_name in workbook.sheetnames:
            selected_sheet = workbook[sheet_name]
            print(f"Loaded worksheet '{sheet_name}' from Excel file '{excel_file}' successfully.")
            print(f"Number of rows: {selected_sheet.max_row}, Number of columns: {selected_sheet.max_column}")

            utility.replace_stars(selected_sheet)
            return selected_sheet
        else:
            print(f"Worksheet '{sheet_name}' not found in the Excel file.")
            return None
    except Exception as e:
        print(f"Error loading the Excel file: {e}")
        return None   
    

#mook add
def search_keywords(worksheet):

    keywords_right = {
        "Job Name": None,
        "Source File Name/ File Path": None,
        "Target Table Name": None,
        "Data Frequency": None,
        "Skip Holiday Flag" : None,
        

    }
    keywords_below = {
        "Source System Name": None
    }
    keywords_right_list = {
        "Job Name": None,
      

    }



    results_right = utility.search_keywords_right(worksheet,keywords_right)
    results_right_list = utility.search_keywords_right_list(worksheet,keywords_right_list)

    results_below = utility.search_keywords_below(worksheet,keywords_below)
    
    results = {**results_right, **results_below,**results_right_list}
    return results

if __name__ == "__main__":
 


    ##-------- Pull DB
    ##UD have 2 tables not with Pull DB
     



    path_in = "/Users/n.prayoonsoontorn/Downloads/script_gen_dpnd_for_delta/input/"
    path_out = "/Users/n.prayoonsoontorn/Downloads/script_gen_dpnd_for_delta/output/"



    sheet_name = "mdp_request_field"
    
    count = 0
    failed = []
    #---------  for investigation ---------
    parquet_file = []
    uniq_job_name = []
    text_file = []

    base_dir = []
    #--------------------------------------
    for dir_name in os.listdir(path_in):
        if dir_name != ".DS_Store":
            dir_path = os.path.join(path_in, dir_name)
            if os.path.isdir(dir_path):
                for filename in os.listdir(dir_path):
                    if filename != ".DS_Store":
                        count += 1
                        file_path = os.path.join(dir_path, filename)
                        worksheet = load_workbook(file_path, sheet_name)
                        results = search_keywords(worksheet)


                        #---------  Correction Field (format,etc.) ---------
                        job_name =results["Job Name"][0]
                        table_name = results["Target Table Name"]
                        target_database = results["Source System Name"]
                        persist_target_database = "persist_"+target_database
                        fileNameOut = "dpnd_"+job_name
                        freq = results["Data Frequency"]
                        # freq = freq.split(' ')[0].upper()
                        freq = freq[0].upper()
                        print(freq)
                        holdiday_flag = results["Skip Holiday Flag"]
                        print(holdiday_flag)
                        # Daily + Flag Y skipload on weekend = B
                        if freq == "D" and holdiday_flag == "y = skip load on weekend only" :
                            freq = "B"      

                        holdiday_flag = holdiday_flag.split(' ')[0].upper()
                        print(holdiday_flag)          
                     

                    # Define the JSON data for each job
                        json_data = [
                            {
                                "job_name": job_name,
                                "dependency_check_type": "oper_log_table",
                                "dependent_job_type": "ingestion",
                                "dependent_job_name": job_name,
                                "dependent_catalog_name": "mdp{{env}}",
                                "dependent_database_name": persist_target_database,
                                "dependent_table_name": table_name,
                                "dependent_dates": {
                                    "prev_dt": {
                                        "end": "{{pos_dt}}",
                                        "freq":  freq,
                                        "periods": 2,
                                        "inclusive": "left"
                                    },
                                }
                            }
                        ]


                        if holdiday_flag == "Y":
                                json_data[0]["dependent_dates"]["holiday_flag"] = "True"

                        # Print or use the JSON object
                        json_string = json.dumps(json_data, indent=4)

                    
                        output_file = fileNameOut + ".json"
                        output_path = os.path.join(path_out, dir_name, output_file)
                        os.makedirs(os.path.dirname(output_path), exist_ok=True)


                        try:
                            with open(output_path, "w") as json_file:
                                print(output_path)
                                json.dump(json_data, json_file, indent=4, ensure_ascii=False)
                            print(f"\nJSON data has been written to {output_file}\n")
                        except Exception as e:
                            print(f"Failed to write JSON data to {output_file}: {e}")
                            failed.append(filename)
        
    print("Done writing", count, "files to", path_out)
    print("Failed files:", failed)






