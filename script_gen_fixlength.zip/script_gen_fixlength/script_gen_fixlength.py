import json
import os
import pandas as pd
import re






if __name__ == "__main__":
    


    path_in = "/Users/n.prayoonsoontorn/Downloads/script_gen_fixlength/input"
    path_out = "/Users/n.prayoonsoontorn/Downloads/script_gen_fixlength/output"

    sheet_name = "mdp_request_field"
   
    count = 0
    failed = []
    #---------  for investigation ---------
    parquet_file = []
    uniq_job_name = []
    text_file = []
    

    base_dir = []
    #--------------------------------------
    for root, dirs, files in os.walk(path_in):
        for dir_name in dirs:
            # Ignore system files like .DS_Store
            if dir_name != ".DS_Store":
                dir_path_in = os.path.join(root, dir_name)
                # Create corresponding output directory
                dir_path_out = os.path.join(path_out, os.path.relpath(dir_path_in, path_in))
                os.makedirs(dir_path_out, exist_ok=True)
                for filename in os.listdir(dir_path_in):
                    if filename != ".DS_Store":
                        count += 1
                        file_path_in = os.path.join(os.path.join(dir_path_in, filename))
                        if os.path.isfile(file_path_in):
                            ##annouce 
                            if filename.endswith('.xlsx') or filename.endswith('.xls'):
                                try:     
                                    is_encrypted = False    
                                    encryped_list = []
                                    df = pd.read_excel(file_path_in, sheet_name=None, header=None)
                                    for sheet_name, data in df.items():            
                                        if 'mdp_request_field' in sheet_name.lower() and not any(keyword in sheet_name.lower() for keyword in ['Revision History', 'LOV', 'old request', 'Standard Naming']):
                                            if not data.isin(["F = Fixed length"]).any().any():  # Check if any cell contains "F = Fixed length"
                                                    print(f"Skipping file '{filename}' because it does not contain 'F = Fixed length' in any cell.")
                                                    continue  # Skip the fil
                                            for index, row in data.iterrows():
                                                for j, value in enumerate(row):
                                                    if value == "cardencryptedpb":
                                                        cardencryptedpb_found = True
                                                        # Check if the value 5 columns to the right exists
                                                        if j + 4 < len(row):
                                                            value_to_append = row[j + 4]
                                                            encryped_list.append(value_to_append)
                                                        else:
                                                            print("Value not found 4 columns to the right")
                                                        if not cardencryptedpb_found:
                                                            print("The word 'cardencryptedpb' was not found in the Excel file.")


                                            body_source_list = []
                                            fields_to_skip = ["pos_dt", "load_tms", "src_sys_id", "ptn_yyyy", "ptn_mm", "ptn_dd"]##delta not have fixlength so don't have update timestamp
                                            json_data = {"header": [],"body": [], "footer": []}
                                            read_cbr_file = pd.ExcelFile(file_path_in).parse("mdp_request_field", skiprows=28, index_col=None, na_values=['NA'])
                                            v_seq = read_cbr_file["V Seq."].to_list()

                                            start_row_initial = 29
                                            column_name_on_source = 23 ##Column on source 
                                            column_name_on_target = 12 ##Column on target


                                            #------- start retrieve body source 
                                            
                                            # offset = 1 #set start everyfile 
                                            start_row_body = start_row_initial+(v_seq.index("Body"))+1
                                            end_row_body = 29+(v_seq.index("Tailor Label"))

                                            
                                            i = start_row_body 
                                            while i < end_row_body:
                                                #skip empty cell
                                                
                                                if not pd.notna(data.iloc[i, column_name_on_source]):
                                                    i += 1
                                                    continue
                                                

                                                col = data.iloc[i, column_name_on_source].lower().strip().replace("\n", "")
                                                
                                                # get data type and data size <if column data type have changed --> change column+2 to change column number>
                                                body_columns_name = data.iloc[i, column_name_on_source].lower().strip().replace("\n", "").replace('\\"', '')
                                            
                                                body_data_size = data.iloc[i, column_name_on_source+3]
                                                size = int(body_data_size)
                                            # Replace special characters in body_columns_name
                                                if '(' in body_columns_name and ')' in body_columns_name:
                                                    body_columns_name = body_columns_name.replace(' ', '')

                                                body_columns_name = body_columns_name.replace(' ', '_').replace('-', '_').replace('.', '_')
                                                body_columns_name = re.sub(r'\([^)]*\)', '', body_columns_name)

                                                body_source_list.append([body_columns_name, body_data_size])

                                                i += 1 

                                            


                                            #-------end retrieve body source     



                                        ##---------------------------------------------                                           
                                            job_name = data.iloc[6,11] #START COUNT AT 0
                                            table_name = data.iloc[10,8]

                                            ##Column on target


                                            start_row_header = start_row_initial+(v_seq.index("Header Label"))+1
                                            end_row_header = 29+(v_seq.index("Body"))


                                            #initial start column
                                            
                                            i = start_row_header 
                                            while i < end_row_header:
                                                #skip empty cell
                                                if not pd.notna(data.iloc[i, column_name_on_source]):
                                                    i += 1
                                                    continue
                                                col = data.iloc[i, column_name_on_source].lower().strip().replace("\n", "")

                                                header_columns_name = data.iloc[i, column_name_on_source].lower().strip().replace("\n", "").replace('\\"', '')
                                                header_type = data.iloc[i, column_name_on_source+2].lower().strip().replace("\n", "").replace('\\"', '')
                                                header_data_size = data.iloc[i, column_name_on_source+3]
                                                header_offset = data.iloc[i, column_name_on_source+4]
                                                
                                            

                                                field_name = header_columns_name
                                                size = int(header_data_size)
                                                offset = int(header_offset)
                                                # type = header_type
                                                type = "string"


                                                # Append the field details to the JSON data
                                                json_data["header"].append({
                                                    "field_name": field_name,
                                                    "size": size,
                                                    "offset": offset,
                                                    "type": type
                                                })
                                            

                                                i += 1



                                            offset = 1 #set start every file 
                                            start_row_body = start_row_initial+(v_seq.index("Body"))+1
                                            end_row_body = 29+(v_seq.index("Tailor Label"))



                                            first_iteration = True
                                            i = start_row_body 
                                            while i < end_row_body:
                                                #skip empty cell
                                                if not pd.notna(data.iloc[i, column_name_on_source]):
                                                    i += 1
                                                    continue
                                                col = data.iloc[i, column_name_on_source].lower().strip().replace("\n", "")


                                                body_columns_name = data.iloc[i, column_name_on_source].lower().strip().replace("\n", "").replace('\\"', '')
                                                
                                                if '(' in body_columns_name and ')' in body_columns_name:
                                                    body_columns_name = body_columns_name.replace(' ', '')

                                                body_columns_name = body_columns_name.replace(' ', '_').replace('-', '_').replace('.', '_')
                                                body_columns_name = re.sub(r'\([^)]*\)', '', body_columns_name)

                                                if body_columns_name is not None:
                                                    body_columns_name = body_columns_name.replace('__', '_')


                                                # body_type = data.iloc[i, column_name_on_source+2].lower().strip().replace("\n", "").replace('\\"', '')
                                                body_data_size = data.iloc[i, column_name_on_source+3]
                                                body_offset = data.iloc[i, column_name_on_source+4]


                                                if first_iteration:
                                                    # Add your condition check here
                                                    if 'rec' in body_columns_name and '(' in body_columns_name and ')' in body_columns_name:
                                                        body_columns_name = body_columns_name.replace(' ', '')
                                                    first_iteration = False
                                                
                                                
                                                if i == end_row_body:
                                                    if 'filler' in body_columns_name and '(' in body_columns_name and ')' in body_columns_name:
                                                        body_columns_name = body_columns_name.replace(' ', '')

                                            

                                                field_name = body_columns_name
                                                size = int(body_data_size)
                                                offset = int(body_offset)
                                        
                                                type = "string"


                                                # Append the field details to the JSON data
                                                json_data["body"].append({
                                                    "field_name": field_name,
                                                    "size": size,
                                                    "offset": offset,
                                                    "type": type
                                                })
                                            

                                                i += 1


                                            
                                            
                            
                                            start_row_tailor = start_row_initial+ (v_seq.index("Tailor Label")) + 1
                                            end_row_tailor = len(data) 

                                            i = start_row_tailor 
                                            while i < end_row_tailor:
                                                #skip empty cell
                                                if not pd.notna(data.iloc[i, column_name_on_source]):
                                                    i += 1
                                                    continue
                                                col = data.iloc[i, column_name_on_source].lower().strip().replace("\n", "")

                                                tailor_columns_name = data.iloc[i, column_name_on_source].lower().strip().replace("\n", "").replace('\\"', '')
                                                tailor_type = data.iloc[i, column_name_on_source+2].lower().strip().replace("\n", "").replace('\\"', '')
                                                tailor_data_size = data.iloc[i, column_name_on_source+3]
                                                tailor_offset = data.iloc[i, column_name_on_source+4]
                                            

                                                field_name = tailor_columns_name
                                                size = int(tailor_data_size)
                                                offset = int(tailor_offset)
                                                # type = tailor_type
                                                type = "string"


                                                # Append the field details to the JSON data
                                                json_data["footer"].append({
                                                    "field_name": field_name,
                                                    "size": size,
                                                    "offset": offset,
                                                    "type": type
                                                })
                                        
                                            
                                                i += 1




                                            sections = ['body', 'header', 'footer']
                                            for section in sections:
                                                for field in json_data[section]:
                                                    if field['field_name'] == 'cardencryptedpb':
                                                        # Check if 'Y' is in the encrypted list
                                                        if 'Y' in encryped_list:
                                                            field['is_encrypted'] = "true"
                                                        else:
                                                            field['is_encrypted'] = "false"
                            
                                                

                                        
                                            for section in ["header", "body", "footer"]:
                                                if not json_data[section]:
                                                    del json_data[section]

                                                    # Print or use the JSON object
                                            json_string = json.dumps(json_data, indent=4)
                                            output_file = "ingest_spec_"+table_name+ "_fixed_length.json"

                                                            # Print or use the JSON object
                                        
                                            output_path = os.path.join(path_out, dir_name, output_file)
                                            os.makedirs(os.path.dirname(output_path), exist_ok=True)


                                            try:
                                                with open(output_path, "w") as json_file:
                                                    print(output_path)
                                                    json.dump(json_data, json_file, indent=4, ensure_ascii=False)
                                                print(f"\nJSON data has been written to {output_file}\n")
                                            except Exception as e:
                                                print(f"Failed to write JSON data to {output_file}: {e}")
                                                failed.append(filename)
            

                                except pd.errors.ParserError:
                                    print(f"Skipping file '{filename}' because it is not an Excel file.") 


       
    
    print("Done writing", count, "files to", path_out)
    print("Failed files:", failed)




