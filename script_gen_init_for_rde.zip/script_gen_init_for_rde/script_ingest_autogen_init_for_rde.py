import os
import pandas as pd
from datetime import datetime

def get_target_from_cbr(cbr_path: str, sheet_nm: str) -> (str, str, str, str):
    target_pd = pd.read_excel(cbr_path, sheet_name=sheet_nm, header=None, dtype=str)
    target_table = target_pd.iloc[10, 8].strip()
    target_view = target_pd.iloc[7, 8].strip()
    schema_table = target_pd.iloc[9, 8].strip()
    schema_view = target_pd.iloc[8, 8].strip()

    return target_table, target_view, schema_table, schema_view

def get_subject_area_from_cbr(cbr_path: str, sheet_nm: str) -> str:
    area_pos = pd.read_excel(cbr_path, sheet_name=sheet_nm, header=None, dtype=str)
    subject_area = area_pos.iloc[3, 1].lower()
    return subject_area

def get_ingest_cbr(cbr_path: str, sheet_nm: str) -> pd.DataFrame:
    select_col = [
        "T Seq.",
        "Column Name",
        "Column Name.1",
        "RBAC Data Element",
    ]

    cbr_pd = pd.read_excel(cbr_path, sheet_name=sheet_nm, skiprows=28, dtype=str)

    for col_name in select_col:
        col_name = col_name.strip()

        if col_name in cbr_pd.columns:
            cbr_pd[col_name] = cbr_pd[col_name].apply(lambda x: x.strip() if isinstance(x, str) else x)
        else:
            print(f"Column '{col_name}' not found in DataFrame.")

    cbr_pd = cbr_pd[cbr_pd["T Seq."].notnull()]

    cbr_pd["index"] = range(1, len(cbr_pd) + 1)
    cbr_indx_pd = cbr_pd[cbr_pd["T Seq."].str.upper().str.startswith("TABLE")].loc[:, ["index"]]
    cnt_cbr_indx = cbr_indx_pd.shape[0]

    if cnt_cbr_indx > 1:
        cbr_indx = cbr_indx_pd.iloc[1, 0] - 1
    else:
        cbr_indx = len(cbr_pd)

    ltst_cbr_pd = cbr_pd.iloc[:cbr_indx]
    ltst_cbr_pd = ltst_cbr_pd[~ltst_cbr_pd["T Seq."].str.upper().str.startswith("TABLE")]
    ltst_cbr_pd = ltst_cbr_pd.loc[:, select_col]

    return ltst_cbr_pd

def save_to_file(content: str, path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)  # Ensure directory exists

    with open(path, "w") as file:
        file.write(content)
    print(f"Generated file: {path}")

def get_c1(exname: str, name: str, area: str) -> str:
    authors = "Nuttapol.P"
    name_length = len(authors)
    additional_spaces = "".ljust(max(name_length + 3 - 18, 0))
    name_adjust = max(name_length + 3, 18)

    now = datetime.now()
    formatted_date = now.strftime('%Y-%m-%d')

    content = f"""-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: {name}
# Area: {area}
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....           Who....           {additional_spaces}Description....
#----------------------------------------------------------------------------------------------------
# {formatted_date}         {authors}        Initial.
#
# Target table(s)/view(s): {exname}
#--------------------------------------------------------------------------------------------------*/
"""
    return content

def get_c2(field_lines: list[str]) -> str:
    column_content = '\n'.join(field_lines)
    content = f"""
{column_content}
"""
    return content

def get_c(contents: list[str]) -> str:
    contents = [x.replace(u'\xa0', u' ').replace(u'\u202f', u' ') for x in contents]
    return "\n".join(contents)

def gen_init_script(cbr_path: str, target_folder: str, sheet_nm: str = "mdp_request_field") -> None:
    area = get_subject_area_from_cbr(cbr_path, sheet_nm)
    target_table, target_view, schema_table, schema_view = get_target_from_cbr(cbr_path, sheet_nm)
    
    file_name_physical = f"set_tag_{target_table}.sql"
    file_name_view = f"set_tag_{target_view}.sql"

    target_path = os.path.join(target_folder, area, file_name_physical)
    target_path_view = os.path.join(target_folder, area, file_name_view)

    cbr_df = get_ingest_cbr(cbr_path, sheet_nm)

    field_lines = []
    view_lines = []
    prefix = "${catalog}."

    line = f"""
-- COMMAND ----------
    
alter table {prefix}{schema_table}.{target_table} set tags ('rbac_table_{area}');
"""
    field_lines.append(line)

    line = f"""
-- COMMAND ----------

alter table {prefix}{schema_view}.{target_view} set tags ('rbac_table_{area}');
"""
    view_lines.append(line)

    cbr_df = cbr_df[~cbr_df['RBAC Data Element'].isna()]

    for _, row in cbr_df.iterrows():
        column_name_view = row["Column Name"]
        column_name_physical = row["Column Name.1"]
        rbac_data_element = row["RBAC Data Element"]

        if pd.notna(column_name_physical):
            line = f"""
-- COMMAND ----------
            
alter table {prefix}{schema_table}.{target_table} alter column {column_name_physical} set tags ('{rbac_data_element}');
"""
            field_lines.append(line)

        if pd.notna(column_name_view):
            line = f"""
-- COMMAND ----------

alter table {prefix}{schema_view}.{target_view} alter column {column_name_view} set tags ('{rbac_data_element}');
"""
            view_lines.append(line)

    target_name_table = f"{prefix}{schema_table}.{target_table}"
    target_name_view = f"{prefix}{schema_view}.{target_view}"

    cell_1_content = get_c1(target_name_table, file_name_physical, area)
    cell_2_content = get_c2(field_lines)
    content_target = get_c([cell_1_content, cell_2_content])
    save_to_file(content_target, target_path)

    cell_1_content = get_c1(target_name_view, file_name_view, area)
    cell_2_content = get_c2(view_lines)
    content_target = get_c([cell_1_content, cell_2_content])
    save_to_file(content_target, target_path_view)

def process_directory(path_in: str, path_out: str, sheet_name: str = "mdp_request_field"):
    count = 0
    failed = []

    for dir_name in os.listdir(path_in):
        if dir_name != ".DS_Store":
            dir_path = os.path.join(path_in, dir_name)
            if os.path.isdir(dir_path):
                for filename in os.listdir(dir_path):
                    if filename != ".DS_Store":
                        try:
                            count += 1
                            file_path = os.path.join(dir_path, filename)
                            gen_init_script(file_path, path_out, sheet_name)
                        except Exception as e:
                            print(f"Failed to process {file_path}: {e}")
                            failed.append(file_path)

    print(f"Processed {count} files.")
    if failed:
        print("Failed files:")
        for f in failed:
            print(f)

if __name__ == "__main__":
    path_in = "/Users/n.prayoonsoontorn/Downloads/script_gen_init_for_rde/input"
    path_out = "/Users/n.prayoonsoontorn/Downloads/script_gen_init_for_rde/output"
    process_directory(path_in, path_out)
