-- Databricks notebook source
/*---------------------------------------------------------------------------------------------------
# Name: view_init_v_lpm_tdr_acct_reschd_prfl.sql
#----------------------------------------------------------------------------------------------------
#
# Change Revision
#----------------------------------------------------------------------------------------------------
# Date....      Who....           Description....
#----------------------------------------------------------------------------------------------------
# 23-08-2024    Saranchai S.      Initial
# 23-08-2024    Saranchai S.      Update script alter
#
#
# Target table(s)/view(s): ${catalog}.persist_lpm_tdr_view.v_lpm_tdr_acct_reschd_prfl
#--------------------------------------------------------------------------------------------------*/

-- COMMAND ----------

CREATE VIEW IF NOT EXISTS ${catalog}.persist_lpm_tdr_view.v_lpm_tdr_acct_reschd_prfl AS
SELECT
pos_dt AS pos_dt,
g_b AS good_bad_cd,
`ภาค` AS area_cd,
`ศูนย์` AS center_cd,
`หน่วย` AS unit_cd,
`สาขา ` AS br_num,
`เลขที่ลูกหนี้` AS lpm_num,
`ชื่อ-สกุล` AS cst_nm,
`วิธีการแก้ไขหนี้` AS reschd_mthd_cd,
`ระยะเวลา เดิม(ปี)` AS nbr_yr_ln_instl,
`ระยะเวลา เดิม(เดือน)` AS nbr_mo_ln_instl,
`ระยะเวลา ผ่อนมาแล้ว(ปี)` AS nbr_yr_paid_ln_instl,
`ระยะเวลา ผ่อนมาแล้ว(เดือน)` AS nbr_mo_paid_ln_instl,
`ระยะเวลา เหลือ(ปี)` AS nbr_yr_rmain_ln_instl,
`ระยะเวลา เหลือ(เดือน)` AS nbr_mo_rmain_ln_instl,
`ระยะเวลาตั๋ว เดิม(วัน)  ` AS nbr_day_bfr_reschd,
`ระยะเวลาตั๋ว ใหม่(วัน) ` AS nbr_day_after_reschd,
`เลขที่บัญชี(เดิม)` AS orig_ar_id,
`ประเภทบัญชี(เดิม)` AS orig_ar_tp_cd,
`รหัสเปลี่ยนเลขที่บัญชี ` AS chng_ar_cd,
`เปลี่ยนหนี้(บัญชีใหม่)` AS new_ar_id,
`ประเภท(บัญชีใหม่)` AS new_ar_tp_cd,
`เงินต้นก่อนแก้ไขหนี้` AS bfr_reschd_bfr_wrtoff_pnp_amt,
`ดอกเบี้ยก่อนแก้ไขหนี้` AS bfr_reschd_bfr_wrtoff_acru_int_amt,
`ยอดหนี้ก่อนแก้ไขหนี้` AS bfr_reschd_bfr_wrtoff_otsnd_bal,
grace_period AS grc_priod_ind,
`วันค้างชำระ ก่อนแก้ไขหนี้` AS bfr_reschd_dlq_day,
manual_aging AS mnul_age_usr_id,
`หมวดสาเหตุที่ขอแก้ไขหนี้` AS main_cause_reschd,
`รายละเอียดสาเหตุที่ขอแก้ไขหนี้` AS dtl_cause_reschd,
`ครั้งที่แก้ไขหนี้` AS reschd_seq,
`เลขที่อนุมัติ` AS reschd_apprv_id,
`วันที่อนุมัติให้แก้ไขหนี้` AS reschd_apprv_dt,
`ผู้มีอำนาจอนุมัติ` AS reschd_apprv_nm,
`วันลงนามบันทึกข้อตกลง/สัญญา` AS reschd_dt,
`วันที่บันทึกในระบบ` AS insrt_dt,
`วันที่อนุมัติในระบบ` AS reschd_sys_apprv_dt,
`ผู้อนุมัติในระบบ` AS reschd_sys_apprv_usr_id,
`ผลการปลด` AS reschd_rslt_desc,
`สาเหตุในการปลด` AS exmpt_desc,
`ปลดด้วยวิธีการแก้ไขหนี้ที่` AS exmpt_mthd_desc,
`ช่วงเวลาที่ใช้ในกการปลด` AS exmpt_priod,
`วันที่ปลดสถานะ` AS reschd_rslt_chng_dt,
`ผู้บันทึกปลดสถานะ` AS reschd_rslt_chng_usr_id,
data_date AS data_mo,
load_tms AS load_tms,
src_sys_id AS src_sys_id,
ptn_yyyy AS ptn_yyyy,
ptn_mm AS ptn_mm,
ptn_dd AS ptn_dd

FROM ${catalog}.persist_lpm_tdr.lpm_tdr_ct1d408a
WHERE ptn_yyyy >= year(current_date()) - 5;


-- COMMAND ----------

ALTER VIEW ${catalog}.persist_lpm_tdr_view.v_lpm_tdr_acct_reschd_prfl AS
SELECT
pos_dt AS pos_dt,
g_b AS good_bad_cd,
`ภาค` AS area_cd,
`ศูนย์` AS center_cd,
`หน่วย` AS unit_cd,
`สาขา ` AS br_num,
`เลขที่ลูกหนี้` AS lpm_num,
`ชื่อ-สกุล` AS cst_nm,
`วิธีการแก้ไขหนี้` AS reschd_mthd_cd,
`ระยะเวลา เดิม(ปี)` AS nbr_yr_ln_instl,
`ระยะเวลา เดิม(เดือน)` AS nbr_mo_ln_instl,
`ระยะเวลา ผ่อนมาแล้ว(ปี)` AS nbr_yr_paid_ln_instl,
`ระยะเวลา ผ่อนมาแล้ว(เดือน)` AS nbr_mo_paid_ln_instl,
`ระยะเวลา เหลือ(ปี)` AS nbr_yr_rmain_ln_instl,
`ระยะเวลา เหลือ(เดือน)` AS nbr_mo_rmain_ln_instl,
`ระยะเวลาตั๋ว เดิม(วัน)  ` AS nbr_day_bfr_reschd,
`ระยะเวลาตั๋ว ใหม่(วัน) ` AS nbr_day_after_reschd,
`เลขที่บัญชี(เดิม)` AS orig_ar_id,
`ประเภทบัญชี(เดิม)` AS orig_ar_tp_cd,
`รหัสเปลี่ยนเลขที่บัญชี ` AS chng_ar_cd,
`เปลี่ยนหนี้(บัญชีใหม่)` AS new_ar_id,
`ประเภท(บัญชีใหม่)` AS new_ar_tp_cd,
`เงินต้นก่อนแก้ไขหนี้` AS bfr_reschd_bfr_wrtoff_pnp_amt,
`ดอกเบี้ยก่อนแก้ไขหนี้` AS bfr_reschd_bfr_wrtoff_acru_int_amt,
`ยอดหนี้ก่อนแก้ไขหนี้` AS bfr_reschd_bfr_wrtoff_otsnd_bal,
grace_period AS grc_priod_ind,
`วันค้างชำระ ก่อนแก้ไขหนี้` AS bfr_reschd_dlq_day,
manual_aging AS mnul_age_usr_id,
`หมวดสาเหตุที่ขอแก้ไขหนี้` AS main_cause_reschd,
`รายละเอียดสาเหตุที่ขอแก้ไขหนี้` AS dtl_cause_reschd,
`ครั้งที่แก้ไขหนี้` AS reschd_seq,
`เลขที่อนุมัติ` AS reschd_apprv_id,
`วันที่อนุมัติให้แก้ไขหนี้` AS reschd_apprv_dt,
`ผู้มีอำนาจอนุมัติ` AS reschd_apprv_nm,
`วันลงนามบันทึกข้อตกลง/สัญญา` AS reschd_dt,
`วันที่บันทึกในระบบ` AS insrt_dt,
`วันที่อนุมัติในระบบ` AS reschd_sys_apprv_dt,
`ผู้อนุมัติในระบบ` AS reschd_sys_apprv_usr_id,
`ผลการปลด` AS reschd_rslt_desc,
`สาเหตุในการปลด` AS exmpt_desc,
`ปลดด้วยวิธีการแก้ไขหนี้ที่` AS exmpt_mthd_desc,
`ช่วงเวลาที่ใช้ในกการปลด` AS exmpt_priod,
`วันที่ปลดสถานะ` AS reschd_rslt_chng_dt,
`ผู้บันทึกปลดสถานะ` AS reschd_rslt_chng_usr_id,
data_date AS data_mo,
load_tms AS load_tms,
src_sys_id AS src_sys_id,
ptn_yyyy AS ptn_yyyy,
ptn_mm AS ptn_mm,
ptn_dd AS ptn_dd

FROM ${catalog}.persist_lpm_tdr.lpm_tdr_ct1d408a
WHERE ptn_yyyy >= year(current_date()) - 5;
