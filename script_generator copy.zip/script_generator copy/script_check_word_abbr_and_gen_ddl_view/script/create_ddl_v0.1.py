import openpyxl
import os
from datetime import datetime
import re
import configparser

config = configparser.ConfigParser()

script_dir = os.path.dirname(__file__)
config_path = os.path.abspath("config_generator_for_foundation.ini")
config.read(config_path)
#Input Information
name = "Saranchai S."
#Variable
foundation_view_input_path = config.get('path', 'foundation_view_input_path')
foundation_view_output_path = config.get('path', 'foundation_view_output_path')
foundation_view_abbr_path = config.get('path', 'foundation_view_abbr_path')

# Resolve paths relative to the script's directory

input_folder = os.path.abspath(os.path.join(script_dir, foundation_view_input_path))
output_folder= os.path.abspath(os.path.join(script_dir, foundation_view_output_path))
abbr_path = os.path.abspath(os.path.join(script_dir, foundation_view_abbr_path))

catalog = "{catalog}"
space_nm = 18-len(name)
init_nm = f"{name}{space_nm*' '}"



def read_excel_to_text(file_path, abbr_list, abbr_compound_list):
    exclude_columns = ["pos_dt", 'load_tms', 'src_sys_id', 'ptn_yyyy', 'ptn_mm', 'ptn_dd', "upd_tms"]
    try:
        wb = openpyxl.load_workbook(file_path)
        
        sheet = wb['mdp_request_field']

        views_cell = sheet['I8']
        views_name = views_cell.value if views_cell else None
        views_name_parts = views_name.split("_")[1:] if views_name else []
        convert_views_name = '_'.join(views_name_parts)

        schema_cell = sheet['I10']
        schema = schema_cell.value if schema_cell else None

        view_name_cell = sheet['I11']
        view_name = view_name_cell.value if view_name_cell else None

        header_cell_i8 = sheet['I8']
        header_i8 = header_cell_i8.value if header_cell_i8 else None

        header_cell_i9 = sheet['I9']
        header_i9 = header_cell_i9.value if header_cell_i9 else None

        text_data = []
        alias_data = []

        start_collecting = False

        for row_m, row_d in zip(sheet.iter_rows(min_row=1, min_col=13, max_col=13),
                                sheet.iter_rows(min_row=1, min_col=4, max_col=4)):  
            cell_value_m = row_m[0].value
            cell_value_d = row_d[0].value

            if cell_value_d:  
                if cell_value_m and "pos_dt" in cell_value_m.lower():
                    start_collecting = True

                # if start_collecting and cell_value_m:
                #     text_words = re.findall(r'\b\w+\b', cell_value_m)  
                #     text_data.extend(text_words)  

                if start_collecting and cell_value_m:
                    if is_english(cell_value_m):
                        text_words = re.findall(r'\b\w+\b', cell_value_m)  
                        text_data.extend(text_words)  
                    else :
                        text_words = f"`{cell_value_m}`"
                        text_data.append(text_words)


                    alias_data.append(cell_value_d.strip()) 
        
        word_not_match, view_name_correct = check_abbr_word(convert_views_name, exclude_columns, abbr_list, abbr_compound_list, alias_data)
        
         
        if len(word_not_match) > 0:
            file_name = os.path.basename(file_path)
            word_not_match_dict = {
                'file': file_name,
                'wordnotmatch': word_not_match,
                'view_name_correct': view_name_correct
            }
            word_not_match_dict_list.append(word_not_match_dict)
            return None ,None , None ,None,None

        sql_data = [f"{text} AS {alias}" for text, alias in zip(text_data, alias_data)]

        return schema, view_name, header_i8, header_i9, sql_data

    except Exception as e:
        print("An error occurred while reading Excel file:", str(e))
        return None, None, None, None, None

    
def export_to_sql(sql_data, schema, view_name, header_i8, header_i9, output_folder):
    try:
        current_date = datetime.now()
        header_text = f"""-- Databricks notebook source
/*{99*'-'}
# Name: view_init_{header_i8}.sql
#{100*'-'}
#
# Change Revision
#{100*'-'}
# {"Date....":11s}   {"Who....":15s}   Description....
#{100*'-'}
# {current_date.strftime("%d-%m-%Y")}{4*' '}{init_nm}Initial
#
#
# Target table(s)/view(s): ${catalog}.{header_i9}.{header_i8}
#{98*'-'}*/

-- COMMAND ----------

CREATE VIEW IF NOT EXISTS ${catalog}.{header_i9}.{header_i8} AS
SELECT"""

        sql_file_name = f"view_init_{header_i8}.sql"
        sql_file_path = os.path.join(output_folder, sql_file_name)
        
        os.makedirs(output_folder, exist_ok=True)  

        #with open(sql_file_path, 'w') as f:
        with open(sql_file_path, 'w', encoding='UTF-8') as f:
            f.write(header_text + '\n')  
            for i, line in enumerate(sql_data):
                if i < len(sql_data) - 1: 
                    f.write('%s,\n' % line)
                else:
                    f.write('%s\n' % line)  

            footer_text = f"""
FROM ${catalog}.{schema}.{view_name}
WHERE ptn_yyyy >= year(current_date()) - 5;
"""
            f.write(footer_text)

        print("Data exported to SQL file:", sql_file_path)

        return True, len(sql_data)

    except Exception as e:
        print("An error occurred while exporting data to SQL:", str(e))
        return False, 0

def process_excel_file(file_path, output_folder, abbr_list, abbr_compound_list):

    schema, view_name, header_i8, header_i9, sql_data = read_excel_to_text(file_path, abbr_list, abbr_compound_list)
    if schema is not None and view_name is not None and sql_data:
        success, record_count = export_to_sql(sql_data, schema, view_name, header_i8, header_i9, output_folder)
        if success:
            print("Export to SQL successful.")
            return record_count, True
        else:
            print("Export to SQL failed.")
            return 0, False
    else:
        print("Failed to read schema, view name, header_i8, header_i9, or SQL data.")
        return 0, False

def get_excel_files_in_folder(folder):
    excel_files = []
    for root, dirs, files in os.walk(folder):
        for file in files:
            if file.endswith('.xlsx'):
                file_path = os.path.join(root, file)
                excel_files.append(file_path)
    return excel_files

def process_excel_files(excel_files, input_folder, output_folder, abbr_path):
    
    
    
    total_record_count = 0
    success_count = 0
    failure_count = 0
    abbr_list, abbr_compound_list = read_list_abbr(abbr_path)
    for excel_file in excel_files:
        print("Processing :", excel_file)
        
        relative_path = os.path.relpath(excel_file, input_folder)
        output_subfolder = os.path.join(output_folder, os.path.dirname(relative_path))
        
        record_count, success = process_excel_file(excel_file, output_subfolder, abbr_list, abbr_compound_list)
        total_record_count += record_count
        if success:
            success_count += 1
        else:
            failure_count += 1
    
    update_sql_files_in_directory(output_folder, init_nm, 'Update script alter')

    generate_mismatch_documentation(word_not_match_dict_list, output_folder)

    print("All files processed successfully.")
    print(f"Total files processed: {len(excel_files)}")
    print(f"Successfully processed files: {success_count}")
    print(f"Failed processed files: {failure_count}")

def generate_mismatch_documentation(word_not_match_dict_list, main_output_folder):
    try:
        doc_file_path = os.path.join(main_output_folder, "MDP_Persist_View_Mismatch_Abbrs.txt")
        #with open(doc_file_path, 'w') as f:
        with open(doc_file_path, 'w', encoding='UTF-8') as f:
            f.write("Mismatch Documentation\n")
            f.write("-----------------------\n\n")
            
            for index, mismatch_dict in enumerate(word_not_match_dict_list, start=1):
                file_name = mismatch_dict['file']
                mismatch_words = mismatch_dict['wordnotmatch']
                view_name_correct = mismatch_dict.get('view_name_correct', False)
                
                f.write(f"{index}. File: {file_name}\n")

                if mismatch_words:
                    f.write("   Mismatched Words:\n")
                    for word in mismatch_words:
                        f.write(f"     - {word}\n")
                f.write("\n")
        
        print("Mismatch documentation exported to:", doc_file_path)

    except Exception as e:
        print("An error occurred while generating mismatch documentation:", str(e))


def export_check_abbr(output_folder, total_record_count):
    try:
        record_count_file_path = os.path.join(output_folder, "check_abbr_cbr_and_filed.txt")
        with open(record_count_file_path, 'w', encoding='UTF-8') as f:
            f.write(f"Total record count: {total_record_count}")
        print("Total record count exported to:", record_count_file_path)
    except Exception as e:
        print("An error occurred while exporting total record count:", str(e))

def export_record_count(main_output_folder, total_record_count):
    try:
        record_count_file_path = os.path.join(main_output_folder, "total_record_count.txt")
        with open(record_count_file_path, 'w', encoding='UTF-8') as f:
            f.write(f"Total record count: {total_record_count}")
        print("Total record count exported to:", record_count_file_path)
    except Exception as e:
        print("An error occurred while exporting total record count:", str(e))

def update_sql_file(file_path, author, description):
    try:
        with open(file_path, 'r', encoding='UTF-8') as file:
            lines = file.readlines()

        current_date = datetime.now().strftime("%d-%m-%Y")
        new_revision = f"# {current_date}    {author}{description}\n"

        if new_revision in lines:
            print(f"Revision already exists in the file {file_path}. Skipping...")
            return

        insert_index = None
        for i, line in enumerate(lines):
            if line.startswith("# Target table(s)/view(s):"):
                insert_index = i - 2
                break

        if insert_index is not None:
            lines.insert(insert_index, new_revision)

        create_start_index = None
        create_end_index = None
        alter_view_section_exists = False

        for i, line in enumerate(lines):
            if "CREATE VIEW IF NOT EXISTS" in line:
                create_start_index = i
                break

        if create_start_index is not None:
            for i in range(create_start_index, len(lines)):
                if "WHERE" in lines[i]:
                    create_end_index = i
                    break

        if create_start_index is None or create_end_index is None:
            raise Exception("Unable to find the CREATE VIEW IF NOT EXISTS section.")

        # Check if ALTER VIEW section already exists
        for i in range(create_end_index + 1, len(lines)):
            if "ALTER VIEW" in lines[i]:
                alter_view_section_exists = True
                break

        if not alter_view_section_exists:
            alter_view_section = [
                "\n\n-- COMMAND ----------\n\n",
                lines[create_start_index].replace("CREATE VIEW IF NOT EXISTS", "ALTER VIEW"),
            ]
            alter_view_section.extend(lines[create_start_index + 1:create_end_index + 1])

            lines.extend(alter_view_section)

        with open(file_path, 'w', encoding='UTF-8') as file:
            file.writelines(lines)

        print(f"File {file_path} updated successfully.")

    except Exception as e:
        print(f"An error occurred while updating the file {file_path}: {str(e)}")


def update_sql_files_in_directory(directory, author, description):
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.sql'):
                file_path = os.path.join(root, file)
                update_sql_file(file_path, author, description)

def read_list_abbr(abbr_path):
    abbr_list = []
    abbr_compound_list = []

    try:
        abbr_wb = openpyxl.load_workbook(abbr_path)
        abbr_bf_one_word_s = abbr_wb['GuideWord1']
        abbr_bf_multiple_word_s = abbr_wb['GuideWord2']
        abbr_bf_system_s = abbr_wb['System']

        abbr_bf_one_word_list,abbr_bf_one_word_compound_list = get_column_values_in_range_with_diff_underscore(abbr_bf_one_word_s, "B", 1, abbr_bf_one_word_s.max_row + 1)
        # abbr_bf_one_word_list = utility.get_column_values_in_range(abbr_bf_one_word_s, "B", 1, abbr_bf_one_word_s.max_row + 1)
        abbr_bf_one_multiple_list,abbr_bf_multiple_word_compound_list = get_column_values_in_range_with_diff_underscore(abbr_bf_multiple_word_s, "B", 1, abbr_bf_multiple_word_s.max_row + 1)
        abbr_bf_system_list,abbr_bf_system_compound_list = get_column_values_in_range_with_diff_underscore(abbr_bf_system_s, "B", 1, abbr_bf_system_s.max_row + 1)

        abbr_list.extend(abbr_bf_one_word_list)
        abbr_list.extend(abbr_bf_one_multiple_list)
        abbr_list.extend(abbr_bf_system_list)

        abbr_compound_list.extend(abbr_bf_one_word_compound_list)
        abbr_compound_list.extend(abbr_bf_multiple_word_compound_list)
        abbr_compound_list.extend(abbr_bf_system_compound_list)


        print("Count Abbr word compound List:", len(abbr_compound_list))
        print("Count Guideline1 word Compound List",len(abbr_bf_one_word_compound_list))
        print("Count GuideLine2 word Compound List",len(abbr_bf_multiple_word_compound_list))
        print("Count system word Compound List",len(abbr_bf_system_compound_list))


        print("Count Abbr List:", len(abbr_list))
        print("Count GuideLine1 single word List:", len(abbr_bf_one_word_list))
        print("Count GuideLine2 single word List:", len(abbr_bf_one_multiple_list))
        print("Count system single word List:", len(abbr_bf_system_list))

    except Exception as e:
        print(f"An error occurred while reading abbreviation list: {str(e)}")

    return abbr_list,abbr_compound_list


# def starts_with_any_prefix(word, prefixes):
#     return any(word.startswith(prefix) for prefix in prefixes)


def get_column_values_in_range(cbr_file, column_letter, start_row_index, end_row_index):
    column_index = openpyxl.utils.column_index_from_string(column_letter) - 1  

    # Get cell values in the specified column for the given range of row indices
    column_values = []
    for row in cbr_file.iter_rows(min_row=start_row_index+1, max_row=end_row_index-1, min_col=column_index+1, max_col=column_index+1, values_only=True):
        for cell_value in row:
            if cell_value is not None:
                column_values.append(str(cell_value).lower())

    return column_values


def get_column_values_in_range_with_diff_underscore(cbr_file, column_letter, start_row_index, end_row_index):
    column_index = openpyxl.utils.column_index_from_string(column_letter) - 1  

    # Get cell values in the specified column for the given range of row indices
    column_values = []
    for row in cbr_file.iter_rows(min_row=start_row_index+1, max_row=end_row_index-1, min_col=column_index+1, max_col=column_index+1, values_only=True):
        for cell_value in row:
            if cell_value is not None:
                column_values.append(str(cell_value).lower().replace(" ",""))

    # Split the values into two lists
    values_without_underscore = [value for value in column_values if '_' not in value]
    values_with_underscore = [value for value in column_values if '_' in value]

    return values_without_underscore, values_with_underscore

def starts_with_any_prefix(word, prefixes):
    lower_word = word.lower()
    lower_prefixes = [prefix.lower() for prefix in prefixes]
    for prefix in lower_prefixes:
        if lower_word.startswith(prefix):
            return prefix
    return None


def is_english(text):

    return bool(re.fullmatch(r'[a-zA-Z0-9_()]*', text))


def remove_prefix(word, prefix):
    return word[len(prefix):] if word.startswith(prefix) else word



def check_abbr_word(view_name,exclude_columns, abbr_list, abbr_compound_list, alias_data):
    collected_words = []
    view_name_correct = False

    # Check view_name
    if view_name:
        view_name = view_name.lower()
        default_view_name = view_name

        # Remove compound abbreviations from view_name
        for value in abbr_compound_list:
            view_name = view_name.replace(value.lower(), '').replace('__', '_').strip('_')

        if view_name:
            view_words = view_name.split('_')
            view_mismatched_words = []

            for word in view_words:
                if not word.isdigit() and word not in abbr_list:
                    view_mismatched_words.append(word)

            if view_mismatched_words:
                mismatch_word = f"view_name -> {default_view_name} --> [{', '.join(view_mismatched_words)}]"
                collected_words.append(mismatch_word)
            else:
                view_name_correct = True


    for alias in alias_data:
        if alias in exclude_columns:
            continue

        alias = alias.lower()
        default_alias = alias

        for value in abbr_compound_list:
            alias = alias.replace(value.lower(), '').replace('__', '_').strip('_')

        if not alias:
            continue

        words = alias.split('_')
        mismatched_words = []

        for word in words:
            if not word.isdigit() and word not in abbr_list:
                mismatched_words.append(word)


        word_prefix_list = ['Pre', 'Pr', 'Re', 'De', 'Un', 'E', 'Dis', 'Im', 'Non']


        if mismatched_words:
            # Check if the remaining word is in abbr_list
            
            # Separate prefixed words from non-prefixed words
            prefixed_mismatched_words = [w for w in mismatched_words if starts_with_any_prefix(w, word_prefix_list)]
            non_prefixed_mismatched_words = [w for w in mismatched_words if not starts_with_any_prefix(w, word_prefix_list)]

            # Process prefixed mismatched words
            final_prefixed_words = []
            for w in prefixed_mismatched_words:
                prefix = starts_with_any_prefix(w, word_prefix_list)
                if prefix:
                    remaining_word =  remove_prefix(w, prefix)
                    if remaining_word not in abbr_list:
                        final_prefixed_words.append(w)
                    else:
                        pass

            if final_prefixed_words:
                mismatch_word = f"{default_alias} --> [{', '.join(final_prefixed_words)}]"
                collected_words.append(mismatch_word)
            elif non_prefixed_mismatched_words :
                # Combine non-prefixed mismatched words with the final prefixed words if needed
                mismatch_word = f"{default_alias} --> [{', '.join(non_prefixed_mismatched_words)}]"
                collected_words.append(mismatch_word)

            



    return collected_words, view_name_correct



if __name__ == "__main__":

    


    total_record_count = 0
    excel_files = get_excel_files_in_folder(input_folder)
    # abbr_list = read_list_abbr(abbr_path)
    word_not_match_dict_list = []

    process_excel_files(excel_files, input_folder, output_folder, abbr_path)

    print("All files processed successfully.")